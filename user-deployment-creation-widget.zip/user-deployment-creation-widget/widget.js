(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
module.exports = { "default": require("core-js/library/fn/json/stringify"), __esModule: true };
},{"core-js/library/fn/json/stringify":17}],2:[function(require,module,exports){
module.exports = { "default": require("core-js/library/fn/object/assign"), __esModule: true };
},{"core-js/library/fn/object/assign":18}],3:[function(require,module,exports){
module.exports = { "default": require("core-js/library/fn/object/create"), __esModule: true };
},{"core-js/library/fn/object/create":19}],4:[function(require,module,exports){
module.exports = { "default": require("core-js/library/fn/object/define-property"), __esModule: true };
},{"core-js/library/fn/object/define-property":20}],5:[function(require,module,exports){
module.exports = { "default": require("core-js/library/fn/object/get-prototype-of"), __esModule: true };
},{"core-js/library/fn/object/get-prototype-of":21}],6:[function(require,module,exports){
module.exports = { "default": require("core-js/library/fn/object/keys"), __esModule: true };
},{"core-js/library/fn/object/keys":22}],7:[function(require,module,exports){
module.exports = { "default": require("core-js/library/fn/object/set-prototype-of"), __esModule: true };
},{"core-js/library/fn/object/set-prototype-of":23}],8:[function(require,module,exports){
module.exports = { "default": require("core-js/library/fn/promise"), __esModule: true };
},{"core-js/library/fn/promise":24}],9:[function(require,module,exports){
module.exports = { "default": require("core-js/library/fn/symbol"), __esModule: true };
},{"core-js/library/fn/symbol":25}],10:[function(require,module,exports){
module.exports = { "default": require("core-js/library/fn/symbol/iterator"), __esModule: true };
},{"core-js/library/fn/symbol/iterator":26}],11:[function(require,module,exports){
"use strict";

exports.__esModule = true;

exports.default = function (instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
};
},{}],12:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var _defineProperty = require("../core-js/object/define-property");

var _defineProperty2 = _interopRequireDefault(_defineProperty);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function () {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      (0, _defineProperty2.default)(target, descriptor.key, descriptor);
    }
  }

  return function (Constructor, protoProps, staticProps) {
    if (protoProps) defineProperties(Constructor.prototype, protoProps);
    if (staticProps) defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
},{"../core-js/object/define-property":4}],13:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var _defineProperty = require("../core-js/object/define-property");

var _defineProperty2 = _interopRequireDefault(_defineProperty);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function (obj, key, value) {
  if (key in obj) {
    (0, _defineProperty2.default)(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
};
},{"../core-js/object/define-property":4}],14:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var _setPrototypeOf = require("../core-js/object/set-prototype-of");

var _setPrototypeOf2 = _interopRequireDefault(_setPrototypeOf);

var _create = require("../core-js/object/create");

var _create2 = _interopRequireDefault(_create);

var _typeof2 = require("../helpers/typeof");

var _typeof3 = _interopRequireDefault(_typeof2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function (subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === "undefined" ? "undefined" : (0, _typeof3.default)(superClass)));
  }

  subClass.prototype = (0, _create2.default)(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      enumerable: false,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf2.default ? (0, _setPrototypeOf2.default)(subClass, superClass) : subClass.__proto__ = superClass;
};
},{"../core-js/object/create":3,"../core-js/object/set-prototype-of":7,"../helpers/typeof":16}],15:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var _typeof2 = require("../helpers/typeof");

var _typeof3 = _interopRequireDefault(_typeof2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function (self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return call && ((typeof call === "undefined" ? "undefined" : (0, _typeof3.default)(call)) === "object" || typeof call === "function") ? call : self;
};
},{"../helpers/typeof":16}],16:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var _iterator = require("../core-js/symbol/iterator");

var _iterator2 = _interopRequireDefault(_iterator);

var _symbol = require("../core-js/symbol");

var _symbol2 = _interopRequireDefault(_symbol);

var _typeof = typeof _symbol2.default === "function" && typeof _iterator2.default === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof _symbol2.default === "function" && obj.constructor === _symbol2.default && obj !== _symbol2.default.prototype ? "symbol" : typeof obj; };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = typeof _symbol2.default === "function" && _typeof(_iterator2.default) === "symbol" ? function (obj) {
  return typeof obj === "undefined" ? "undefined" : _typeof(obj);
} : function (obj) {
  return obj && typeof _symbol2.default === "function" && obj.constructor === _symbol2.default && obj !== _symbol2.default.prototype ? "symbol" : typeof obj === "undefined" ? "undefined" : _typeof(obj);
};
},{"../core-js/symbol":9,"../core-js/symbol/iterator":10}],17:[function(require,module,exports){
var core = require('../../modules/_core');
var $JSON = core.JSON || (core.JSON = { stringify: JSON.stringify });
module.exports = function stringify(it) { // eslint-disable-line no-unused-vars
  return $JSON.stringify.apply($JSON, arguments);
};

},{"../../modules/_core":34}],18:[function(require,module,exports){
require('../../modules/es6.object.assign');
module.exports = require('../../modules/_core').Object.assign;

},{"../../modules/_core":34,"../../modules/es6.object.assign":103}],19:[function(require,module,exports){
require('../../modules/es6.object.create');
var $Object = require('../../modules/_core').Object;
module.exports = function create(P, D) {
  return $Object.create(P, D);
};

},{"../../modules/_core":34,"../../modules/es6.object.create":104}],20:[function(require,module,exports){
require('../../modules/es6.object.define-property');
var $Object = require('../../modules/_core').Object;
module.exports = function defineProperty(it, key, desc) {
  return $Object.defineProperty(it, key, desc);
};

},{"../../modules/_core":34,"../../modules/es6.object.define-property":105}],21:[function(require,module,exports){
require('../../modules/es6.object.get-prototype-of');
module.exports = require('../../modules/_core').Object.getPrototypeOf;

},{"../../modules/_core":34,"../../modules/es6.object.get-prototype-of":106}],22:[function(require,module,exports){
require('../../modules/es6.object.keys');
module.exports = require('../../modules/_core').Object.keys;

},{"../../modules/_core":34,"../../modules/es6.object.keys":107}],23:[function(require,module,exports){
require('../../modules/es6.object.set-prototype-of');
module.exports = require('../../modules/_core').Object.setPrototypeOf;

},{"../../modules/_core":34,"../../modules/es6.object.set-prototype-of":108}],24:[function(require,module,exports){
require('../modules/es6.object.to-string');
require('../modules/es6.string.iterator');
require('../modules/web.dom.iterable');
require('../modules/es6.promise');
require('../modules/es7.promise.finally');
require('../modules/es7.promise.try');
module.exports = require('../modules/_core').Promise;

},{"../modules/_core":34,"../modules/es6.object.to-string":109,"../modules/es6.promise":110,"../modules/es6.string.iterator":111,"../modules/es7.promise.finally":113,"../modules/es7.promise.try":114,"../modules/web.dom.iterable":117}],25:[function(require,module,exports){
require('../../modules/es6.symbol');
require('../../modules/es6.object.to-string');
require('../../modules/es7.symbol.async-iterator');
require('../../modules/es7.symbol.observable');
module.exports = require('../../modules/_core').Symbol;

},{"../../modules/_core":34,"../../modules/es6.object.to-string":109,"../../modules/es6.symbol":112,"../../modules/es7.symbol.async-iterator":115,"../../modules/es7.symbol.observable":116}],26:[function(require,module,exports){
require('../../modules/es6.string.iterator');
require('../../modules/web.dom.iterable');
module.exports = require('../../modules/_wks-ext').f('iterator');

},{"../../modules/_wks-ext":99,"../../modules/es6.string.iterator":111,"../../modules/web.dom.iterable":117}],27:[function(require,module,exports){
module.exports = function (it) {
  if (typeof it != 'function') throw TypeError(it + ' is not a function!');
  return it;
};

},{}],28:[function(require,module,exports){
module.exports = function () { /* empty */ };

},{}],29:[function(require,module,exports){
module.exports = function (it, Constructor, name, forbiddenField) {
  if (!(it instanceof Constructor) || (forbiddenField !== undefined && forbiddenField in it)) {
    throw TypeError(name + ': incorrect invocation!');
  } return it;
};

},{}],30:[function(require,module,exports){
var isObject = require('./_is-object');
module.exports = function (it) {
  if (!isObject(it)) throw TypeError(it + ' is not an object!');
  return it;
};

},{"./_is-object":53}],31:[function(require,module,exports){
// false -> Array#indexOf
// true  -> Array#includes
var toIObject = require('./_to-iobject');
var toLength = require('./_to-length');
var toAbsoluteIndex = require('./_to-absolute-index');
module.exports = function (IS_INCLUDES) {
  return function ($this, el, fromIndex) {
    var O = toIObject($this);
    var length = toLength(O.length);
    var index = toAbsoluteIndex(fromIndex, length);
    var value;
    // Array#includes uses SameValueZero equality algorithm
    // eslint-disable-next-line no-self-compare
    if (IS_INCLUDES && el != el) while (length > index) {
      value = O[index++];
      // eslint-disable-next-line no-self-compare
      if (value != value) return true;
    // Array#indexOf ignores holes, Array#includes - not
    } else for (;length > index; index++) if (IS_INCLUDES || index in O) {
      if (O[index] === el) return IS_INCLUDES || index || 0;
    } return !IS_INCLUDES && -1;
  };
};

},{"./_to-absolute-index":90,"./_to-iobject":92,"./_to-length":93}],32:[function(require,module,exports){
// getting tag from 19.1.3.6 Object.prototype.toString()
var cof = require('./_cof');
var TAG = require('./_wks')('toStringTag');
// ES3 wrong here
var ARG = cof(function () { return arguments; }()) == 'Arguments';

// fallback for IE11 Script Access Denied error
var tryGet = function (it, key) {
  try {
    return it[key];
  } catch (e) { /* empty */ }
};

module.exports = function (it) {
  var O, T, B;
  return it === undefined ? 'Undefined' : it === null ? 'Null'
    // @@toStringTag case
    : typeof (T = tryGet(O = Object(it), TAG)) == 'string' ? T
    // builtinTag case
    : ARG ? cof(O)
    // ES3 arguments fallback
    : (B = cof(O)) == 'Object' && typeof O.callee == 'function' ? 'Arguments' : B;
};

},{"./_cof":33,"./_wks":100}],33:[function(require,module,exports){
var toString = {}.toString;

module.exports = function (it) {
  return toString.call(it).slice(8, -1);
};

},{}],34:[function(require,module,exports){
var core = module.exports = { version: '2.6.3' };
if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef

},{}],35:[function(require,module,exports){
// optional / simple context binding
var aFunction = require('./_a-function');
module.exports = function (fn, that, length) {
  aFunction(fn);
  if (that === undefined) return fn;
  switch (length) {
    case 1: return function (a) {
      return fn.call(that, a);
    };
    case 2: return function (a, b) {
      return fn.call(that, a, b);
    };
    case 3: return function (a, b, c) {
      return fn.call(that, a, b, c);
    };
  }
  return function (/* ...args */) {
    return fn.apply(that, arguments);
  };
};

},{"./_a-function":27}],36:[function(require,module,exports){
// 7.2.1 RequireObjectCoercible(argument)
module.exports = function (it) {
  if (it == undefined) throw TypeError("Can't call method on  " + it);
  return it;
};

},{}],37:[function(require,module,exports){
// Thank's IE8 for his funny defineProperty
module.exports = !require('./_fails')(function () {
  return Object.defineProperty({}, 'a', { get: function () { return 7; } }).a != 7;
});

},{"./_fails":42}],38:[function(require,module,exports){
var isObject = require('./_is-object');
var document = require('./_global').document;
// typeof document.createElement is 'object' in old IE
var is = isObject(document) && isObject(document.createElement);
module.exports = function (it) {
  return is ? document.createElement(it) : {};
};

},{"./_global":44,"./_is-object":53}],39:[function(require,module,exports){
// IE 8- don't enum bug keys
module.exports = (
  'constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf'
).split(',');

},{}],40:[function(require,module,exports){
// all enumerable object keys, includes symbols
var getKeys = require('./_object-keys');
var gOPS = require('./_object-gops');
var pIE = require('./_object-pie');
module.exports = function (it) {
  var result = getKeys(it);
  var getSymbols = gOPS.f;
  if (getSymbols) {
    var symbols = getSymbols(it);
    var isEnum = pIE.f;
    var i = 0;
    var key;
    while (symbols.length > i) if (isEnum.call(it, key = symbols[i++])) result.push(key);
  } return result;
};

},{"./_object-gops":71,"./_object-keys":74,"./_object-pie":75}],41:[function(require,module,exports){
var global = require('./_global');
var core = require('./_core');
var ctx = require('./_ctx');
var hide = require('./_hide');
var has = require('./_has');
var PROTOTYPE = 'prototype';

var $export = function (type, name, source) {
  var IS_FORCED = type & $export.F;
  var IS_GLOBAL = type & $export.G;
  var IS_STATIC = type & $export.S;
  var IS_PROTO = type & $export.P;
  var IS_BIND = type & $export.B;
  var IS_WRAP = type & $export.W;
  var exports = IS_GLOBAL ? core : core[name] || (core[name] = {});
  var expProto = exports[PROTOTYPE];
  var target = IS_GLOBAL ? global : IS_STATIC ? global[name] : (global[name] || {})[PROTOTYPE];
  var key, own, out;
  if (IS_GLOBAL) source = name;
  for (key in source) {
    // contains in native
    own = !IS_FORCED && target && target[key] !== undefined;
    if (own && has(exports, key)) continue;
    // export native or passed
    out = own ? target[key] : source[key];
    // prevent global pollution for namespaces
    exports[key] = IS_GLOBAL && typeof target[key] != 'function' ? source[key]
    // bind timers to global for call from export context
    : IS_BIND && own ? ctx(out, global)
    // wrap global constructors for prevent change them in library
    : IS_WRAP && target[key] == out ? (function (C) {
      var F = function (a, b, c) {
        if (this instanceof C) {
          switch (arguments.length) {
            case 0: return new C();
            case 1: return new C(a);
            case 2: return new C(a, b);
          } return new C(a, b, c);
        } return C.apply(this, arguments);
      };
      F[PROTOTYPE] = C[PROTOTYPE];
      return F;
    // make static versions for prototype methods
    })(out) : IS_PROTO && typeof out == 'function' ? ctx(Function.call, out) : out;
    // export proto methods to core.%CONSTRUCTOR%.methods.%NAME%
    if (IS_PROTO) {
      (exports.virtual || (exports.virtual = {}))[key] = out;
      // export proto methods to core.%CONSTRUCTOR%.prototype.%NAME%
      if (type & $export.R && expProto && !expProto[key]) hide(expProto, key, out);
    }
  }
};
// type bitmap
$export.F = 1;   // forced
$export.G = 2;   // global
$export.S = 4;   // static
$export.P = 8;   // proto
$export.B = 16;  // bind
$export.W = 32;  // wrap
$export.U = 64;  // safe
$export.R = 128; // real proto method for `library`
module.exports = $export;

},{"./_core":34,"./_ctx":35,"./_global":44,"./_has":45,"./_hide":46}],42:[function(require,module,exports){
module.exports = function (exec) {
  try {
    return !!exec();
  } catch (e) {
    return true;
  }
};

},{}],43:[function(require,module,exports){
var ctx = require('./_ctx');
var call = require('./_iter-call');
var isArrayIter = require('./_is-array-iter');
var anObject = require('./_an-object');
var toLength = require('./_to-length');
var getIterFn = require('./core.get-iterator-method');
var BREAK = {};
var RETURN = {};
var exports = module.exports = function (iterable, entries, fn, that, ITERATOR) {
  var iterFn = ITERATOR ? function () { return iterable; } : getIterFn(iterable);
  var f = ctx(fn, that, entries ? 2 : 1);
  var index = 0;
  var length, step, iterator, result;
  if (typeof iterFn != 'function') throw TypeError(iterable + ' is not iterable!');
  // fast case for arrays with default iterator
  if (isArrayIter(iterFn)) for (length = toLength(iterable.length); length > index; index++) {
    result = entries ? f(anObject(step = iterable[index])[0], step[1]) : f(iterable[index]);
    if (result === BREAK || result === RETURN) return result;
  } else for (iterator = iterFn.call(iterable); !(step = iterator.next()).done;) {
    result = call(iterator, f, step.value, entries);
    if (result === BREAK || result === RETURN) return result;
  }
};
exports.BREAK = BREAK;
exports.RETURN = RETURN;

},{"./_an-object":30,"./_ctx":35,"./_is-array-iter":51,"./_iter-call":54,"./_to-length":93,"./core.get-iterator-method":101}],44:[function(require,module,exports){
// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
var global = module.exports = typeof window != 'undefined' && window.Math == Math
  ? window : typeof self != 'undefined' && self.Math == Math ? self
  // eslint-disable-next-line no-new-func
  : Function('return this')();
if (typeof __g == 'number') __g = global; // eslint-disable-line no-undef

},{}],45:[function(require,module,exports){
var hasOwnProperty = {}.hasOwnProperty;
module.exports = function (it, key) {
  return hasOwnProperty.call(it, key);
};

},{}],46:[function(require,module,exports){
var dP = require('./_object-dp');
var createDesc = require('./_property-desc');
module.exports = require('./_descriptors') ? function (object, key, value) {
  return dP.f(object, key, createDesc(1, value));
} : function (object, key, value) {
  object[key] = value;
  return object;
};

},{"./_descriptors":37,"./_object-dp":66,"./_property-desc":79}],47:[function(require,module,exports){
var document = require('./_global').document;
module.exports = document && document.documentElement;

},{"./_global":44}],48:[function(require,module,exports){
module.exports = !require('./_descriptors') && !require('./_fails')(function () {
  return Object.defineProperty(require('./_dom-create')('div'), 'a', { get: function () { return 7; } }).a != 7;
});

},{"./_descriptors":37,"./_dom-create":38,"./_fails":42}],49:[function(require,module,exports){
// fast apply, http://jsperf.lnkit.com/fast-apply/5
module.exports = function (fn, args, that) {
  var un = that === undefined;
  switch (args.length) {
    case 0: return un ? fn()
                      : fn.call(that);
    case 1: return un ? fn(args[0])
                      : fn.call(that, args[0]);
    case 2: return un ? fn(args[0], args[1])
                      : fn.call(that, args[0], args[1]);
    case 3: return un ? fn(args[0], args[1], args[2])
                      : fn.call(that, args[0], args[1], args[2]);
    case 4: return un ? fn(args[0], args[1], args[2], args[3])
                      : fn.call(that, args[0], args[1], args[2], args[3]);
  } return fn.apply(that, args);
};

},{}],50:[function(require,module,exports){
// fallback for non-array-like ES3 and non-enumerable old V8 strings
var cof = require('./_cof');
// eslint-disable-next-line no-prototype-builtins
module.exports = Object('z').propertyIsEnumerable(0) ? Object : function (it) {
  return cof(it) == 'String' ? it.split('') : Object(it);
};

},{"./_cof":33}],51:[function(require,module,exports){
// check on default Array iterator
var Iterators = require('./_iterators');
var ITERATOR = require('./_wks')('iterator');
var ArrayProto = Array.prototype;

module.exports = function (it) {
  return it !== undefined && (Iterators.Array === it || ArrayProto[ITERATOR] === it);
};

},{"./_iterators":59,"./_wks":100}],52:[function(require,module,exports){
// 7.2.2 IsArray(argument)
var cof = require('./_cof');
module.exports = Array.isArray || function isArray(arg) {
  return cof(arg) == 'Array';
};

},{"./_cof":33}],53:[function(require,module,exports){
module.exports = function (it) {
  return typeof it === 'object' ? it !== null : typeof it === 'function';
};

},{}],54:[function(require,module,exports){
// call something on iterator step with safe closing on error
var anObject = require('./_an-object');
module.exports = function (iterator, fn, value, entries) {
  try {
    return entries ? fn(anObject(value)[0], value[1]) : fn(value);
  // 7.4.6 IteratorClose(iterator, completion)
  } catch (e) {
    var ret = iterator['return'];
    if (ret !== undefined) anObject(ret.call(iterator));
    throw e;
  }
};

},{"./_an-object":30}],55:[function(require,module,exports){
'use strict';
var create = require('./_object-create');
var descriptor = require('./_property-desc');
var setToStringTag = require('./_set-to-string-tag');
var IteratorPrototype = {};

// 25.1.2.1.1 %IteratorPrototype%[@@iterator]()
require('./_hide')(IteratorPrototype, require('./_wks')('iterator'), function () { return this; });

module.exports = function (Constructor, NAME, next) {
  Constructor.prototype = create(IteratorPrototype, { next: descriptor(1, next) });
  setToStringTag(Constructor, NAME + ' Iterator');
};

},{"./_hide":46,"./_object-create":65,"./_property-desc":79,"./_set-to-string-tag":84,"./_wks":100}],56:[function(require,module,exports){
'use strict';
var LIBRARY = require('./_library');
var $export = require('./_export');
var redefine = require('./_redefine');
var hide = require('./_hide');
var Iterators = require('./_iterators');
var $iterCreate = require('./_iter-create');
var setToStringTag = require('./_set-to-string-tag');
var getPrototypeOf = require('./_object-gpo');
var ITERATOR = require('./_wks')('iterator');
var BUGGY = !([].keys && 'next' in [].keys()); // Safari has buggy iterators w/o `next`
var FF_ITERATOR = '@@iterator';
var KEYS = 'keys';
var VALUES = 'values';

var returnThis = function () { return this; };

module.exports = function (Base, NAME, Constructor, next, DEFAULT, IS_SET, FORCED) {
  $iterCreate(Constructor, NAME, next);
  var getMethod = function (kind) {
    if (!BUGGY && kind in proto) return proto[kind];
    switch (kind) {
      case KEYS: return function keys() { return new Constructor(this, kind); };
      case VALUES: return function values() { return new Constructor(this, kind); };
    } return function entries() { return new Constructor(this, kind); };
  };
  var TAG = NAME + ' Iterator';
  var DEF_VALUES = DEFAULT == VALUES;
  var VALUES_BUG = false;
  var proto = Base.prototype;
  var $native = proto[ITERATOR] || proto[FF_ITERATOR] || DEFAULT && proto[DEFAULT];
  var $default = $native || getMethod(DEFAULT);
  var $entries = DEFAULT ? !DEF_VALUES ? $default : getMethod('entries') : undefined;
  var $anyNative = NAME == 'Array' ? proto.entries || $native : $native;
  var methods, key, IteratorPrototype;
  // Fix native
  if ($anyNative) {
    IteratorPrototype = getPrototypeOf($anyNative.call(new Base()));
    if (IteratorPrototype !== Object.prototype && IteratorPrototype.next) {
      // Set @@toStringTag to native iterators
      setToStringTag(IteratorPrototype, TAG, true);
      // fix for some old engines
      if (!LIBRARY && typeof IteratorPrototype[ITERATOR] != 'function') hide(IteratorPrototype, ITERATOR, returnThis);
    }
  }
  // fix Array#{values, @@iterator}.name in V8 / FF
  if (DEF_VALUES && $native && $native.name !== VALUES) {
    VALUES_BUG = true;
    $default = function values() { return $native.call(this); };
  }
  // Define iterator
  if ((!LIBRARY || FORCED) && (BUGGY || VALUES_BUG || !proto[ITERATOR])) {
    hide(proto, ITERATOR, $default);
  }
  // Plug for library
  Iterators[NAME] = $default;
  Iterators[TAG] = returnThis;
  if (DEFAULT) {
    methods = {
      values: DEF_VALUES ? $default : getMethod(VALUES),
      keys: IS_SET ? $default : getMethod(KEYS),
      entries: $entries
    };
    if (FORCED) for (key in methods) {
      if (!(key in proto)) redefine(proto, key, methods[key]);
    } else $export($export.P + $export.F * (BUGGY || VALUES_BUG), NAME, methods);
  }
  return methods;
};

},{"./_export":41,"./_hide":46,"./_iter-create":55,"./_iterators":59,"./_library":60,"./_object-gpo":72,"./_redefine":81,"./_set-to-string-tag":84,"./_wks":100}],57:[function(require,module,exports){
var ITERATOR = require('./_wks')('iterator');
var SAFE_CLOSING = false;

try {
  var riter = [7][ITERATOR]();
  riter['return'] = function () { SAFE_CLOSING = true; };
  // eslint-disable-next-line no-throw-literal
  Array.from(riter, function () { throw 2; });
} catch (e) { /* empty */ }

module.exports = function (exec, skipClosing) {
  if (!skipClosing && !SAFE_CLOSING) return false;
  var safe = false;
  try {
    var arr = [7];
    var iter = arr[ITERATOR]();
    iter.next = function () { return { done: safe = true }; };
    arr[ITERATOR] = function () { return iter; };
    exec(arr);
  } catch (e) { /* empty */ }
  return safe;
};

},{"./_wks":100}],58:[function(require,module,exports){
module.exports = function (done, value) {
  return { value: value, done: !!done };
};

},{}],59:[function(require,module,exports){
module.exports = {};

},{}],60:[function(require,module,exports){
module.exports = true;

},{}],61:[function(require,module,exports){
var META = require('./_uid')('meta');
var isObject = require('./_is-object');
var has = require('./_has');
var setDesc = require('./_object-dp').f;
var id = 0;
var isExtensible = Object.isExtensible || function () {
  return true;
};
var FREEZE = !require('./_fails')(function () {
  return isExtensible(Object.preventExtensions({}));
});
var setMeta = function (it) {
  setDesc(it, META, { value: {
    i: 'O' + ++id, // object ID
    w: {}          // weak collections IDs
  } });
};
var fastKey = function (it, create) {
  // return primitive with prefix
  if (!isObject(it)) return typeof it == 'symbol' ? it : (typeof it == 'string' ? 'S' : 'P') + it;
  if (!has(it, META)) {
    // can't set metadata to uncaught frozen object
    if (!isExtensible(it)) return 'F';
    // not necessary to add metadata
    if (!create) return 'E';
    // add missing metadata
    setMeta(it);
  // return object ID
  } return it[META].i;
};
var getWeak = function (it, create) {
  if (!has(it, META)) {
    // can't set metadata to uncaught frozen object
    if (!isExtensible(it)) return true;
    // not necessary to add metadata
    if (!create) return false;
    // add missing metadata
    setMeta(it);
  // return hash weak collections IDs
  } return it[META].w;
};
// add metadata on freeze-family methods calling
var onFreeze = function (it) {
  if (FREEZE && meta.NEED && isExtensible(it) && !has(it, META)) setMeta(it);
  return it;
};
var meta = module.exports = {
  KEY: META,
  NEED: false,
  fastKey: fastKey,
  getWeak: getWeak,
  onFreeze: onFreeze
};

},{"./_fails":42,"./_has":45,"./_is-object":53,"./_object-dp":66,"./_uid":96}],62:[function(require,module,exports){
var global = require('./_global');
var macrotask = require('./_task').set;
var Observer = global.MutationObserver || global.WebKitMutationObserver;
var process = global.process;
var Promise = global.Promise;
var isNode = require('./_cof')(process) == 'process';

module.exports = function () {
  var head, last, notify;

  var flush = function () {
    var parent, fn;
    if (isNode && (parent = process.domain)) parent.exit();
    while (head) {
      fn = head.fn;
      head = head.next;
      try {
        fn();
      } catch (e) {
        if (head) notify();
        else last = undefined;
        throw e;
      }
    } last = undefined;
    if (parent) parent.enter();
  };

  // Node.js
  if (isNode) {
    notify = function () {
      process.nextTick(flush);
    };
  // browsers with MutationObserver, except iOS Safari - https://github.com/zloirock/core-js/issues/339
  } else if (Observer && !(global.navigator && global.navigator.standalone)) {
    var toggle = true;
    var node = document.createTextNode('');
    new Observer(flush).observe(node, { characterData: true }); // eslint-disable-line no-new
    notify = function () {
      node.data = toggle = !toggle;
    };
  // environments with maybe non-completely correct, but existent Promise
  } else if (Promise && Promise.resolve) {
    // Promise.resolve without an argument throws an error in LG WebOS 2
    var promise = Promise.resolve(undefined);
    notify = function () {
      promise.then(flush);
    };
  // for other environments - macrotask based on:
  // - setImmediate
  // - MessageChannel
  // - window.postMessag
  // - onreadystatechange
  // - setTimeout
  } else {
    notify = function () {
      // strange IE + webpack dev server bug - use .call(global)
      macrotask.call(global, flush);
    };
  }

  return function (fn) {
    var task = { fn: fn, next: undefined };
    if (last) last.next = task;
    if (!head) {
      head = task;
      notify();
    } last = task;
  };
};

},{"./_cof":33,"./_global":44,"./_task":89}],63:[function(require,module,exports){
'use strict';
// 25.4.1.5 NewPromiseCapability(C)
var aFunction = require('./_a-function');

function PromiseCapability(C) {
  var resolve, reject;
  this.promise = new C(function ($$resolve, $$reject) {
    if (resolve !== undefined || reject !== undefined) throw TypeError('Bad Promise constructor');
    resolve = $$resolve;
    reject = $$reject;
  });
  this.resolve = aFunction(resolve);
  this.reject = aFunction(reject);
}

module.exports.f = function (C) {
  return new PromiseCapability(C);
};

},{"./_a-function":27}],64:[function(require,module,exports){
'use strict';
// 19.1.2.1 Object.assign(target, source, ...)
var getKeys = require('./_object-keys');
var gOPS = require('./_object-gops');
var pIE = require('./_object-pie');
var toObject = require('./_to-object');
var IObject = require('./_iobject');
var $assign = Object.assign;

// should work with symbols and should have deterministic property order (V8 bug)
module.exports = !$assign || require('./_fails')(function () {
  var A = {};
  var B = {};
  // eslint-disable-next-line no-undef
  var S = Symbol();
  var K = 'abcdefghijklmnopqrst';
  A[S] = 7;
  K.split('').forEach(function (k) { B[k] = k; });
  return $assign({}, A)[S] != 7 || Object.keys($assign({}, B)).join('') != K;
}) ? function assign(target, source) { // eslint-disable-line no-unused-vars
  var T = toObject(target);
  var aLen = arguments.length;
  var index = 1;
  var getSymbols = gOPS.f;
  var isEnum = pIE.f;
  while (aLen > index) {
    var S = IObject(arguments[index++]);
    var keys = getSymbols ? getKeys(S).concat(getSymbols(S)) : getKeys(S);
    var length = keys.length;
    var j = 0;
    var key;
    while (length > j) if (isEnum.call(S, key = keys[j++])) T[key] = S[key];
  } return T;
} : $assign;

},{"./_fails":42,"./_iobject":50,"./_object-gops":71,"./_object-keys":74,"./_object-pie":75,"./_to-object":94}],65:[function(require,module,exports){
// 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
var anObject = require('./_an-object');
var dPs = require('./_object-dps');
var enumBugKeys = require('./_enum-bug-keys');
var IE_PROTO = require('./_shared-key')('IE_PROTO');
var Empty = function () { /* empty */ };
var PROTOTYPE = 'prototype';

// Create object with fake `null` prototype: use iframe Object with cleared prototype
var createDict = function () {
  // Thrash, waste and sodomy: IE GC bug
  var iframe = require('./_dom-create')('iframe');
  var i = enumBugKeys.length;
  var lt = '<';
  var gt = '>';
  var iframeDocument;
  iframe.style.display = 'none';
  require('./_html').appendChild(iframe);
  iframe.src = 'javascript:'; // eslint-disable-line no-script-url
  // createDict = iframe.contentWindow.Object;
  // html.removeChild(iframe);
  iframeDocument = iframe.contentWindow.document;
  iframeDocument.open();
  iframeDocument.write(lt + 'script' + gt + 'document.F=Object' + lt + '/script' + gt);
  iframeDocument.close();
  createDict = iframeDocument.F;
  while (i--) delete createDict[PROTOTYPE][enumBugKeys[i]];
  return createDict();
};

module.exports = Object.create || function create(O, Properties) {
  var result;
  if (O !== null) {
    Empty[PROTOTYPE] = anObject(O);
    result = new Empty();
    Empty[PROTOTYPE] = null;
    // add "__proto__" for Object.getPrototypeOf polyfill
    result[IE_PROTO] = O;
  } else result = createDict();
  return Properties === undefined ? result : dPs(result, Properties);
};

},{"./_an-object":30,"./_dom-create":38,"./_enum-bug-keys":39,"./_html":47,"./_object-dps":67,"./_shared-key":85}],66:[function(require,module,exports){
var anObject = require('./_an-object');
var IE8_DOM_DEFINE = require('./_ie8-dom-define');
var toPrimitive = require('./_to-primitive');
var dP = Object.defineProperty;

exports.f = require('./_descriptors') ? Object.defineProperty : function defineProperty(O, P, Attributes) {
  anObject(O);
  P = toPrimitive(P, true);
  anObject(Attributes);
  if (IE8_DOM_DEFINE) try {
    return dP(O, P, Attributes);
  } catch (e) { /* empty */ }
  if ('get' in Attributes || 'set' in Attributes) throw TypeError('Accessors not supported!');
  if ('value' in Attributes) O[P] = Attributes.value;
  return O;
};

},{"./_an-object":30,"./_descriptors":37,"./_ie8-dom-define":48,"./_to-primitive":95}],67:[function(require,module,exports){
var dP = require('./_object-dp');
var anObject = require('./_an-object');
var getKeys = require('./_object-keys');

module.exports = require('./_descriptors') ? Object.defineProperties : function defineProperties(O, Properties) {
  anObject(O);
  var keys = getKeys(Properties);
  var length = keys.length;
  var i = 0;
  var P;
  while (length > i) dP.f(O, P = keys[i++], Properties[P]);
  return O;
};

},{"./_an-object":30,"./_descriptors":37,"./_object-dp":66,"./_object-keys":74}],68:[function(require,module,exports){
var pIE = require('./_object-pie');
var createDesc = require('./_property-desc');
var toIObject = require('./_to-iobject');
var toPrimitive = require('./_to-primitive');
var has = require('./_has');
var IE8_DOM_DEFINE = require('./_ie8-dom-define');
var gOPD = Object.getOwnPropertyDescriptor;

exports.f = require('./_descriptors') ? gOPD : function getOwnPropertyDescriptor(O, P) {
  O = toIObject(O);
  P = toPrimitive(P, true);
  if (IE8_DOM_DEFINE) try {
    return gOPD(O, P);
  } catch (e) { /* empty */ }
  if (has(O, P)) return createDesc(!pIE.f.call(O, P), O[P]);
};

},{"./_descriptors":37,"./_has":45,"./_ie8-dom-define":48,"./_object-pie":75,"./_property-desc":79,"./_to-iobject":92,"./_to-primitive":95}],69:[function(require,module,exports){
// fallback for IE11 buggy Object.getOwnPropertyNames with iframe and window
var toIObject = require('./_to-iobject');
var gOPN = require('./_object-gopn').f;
var toString = {}.toString;

var windowNames = typeof window == 'object' && window && Object.getOwnPropertyNames
  ? Object.getOwnPropertyNames(window) : [];

var getWindowNames = function (it) {
  try {
    return gOPN(it);
  } catch (e) {
    return windowNames.slice();
  }
};

module.exports.f = function getOwnPropertyNames(it) {
  return windowNames && toString.call(it) == '[object Window]' ? getWindowNames(it) : gOPN(toIObject(it));
};

},{"./_object-gopn":70,"./_to-iobject":92}],70:[function(require,module,exports){
// 19.1.2.7 / 15.2.3.4 Object.getOwnPropertyNames(O)
var $keys = require('./_object-keys-internal');
var hiddenKeys = require('./_enum-bug-keys').concat('length', 'prototype');

exports.f = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
  return $keys(O, hiddenKeys);
};

},{"./_enum-bug-keys":39,"./_object-keys-internal":73}],71:[function(require,module,exports){
exports.f = Object.getOwnPropertySymbols;

},{}],72:[function(require,module,exports){
// 19.1.2.9 / 15.2.3.2 Object.getPrototypeOf(O)
var has = require('./_has');
var toObject = require('./_to-object');
var IE_PROTO = require('./_shared-key')('IE_PROTO');
var ObjectProto = Object.prototype;

module.exports = Object.getPrototypeOf || function (O) {
  O = toObject(O);
  if (has(O, IE_PROTO)) return O[IE_PROTO];
  if (typeof O.constructor == 'function' && O instanceof O.constructor) {
    return O.constructor.prototype;
  } return O instanceof Object ? ObjectProto : null;
};

},{"./_has":45,"./_shared-key":85,"./_to-object":94}],73:[function(require,module,exports){
var has = require('./_has');
var toIObject = require('./_to-iobject');
var arrayIndexOf = require('./_array-includes')(false);
var IE_PROTO = require('./_shared-key')('IE_PROTO');

module.exports = function (object, names) {
  var O = toIObject(object);
  var i = 0;
  var result = [];
  var key;
  for (key in O) if (key != IE_PROTO) has(O, key) && result.push(key);
  // Don't enum bug & hidden keys
  while (names.length > i) if (has(O, key = names[i++])) {
    ~arrayIndexOf(result, key) || result.push(key);
  }
  return result;
};

},{"./_array-includes":31,"./_has":45,"./_shared-key":85,"./_to-iobject":92}],74:[function(require,module,exports){
// 19.1.2.14 / 15.2.3.14 Object.keys(O)
var $keys = require('./_object-keys-internal');
var enumBugKeys = require('./_enum-bug-keys');

module.exports = Object.keys || function keys(O) {
  return $keys(O, enumBugKeys);
};

},{"./_enum-bug-keys":39,"./_object-keys-internal":73}],75:[function(require,module,exports){
exports.f = {}.propertyIsEnumerable;

},{}],76:[function(require,module,exports){
// most Object methods by ES6 should accept primitives
var $export = require('./_export');
var core = require('./_core');
var fails = require('./_fails');
module.exports = function (KEY, exec) {
  var fn = (core.Object || {})[KEY] || Object[KEY];
  var exp = {};
  exp[KEY] = exec(fn);
  $export($export.S + $export.F * fails(function () { fn(1); }), 'Object', exp);
};

},{"./_core":34,"./_export":41,"./_fails":42}],77:[function(require,module,exports){
module.exports = function (exec) {
  try {
    return { e: false, v: exec() };
  } catch (e) {
    return { e: true, v: e };
  }
};

},{}],78:[function(require,module,exports){
var anObject = require('./_an-object');
var isObject = require('./_is-object');
var newPromiseCapability = require('./_new-promise-capability');

module.exports = function (C, x) {
  anObject(C);
  if (isObject(x) && x.constructor === C) return x;
  var promiseCapability = newPromiseCapability.f(C);
  var resolve = promiseCapability.resolve;
  resolve(x);
  return promiseCapability.promise;
};

},{"./_an-object":30,"./_is-object":53,"./_new-promise-capability":63}],79:[function(require,module,exports){
module.exports = function (bitmap, value) {
  return {
    enumerable: !(bitmap & 1),
    configurable: !(bitmap & 2),
    writable: !(bitmap & 4),
    value: value
  };
};

},{}],80:[function(require,module,exports){
var hide = require('./_hide');
module.exports = function (target, src, safe) {
  for (var key in src) {
    if (safe && target[key]) target[key] = src[key];
    else hide(target, key, src[key]);
  } return target;
};

},{"./_hide":46}],81:[function(require,module,exports){
module.exports = require('./_hide');

},{"./_hide":46}],82:[function(require,module,exports){
// Works with __proto__ only. Old v8 can't work with null proto objects.
/* eslint-disable no-proto */
var isObject = require('./_is-object');
var anObject = require('./_an-object');
var check = function (O, proto) {
  anObject(O);
  if (!isObject(proto) && proto !== null) throw TypeError(proto + ": can't set as prototype!");
};
module.exports = {
  set: Object.setPrototypeOf || ('__proto__' in {} ? // eslint-disable-line
    function (test, buggy, set) {
      try {
        set = require('./_ctx')(Function.call, require('./_object-gopd').f(Object.prototype, '__proto__').set, 2);
        set(test, []);
        buggy = !(test instanceof Array);
      } catch (e) { buggy = true; }
      return function setPrototypeOf(O, proto) {
        check(O, proto);
        if (buggy) O.__proto__ = proto;
        else set(O, proto);
        return O;
      };
    }({}, false) : undefined),
  check: check
};

},{"./_an-object":30,"./_ctx":35,"./_is-object":53,"./_object-gopd":68}],83:[function(require,module,exports){
'use strict';
var global = require('./_global');
var core = require('./_core');
var dP = require('./_object-dp');
var DESCRIPTORS = require('./_descriptors');
var SPECIES = require('./_wks')('species');

module.exports = function (KEY) {
  var C = typeof core[KEY] == 'function' ? core[KEY] : global[KEY];
  if (DESCRIPTORS && C && !C[SPECIES]) dP.f(C, SPECIES, {
    configurable: true,
    get: function () { return this; }
  });
};

},{"./_core":34,"./_descriptors":37,"./_global":44,"./_object-dp":66,"./_wks":100}],84:[function(require,module,exports){
var def = require('./_object-dp').f;
var has = require('./_has');
var TAG = require('./_wks')('toStringTag');

module.exports = function (it, tag, stat) {
  if (it && !has(it = stat ? it : it.prototype, TAG)) def(it, TAG, { configurable: true, value: tag });
};

},{"./_has":45,"./_object-dp":66,"./_wks":100}],85:[function(require,module,exports){
var shared = require('./_shared')('keys');
var uid = require('./_uid');
module.exports = function (key) {
  return shared[key] || (shared[key] = uid(key));
};

},{"./_shared":86,"./_uid":96}],86:[function(require,module,exports){
var core = require('./_core');
var global = require('./_global');
var SHARED = '__core-js_shared__';
var store = global[SHARED] || (global[SHARED] = {});

(module.exports = function (key, value) {
  return store[key] || (store[key] = value !== undefined ? value : {});
})('versions', []).push({
  version: core.version,
  mode: require('./_library') ? 'pure' : 'global',
  copyright: '© 2019 Denis Pushkarev (zloirock.ru)'
});

},{"./_core":34,"./_global":44,"./_library":60}],87:[function(require,module,exports){
// 7.3.20 SpeciesConstructor(O, defaultConstructor)
var anObject = require('./_an-object');
var aFunction = require('./_a-function');
var SPECIES = require('./_wks')('species');
module.exports = function (O, D) {
  var C = anObject(O).constructor;
  var S;
  return C === undefined || (S = anObject(C)[SPECIES]) == undefined ? D : aFunction(S);
};

},{"./_a-function":27,"./_an-object":30,"./_wks":100}],88:[function(require,module,exports){
var toInteger = require('./_to-integer');
var defined = require('./_defined');
// true  -> String#at
// false -> String#codePointAt
module.exports = function (TO_STRING) {
  return function (that, pos) {
    var s = String(defined(that));
    var i = toInteger(pos);
    var l = s.length;
    var a, b;
    if (i < 0 || i >= l) return TO_STRING ? '' : undefined;
    a = s.charCodeAt(i);
    return a < 0xd800 || a > 0xdbff || i + 1 === l || (b = s.charCodeAt(i + 1)) < 0xdc00 || b > 0xdfff
      ? TO_STRING ? s.charAt(i) : a
      : TO_STRING ? s.slice(i, i + 2) : (a - 0xd800 << 10) + (b - 0xdc00) + 0x10000;
  };
};

},{"./_defined":36,"./_to-integer":91}],89:[function(require,module,exports){
var ctx = require('./_ctx');
var invoke = require('./_invoke');
var html = require('./_html');
var cel = require('./_dom-create');
var global = require('./_global');
var process = global.process;
var setTask = global.setImmediate;
var clearTask = global.clearImmediate;
var MessageChannel = global.MessageChannel;
var Dispatch = global.Dispatch;
var counter = 0;
var queue = {};
var ONREADYSTATECHANGE = 'onreadystatechange';
var defer, channel, port;
var run = function () {
  var id = +this;
  // eslint-disable-next-line no-prototype-builtins
  if (queue.hasOwnProperty(id)) {
    var fn = queue[id];
    delete queue[id];
    fn();
  }
};
var listener = function (event) {
  run.call(event.data);
};
// Node.js 0.9+ & IE10+ has setImmediate, otherwise:
if (!setTask || !clearTask) {
  setTask = function setImmediate(fn) {
    var args = [];
    var i = 1;
    while (arguments.length > i) args.push(arguments[i++]);
    queue[++counter] = function () {
      // eslint-disable-next-line no-new-func
      invoke(typeof fn == 'function' ? fn : Function(fn), args);
    };
    defer(counter);
    return counter;
  };
  clearTask = function clearImmediate(id) {
    delete queue[id];
  };
  // Node.js 0.8-
  if (require('./_cof')(process) == 'process') {
    defer = function (id) {
      process.nextTick(ctx(run, id, 1));
    };
  // Sphere (JS game engine) Dispatch API
  } else if (Dispatch && Dispatch.now) {
    defer = function (id) {
      Dispatch.now(ctx(run, id, 1));
    };
  // Browsers with MessageChannel, includes WebWorkers
  } else if (MessageChannel) {
    channel = new MessageChannel();
    port = channel.port2;
    channel.port1.onmessage = listener;
    defer = ctx(port.postMessage, port, 1);
  // Browsers with postMessage, skip WebWorkers
  // IE8 has postMessage, but it's sync & typeof its postMessage is 'object'
  } else if (global.addEventListener && typeof postMessage == 'function' && !global.importScripts) {
    defer = function (id) {
      global.postMessage(id + '', '*');
    };
    global.addEventListener('message', listener, false);
  // IE8-
  } else if (ONREADYSTATECHANGE in cel('script')) {
    defer = function (id) {
      html.appendChild(cel('script'))[ONREADYSTATECHANGE] = function () {
        html.removeChild(this);
        run.call(id);
      };
    };
  // Rest old browsers
  } else {
    defer = function (id) {
      setTimeout(ctx(run, id, 1), 0);
    };
  }
}
module.exports = {
  set: setTask,
  clear: clearTask
};

},{"./_cof":33,"./_ctx":35,"./_dom-create":38,"./_global":44,"./_html":47,"./_invoke":49}],90:[function(require,module,exports){
var toInteger = require('./_to-integer');
var max = Math.max;
var min = Math.min;
module.exports = function (index, length) {
  index = toInteger(index);
  return index < 0 ? max(index + length, 0) : min(index, length);
};

},{"./_to-integer":91}],91:[function(require,module,exports){
// 7.1.4 ToInteger
var ceil = Math.ceil;
var floor = Math.floor;
module.exports = function (it) {
  return isNaN(it = +it) ? 0 : (it > 0 ? floor : ceil)(it);
};

},{}],92:[function(require,module,exports){
// to indexed object, toObject with fallback for non-array-like ES3 strings
var IObject = require('./_iobject');
var defined = require('./_defined');
module.exports = function (it) {
  return IObject(defined(it));
};

},{"./_defined":36,"./_iobject":50}],93:[function(require,module,exports){
// 7.1.15 ToLength
var toInteger = require('./_to-integer');
var min = Math.min;
module.exports = function (it) {
  return it > 0 ? min(toInteger(it), 0x1fffffffffffff) : 0; // pow(2, 53) - 1 == 9007199254740991
};

},{"./_to-integer":91}],94:[function(require,module,exports){
// 7.1.13 ToObject(argument)
var defined = require('./_defined');
module.exports = function (it) {
  return Object(defined(it));
};

},{"./_defined":36}],95:[function(require,module,exports){
// 7.1.1 ToPrimitive(input [, PreferredType])
var isObject = require('./_is-object');
// instead of the ES6 spec version, we didn't implement @@toPrimitive case
// and the second argument - flag - preferred type is a string
module.exports = function (it, S) {
  if (!isObject(it)) return it;
  var fn, val;
  if (S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
  if (typeof (fn = it.valueOf) == 'function' && !isObject(val = fn.call(it))) return val;
  if (!S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
  throw TypeError("Can't convert object to primitive value");
};

},{"./_is-object":53}],96:[function(require,module,exports){
var id = 0;
var px = Math.random();
module.exports = function (key) {
  return 'Symbol('.concat(key === undefined ? '' : key, ')_', (++id + px).toString(36));
};

},{}],97:[function(require,module,exports){
var global = require('./_global');
var navigator = global.navigator;

module.exports = navigator && navigator.userAgent || '';

},{"./_global":44}],98:[function(require,module,exports){
var global = require('./_global');
var core = require('./_core');
var LIBRARY = require('./_library');
var wksExt = require('./_wks-ext');
var defineProperty = require('./_object-dp').f;
module.exports = function (name) {
  var $Symbol = core.Symbol || (core.Symbol = LIBRARY ? {} : global.Symbol || {});
  if (name.charAt(0) != '_' && !(name in $Symbol)) defineProperty($Symbol, name, { value: wksExt.f(name) });
};

},{"./_core":34,"./_global":44,"./_library":60,"./_object-dp":66,"./_wks-ext":99}],99:[function(require,module,exports){
exports.f = require('./_wks');

},{"./_wks":100}],100:[function(require,module,exports){
var store = require('./_shared')('wks');
var uid = require('./_uid');
var Symbol = require('./_global').Symbol;
var USE_SYMBOL = typeof Symbol == 'function';

var $exports = module.exports = function (name) {
  return store[name] || (store[name] =
    USE_SYMBOL && Symbol[name] || (USE_SYMBOL ? Symbol : uid)('Symbol.' + name));
};

$exports.store = store;

},{"./_global":44,"./_shared":86,"./_uid":96}],101:[function(require,module,exports){
var classof = require('./_classof');
var ITERATOR = require('./_wks')('iterator');
var Iterators = require('./_iterators');
module.exports = require('./_core').getIteratorMethod = function (it) {
  if (it != undefined) return it[ITERATOR]
    || it['@@iterator']
    || Iterators[classof(it)];
};

},{"./_classof":32,"./_core":34,"./_iterators":59,"./_wks":100}],102:[function(require,module,exports){
'use strict';
var addToUnscopables = require('./_add-to-unscopables');
var step = require('./_iter-step');
var Iterators = require('./_iterators');
var toIObject = require('./_to-iobject');

// 22.1.3.4 Array.prototype.entries()
// 22.1.3.13 Array.prototype.keys()
// 22.1.3.29 Array.prototype.values()
// 22.1.3.30 Array.prototype[@@iterator]()
module.exports = require('./_iter-define')(Array, 'Array', function (iterated, kind) {
  this._t = toIObject(iterated); // target
  this._i = 0;                   // next index
  this._k = kind;                // kind
// 22.1.5.2.1 %ArrayIteratorPrototype%.next()
}, function () {
  var O = this._t;
  var kind = this._k;
  var index = this._i++;
  if (!O || index >= O.length) {
    this._t = undefined;
    return step(1);
  }
  if (kind == 'keys') return step(0, index);
  if (kind == 'values') return step(0, O[index]);
  return step(0, [index, O[index]]);
}, 'values');

// argumentsList[@@iterator] is %ArrayProto_values% (9.4.4.6, 9.4.4.7)
Iterators.Arguments = Iterators.Array;

addToUnscopables('keys');
addToUnscopables('values');
addToUnscopables('entries');

},{"./_add-to-unscopables":28,"./_iter-define":56,"./_iter-step":58,"./_iterators":59,"./_to-iobject":92}],103:[function(require,module,exports){
// 19.1.3.1 Object.assign(target, source)
var $export = require('./_export');

$export($export.S + $export.F, 'Object', { assign: require('./_object-assign') });

},{"./_export":41,"./_object-assign":64}],104:[function(require,module,exports){
var $export = require('./_export');
// 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
$export($export.S, 'Object', { create: require('./_object-create') });

},{"./_export":41,"./_object-create":65}],105:[function(require,module,exports){
var $export = require('./_export');
// 19.1.2.4 / 15.2.3.6 Object.defineProperty(O, P, Attributes)
$export($export.S + $export.F * !require('./_descriptors'), 'Object', { defineProperty: require('./_object-dp').f });

},{"./_descriptors":37,"./_export":41,"./_object-dp":66}],106:[function(require,module,exports){
// 19.1.2.9 Object.getPrototypeOf(O)
var toObject = require('./_to-object');
var $getPrototypeOf = require('./_object-gpo');

require('./_object-sap')('getPrototypeOf', function () {
  return function getPrototypeOf(it) {
    return $getPrototypeOf(toObject(it));
  };
});

},{"./_object-gpo":72,"./_object-sap":76,"./_to-object":94}],107:[function(require,module,exports){
// 19.1.2.14 Object.keys(O)
var toObject = require('./_to-object');
var $keys = require('./_object-keys');

require('./_object-sap')('keys', function () {
  return function keys(it) {
    return $keys(toObject(it));
  };
});

},{"./_object-keys":74,"./_object-sap":76,"./_to-object":94}],108:[function(require,module,exports){
// 19.1.3.19 Object.setPrototypeOf(O, proto)
var $export = require('./_export');
$export($export.S, 'Object', { setPrototypeOf: require('./_set-proto').set });

},{"./_export":41,"./_set-proto":82}],109:[function(require,module,exports){

},{}],110:[function(require,module,exports){
'use strict';
var LIBRARY = require('./_library');
var global = require('./_global');
var ctx = require('./_ctx');
var classof = require('./_classof');
var $export = require('./_export');
var isObject = require('./_is-object');
var aFunction = require('./_a-function');
var anInstance = require('./_an-instance');
var forOf = require('./_for-of');
var speciesConstructor = require('./_species-constructor');
var task = require('./_task').set;
var microtask = require('./_microtask')();
var newPromiseCapabilityModule = require('./_new-promise-capability');
var perform = require('./_perform');
var userAgent = require('./_user-agent');
var promiseResolve = require('./_promise-resolve');
var PROMISE = 'Promise';
var TypeError = global.TypeError;
var process = global.process;
var versions = process && process.versions;
var v8 = versions && versions.v8 || '';
var $Promise = global[PROMISE];
var isNode = classof(process) == 'process';
var empty = function () { /* empty */ };
var Internal, newGenericPromiseCapability, OwnPromiseCapability, Wrapper;
var newPromiseCapability = newGenericPromiseCapability = newPromiseCapabilityModule.f;

var USE_NATIVE = !!function () {
  try {
    // correct subclassing with @@species support
    var promise = $Promise.resolve(1);
    var FakePromise = (promise.constructor = {})[require('./_wks')('species')] = function (exec) {
      exec(empty, empty);
    };
    // unhandled rejections tracking support, NodeJS Promise without it fails @@species test
    return (isNode || typeof PromiseRejectionEvent == 'function')
      && promise.then(empty) instanceof FakePromise
      // v8 6.6 (Node 10 and Chrome 66) have a bug with resolving custom thenables
      // https://bugs.chromium.org/p/chromium/issues/detail?id=830565
      // we can't detect it synchronously, so just check versions
      && v8.indexOf('6.6') !== 0
      && userAgent.indexOf('Chrome/66') === -1;
  } catch (e) { /* empty */ }
}();

// helpers
var isThenable = function (it) {
  var then;
  return isObject(it) && typeof (then = it.then) == 'function' ? then : false;
};
var notify = function (promise, isReject) {
  if (promise._n) return;
  promise._n = true;
  var chain = promise._c;
  microtask(function () {
    var value = promise._v;
    var ok = promise._s == 1;
    var i = 0;
    var run = function (reaction) {
      var handler = ok ? reaction.ok : reaction.fail;
      var resolve = reaction.resolve;
      var reject = reaction.reject;
      var domain = reaction.domain;
      var result, then, exited;
      try {
        if (handler) {
          if (!ok) {
            if (promise._h == 2) onHandleUnhandled(promise);
            promise._h = 1;
          }
          if (handler === true) result = value;
          else {
            if (domain) domain.enter();
            result = handler(value); // may throw
            if (domain) {
              domain.exit();
              exited = true;
            }
          }
          if (result === reaction.promise) {
            reject(TypeError('Promise-chain cycle'));
          } else if (then = isThenable(result)) {
            then.call(result, resolve, reject);
          } else resolve(result);
        } else reject(value);
      } catch (e) {
        if (domain && !exited) domain.exit();
        reject(e);
      }
    };
    while (chain.length > i) run(chain[i++]); // variable length - can't use forEach
    promise._c = [];
    promise._n = false;
    if (isReject && !promise._h) onUnhandled(promise);
  });
};
var onUnhandled = function (promise) {
  task.call(global, function () {
    var value = promise._v;
    var unhandled = isUnhandled(promise);
    var result, handler, console;
    if (unhandled) {
      result = perform(function () {
        if (isNode) {
          process.emit('unhandledRejection', value, promise);
        } else if (handler = global.onunhandledrejection) {
          handler({ promise: promise, reason: value });
        } else if ((console = global.console) && console.error) {
          console.error('Unhandled promise rejection', value);
        }
      });
      // Browsers should not trigger `rejectionHandled` event if it was handled here, NodeJS - should
      promise._h = isNode || isUnhandled(promise) ? 2 : 1;
    } promise._a = undefined;
    if (unhandled && result.e) throw result.v;
  });
};
var isUnhandled = function (promise) {
  return promise._h !== 1 && (promise._a || promise._c).length === 0;
};
var onHandleUnhandled = function (promise) {
  task.call(global, function () {
    var handler;
    if (isNode) {
      process.emit('rejectionHandled', promise);
    } else if (handler = global.onrejectionhandled) {
      handler({ promise: promise, reason: promise._v });
    }
  });
};
var $reject = function (value) {
  var promise = this;
  if (promise._d) return;
  promise._d = true;
  promise = promise._w || promise; // unwrap
  promise._v = value;
  promise._s = 2;
  if (!promise._a) promise._a = promise._c.slice();
  notify(promise, true);
};
var $resolve = function (value) {
  var promise = this;
  var then;
  if (promise._d) return;
  promise._d = true;
  promise = promise._w || promise; // unwrap
  try {
    if (promise === value) throw TypeError("Promise can't be resolved itself");
    if (then = isThenable(value)) {
      microtask(function () {
        var wrapper = { _w: promise, _d: false }; // wrap
        try {
          then.call(value, ctx($resolve, wrapper, 1), ctx($reject, wrapper, 1));
        } catch (e) {
          $reject.call(wrapper, e);
        }
      });
    } else {
      promise._v = value;
      promise._s = 1;
      notify(promise, false);
    }
  } catch (e) {
    $reject.call({ _w: promise, _d: false }, e); // wrap
  }
};

// constructor polyfill
if (!USE_NATIVE) {
  // 25.4.3.1 Promise(executor)
  $Promise = function Promise(executor) {
    anInstance(this, $Promise, PROMISE, '_h');
    aFunction(executor);
    Internal.call(this);
    try {
      executor(ctx($resolve, this, 1), ctx($reject, this, 1));
    } catch (err) {
      $reject.call(this, err);
    }
  };
  // eslint-disable-next-line no-unused-vars
  Internal = function Promise(executor) {
    this._c = [];             // <- awaiting reactions
    this._a = undefined;      // <- checked in isUnhandled reactions
    this._s = 0;              // <- state
    this._d = false;          // <- done
    this._v = undefined;      // <- value
    this._h = 0;              // <- rejection state, 0 - default, 1 - handled, 2 - unhandled
    this._n = false;          // <- notify
  };
  Internal.prototype = require('./_redefine-all')($Promise.prototype, {
    // 25.4.5.3 Promise.prototype.then(onFulfilled, onRejected)
    then: function then(onFulfilled, onRejected) {
      var reaction = newPromiseCapability(speciesConstructor(this, $Promise));
      reaction.ok = typeof onFulfilled == 'function' ? onFulfilled : true;
      reaction.fail = typeof onRejected == 'function' && onRejected;
      reaction.domain = isNode ? process.domain : undefined;
      this._c.push(reaction);
      if (this._a) this._a.push(reaction);
      if (this._s) notify(this, false);
      return reaction.promise;
    },
    // 25.4.5.1 Promise.prototype.catch(onRejected)
    'catch': function (onRejected) {
      return this.then(undefined, onRejected);
    }
  });
  OwnPromiseCapability = function () {
    var promise = new Internal();
    this.promise = promise;
    this.resolve = ctx($resolve, promise, 1);
    this.reject = ctx($reject, promise, 1);
  };
  newPromiseCapabilityModule.f = newPromiseCapability = function (C) {
    return C === $Promise || C === Wrapper
      ? new OwnPromiseCapability(C)
      : newGenericPromiseCapability(C);
  };
}

$export($export.G + $export.W + $export.F * !USE_NATIVE, { Promise: $Promise });
require('./_set-to-string-tag')($Promise, PROMISE);
require('./_set-species')(PROMISE);
Wrapper = require('./_core')[PROMISE];

// statics
$export($export.S + $export.F * !USE_NATIVE, PROMISE, {
  // 25.4.4.5 Promise.reject(r)
  reject: function reject(r) {
    var capability = newPromiseCapability(this);
    var $$reject = capability.reject;
    $$reject(r);
    return capability.promise;
  }
});
$export($export.S + $export.F * (LIBRARY || !USE_NATIVE), PROMISE, {
  // 25.4.4.6 Promise.resolve(x)
  resolve: function resolve(x) {
    return promiseResolve(LIBRARY && this === Wrapper ? $Promise : this, x);
  }
});
$export($export.S + $export.F * !(USE_NATIVE && require('./_iter-detect')(function (iter) {
  $Promise.all(iter)['catch'](empty);
})), PROMISE, {
  // 25.4.4.1 Promise.all(iterable)
  all: function all(iterable) {
    var C = this;
    var capability = newPromiseCapability(C);
    var resolve = capability.resolve;
    var reject = capability.reject;
    var result = perform(function () {
      var values = [];
      var index = 0;
      var remaining = 1;
      forOf(iterable, false, function (promise) {
        var $index = index++;
        var alreadyCalled = false;
        values.push(undefined);
        remaining++;
        C.resolve(promise).then(function (value) {
          if (alreadyCalled) return;
          alreadyCalled = true;
          values[$index] = value;
          --remaining || resolve(values);
        }, reject);
      });
      --remaining || resolve(values);
    });
    if (result.e) reject(result.v);
    return capability.promise;
  },
  // 25.4.4.4 Promise.race(iterable)
  race: function race(iterable) {
    var C = this;
    var capability = newPromiseCapability(C);
    var reject = capability.reject;
    var result = perform(function () {
      forOf(iterable, false, function (promise) {
        C.resolve(promise).then(capability.resolve, reject);
      });
    });
    if (result.e) reject(result.v);
    return capability.promise;
  }
});

},{"./_a-function":27,"./_an-instance":29,"./_classof":32,"./_core":34,"./_ctx":35,"./_export":41,"./_for-of":43,"./_global":44,"./_is-object":53,"./_iter-detect":57,"./_library":60,"./_microtask":62,"./_new-promise-capability":63,"./_perform":77,"./_promise-resolve":78,"./_redefine-all":80,"./_set-species":83,"./_set-to-string-tag":84,"./_species-constructor":87,"./_task":89,"./_user-agent":97,"./_wks":100}],111:[function(require,module,exports){
'use strict';
var $at = require('./_string-at')(true);

// 21.1.3.27 String.prototype[@@iterator]()
require('./_iter-define')(String, 'String', function (iterated) {
  this._t = String(iterated); // target
  this._i = 0;                // next index
// 21.1.5.2.1 %StringIteratorPrototype%.next()
}, function () {
  var O = this._t;
  var index = this._i;
  var point;
  if (index >= O.length) return { value: undefined, done: true };
  point = $at(O, index);
  this._i += point.length;
  return { value: point, done: false };
});

},{"./_iter-define":56,"./_string-at":88}],112:[function(require,module,exports){
'use strict';
// ECMAScript 6 symbols shim
var global = require('./_global');
var has = require('./_has');
var DESCRIPTORS = require('./_descriptors');
var $export = require('./_export');
var redefine = require('./_redefine');
var META = require('./_meta').KEY;
var $fails = require('./_fails');
var shared = require('./_shared');
var setToStringTag = require('./_set-to-string-tag');
var uid = require('./_uid');
var wks = require('./_wks');
var wksExt = require('./_wks-ext');
var wksDefine = require('./_wks-define');
var enumKeys = require('./_enum-keys');
var isArray = require('./_is-array');
var anObject = require('./_an-object');
var isObject = require('./_is-object');
var toIObject = require('./_to-iobject');
var toPrimitive = require('./_to-primitive');
var createDesc = require('./_property-desc');
var _create = require('./_object-create');
var gOPNExt = require('./_object-gopn-ext');
var $GOPD = require('./_object-gopd');
var $DP = require('./_object-dp');
var $keys = require('./_object-keys');
var gOPD = $GOPD.f;
var dP = $DP.f;
var gOPN = gOPNExt.f;
var $Symbol = global.Symbol;
var $JSON = global.JSON;
var _stringify = $JSON && $JSON.stringify;
var PROTOTYPE = 'prototype';
var HIDDEN = wks('_hidden');
var TO_PRIMITIVE = wks('toPrimitive');
var isEnum = {}.propertyIsEnumerable;
var SymbolRegistry = shared('symbol-registry');
var AllSymbols = shared('symbols');
var OPSymbols = shared('op-symbols');
var ObjectProto = Object[PROTOTYPE];
var USE_NATIVE = typeof $Symbol == 'function';
var QObject = global.QObject;
// Don't use setters in Qt Script, https://github.com/zloirock/core-js/issues/173
var setter = !QObject || !QObject[PROTOTYPE] || !QObject[PROTOTYPE].findChild;

// fallback for old Android, https://code.google.com/p/v8/issues/detail?id=687
var setSymbolDesc = DESCRIPTORS && $fails(function () {
  return _create(dP({}, 'a', {
    get: function () { return dP(this, 'a', { value: 7 }).a; }
  })).a != 7;
}) ? function (it, key, D) {
  var protoDesc = gOPD(ObjectProto, key);
  if (protoDesc) delete ObjectProto[key];
  dP(it, key, D);
  if (protoDesc && it !== ObjectProto) dP(ObjectProto, key, protoDesc);
} : dP;

var wrap = function (tag) {
  var sym = AllSymbols[tag] = _create($Symbol[PROTOTYPE]);
  sym._k = tag;
  return sym;
};

var isSymbol = USE_NATIVE && typeof $Symbol.iterator == 'symbol' ? function (it) {
  return typeof it == 'symbol';
} : function (it) {
  return it instanceof $Symbol;
};

var $defineProperty = function defineProperty(it, key, D) {
  if (it === ObjectProto) $defineProperty(OPSymbols, key, D);
  anObject(it);
  key = toPrimitive(key, true);
  anObject(D);
  if (has(AllSymbols, key)) {
    if (!D.enumerable) {
      if (!has(it, HIDDEN)) dP(it, HIDDEN, createDesc(1, {}));
      it[HIDDEN][key] = true;
    } else {
      if (has(it, HIDDEN) && it[HIDDEN][key]) it[HIDDEN][key] = false;
      D = _create(D, { enumerable: createDesc(0, false) });
    } return setSymbolDesc(it, key, D);
  } return dP(it, key, D);
};
var $defineProperties = function defineProperties(it, P) {
  anObject(it);
  var keys = enumKeys(P = toIObject(P));
  var i = 0;
  var l = keys.length;
  var key;
  while (l > i) $defineProperty(it, key = keys[i++], P[key]);
  return it;
};
var $create = function create(it, P) {
  return P === undefined ? _create(it) : $defineProperties(_create(it), P);
};
var $propertyIsEnumerable = function propertyIsEnumerable(key) {
  var E = isEnum.call(this, key = toPrimitive(key, true));
  if (this === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return false;
  return E || !has(this, key) || !has(AllSymbols, key) || has(this, HIDDEN) && this[HIDDEN][key] ? E : true;
};
var $getOwnPropertyDescriptor = function getOwnPropertyDescriptor(it, key) {
  it = toIObject(it);
  key = toPrimitive(key, true);
  if (it === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return;
  var D = gOPD(it, key);
  if (D && has(AllSymbols, key) && !(has(it, HIDDEN) && it[HIDDEN][key])) D.enumerable = true;
  return D;
};
var $getOwnPropertyNames = function getOwnPropertyNames(it) {
  var names = gOPN(toIObject(it));
  var result = [];
  var i = 0;
  var key;
  while (names.length > i) {
    if (!has(AllSymbols, key = names[i++]) && key != HIDDEN && key != META) result.push(key);
  } return result;
};
var $getOwnPropertySymbols = function getOwnPropertySymbols(it) {
  var IS_OP = it === ObjectProto;
  var names = gOPN(IS_OP ? OPSymbols : toIObject(it));
  var result = [];
  var i = 0;
  var key;
  while (names.length > i) {
    if (has(AllSymbols, key = names[i++]) && (IS_OP ? has(ObjectProto, key) : true)) result.push(AllSymbols[key]);
  } return result;
};

// 19.4.1.1 Symbol([description])
if (!USE_NATIVE) {
  $Symbol = function Symbol() {
    if (this instanceof $Symbol) throw TypeError('Symbol is not a constructor!');
    var tag = uid(arguments.length > 0 ? arguments[0] : undefined);
    var $set = function (value) {
      if (this === ObjectProto) $set.call(OPSymbols, value);
      if (has(this, HIDDEN) && has(this[HIDDEN], tag)) this[HIDDEN][tag] = false;
      setSymbolDesc(this, tag, createDesc(1, value));
    };
    if (DESCRIPTORS && setter) setSymbolDesc(ObjectProto, tag, { configurable: true, set: $set });
    return wrap(tag);
  };
  redefine($Symbol[PROTOTYPE], 'toString', function toString() {
    return this._k;
  });

  $GOPD.f = $getOwnPropertyDescriptor;
  $DP.f = $defineProperty;
  require('./_object-gopn').f = gOPNExt.f = $getOwnPropertyNames;
  require('./_object-pie').f = $propertyIsEnumerable;
  require('./_object-gops').f = $getOwnPropertySymbols;

  if (DESCRIPTORS && !require('./_library')) {
    redefine(ObjectProto, 'propertyIsEnumerable', $propertyIsEnumerable, true);
  }

  wksExt.f = function (name) {
    return wrap(wks(name));
  };
}

$export($export.G + $export.W + $export.F * !USE_NATIVE, { Symbol: $Symbol });

for (var es6Symbols = (
  // 19.4.2.2, 19.4.2.3, 19.4.2.4, 19.4.2.6, 19.4.2.8, 19.4.2.9, 19.4.2.10, 19.4.2.11, 19.4.2.12, 19.4.2.13, 19.4.2.14
  'hasInstance,isConcatSpreadable,iterator,match,replace,search,species,split,toPrimitive,toStringTag,unscopables'
).split(','), j = 0; es6Symbols.length > j;)wks(es6Symbols[j++]);

for (var wellKnownSymbols = $keys(wks.store), k = 0; wellKnownSymbols.length > k;) wksDefine(wellKnownSymbols[k++]);

$export($export.S + $export.F * !USE_NATIVE, 'Symbol', {
  // 19.4.2.1 Symbol.for(key)
  'for': function (key) {
    return has(SymbolRegistry, key += '')
      ? SymbolRegistry[key]
      : SymbolRegistry[key] = $Symbol(key);
  },
  // 19.4.2.5 Symbol.keyFor(sym)
  keyFor: function keyFor(sym) {
    if (!isSymbol(sym)) throw TypeError(sym + ' is not a symbol!');
    for (var key in SymbolRegistry) if (SymbolRegistry[key] === sym) return key;
  },
  useSetter: function () { setter = true; },
  useSimple: function () { setter = false; }
});

$export($export.S + $export.F * !USE_NATIVE, 'Object', {
  // 19.1.2.2 Object.create(O [, Properties])
  create: $create,
  // 19.1.2.4 Object.defineProperty(O, P, Attributes)
  defineProperty: $defineProperty,
  // 19.1.2.3 Object.defineProperties(O, Properties)
  defineProperties: $defineProperties,
  // 19.1.2.6 Object.getOwnPropertyDescriptor(O, P)
  getOwnPropertyDescriptor: $getOwnPropertyDescriptor,
  // 19.1.2.7 Object.getOwnPropertyNames(O)
  getOwnPropertyNames: $getOwnPropertyNames,
  // 19.1.2.8 Object.getOwnPropertySymbols(O)
  getOwnPropertySymbols: $getOwnPropertySymbols
});

// 24.3.2 JSON.stringify(value [, replacer [, space]])
$JSON && $export($export.S + $export.F * (!USE_NATIVE || $fails(function () {
  var S = $Symbol();
  // MS Edge converts symbol values to JSON as {}
  // WebKit converts symbol values to JSON as null
  // V8 throws on boxed symbols
  return _stringify([S]) != '[null]' || _stringify({ a: S }) != '{}' || _stringify(Object(S)) != '{}';
})), 'JSON', {
  stringify: function stringify(it) {
    var args = [it];
    var i = 1;
    var replacer, $replacer;
    while (arguments.length > i) args.push(arguments[i++]);
    $replacer = replacer = args[1];
    if (!isObject(replacer) && it === undefined || isSymbol(it)) return; // IE8 returns string on undefined
    if (!isArray(replacer)) replacer = function (key, value) {
      if (typeof $replacer == 'function') value = $replacer.call(this, key, value);
      if (!isSymbol(value)) return value;
    };
    args[1] = replacer;
    return _stringify.apply($JSON, args);
  }
});

// 19.4.3.4 Symbol.prototype[@@toPrimitive](hint)
$Symbol[PROTOTYPE][TO_PRIMITIVE] || require('./_hide')($Symbol[PROTOTYPE], TO_PRIMITIVE, $Symbol[PROTOTYPE].valueOf);
// 19.4.3.5 Symbol.prototype[@@toStringTag]
setToStringTag($Symbol, 'Symbol');
// 20.2.1.9 Math[@@toStringTag]
setToStringTag(Math, 'Math', true);
// 24.3.3 JSON[@@toStringTag]
setToStringTag(global.JSON, 'JSON', true);

},{"./_an-object":30,"./_descriptors":37,"./_enum-keys":40,"./_export":41,"./_fails":42,"./_global":44,"./_has":45,"./_hide":46,"./_is-array":52,"./_is-object":53,"./_library":60,"./_meta":61,"./_object-create":65,"./_object-dp":66,"./_object-gopd":68,"./_object-gopn":70,"./_object-gopn-ext":69,"./_object-gops":71,"./_object-keys":74,"./_object-pie":75,"./_property-desc":79,"./_redefine":81,"./_set-to-string-tag":84,"./_shared":86,"./_to-iobject":92,"./_to-primitive":95,"./_uid":96,"./_wks":100,"./_wks-define":98,"./_wks-ext":99}],113:[function(require,module,exports){
// https://github.com/tc39/proposal-promise-finally
'use strict';
var $export = require('./_export');
var core = require('./_core');
var global = require('./_global');
var speciesConstructor = require('./_species-constructor');
var promiseResolve = require('./_promise-resolve');

$export($export.P + $export.R, 'Promise', { 'finally': function (onFinally) {
  var C = speciesConstructor(this, core.Promise || global.Promise);
  var isFunction = typeof onFinally == 'function';
  return this.then(
    isFunction ? function (x) {
      return promiseResolve(C, onFinally()).then(function () { return x; });
    } : onFinally,
    isFunction ? function (e) {
      return promiseResolve(C, onFinally()).then(function () { throw e; });
    } : onFinally
  );
} });

},{"./_core":34,"./_export":41,"./_global":44,"./_promise-resolve":78,"./_species-constructor":87}],114:[function(require,module,exports){
'use strict';
// https://github.com/tc39/proposal-promise-try
var $export = require('./_export');
var newPromiseCapability = require('./_new-promise-capability');
var perform = require('./_perform');

$export($export.S, 'Promise', { 'try': function (callbackfn) {
  var promiseCapability = newPromiseCapability.f(this);
  var result = perform(callbackfn);
  (result.e ? promiseCapability.reject : promiseCapability.resolve)(result.v);
  return promiseCapability.promise;
} });

},{"./_export":41,"./_new-promise-capability":63,"./_perform":77}],115:[function(require,module,exports){
require('./_wks-define')('asyncIterator');

},{"./_wks-define":98}],116:[function(require,module,exports){
require('./_wks-define')('observable');

},{"./_wks-define":98}],117:[function(require,module,exports){
require('./es6.array.iterator');
var global = require('./_global');
var hide = require('./_hide');
var Iterators = require('./_iterators');
var TO_STRING_TAG = require('./_wks')('toStringTag');

var DOMIterables = ('CSSRuleList,CSSStyleDeclaration,CSSValueList,ClientRectList,DOMRectList,DOMStringList,' +
  'DOMTokenList,DataTransferItemList,FileList,HTMLAllCollection,HTMLCollection,HTMLFormElement,HTMLSelectElement,' +
  'MediaList,MimeTypeArray,NamedNodeMap,NodeList,PaintRequestList,Plugin,PluginArray,SVGLengthList,SVGNumberList,' +
  'SVGPathSegList,SVGPointList,SVGStringList,SVGTransformList,SourceBufferList,StyleSheetList,TextTrackCueList,' +
  'TextTrackList,TouchList').split(',');

for (var i = 0; i < DOMIterables.length; i++) {
  var NAME = DOMIterables[i];
  var Collection = global[NAME];
  var proto = Collection && Collection.prototype;
  if (proto && !proto[TO_STRING_TAG]) hide(proto, TO_STRING_TAG, NAME);
  Iterators[NAME] = Iterators.Array;
}

},{"./_global":44,"./_hide":46,"./_iterators":59,"./_wks":100,"./es6.array.iterator":102}],118:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _promise = require('babel-runtime/core-js/promise');

var _promise2 = _interopRequireDefault(_promise);

var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = require('babel-runtime/helpers/createClass');

var _createClass3 = _interopRequireDefault(_createClass2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Created by Tamer on 06/11/2017.
 */

/**
 * @class Actions
 */
var Actions = function () {
  /**
   * Creates an instance of Actions.
   * 
   * @param {object} 
   * @memberof Actions
   * @access public
   */
  function Actions(o) {
    (0, _classCallCheck3.default)(this, Actions);

    this.toolbox = o.toolbox;
    this.deploymentId = o.deploymentId;
    this.blueprintId = o.blueprintId;
  }

  /**
   * get output data
   * 
   * @returns 
   * @memberof Actions
   * @access public
   */


  (0, _createClass3.default)(Actions, [{
    key: 'doGetDeployment',
    value: function doGetDeployment() {
      return _promise2.default.resolve([{
        id: 'os',
        type: 'dropdown',
        flex: 100,
        position: 50,
        params: {
          label: 'Operating System',
          placeholder: 'Please Select the OS',
          multiple: false,
          options: [{ text: 'Windows', value: 'windows' }, { text: 'Linux', value: 'linux' }]
        }
      }, {
        id: 'my_button',
        type: 'button',
        flex: 100,
        position: 101,
        params: {
          label: 'My Button',
          circular: false,
          icon: 'facebook', // list of icons https://react.semantic-ui.com/elements/icon label will overwrite
          color: 'green', // red, orange, yellow, olive, green, teal, blue, violet, purple, pink, brown, grey, black,
          action: 'createDeployment'
        }
      }, {
        id: 'my_input',
        type: 'input',
        flex: 33,
        position: 99,
        params: {
          label: 'My Input',
          default: 'Hello Input',
          placeholder: 'Please Enter Your Data',
          isPassword: false
        }
      }, {
        id: 'my_checkbox',
        type: 'checkbox',
        flex: 33,
        position: 99,
        params: {
          label: 'My Checkbox',
          default: true
        }
      }, {
        id: 'my_toggle',
        type: 'toggle',
        flex: 33,
        position: 99,
        params: {
          label: 'My Toggle',
          default: true
        }
      }, {
        id: 'my_radio',
        type: 'radio',
        flex: 33,
        position: 99,
        params: {
          label: 'My Radio',
          default: 'op1',
          options: [{ text: 'Option 1', value: 'op1' }, { text: 'Option 2', value: 'op2' }, { text: 'Option 3', value: 'op3' }]
        }
      }, {
        id: 'my_dropdown',
        type: 'dropdown',
        flex: 33,
        position: 99,
        params: {
          label: 'My Dropdown',
          placeholder: 'Hello Dropdown',
          multiple: true,
          default: ['op1'],
          options: [{ text: 'Option 1', value: 'op1' }, { text: 'Option 2', value: 'op2' }, { text: 'Option 3', value: 'op3' }]
        }
      }, {
        id: 'my_range',
        type: 'range',
        flex: 33,
        position: 99,
        params: {
          label: 'My Range',
          default: 20,
          step: 1,
          min: 0,
          max: 100
        }
      }, {
        type: 'message',
        flex: 33,
        position: 99,
        params: {
          label: 'Hello i am a Message',
          color: 'green'
        }
      }, {
        id: 'my_selectbox',
        type: 'selectbox',
        flex: 100,
        position: 97,
        params: {
          label: 'My SelectBox',
          template: '<h1>{{text}}</h1><p>{{value}}</p>',
          style: 1, // 1 or 2
          default: '2b',
          options: [{ text: 'x-small', value: '1m' }, { text: 'small', value: '2b' }, { text: 'medium', value: '3m' }, { text: 'large', value: '5l' }]
        }
      }]);
      // return this.toolbox.getManager().doGet(`/deployments/${this.deploymentId}`);
    }
  }, {
    key: 'doGetInputDescriptor',
    value: function doGetInputDescriptor() {
      var _this = this;

      var path = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'input_descriptor.yaml';

      console.log({ path: path });
      return this.doGetFilesTree(this.blueprintId).then(function (files) {
        var file = files.children[0].children.find(function (item) {
          return item.title === path;
        });
        if (file) {
          return _this.doGetFileContent(file.key);
        } else {
          return _promise2.default.reject(path + ' not found.');
        }
      });
    }
  }, {
    key: 'doGetBlueprintId',
    value: function doGetBlueprintId(deploymentId) {
      return this.toolbox.getManager().doGet('/deployments/' + deploymentId + '?_include=id,blueprint_id');
    }
  }, {
    key: 'doGetFilesTree',
    value: function doGetFilesTree(blueprintId) {
      return this.toolbox.getInternal().doGet('/source/browse/' + blueprintId + '/archive');
    }
  }, {
    key: 'doGetFileContent',
    value: function doGetFileContent(path) {
      return this.toolbox.getInternal().doGet('/source/browse/file', { path: path });
    }
  }]);
  return Actions;
}();

exports.default = Actions;

},{"babel-runtime/core-js/promise":8,"babel-runtime/helpers/classCallCheck":11,"babel-runtime/helpers/createClass":12}],119:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _keys = require('babel-runtime/core-js/object/keys');

var _keys2 = _interopRequireDefault(_keys);

var _defineProperty2 = require('babel-runtime/helpers/defineProperty');

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

var _assign = require('babel-runtime/core-js/object/assign');

var _assign2 = _interopRequireDefault(_assign);

var _getPrototypeOf = require('babel-runtime/core-js/object/get-prototype-of');

var _getPrototypeOf2 = _interopRequireDefault(_getPrototypeOf);

var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = require('babel-runtime/helpers/createClass');

var _createClass3 = _interopRequireDefault(_createClass2);

var _possibleConstructorReturn2 = require('babel-runtime/helpers/possibleConstructorReturn');

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = require('babel-runtime/helpers/inherits');

var _inherits3 = _interopRequireDefault(_inherits2);

var _YAML = require('./utils/YAML');

var _YAML2 = _interopRequireDefault(_YAML);

var _base10to = require('./utils/base10to64');

var _base10to2 = _interopRequireDefault(_base10to);

var _SelectBox = require('./components/SelectBox');

var _SelectBox2 = _interopRequireDefault(_SelectBox);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * @class List
 * @extends {Component}
 */
var List = function (_React$Component) {
  (0, _inherits3.default)(List, _React$Component);

  /**
   * Creates an instance of List.
   * @param {any} props 
   * @param {any} context 
   */
  function List(props, context) {
    (0, _classCallCheck3.default)(this, List);

    var _this = (0, _possibleConstructorReturn3.default)(this, (List.__proto__ || (0, _getPrototypeOf2.default)(List)).call(this, props, context));

    _this.handleChange = function (id, value) {
      // TODO: before submit check for arrays to join them
      _this.setState({ form: (0, _assign2.default)(_this.state.form, (0, _defineProperty3.default)({}, id, value)) });
      console.log('form state', _this.state.form);
    };

    _this._createDeployment = function () {
      var errors = {};
      (0, _keys2.default)(_this.state.form).forEach(function (item) {
        // TODO: add more validations methods, by default now is required
        if (_.isNil(_this.state.form[item]) || _this.state.form[item] === '') {
          errors[item] = 'required';
        }
      });
      if ((0, _keys2.default)(errors).length !== 0) {
        errors.error = 'Please check errors given below';
      }
      _this.setState({ errors: errors });
      if ((0, _keys2.default)(errors).length === 0) {

        var blueprint = _this.props.widget.configuration.blueprintId;
        var deployment = _this.state.deploymentTitle;
        var visibility = 'tenant';
        var skipPluginsValidation = false;

        var blueprint_id = _this.state.form.blueprint_id || 'service';
        var deployment_inputs = _this.state.form;
        if (deployment_inputs.blueprint_id) {
          delete deployment_inputs.blueprint_id;
        }

        var inputs = {
          blueprint_id: blueprint_id,
          deployment_inputs: deployment_inputs
        };
        console.log('inputs', inputs);
        _this.setState({ loading: true });
        var actions = new Stage.Common.BlueprintActions(_this.props.toolbox);
        actions.doDeploy({ id: blueprint }, deployment, inputs, visibility, skipPluginsValidation).then(function (deployment) {
          _this.updateDeploymentName();
          _this.setState({ loading: false, errors: {}, success: 'Your request has been submitted and awaiting approval' });
          var onFinishRedirect = _this.props.widget.configuration.onFinishRedirect;
          var template = _this.props.widget.configuration.template;
          if (onFinishRedirect) {
            _this.props.toolbox.drillDown(_this.props.widget, template, { deploymentId: deployment.id }, deployment.id);
          }
        }).catch(function (err) {
          _this.setState({ loading: false, errors: { error: err.message } });
        });
      }
    };

    _this.state = {
      form: {},
      visual_data: {},
      errors: {},
      success: null,
      deploymentTitle: '',
      loading: false,
      yamlError: null
    };
    return _this;
  }

  (0, _createClass3.default)(List, [{
    key: 'componentWillMount',
    value: function componentWillMount() {
      var _this2 = this;

      var data = this.props.data;
      this.props.toolbox.getEventBus().on('devmode:render', function (res) {
        return res.widgetId === _this2.props.widget.id && _this2.renderJSON2YAML(res.data);
      }, this);
      this.props.toolbox.getEventBus().trigger('devmode:update', data, this.props.widget);

      this.updateDeploymentName();
      this.renderJSON2YAML(data);
    }
  }, {
    key: 'componentWillUnmount',
    value: function componentWillUnmount() {
      this.props.toolbox.getEventBus().off('devmode:render', this._devmode, this);
    }
  }, {
    key: 'updateDeploymentName',
    value: function updateDeploymentName() {
      var user = this.props.toolbox.getManager().getCurrentUsername();
      var blueprint = this.props.widget.configuration.blueprintId;
      var time64 = (0, _base10to2.default)(Math.floor(Date.now() / 1000));
      var deploymentTitle = 'admin deployment ' + user + '_' + blueprint + '_' + time64;
      this.setState({ deploymentTitle: deploymentTitle });
    }
  }, {
    key: 'renderJSON2YAML',
    value: function renderJSON2YAML(value) {
      this.setState({ yamlError: null });
      try {
        var data = _YAML2.default.parse(value);
        this.prepareData(data);
      } catch (e) {
        this.setState({ yamlError: e.message });
      }
    }
  }, {
    key: 'prepareData',
    value: function prepareData(data) {

      // extract available inputs to the loop
      var visual_data = data.filter(function (e) {
        return ['button', 'input', 'textarea', 'checkbox', 'toggle', 'radio', 'dropdown', 'range', 'message', 'selectbox'].includes(e.type);
      });

      console.log({ visual_data: visual_data });

      // sort items by position
      visual_data.sort(function (a, b) {
        return a.position - b.position;
      });

      // set default data
      var form = {};
      visual_data.forEach(function (item) {
        if (item.id && item.type !== 'button') {
          form[item.id] = item.params.default;
        }
      });
      this.setState({ form: form, visual_data: visual_data });
    }
  }, {
    key: 'render',


    /*
    |--------------------------------------------------------------------------
    | React Renderer
    |--------------------------------------------------------------------------
    */
    value: function render() {
      var _this3 = this;

      if (this.state.loading) {
        return React.createElement(Stage.Basic.Loading, null);
      }

      var _Stage$Basic = Stage.Basic,
          Button = _Stage$Basic.Button,
          Input = _Stage$Basic.Input,
          Checkbox = _Stage$Basic.Checkbox,
          Dropdown = _Stage$Basic.Dropdown,
          Message = _Stage$Basic.Message,
          Card = _Stage$Basic.Card;

      /**
       * charts visual output
       */

      var visuals = this.state.visual_data.map(function (item, idx) {
        return React.createElement(
          'div',
          { className: 'chart-box', key: idx, style: { flexBasis: (item.flex || 33) + '%' } },
          item.type === 'button' && React.createElement(
            Button,
            {
              fluid: !item.params.circular,
              color: item.params.color,
              circular: item.params.circular,
              icon: item.params.label ? false : item.params.icon,
              onClick: function onClick() {
                item.params.action === 'createDeployment' && _this3._createDeployment.call(_this3);
              }
            },
            item.params.label
          ),
          item.type === 'input' && React.createElement(Input, {
            fluid: true,
            type: item.params.isPassword ? 'password' : 'text',
            label: item.params.label,
            placeholder: item.params.placeholder,
            value: _this3.state.form[item.id],
            onChange: function onChange(proxy, options) {
              return _this3.handleChange.call(_this3, item.id, options.value);
            }
          }),
          item.type === 'checkbox' && React.createElement(Checkbox, {
            label: item.params.label,
            checked: _this3.state.form[item.id],
            onChange: function onChange(proxy, options) {
              return _this3.handleChange.call(_this3, item.id, options.checked);
            }
          }),
          item.type === 'toggle' && React.createElement(Checkbox, {
            toggle: true,
            label: item.params.label,
            checked: _this3.state.form[item.id],
            onChange: function onChange(proxy, options) {
              return _this3.handleChange.call(_this3, item.id, options.checked);
            }
          }),
          item.type === 'radio' && React.createElement(
            'div',
            null,
            React.createElement(
              'b',
              null,
              item.params.label
            ),
            React.createElement('br', null),
            React.createElement('br', null),
            item.params.options.map(function (option, idx) {
              return React.createElement(
                'div',
                { key: idx },
                React.createElement(Checkbox, {
                  radio: true,
                  name: item.id,
                  label: option.text,
                  value: option.value,
                  checked: _this3.state.form[item.id] === option.value,
                  onChange: function onChange(proxy, options) {
                    return _this3.handleChange.call(_this3, item.id, options.value);
                  }
                })
              );
            })
          ),
          item.type === 'dropdown' && React.createElement(
            'div',
            null,
            React.createElement(
              'b',
              null,
              item.params.label
            ),
            React.createElement('br', null),
            React.createElement('br', null),
            React.createElement(Dropdown, {
              fluid: true,
              selection: true,
              multiple: item.params.multiple,
              placeholder: item.params.placeholder,
              options: item.params.options,
              value: _this3.state.form[item.id],
              onChange: function onChange(proxy, options) {
                return _this3.handleChange.call(_this3, item.id, options.value);
              }
            })
          ),
          item.type === 'range' && React.createElement(
            'div',
            null,
            React.createElement(
              'b',
              null,
              item.params.label
            ),
            React.createElement('br', null),
            React.createElement('br', null),
            React.createElement('input', {
              type: 'range',
              step: item.params.step || 1,
              min: item.params.min || 0,
              max: item.params.max || 100,
              value: _this3.state.form[item.id],
              onChange: function onChange(proxy) {
                return _this3.handleChange.call(_this3, item.id, proxy.target.value);
              },
              style: { width: '100%' }
            })
          ),
          item.type === 'message' && React.createElement(
            Message,
            {
              color: item.params.color
            },
            item.params.label
          ),
          item.type === 'selectbox' && React.createElement(
            'div',
            null,
            React.createElement(
              'b',
              null,
              item.params.label
            ),
            React.createElement('br', null),
            React.createElement(_SelectBox2.default, {
              style: item.params.style,
              template: item.params.template,
              options: item.params.options,
              value: _this3.state.form[item.id],
              onChange: function onChange(value) {
                return _this3.handleChange.call(_this3, item.id, value);
              }
            })
          ),
          _this3.state.errors[item.id] && _this3.state.errors[item.id].split(',').includes('required') && React.createElement(
            'div',
            { className: 'err' },
            'Please Fill ',
            item.params.label || 'Field',
            ' ',
            'its Required'
          )
        );
      });

      var errorMessage = this.state.errors.error && React.createElement(
        Message,
        { color: 'red', onDismiss: function onDismiss() {
            return _this3.setState({ errors: (0, _assign2.default)(_this3.state.errors, { error: null }) });
          } },
        this.state.errors.error
      );

      var successMessage = this.state.success && React.createElement(
        Message,
        { color: 'green', onDismiss: function onDismiss() {
            return _this3.setState({ success: null });
          } },
        this.state.success
      );
      var yamlError = this.state.yamlError && React.createElement(
        Message,
        { color: 'yellow', onDismiss: function onDismiss() {
            return _this3.setState({ yamlError: null });
          } },
        this.state.yamlError
      );

      var allowNameEdit = this.props.widget.configuration.allowNameEdit;

      return React.createElement(
        'div',
        null,
        errorMessage,
        successMessage,
        yamlError,
        !this.state.success && allowNameEdit && React.createElement(Input, {
          fluid: true,
          type: 'text',
          label: 'Deployment Title',
          placeholder: 'Please Enter Your Deployment Title, should be unique name',
          value: this.state.deploymentTitle,
          onChange: function onChange(proxy, options) {
            return _this3.setState({ deploymentTitle: options.value });
          }
        }),
        React.createElement(
          'div',
          { className: 'deployment-visual-creation' },
          !this.state.success && visuals
        )
      );
    }
  }]);
  return List;
}(React.Component); /**
                     * Created by Tamer on 19/10/2017.
                     */


exports.default = List;

},{"./components/SelectBox":120,"./utils/YAML":121,"./utils/base10to64":133,"babel-runtime/core-js/object/assign":2,"babel-runtime/core-js/object/get-prototype-of":5,"babel-runtime/core-js/object/keys":6,"babel-runtime/helpers/classCallCheck":11,"babel-runtime/helpers/createClass":12,"babel-runtime/helpers/defineProperty":13,"babel-runtime/helpers/inherits":14,"babel-runtime/helpers/possibleConstructorReturn":15}],120:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _getPrototypeOf = require('babel-runtime/core-js/object/get-prototype-of');

var _getPrototypeOf2 = _interopRequireDefault(_getPrototypeOf);

var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = require('babel-runtime/helpers/createClass');

var _createClass3 = _interopRequireDefault(_createClass2);

var _possibleConstructorReturn2 = require('babel-runtime/helpers/possibleConstructorReturn');

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = require('babel-runtime/helpers/inherits');

var _inherits3 = _interopRequireDefault(_inherits2);

var _mustache = require('../utils/mustache');

var _mustache2 = _interopRequireDefault(_mustache);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * @class List
 * @extends {Component}
 */
var SelectBox = function (_React$Component) {
  (0, _inherits3.default)(SelectBox, _React$Component);

  /**
   * Creates an instance of List.
   * @param {any} props 
   * @param {any} context 
   */
  function SelectBox(props, context) {
    (0, _classCallCheck3.default)(this, SelectBox);

    var _this = (0, _possibleConstructorReturn3.default)(this, (SelectBox.__proto__ || (0, _getPrototypeOf2.default)(SelectBox)).call(this, props, context));

    _this.state = {
      formData: {}
    };
    return _this;
  }

  /*
  |--------------------------------------------------------------------------
  | React Renderer
  |--------------------------------------------------------------------------
  */


  (0, _createClass3.default)(SelectBox, [{
    key: 'render',
    value: function render() {
      var _props = this.props,
          options = _props.options,
          template = _props.template,
          onChange = _props.onChange,
          value = _props.value,
          style = _props.style;


      return React.createElement(
        'div',
        { className: 'selectbox-style' + (style || 1) },
        options.map(function (item, idx) {
          return React.createElement('div', {
            key: idx,
            className: ['item', item.value === value && 'active'].join(' '),
            onClick: function onClick() {
              return item.value !== value && onChange(item.value);
            },
            dangerouslySetInnerHTML: { __html: (0, _mustache2.default)(template, item) }
          });
        })
      );
    }
  }]);
  return SelectBox;
}(React.Component); /**
                     * Created by Tamer on 19/10/2017.
                     */


exports.default = SelectBox;

},{"../utils/mustache":134,"babel-runtime/core-js/object/get-prototype-of":5,"babel-runtime/helpers/classCallCheck":11,"babel-runtime/helpers/createClass":12,"babel-runtime/helpers/inherits":14,"babel-runtime/helpers/possibleConstructorReturn":15}],121:[function(require,module,exports){
'use strict';

var Yaml = require('./lib/Yaml');
module.exports = Yaml;

},{"./lib/Yaml":132}],122:[function(require,module,exports){
'use strict';

var _typeof2 = require('babel-runtime/helpers/typeof');

var _typeof3 = _interopRequireDefault(_typeof2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// Generated by CoffeeScript 1.12.4
var Dumper, Inline, Utils;

Utils = require('./Utils');

Inline = require('./Inline');

Dumper = function () {
  function Dumper() {}

  Dumper.indentation = 4;

  Dumper.prototype.dump = function (input, inline, indent, exceptionOnInvalidType, objectEncoder) {
    var i, key, len, output, prefix, value, willBeInlined;
    if (inline == null) {
      inline = 0;
    }
    if (indent == null) {
      indent = 0;
    }
    if (exceptionOnInvalidType == null) {
      exceptionOnInvalidType = false;
    }
    if (objectEncoder == null) {
      objectEncoder = null;
    }
    output = '';
    prefix = indent ? Utils.strRepeat(' ', indent) : '';
    if (inline <= 0 || (typeof input === 'undefined' ? 'undefined' : (0, _typeof3.default)(input)) !== 'object' || input instanceof Date || Utils.isEmpty(input)) {
      output += prefix + Inline.dump(input, exceptionOnInvalidType, objectEncoder);
    } else {
      if (input instanceof Array) {
        for (i = 0, len = input.length; i < len; i++) {
          value = input[i];
          willBeInlined = inline - 1 <= 0 || (typeof value === 'undefined' ? 'undefined' : (0, _typeof3.default)(value)) !== 'object' || Utils.isEmpty(value);
          output += prefix + '-' + (willBeInlined ? ' ' : "\n") + this.dump(value, inline - 1, willBeInlined ? 0 : indent + this.indentation, exceptionOnInvalidType, objectEncoder) + (willBeInlined ? "\n" : '');
        }
      } else {
        for (key in input) {
          value = input[key];
          willBeInlined = inline - 1 <= 0 || (typeof value === 'undefined' ? 'undefined' : (0, _typeof3.default)(value)) !== 'object' || Utils.isEmpty(value);
          output += prefix + Inline.dump(key, exceptionOnInvalidType, objectEncoder) + ':' + (willBeInlined ? ' ' : "\n") + this.dump(value, inline - 1, willBeInlined ? 0 : indent + this.indentation, exceptionOnInvalidType, objectEncoder) + (willBeInlined ? "\n" : '');
        }
      }
    }
    return output;
  };

  return Dumper;
}();

module.exports = Dumper;

},{"./Inline":127,"./Utils":131,"babel-runtime/helpers/typeof":16}],123:[function(require,module,exports){
'use strict';

// Generated by CoffeeScript 1.12.4
var Escaper, Pattern;

Pattern = require('./Pattern');

Escaper = function () {
  var ch;

  function Escaper() {}

  Escaper.LIST_ESCAPEES = ['\\', '\\\\', '\\"', '"', "\x00", "\x01", "\x02", "\x03", "\x04", "\x05", "\x06", "\x07", "\x08", "\x09", "\x0a", "\x0b", "\x0c", "\x0d", "\x0e", "\x0f", "\x10", "\x11", "\x12", "\x13", "\x14", "\x15", "\x16", "\x17", "\x18", "\x19", "\x1a", "\x1b", "\x1c", "\x1d", "\x1e", "\x1f", (ch = String.fromCharCode)(0x0085), ch(0x00A0), ch(0x2028), ch(0x2029)];

  Escaper.LIST_ESCAPED = ['\\\\', '\\"', '\\"', '\\"', "\\0", "\\x01", "\\x02", "\\x03", "\\x04", "\\x05", "\\x06", "\\a", "\\b", "\\t", "\\n", "\\v", "\\f", "\\r", "\\x0e", "\\x0f", "\\x10", "\\x11", "\\x12", "\\x13", "\\x14", "\\x15", "\\x16", "\\x17", "\\x18", "\\x19", "\\x1a", "\\e", "\\x1c", "\\x1d", "\\x1e", "\\x1f", "\\N", "\\_", "\\L", "\\P"];

  Escaper.MAPPING_ESCAPEES_TO_ESCAPED = function () {
    var i, j, mapping, ref;
    mapping = {};
    for (i = j = 0, ref = Escaper.LIST_ESCAPEES.length; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
      mapping[Escaper.LIST_ESCAPEES[i]] = Escaper.LIST_ESCAPED[i];
    }
    return mapping;
  }();

  Escaper.PATTERN_CHARACTERS_TO_ESCAPE = new Pattern('[\\x00-\\x1f]|\xc2\x85|\xc2\xa0|\xe2\x80\xa8|\xe2\x80\xa9');

  Escaper.PATTERN_MAPPING_ESCAPEES = new Pattern(Escaper.LIST_ESCAPEES.join('|').split('\\').join('\\\\'));

  Escaper.PATTERN_SINGLE_QUOTING = new Pattern('[\\s\'":{}[\\],&*#?]|^[-?|<>=!%@`]');

  Escaper.requiresDoubleQuoting = function (value) {
    return this.PATTERN_CHARACTERS_TO_ESCAPE.test(value);
  };

  Escaper.escapeWithDoubleQuotes = function (value) {
    var result;
    result = this.PATTERN_MAPPING_ESCAPEES.replace(value, function (_this) {
      return function (str) {
        return _this.MAPPING_ESCAPEES_TO_ESCAPED[str];
      };
    }(this));
    return '"' + result + '"';
  };

  Escaper.requiresSingleQuoting = function (value) {
    return this.PATTERN_SINGLE_QUOTING.test(value);
  };

  Escaper.escapeWithSingleQuotes = function (value) {
    return "'" + value.replace(/'/g, "''") + "'";
  };

  return Escaper;
}();

module.exports = Escaper;

},{"./Pattern":129}],124:[function(require,module,exports){
'use strict';

// Generated by CoffeeScript 1.12.4
var DumpException,
    extend = function extend(child, parent) {
  for (var key in parent) {
    if (hasProp.call(parent, key)) child[key] = parent[key];
  }function ctor() {
    this.constructor = child;
  }ctor.prototype = parent.prototype;child.prototype = new ctor();child.__super__ = parent.prototype;return child;
},
    hasProp = {}.hasOwnProperty;

DumpException = function (superClass) {
  extend(DumpException, superClass);

  function DumpException(message, parsedLine, snippet) {
    this.message = message;
    this.parsedLine = parsedLine;
    this.snippet = snippet;
  }

  DumpException.prototype.toString = function () {
    if (this.parsedLine != null && this.snippet != null) {
      return '<DumpException> ' + this.message + ' (line ' + this.parsedLine + ': \'' + this.snippet + '\')';
    } else {
      return '<DumpException> ' + this.message;
    }
  };

  return DumpException;
}(Error);

module.exports = DumpException;

},{}],125:[function(require,module,exports){
'use strict';

// Generated by CoffeeScript 1.12.4
var ParseException,
    extend = function extend(child, parent) {
  for (var key in parent) {
    if (hasProp.call(parent, key)) child[key] = parent[key];
  }function ctor() {
    this.constructor = child;
  }ctor.prototype = parent.prototype;child.prototype = new ctor();child.__super__ = parent.prototype;return child;
},
    hasProp = {}.hasOwnProperty;

ParseException = function (superClass) {
  extend(ParseException, superClass);

  function ParseException(message, parsedLine, snippet) {
    this.message = message;
    this.parsedLine = parsedLine;
    this.snippet = snippet;
  }

  ParseException.prototype.toString = function () {
    if (this.parsedLine != null && this.snippet != null) {
      return '<ParseException> ' + this.message + ' (line ' + this.parsedLine + ': \'' + this.snippet + '\')';
    } else {
      return '<ParseException> ' + this.message;
    }
  };

  return ParseException;
}(Error);

module.exports = ParseException;

},{}],126:[function(require,module,exports){
'use strict';

// Generated by CoffeeScript 1.12.4
var ParseMore,
    extend = function extend(child, parent) {
  for (var key in parent) {
    if (hasProp.call(parent, key)) child[key] = parent[key];
  }function ctor() {
    this.constructor = child;
  }ctor.prototype = parent.prototype;child.prototype = new ctor();child.__super__ = parent.prototype;return child;
},
    hasProp = {}.hasOwnProperty;

ParseMore = function (superClass) {
  extend(ParseMore, superClass);

  function ParseMore(message, parsedLine, snippet) {
    this.message = message;
    this.parsedLine = parsedLine;
    this.snippet = snippet;
  }

  ParseMore.prototype.toString = function () {
    if (this.parsedLine != null && this.snippet != null) {
      return '<ParseMore> ' + this.message + ' (line ' + this.parsedLine + ': \'' + this.snippet + '\')';
    } else {
      return '<ParseMore> ' + this.message;
    }
  };

  return ParseMore;
}(Error);

module.exports = ParseMore;

},{}],127:[function(require,module,exports){
'use strict';

var _typeof2 = require('babel-runtime/helpers/typeof');

var _typeof3 = _interopRequireDefault(_typeof2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// Generated by CoffeeScript 1.12.4
var DumpException,
    Escaper,
    Inline,
    ParseException,
    ParseMore,
    Pattern,
    Unescaper,
    Utils,
    indexOf = [].indexOf || function (item) {
  for (var i = 0, l = this.length; i < l; i++) {
    if (i in this && this[i] === item) return i;
  }return -1;
};

Pattern = require('./Pattern');

Unescaper = require('./Unescaper');

Escaper = require('./Escaper');

Utils = require('./Utils');

ParseException = require('./Exception/ParseException');

ParseMore = require('./Exception/ParseMore');

DumpException = require('./Exception/DumpException');

Inline = function () {
  function Inline() {}

  Inline.REGEX_QUOTED_STRING = '(?:"(?:[^"\\\\]*(?:\\\\.[^"\\\\]*)*)"|\'(?:[^\']*(?:\'\'[^\']*)*)\')';

  Inline.PATTERN_TRAILING_COMMENTS = new Pattern('^\\s*#.*$');

  Inline.PATTERN_QUOTED_SCALAR = new Pattern('^' + Inline.REGEX_QUOTED_STRING);

  Inline.PATTERN_THOUSAND_NUMERIC_SCALAR = new Pattern('^(-|\\+)?[0-9,]+(\\.[0-9]+)?$');

  Inline.PATTERN_SCALAR_BY_DELIMITERS = {};

  Inline.settings = {};

  Inline.configure = function (exceptionOnInvalidType, objectDecoder) {
    if (exceptionOnInvalidType == null) {
      exceptionOnInvalidType = null;
    }
    if (objectDecoder == null) {
      objectDecoder = null;
    }
    this.settings.exceptionOnInvalidType = exceptionOnInvalidType;
    this.settings.objectDecoder = objectDecoder;
  };

  Inline.parse = function (value, exceptionOnInvalidType, objectDecoder) {
    var context, result;
    if (exceptionOnInvalidType == null) {
      exceptionOnInvalidType = false;
    }
    if (objectDecoder == null) {
      objectDecoder = null;
    }
    this.settings.exceptionOnInvalidType = exceptionOnInvalidType;
    this.settings.objectDecoder = objectDecoder;
    if (value == null) {
      return '';
    }
    value = Utils.trim(value);
    if (0 === value.length) {
      return '';
    }
    context = {
      exceptionOnInvalidType: exceptionOnInvalidType,
      objectDecoder: objectDecoder,
      i: 0
    };
    switch (value.charAt(0)) {
      case '[':
        result = this.parseSequence(value, context);
        ++context.i;
        break;
      case '{':
        result = this.parseMapping(value, context);
        ++context.i;
        break;
      default:
        result = this.parseScalar(value, null, ['"', "'"], context);
    }
    if (this.PATTERN_TRAILING_COMMENTS.replace(value.slice(context.i), '') !== '') {
      throw new ParseException('Unexpected characters near "' + value.slice(context.i) + '".');
    }
    return result;
  };

  Inline.dump = function (value, exceptionOnInvalidType, objectEncoder) {
    var ref, result, type;
    if (exceptionOnInvalidType == null) {
      exceptionOnInvalidType = false;
    }
    if (objectEncoder == null) {
      objectEncoder = null;
    }
    if (value == null) {
      return 'null';
    }
    type = typeof value === 'undefined' ? 'undefined' : (0, _typeof3.default)(value);
    if (type === 'object') {
      if (value instanceof Date) {
        return value.toISOString();
      } else if (objectEncoder != null) {
        result = objectEncoder(value);
        if (typeof result === 'string' || result != null) {
          return result;
        }
      }
      return this.dumpObject(value);
    }
    if (type === 'boolean') {
      return value ? 'true' : 'false';
    }
    if (Utils.isDigits(value)) {
      return type === 'string' ? "'" + value + "'" : String(parseInt(value));
    }
    if (Utils.isNumeric(value)) {
      return type === 'string' ? "'" + value + "'" : String(parseFloat(value));
    }
    if (type === 'number') {
      return value === 2e308 ? '.Inf' : value === -2e308 ? '-.Inf' : isNaN(value) ? '.NaN' : value;
    }
    if (Escaper.requiresDoubleQuoting(value)) {
      return Escaper.escapeWithDoubleQuotes(value);
    }
    if (Escaper.requiresSingleQuoting(value)) {
      return Escaper.escapeWithSingleQuotes(value);
    }
    if ('' === value) {
      return '""';
    }
    if (Utils.PATTERN_DATE.test(value)) {
      return "'" + value + "'";
    }
    if ((ref = value.toLowerCase()) === 'null' || ref === '~' || ref === 'true' || ref === 'false') {
      return "'" + value + "'";
    }
    return value;
  };

  Inline.dumpObject = function (value, exceptionOnInvalidType, objectSupport) {
    var j, key, len1, output, val;
    if (objectSupport == null) {
      objectSupport = null;
    }
    if (value instanceof Array) {
      output = [];
      for (j = 0, len1 = value.length; j < len1; j++) {
        val = value[j];
        output.push(this.dump(val));
      }
      return '[' + output.join(', ') + ']';
    } else {
      output = [];
      for (key in value) {
        val = value[key];
        output.push(this.dump(key) + ': ' + this.dump(val));
      }
      return '{' + output.join(', ') + '}';
    }
  };

  Inline.parseScalar = function (scalar, delimiters, stringDelimiters, context, evaluate) {
    var i, joinedDelimiters, match, output, pattern, ref, ref1, strpos, tmp;
    if (delimiters == null) {
      delimiters = null;
    }
    if (stringDelimiters == null) {
      stringDelimiters = ['"', "'"];
    }
    if (context == null) {
      context = null;
    }
    if (evaluate == null) {
      evaluate = true;
    }
    if (context == null) {
      context = {
        exceptionOnInvalidType: this.settings.exceptionOnInvalidType,
        objectDecoder: this.settings.objectDecoder,
        i: 0
      };
    }
    i = context.i;
    if (ref = scalar.charAt(i), indexOf.call(stringDelimiters, ref) >= 0) {
      output = this.parseQuotedScalar(scalar, context);
      i = context.i;
      if (delimiters != null) {
        tmp = Utils.ltrim(scalar.slice(i), ' ');
        if (!(ref1 = tmp.charAt(0), indexOf.call(delimiters, ref1) >= 0)) {
          throw new ParseException('Unexpected characters (' + scalar.slice(i) + ').');
        }
      }
    } else {
      if (!delimiters) {
        output = scalar.slice(i);
        i += output.length;
        strpos = output.indexOf(' #');
        if (strpos !== -1) {
          output = Utils.rtrim(output.slice(0, strpos));
        }
      } else {
        joinedDelimiters = delimiters.join('|');
        pattern = this.PATTERN_SCALAR_BY_DELIMITERS[joinedDelimiters];
        if (pattern == null) {
          pattern = new Pattern('^(.+?)(' + joinedDelimiters + ')');
          this.PATTERN_SCALAR_BY_DELIMITERS[joinedDelimiters] = pattern;
        }
        if (match = pattern.exec(scalar.slice(i))) {
          output = match[1];
          i += output.length;
        } else {
          throw new ParseException('Malformed inline YAML string (' + scalar + ').');
        }
      }
      if (evaluate) {
        output = this.evaluateScalar(output, context);
      }
    }
    context.i = i;
    return output;
  };

  Inline.parseQuotedScalar = function (scalar, context) {
    var i, match, output;
    i = context.i;
    if (!(match = this.PATTERN_QUOTED_SCALAR.exec(scalar.slice(i)))) {
      throw new ParseMore('Malformed inline YAML string (' + scalar.slice(i) + ').');
    }
    output = match[0].substr(1, match[0].length - 2);
    if ('"' === scalar.charAt(i)) {
      output = Unescaper.unescapeDoubleQuotedString(output);
    } else {
      output = Unescaper.unescapeSingleQuotedString(output);
    }
    i += match[0].length;
    context.i = i;
    return output;
  };

  Inline.parseSequence = function (sequence, context) {
    var e, i, isQuoted, len, output, ref, value;
    output = [];
    len = sequence.length;
    i = context.i;
    i += 1;
    while (i < len) {
      context.i = i;
      switch (sequence.charAt(i)) {
        case '[':
          output.push(this.parseSequence(sequence, context));
          i = context.i;
          break;
        case '{':
          output.push(this.parseMapping(sequence, context));
          i = context.i;
          break;
        case ']':
          return output;
        case ',':
        case ' ':
        case "\n":
          break;
        default:
          isQuoted = (ref = sequence.charAt(i)) === '"' || ref === "'";
          value = this.parseScalar(sequence, [',', ']'], ['"', "'"], context);
          i = context.i;
          if (!isQuoted && typeof value === 'string' && (value.indexOf(': ') !== -1 || value.indexOf(":\n") !== -1)) {
            try {
              value = this.parseMapping('{' + value + '}');
            } catch (error) {
              e = error;
            }
          }
          output.push(value);
          --i;
      }
      ++i;
    }
    throw new ParseMore('Malformed inline YAML string ' + sequence);
  };

  Inline.parseMapping = function (mapping, context) {
    var done, i, key, len, output, shouldContinueWhileLoop, value;
    output = {};
    len = mapping.length;
    i = context.i;
    i += 1;
    shouldContinueWhileLoop = false;
    while (i < len) {
      context.i = i;
      switch (mapping.charAt(i)) {
        case ' ':
        case ',':
        case "\n":
          ++i;
          context.i = i;
          shouldContinueWhileLoop = true;
          break;
        case '}':
          return output;
      }
      if (shouldContinueWhileLoop) {
        shouldContinueWhileLoop = false;
        continue;
      }
      key = this.parseScalar(mapping, [':', ' ', "\n"], ['"', "'"], context, false);
      i = context.i;
      done = false;
      while (i < len) {
        context.i = i;
        switch (mapping.charAt(i)) {
          case '[':
            value = this.parseSequence(mapping, context);
            i = context.i;
            if (output[key] === void 0) {
              output[key] = value;
            }
            done = true;
            break;
          case '{':
            value = this.parseMapping(mapping, context);
            i = context.i;
            if (output[key] === void 0) {
              output[key] = value;
            }
            done = true;
            break;
          case ':':
          case ' ':
          case "\n":
            break;
          default:
            value = this.parseScalar(mapping, [',', '}'], ['"', "'"], context);
            i = context.i;
            if (output[key] === void 0) {
              output[key] = value;
            }
            done = true;
            --i;
        }
        ++i;
        if (done) {
          break;
        }
      }
    }
    throw new ParseMore('Malformed inline YAML string ' + mapping);
  };

  Inline.evaluateScalar = function (scalar, context) {
    var cast, date, exceptionOnInvalidType, firstChar, firstSpace, firstWord, objectDecoder, raw, scalarLower, subValue, trimmedScalar;
    scalar = Utils.trim(scalar);
    scalarLower = scalar.toLowerCase();
    switch (scalarLower) {
      case 'null':
      case '':
      case '~':
        return null;
      case 'true':
        return true;
      case 'false':
        return false;
      case '.inf':
        return 2e308;
      case '.nan':
        return 0 / 0;
      case '-.inf':
        return 2e308;
      default:
        firstChar = scalarLower.charAt(0);
        switch (firstChar) {
          case '!':
            firstSpace = scalar.indexOf(' ');
            if (firstSpace === -1) {
              firstWord = scalarLower;
            } else {
              firstWord = scalarLower.slice(0, firstSpace);
            }
            switch (firstWord) {
              case '!':
                if (firstSpace !== -1) {
                  return parseInt(this.parseScalar(scalar.slice(2)));
                }
                return null;
              case '!str':
                return Utils.ltrim(scalar.slice(4));
              case '!!str':
                return Utils.ltrim(scalar.slice(5));
              case '!!int':
                return parseInt(this.parseScalar(scalar.slice(5)));
              case '!!bool':
                return Utils.parseBoolean(this.parseScalar(scalar.slice(6)), false);
              case '!!float':
                return parseFloat(this.parseScalar(scalar.slice(7)));
              case '!!timestamp':
                return Utils.stringToDate(Utils.ltrim(scalar.slice(11)));
              default:
                if (context == null) {
                  context = {
                    exceptionOnInvalidType: this.settings.exceptionOnInvalidType,
                    objectDecoder: this.settings.objectDecoder,
                    i: 0
                  };
                }
                objectDecoder = context.objectDecoder, exceptionOnInvalidType = context.exceptionOnInvalidType;
                if (objectDecoder) {
                  trimmedScalar = Utils.rtrim(scalar);
                  firstSpace = trimmedScalar.indexOf(' ');
                  if (firstSpace === -1) {
                    return objectDecoder(trimmedScalar, null);
                  } else {
                    subValue = Utils.ltrim(trimmedScalar.slice(firstSpace + 1));
                    if (!(subValue.length > 0)) {
                      subValue = null;
                    }
                    return objectDecoder(trimmedScalar.slice(0, firstSpace), subValue);
                  }
                }
                if (exceptionOnInvalidType) {
                  throw new ParseException('Custom object support when parsing a YAML file has been disabled.');
                }
                return null;
            }
            break;
          case '0':
            if ('0x' === scalar.slice(0, 2)) {
              return Utils.hexDec(scalar);
            } else if (Utils.isDigits(scalar)) {
              return Utils.octDec(scalar);
            } else if (Utils.isNumeric(scalar)) {
              return parseFloat(scalar);
            } else {
              return scalar;
            }
            break;
          case '+':
            if (Utils.isDigits(scalar)) {
              raw = scalar;
              cast = parseInt(raw);
              if (raw === String(cast)) {
                return cast;
              } else {
                return raw;
              }
            } else if (Utils.isNumeric(scalar)) {
              return parseFloat(scalar);
            } else if (this.PATTERN_THOUSAND_NUMERIC_SCALAR.test(scalar)) {
              return parseFloat(scalar.replace(',', ''));
            }
            return scalar;
          case '-':
            if (Utils.isDigits(scalar.slice(1))) {
              if ('0' === scalar.charAt(1)) {
                return -Utils.octDec(scalar.slice(1));
              } else {
                raw = scalar.slice(1);
                cast = parseInt(raw);
                if (raw === String(cast)) {
                  return -cast;
                } else {
                  return -raw;
                }
              }
            } else if (Utils.isNumeric(scalar)) {
              return parseFloat(scalar);
            } else if (this.PATTERN_THOUSAND_NUMERIC_SCALAR.test(scalar)) {
              return parseFloat(scalar.replace(',', ''));
            }
            return scalar;
          default:
            if (date = Utils.stringToDate(scalar)) {
              return date;
            } else if (Utils.isNumeric(scalar)) {
              return parseFloat(scalar);
            } else if (this.PATTERN_THOUSAND_NUMERIC_SCALAR.test(scalar)) {
              return parseFloat(scalar.replace(',', ''));
            }
            return scalar;
        }
    }
  };

  return Inline;
}();

module.exports = Inline;

},{"./Escaper":123,"./Exception/DumpException":124,"./Exception/ParseException":125,"./Exception/ParseMore":126,"./Pattern":129,"./Unescaper":130,"./Utils":131,"babel-runtime/helpers/typeof":16}],128:[function(require,module,exports){
'use strict';

var _typeof2 = require('babel-runtime/helpers/typeof');

var _typeof3 = _interopRequireDefault(_typeof2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// Generated by CoffeeScript 1.12.4
var Inline, ParseException, ParseMore, Parser, Pattern, Utils;

Inline = require('./Inline');

Pattern = require('./Pattern');

Utils = require('./Utils');

ParseException = require('./Exception/ParseException');

ParseMore = require('./Exception/ParseMore');

Parser = function () {
  Parser.prototype.PATTERN_FOLDED_SCALAR_ALL = new Pattern('^(?:(?<type>![^\\|>]*)\\s+)?(?<separator>\\||>)(?<modifiers>\\+|\\-|\\d+|\\+\\d+|\\-\\d+|\\d+\\+|\\d+\\-)?(?<comments> +#.*)?$');

  Parser.prototype.PATTERN_FOLDED_SCALAR_END = new Pattern('(?<separator>\\||>)(?<modifiers>\\+|\\-|\\d+|\\+\\d+|\\-\\d+|\\d+\\+|\\d+\\-)?(?<comments> +#.*)?$');

  Parser.prototype.PATTERN_SEQUENCE_ITEM = new Pattern('^\\-((?<leadspaces>\\s+)(?<value>.+?))?\\s*$');

  Parser.prototype.PATTERN_ANCHOR_VALUE = new Pattern('^&(?<ref>[^ ]+) *(?<value>.*)');

  Parser.prototype.PATTERN_COMPACT_NOTATION = new Pattern('^(?<key>' + Inline.REGEX_QUOTED_STRING + '|[^ \'"\\{\\[].*?) *\\:(\\s+(?<value>.+?))?\\s*$');

  Parser.prototype.PATTERN_MAPPING_ITEM = new Pattern('^(?<key>' + Inline.REGEX_QUOTED_STRING + '|[^ \'"\\[\\{].*?) *\\:(\\s+(?<value>.+?))?\\s*$');

  Parser.prototype.PATTERN_DECIMAL = new Pattern('\\d+');

  Parser.prototype.PATTERN_INDENT_SPACES = new Pattern('^ +');

  Parser.prototype.PATTERN_TRAILING_LINES = new Pattern('(\n*)$');

  Parser.prototype.PATTERN_YAML_HEADER = new Pattern('^\\%YAML[: ][\\d\\.]+.*\n', 'm');

  Parser.prototype.PATTERN_LEADING_COMMENTS = new Pattern('^(\\#.*?\n)+', 'm');

  Parser.prototype.PATTERN_DOCUMENT_MARKER_START = new Pattern('^\\-\\-\\-.*?\n', 'm');

  Parser.prototype.PATTERN_DOCUMENT_MARKER_END = new Pattern('^\\.\\.\\.\\s*$', 'm');

  Parser.prototype.PATTERN_FOLDED_SCALAR_BY_INDENTATION = {};

  Parser.prototype.CONTEXT_NONE = 0;

  Parser.prototype.CONTEXT_SEQUENCE = 1;

  Parser.prototype.CONTEXT_MAPPING = 2;

  function Parser(offset) {
    this.offset = offset != null ? offset : 0;
    this.lines = [];
    this.currentLineNb = -1;
    this.currentLine = '';
    this.refs = {};
  }

  Parser.prototype.parse = function (value, exceptionOnInvalidType, objectDecoder) {
    var alias, allowOverwrite, block, c, context, data, e, first, i, indent, isRef, j, k, key, l, lastKey, len, len1, len2, len3, lineCount, m, matches, mergeNode, n, name, parsed, parsedItem, parser, ref, ref1, ref2, refName, refValue, val, values;
    if (exceptionOnInvalidType == null) {
      exceptionOnInvalidType = false;
    }
    if (objectDecoder == null) {
      objectDecoder = null;
    }
    this.currentLineNb = -1;
    this.currentLine = '';
    this.lines = this.cleanup(value).split("\n");
    data = null;
    context = this.CONTEXT_NONE;
    allowOverwrite = false;
    while (this.moveToNextLine()) {
      if (this.isCurrentLineEmpty()) {
        continue;
      }
      if ("\t" === this.currentLine[0]) {
        throw new ParseException('A YAML file cannot contain tabs as indentation.', this.getRealCurrentLineNb() + 1, this.currentLine);
      }
      isRef = mergeNode = false;
      if (values = this.PATTERN_SEQUENCE_ITEM.exec(this.currentLine)) {
        if (this.CONTEXT_MAPPING === context) {
          throw new ParseException('You cannot define a sequence item when in a mapping');
        }
        context = this.CONTEXT_SEQUENCE;
        if (data == null) {
          data = [];
        }
        if (values.value != null && (matches = this.PATTERN_ANCHOR_VALUE.exec(values.value))) {
          isRef = matches.ref;
          values.value = matches.value;
        }
        if (!(values.value != null) || '' === Utils.trim(values.value, ' ') || Utils.ltrim(values.value, ' ').indexOf('#') === 0) {
          if (this.currentLineNb < this.lines.length - 1 && !this.isNextLineUnIndentedCollection()) {
            c = this.getRealCurrentLineNb() + 1;
            parser = new Parser(c);
            parser.refs = this.refs;
            data.push(parser.parse(this.getNextEmbedBlock(null, true), exceptionOnInvalidType, objectDecoder));
          } else {
            data.push(null);
          }
        } else {
          if (((ref = values.leadspaces) != null ? ref.length : void 0) && (matches = this.PATTERN_COMPACT_NOTATION.exec(values.value))) {
            c = this.getRealCurrentLineNb();
            parser = new Parser(c);
            parser.refs = this.refs;
            block = values.value;
            indent = this.getCurrentLineIndentation();
            if (this.isNextLineIndented(false)) {
              block += "\n" + this.getNextEmbedBlock(indent + values.leadspaces.length + 1, true);
            }
            data.push(parser.parse(block, exceptionOnInvalidType, objectDecoder));
          } else {
            data.push(this.parseValue(values.value, exceptionOnInvalidType, objectDecoder));
          }
        }
      } else if ((values = this.PATTERN_MAPPING_ITEM.exec(this.currentLine)) && values.key.indexOf(' #') === -1) {
        if (this.CONTEXT_SEQUENCE === context) {
          throw new ParseException('You cannot define a mapping item when in a sequence');
        }
        context = this.CONTEXT_MAPPING;
        if (data == null) {
          data = {};
        }
        Inline.configure(exceptionOnInvalidType, objectDecoder);
        try {
          key = Inline.parseScalar(values.key);
        } catch (error) {
          e = error;
          e.parsedLine = this.getRealCurrentLineNb() + 1;
          e.snippet = this.currentLine;
          throw e;
        }
        if ('<<' === key) {
          mergeNode = true;
          allowOverwrite = true;
          if (((ref1 = values.value) != null ? ref1.indexOf('*') : void 0) === 0) {
            refName = values.value.slice(1);
            if (this.refs[refName] == null) {
              throw new ParseException('Reference "' + refName + '" does not exist.', this.getRealCurrentLineNb() + 1, this.currentLine);
            }
            refValue = this.refs[refName];
            if ((typeof refValue === 'undefined' ? 'undefined' : (0, _typeof3.default)(refValue)) !== 'object') {
              throw new ParseException('YAML merge keys used with a scalar value instead of an object.', this.getRealCurrentLineNb() + 1, this.currentLine);
            }
            if (refValue instanceof Array) {
              for (i = j = 0, len = refValue.length; j < len; i = ++j) {
                value = refValue[i];
                if (data[name = String(i)] == null) {
                  data[name] = value;
                }
              }
            } else {
              for (key in refValue) {
                value = refValue[key];
                if (data[key] == null) {
                  data[key] = value;
                }
              }
            }
          } else {
            if (values.value != null && values.value !== '') {
              value = values.value;
            } else {
              value = this.getNextEmbedBlock();
            }
            c = this.getRealCurrentLineNb() + 1;
            parser = new Parser(c);
            parser.refs = this.refs;
            parsed = parser.parse(value, exceptionOnInvalidType);
            if ((typeof parsed === 'undefined' ? 'undefined' : (0, _typeof3.default)(parsed)) !== 'object') {
              throw new ParseException('YAML merge keys used with a scalar value instead of an object.', this.getRealCurrentLineNb() + 1, this.currentLine);
            }
            if (parsed instanceof Array) {
              for (l = 0, len1 = parsed.length; l < len1; l++) {
                parsedItem = parsed[l];
                if ((typeof parsedItem === 'undefined' ? 'undefined' : (0, _typeof3.default)(parsedItem)) !== 'object') {
                  throw new ParseException('Merge items must be objects.', this.getRealCurrentLineNb() + 1, parsedItem);
                }
                if (parsedItem instanceof Array) {
                  for (i = m = 0, len2 = parsedItem.length; m < len2; i = ++m) {
                    value = parsedItem[i];
                    k = String(i);
                    if (!data.hasOwnProperty(k)) {
                      data[k] = value;
                    }
                  }
                } else {
                  for (key in parsedItem) {
                    value = parsedItem[key];
                    if (!data.hasOwnProperty(key)) {
                      data[key] = value;
                    }
                  }
                }
              }
            } else {
              for (key in parsed) {
                value = parsed[key];
                if (!data.hasOwnProperty(key)) {
                  data[key] = value;
                }
              }
            }
          }
        } else if (values.value != null && (matches = this.PATTERN_ANCHOR_VALUE.exec(values.value))) {
          isRef = matches.ref;
          values.value = matches.value;
        }
        if (mergeNode) {} else if (!(values.value != null) || '' === Utils.trim(values.value, ' ') || Utils.ltrim(values.value, ' ').indexOf('#') === 0) {
          if (!this.isNextLineIndented() && !this.isNextLineUnIndentedCollection()) {
            if (allowOverwrite || data[key] === void 0) {
              data[key] = null;
            }
          } else {
            c = this.getRealCurrentLineNb() + 1;
            parser = new Parser(c);
            parser.refs = this.refs;
            val = parser.parse(this.getNextEmbedBlock(), exceptionOnInvalidType, objectDecoder);
            if (allowOverwrite || data[key] === void 0) {
              data[key] = val;
            }
          }
        } else {
          val = this.parseValue(values.value, exceptionOnInvalidType, objectDecoder);
          if (allowOverwrite || data[key] === void 0) {
            data[key] = val;
          }
        }
      } else {
        lineCount = this.lines.length;
        if (1 === lineCount || 2 === lineCount && Utils.isEmpty(this.lines[1])) {
          try {
            value = Inline.parse(this.lines[0], exceptionOnInvalidType, objectDecoder);
          } catch (error) {
            e = error;
            e.parsedLine = this.getRealCurrentLineNb() + 1;
            e.snippet = this.currentLine;
            throw e;
          }
          if ((typeof value === 'undefined' ? 'undefined' : (0, _typeof3.default)(value)) === 'object') {
            if (value instanceof Array) {
              first = value[0];
            } else {
              for (key in value) {
                first = value[key];
                break;
              }
            }
            if (typeof first === 'string' && first.indexOf('*') === 0) {
              data = [];
              for (n = 0, len3 = value.length; n < len3; n++) {
                alias = value[n];
                data.push(this.refs[alias.slice(1)]);
              }
              value = data;
            }
          }
          return value;
        } else if ((ref2 = Utils.ltrim(value).charAt(0)) === '[' || ref2 === '{') {
          try {
            return Inline.parse(value, exceptionOnInvalidType, objectDecoder);
          } catch (error) {
            e = error;
            e.parsedLine = this.getRealCurrentLineNb() + 1;
            e.snippet = this.currentLine;
            throw e;
          }
        }
        throw new ParseException('Unable to parse.', this.getRealCurrentLineNb() + 1, this.currentLine);
      }
      if (isRef) {
        if (data instanceof Array) {
          this.refs[isRef] = data[data.length - 1];
        } else {
          lastKey = null;
          for (key in data) {
            lastKey = key;
          }
          this.refs[isRef] = data[lastKey];
        }
      }
    }
    if (Utils.isEmpty(data)) {
      return null;
    } else {
      return data;
    }
  };

  Parser.prototype.getRealCurrentLineNb = function () {
    return this.currentLineNb + this.offset;
  };

  Parser.prototype.getCurrentLineIndentation = function () {
    return this.currentLine.length - Utils.ltrim(this.currentLine, ' ').length;
  };

  Parser.prototype.getNextEmbedBlock = function (indentation, includeUnindentedCollection) {
    var data, indent, isItUnindentedCollection, newIndent, removeComments, removeCommentsPattern, unindentedEmbedBlock;
    if (indentation == null) {
      indentation = null;
    }
    if (includeUnindentedCollection == null) {
      includeUnindentedCollection = false;
    }
    this.moveToNextLine();
    if (indentation == null) {
      newIndent = this.getCurrentLineIndentation();
      unindentedEmbedBlock = this.isStringUnIndentedCollectionItem(this.currentLine);
      if (!this.isCurrentLineEmpty() && 0 === newIndent && !unindentedEmbedBlock) {
        throw new ParseException('Indentation problem.', this.getRealCurrentLineNb() + 1, this.currentLine);
      }
    } else {
      newIndent = indentation;
    }
    data = [this.currentLine.slice(newIndent)];
    if (!includeUnindentedCollection) {
      isItUnindentedCollection = this.isStringUnIndentedCollectionItem(this.currentLine);
    }
    removeCommentsPattern = this.PATTERN_FOLDED_SCALAR_END;
    removeComments = !removeCommentsPattern.test(this.currentLine);
    while (this.moveToNextLine()) {
      indent = this.getCurrentLineIndentation();
      if (indent === newIndent) {
        removeComments = !removeCommentsPattern.test(this.currentLine);
      }
      if (removeComments && this.isCurrentLineComment()) {
        continue;
      }
      if (this.isCurrentLineBlank()) {
        data.push(this.currentLine.slice(newIndent));
        continue;
      }
      if (isItUnindentedCollection && !this.isStringUnIndentedCollectionItem(this.currentLine) && indent === newIndent) {
        this.moveToPreviousLine();
        break;
      }
      if (indent >= newIndent) {
        data.push(this.currentLine.slice(newIndent));
      } else if (Utils.ltrim(this.currentLine).charAt(0) === '#') {} else if (0 === indent) {
        this.moveToPreviousLine();
        break;
      } else {
        throw new ParseException('Indentation problem.', this.getRealCurrentLineNb() + 1, this.currentLine);
      }
    }
    return data.join("\n");
  };

  Parser.prototype.moveToNextLine = function () {
    if (this.currentLineNb >= this.lines.length - 1) {
      return false;
    }
    this.currentLine = this.lines[++this.currentLineNb];
    return true;
  };

  Parser.prototype.moveToPreviousLine = function () {
    this.currentLine = this.lines[--this.currentLineNb];
  };

  Parser.prototype.parseValue = function (value, exceptionOnInvalidType, objectDecoder) {
    var e, foldedIndent, matches, modifiers, pos, ref, ref1, val;
    if (0 === value.indexOf('*')) {
      pos = value.indexOf('#');
      if (pos !== -1) {
        value = value.substr(1, pos - 2);
      } else {
        value = value.slice(1);
      }
      if (this.refs[value] === void 0) {
        throw new ParseException('Reference "' + value + '" does not exist.', this.currentLine);
      }
      return this.refs[value];
    }
    if (matches = this.PATTERN_FOLDED_SCALAR_ALL.exec(value)) {
      modifiers = (ref = matches.modifiers) != null ? ref : '';
      foldedIndent = Math.abs(parseInt(modifiers));
      if (isNaN(foldedIndent)) {
        foldedIndent = 0;
      }
      val = this.parseFoldedScalar(matches.separator, this.PATTERN_DECIMAL.replace(modifiers, ''), foldedIndent);
      if (matches.type != null) {
        Inline.configure(exceptionOnInvalidType, objectDecoder);
        return Inline.parseScalar(matches.type + ' ' + val);
      } else {
        return val;
      }
    }
    if ((ref1 = value.charAt(0)) === '[' || ref1 === '{' || ref1 === '"' || ref1 === "'") {
      while (true) {
        try {
          return Inline.parse(value, exceptionOnInvalidType, objectDecoder);
        } catch (error) {
          e = error;
          if (e instanceof ParseMore && this.moveToNextLine()) {
            value += "\n" + Utils.trim(this.currentLine, ' ');
          } else {
            e.parsedLine = this.getRealCurrentLineNb() + 1;
            e.snippet = this.currentLine;
            throw e;
          }
        }
      }
    } else {
      if (this.isNextLineIndented()) {
        value += "\n" + this.getNextEmbedBlock();
      }
      return Inline.parse(value, exceptionOnInvalidType, objectDecoder);
    }
  };

  Parser.prototype.parseFoldedScalar = function (separator, indicator, indentation) {
    var isCurrentLineBlank, j, len, line, matches, newText, notEOF, pattern, ref, text;
    if (indicator == null) {
      indicator = '';
    }
    if (indentation == null) {
      indentation = 0;
    }
    notEOF = this.moveToNextLine();
    if (!notEOF) {
      return '';
    }
    isCurrentLineBlank = this.isCurrentLineBlank();
    text = '';
    while (notEOF && isCurrentLineBlank) {
      if (notEOF = this.moveToNextLine()) {
        text += "\n";
        isCurrentLineBlank = this.isCurrentLineBlank();
      }
    }
    if (0 === indentation) {
      if (matches = this.PATTERN_INDENT_SPACES.exec(this.currentLine)) {
        indentation = matches[0].length;
      }
    }
    if (indentation > 0) {
      pattern = this.PATTERN_FOLDED_SCALAR_BY_INDENTATION[indentation];
      if (pattern == null) {
        pattern = new Pattern('^ {' + indentation + '}(.*)$');
        Parser.prototype.PATTERN_FOLDED_SCALAR_BY_INDENTATION[indentation] = pattern;
      }
      while (notEOF && (isCurrentLineBlank || (matches = pattern.exec(this.currentLine)))) {
        if (isCurrentLineBlank) {
          text += this.currentLine.slice(indentation);
        } else {
          text += matches[1];
        }
        if (notEOF = this.moveToNextLine()) {
          text += "\n";
          isCurrentLineBlank = this.isCurrentLineBlank();
        }
      }
    } else if (notEOF) {
      text += "\n";
    }
    if (notEOF) {
      this.moveToPreviousLine();
    }
    if ('>' === separator) {
      newText = '';
      ref = text.split("\n");
      for (j = 0, len = ref.length; j < len; j++) {
        line = ref[j];
        if (line.length === 0 || line.charAt(0) === ' ') {
          newText = Utils.rtrim(newText, ' ') + line + "\n";
        } else {
          newText += line + ' ';
        }
      }
      text = newText;
    }
    if ('+' !== indicator) {
      text = Utils.rtrim(text);
    }
    if ('' === indicator) {
      text = this.PATTERN_TRAILING_LINES.replace(text, "\n");
    } else if ('-' === indicator) {
      text = this.PATTERN_TRAILING_LINES.replace(text, '');
    }
    return text;
  };

  Parser.prototype.isNextLineIndented = function (ignoreComments) {
    var EOF, currentIndentation, ret;
    if (ignoreComments == null) {
      ignoreComments = true;
    }
    currentIndentation = this.getCurrentLineIndentation();
    EOF = !this.moveToNextLine();
    if (ignoreComments) {
      while (!EOF && this.isCurrentLineEmpty()) {
        EOF = !this.moveToNextLine();
      }
    } else {
      while (!EOF && this.isCurrentLineBlank()) {
        EOF = !this.moveToNextLine();
      }
    }
    if (EOF) {
      return false;
    }
    ret = false;
    if (this.getCurrentLineIndentation() > currentIndentation) {
      ret = true;
    }
    this.moveToPreviousLine();
    return ret;
  };

  Parser.prototype.isCurrentLineEmpty = function () {
    var trimmedLine;
    trimmedLine = Utils.trim(this.currentLine, ' ');
    return trimmedLine.length === 0 || trimmedLine.charAt(0) === '#';
  };

  Parser.prototype.isCurrentLineBlank = function () {
    return '' === Utils.trim(this.currentLine, ' ');
  };

  Parser.prototype.isCurrentLineComment = function () {
    var ltrimmedLine;
    ltrimmedLine = Utils.ltrim(this.currentLine, ' ');
    return ltrimmedLine.charAt(0) === '#';
  };

  Parser.prototype.cleanup = function (value) {
    var count, i, indent, j, l, len, len1, line, lines, ref, ref1, ref2, smallestIndent, trimmedValue;
    if (value.indexOf("\r") !== -1) {
      value = value.split("\r\n").join("\n").split("\r").join("\n");
    }
    count = 0;
    ref = this.PATTERN_YAML_HEADER.replaceAll(value, ''), value = ref[0], count = ref[1];
    this.offset += count;
    ref1 = this.PATTERN_LEADING_COMMENTS.replaceAll(value, '', 1), trimmedValue = ref1[0], count = ref1[1];
    if (count === 1) {
      this.offset += Utils.subStrCount(value, "\n") - Utils.subStrCount(trimmedValue, "\n");
      value = trimmedValue;
    }
    ref2 = this.PATTERN_DOCUMENT_MARKER_START.replaceAll(value, '', 1), trimmedValue = ref2[0], count = ref2[1];
    if (count === 1) {
      this.offset += Utils.subStrCount(value, "\n") - Utils.subStrCount(trimmedValue, "\n");
      value = trimmedValue;
      value = this.PATTERN_DOCUMENT_MARKER_END.replace(value, '');
    }
    lines = value.split("\n");
    smallestIndent = -1;
    for (j = 0, len = lines.length; j < len; j++) {
      line = lines[j];
      if (Utils.trim(line, ' ').length === 0) {
        continue;
      }
      indent = line.length - Utils.ltrim(line).length;
      if (smallestIndent === -1 || indent < smallestIndent) {
        smallestIndent = indent;
      }
    }
    if (smallestIndent > 0) {
      for (i = l = 0, len1 = lines.length; l < len1; i = ++l) {
        line = lines[i];
        lines[i] = line.slice(smallestIndent);
      }
      value = lines.join("\n");
    }
    return value;
  };

  Parser.prototype.isNextLineUnIndentedCollection = function (currentIndentation) {
    var notEOF, ret;
    if (currentIndentation == null) {
      currentIndentation = null;
    }
    if (currentIndentation == null) {
      currentIndentation = this.getCurrentLineIndentation();
    }
    notEOF = this.moveToNextLine();
    while (notEOF && this.isCurrentLineEmpty()) {
      notEOF = this.moveToNextLine();
    }
    if (false === notEOF) {
      return false;
    }
    ret = false;
    if (this.getCurrentLineIndentation() === currentIndentation && this.isStringUnIndentedCollectionItem(this.currentLine)) {
      ret = true;
    }
    this.moveToPreviousLine();
    return ret;
  };

  Parser.prototype.isStringUnIndentedCollectionItem = function () {
    return this.currentLine === '-' || this.currentLine.slice(0, 2) === '- ';
  };

  return Parser;
}();

module.exports = Parser;

},{"./Exception/ParseException":125,"./Exception/ParseMore":126,"./Inline":127,"./Pattern":129,"./Utils":131,"babel-runtime/helpers/typeof":16}],129:[function(require,module,exports){
'use strict';

// Generated by CoffeeScript 1.12.4
var Pattern;

Pattern = function () {
  Pattern.prototype.regex = null;

  Pattern.prototype.rawRegex = null;

  Pattern.prototype.cleanedRegex = null;

  Pattern.prototype.mapping = null;

  function Pattern(rawRegex, modifiers) {
    var _char, capturingBracketNumber, cleanedRegex, i, len, mapping, name, part, subChar;
    if (modifiers == null) {
      modifiers = '';
    }
    cleanedRegex = '';
    len = rawRegex.length;
    mapping = null;
    capturingBracketNumber = 0;
    i = 0;
    while (i < len) {
      _char = rawRegex.charAt(i);
      if (_char === '\\') {
        cleanedRegex += rawRegex.slice(i, +(i + 1) + 1 || 9e9);
        i++;
      } else if (_char === '(') {
        if (i < len - 2) {
          part = rawRegex.slice(i, +(i + 2) + 1 || 9e9);
          if (part === '(?:') {
            i += 2;
            cleanedRegex += part;
          } else if (part === '(?<') {
            capturingBracketNumber++;
            i += 2;
            name = '';
            while (i + 1 < len) {
              subChar = rawRegex.charAt(i + 1);
              if (subChar === '>') {
                cleanedRegex += '(';
                i++;
                if (name.length > 0) {
                  if (mapping == null) {
                    mapping = {};
                  }
                  mapping[name] = capturingBracketNumber;
                }
                break;
              } else {
                name += subChar;
              }
              i++;
            }
          } else {
            cleanedRegex += _char;
            capturingBracketNumber++;
          }
        } else {
          cleanedRegex += _char;
        }
      } else {
        cleanedRegex += _char;
      }
      i++;
    }
    this.rawRegex = rawRegex;
    this.cleanedRegex = cleanedRegex;
    this.regex = new RegExp(this.cleanedRegex, 'g' + modifiers.replace('g', ''));
    this.mapping = mapping;
  }

  Pattern.prototype.exec = function (str) {
    var index, matches, name, ref;
    this.regex.lastIndex = 0;
    matches = this.regex.exec(str);
    if (matches == null) {
      return null;
    }
    if (this.mapping != null) {
      ref = this.mapping;
      for (name in ref) {
        index = ref[name];
        matches[name] = matches[index];
      }
    }
    return matches;
  };

  Pattern.prototype.test = function (str) {
    this.regex.lastIndex = 0;
    return this.regex.test(str);
  };

  Pattern.prototype.replace = function (str, replacement) {
    this.regex.lastIndex = 0;
    return str.replace(this.regex, replacement);
  };

  Pattern.prototype.replaceAll = function (str, replacement, limit) {
    var count;
    if (limit == null) {
      limit = 0;
    }
    this.regex.lastIndex = 0;
    count = 0;
    while (this.regex.test(str) && (limit === 0 || count < limit)) {
      this.regex.lastIndex = 0;
      str = str.replace(this.regex, replacement);
      count++;
    }
    return [str, count];
  };

  return Pattern;
}();

module.exports = Pattern;

},{}],130:[function(require,module,exports){
'use strict';

// Generated by CoffeeScript 1.12.4
var Pattern, Unescaper, Utils;

Utils = require('./Utils');

Pattern = require('./Pattern');

Unescaper = function () {
  function Unescaper() {}

  Unescaper.PATTERN_ESCAPED_CHARACTER = new Pattern('\\\\([0abt\tnvfre "\\/\\\\N_LP]|x[0-9a-fA-F]{2}|u[0-9a-fA-F]{4}|U[0-9a-fA-F]{8})');

  Unescaper.unescapeSingleQuotedString = function (value) {
    return value.replace(/\'\'/g, '\'');
  };

  Unescaper.unescapeDoubleQuotedString = function (value) {
    if (this._unescapeCallback == null) {
      this._unescapeCallback = function (_this) {
        return function (str) {
          return _this.unescapeCharacter(str);
        };
      }(this);
    }
    return this.PATTERN_ESCAPED_CHARACTER.replace(value, this._unescapeCallback);
  };

  Unescaper.unescapeCharacter = function (value) {
    var ch;
    ch = String.fromCharCode;
    switch (value.charAt(1)) {
      case '0':
        return ch(0);
      case 'a':
        return ch(7);
      case 'b':
        return ch(8);
      case 't':
        return "\t";
      case "\t":
        return "\t";
      case 'n':
        return "\n";
      case 'v':
        return ch(11);
      case 'f':
        return ch(12);
      case 'r':
        return ch(13);
      case 'e':
        return ch(27);
      case ' ':
        return ' ';
      case '"':
        return '"';
      case '/':
        return '/';
      case '\\':
        return '\\';
      case 'N':
        return ch(0x0085);
      case '_':
        return ch(0x00A0);
      case 'L':
        return ch(0x2028);
      case 'P':
        return ch(0x2029);
      case 'x':
        return Utils.utf8chr(Utils.hexDec(value.substr(2, 2)));
      case 'u':
        return Utils.utf8chr(Utils.hexDec(value.substr(2, 4)));
      case 'U':
        return Utils.utf8chr(Utils.hexDec(value.substr(2, 8)));
      default:
        return '';
    }
  };

  return Unescaper;
}();

module.exports = Unescaper;

},{"./Pattern":129,"./Utils":131}],131:[function(require,module,exports){
'use strict';

// Generated by CoffeeScript 1.12.4
var Pattern,
    Utils,
    hasProp = {}.hasOwnProperty;

Pattern = require('./Pattern');

Utils = function () {
  function Utils() {}

  Utils.REGEX_LEFT_TRIM_BY_CHAR = {};

  Utils.REGEX_RIGHT_TRIM_BY_CHAR = {};

  Utils.REGEX_SPACES = /\s+/g;

  Utils.REGEX_DIGITS = /^\d+$/;

  Utils.REGEX_OCTAL = /[^0-7]/gi;

  Utils.REGEX_HEXADECIMAL = /[^a-f0-9]/gi;

  Utils.PATTERN_DATE = new Pattern('^' + '(?<year>[0-9][0-9][0-9][0-9])' + '-(?<month>[0-9][0-9]?)' + '-(?<day>[0-9][0-9]?)' + '(?:(?:[Tt]|[ \t]+)' + '(?<hour>[0-9][0-9]?)' + ':(?<minute>[0-9][0-9])' + ':(?<second>[0-9][0-9])' + '(?:\.(?<fraction>[0-9]*))?' + '(?:[ \t]*(?<tz>Z|(?<tz_sign>[-+])(?<tz_hour>[0-9][0-9]?)' + '(?::(?<tz_minute>[0-9][0-9]))?))?)?' + '$', 'i');

  Utils.LOCAL_TIMEZONE_OFFSET = new Date().getTimezoneOffset() * 60 * 1000;

  Utils.trim = function (str, _char) {
    var regexLeft, regexRight;
    if (_char == null) {
      _char = '\\s';
    }
    regexLeft = this.REGEX_LEFT_TRIM_BY_CHAR[_char];
    if (regexLeft == null) {
      this.REGEX_LEFT_TRIM_BY_CHAR[_char] = regexLeft = new RegExp('^' + _char + '' + _char + '*');
    }
    regexLeft.lastIndex = 0;
    regexRight = this.REGEX_RIGHT_TRIM_BY_CHAR[_char];
    if (regexRight == null) {
      this.REGEX_RIGHT_TRIM_BY_CHAR[_char] = regexRight = new RegExp(_char + '' + _char + '*$');
    }
    regexRight.lastIndex = 0;
    return str.replace(regexLeft, '').replace(regexRight, '');
  };

  Utils.ltrim = function (str, _char) {
    var regexLeft;
    if (_char == null) {
      _char = '\\s';
    }
    regexLeft = this.REGEX_LEFT_TRIM_BY_CHAR[_char];
    if (regexLeft == null) {
      this.REGEX_LEFT_TRIM_BY_CHAR[_char] = regexLeft = new RegExp('^' + _char + '' + _char + '*');
    }
    regexLeft.lastIndex = 0;
    return str.replace(regexLeft, '');
  };

  Utils.rtrim = function (str, _char) {
    var regexRight;
    if (_char == null) {
      _char = '\\s';
    }
    regexRight = this.REGEX_RIGHT_TRIM_BY_CHAR[_char];
    if (regexRight == null) {
      this.REGEX_RIGHT_TRIM_BY_CHAR[_char] = regexRight = new RegExp(_char + '' + _char + '*$');
    }
    regexRight.lastIndex = 0;
    return str.replace(regexRight, '');
  };

  Utils.isEmpty = function (value) {
    return !value || value === '' || value === '0' || value instanceof Array && value.length === 0 || this.isEmptyObject(value);
  };

  Utils.isEmptyObject = function (value) {
    var k;
    return value instanceof Object && function () {
      var results;
      results = [];
      for (k in value) {
        if (!hasProp.call(value, k)) continue;
        results.push(k);
      }
      return results;
    }().length === 0;
  };

  Utils.subStrCount = function (string, subString, start, length) {
    var c, i, j, len, ref, sublen;
    c = 0;
    string = '' + string;
    subString = '' + subString;
    if (start != null) {
      string = string.slice(start);
    }
    if (length != null) {
      string = string.slice(0, length);
    }
    len = string.length;
    sublen = subString.length;
    for (i = j = 0, ref = len; 0 <= ref ? j < ref : j > ref; i = 0 <= ref ? ++j : --j) {
      if (subString === string.slice(i, sublen)) {
        c++;
        i += sublen - 1;
      }
    }
    return c;
  };

  Utils.isDigits = function (input) {
    this.REGEX_DIGITS.lastIndex = 0;
    return this.REGEX_DIGITS.test(input);
  };

  Utils.octDec = function (input) {
    this.REGEX_OCTAL.lastIndex = 0;
    return parseInt((input + '').replace(this.REGEX_OCTAL, ''), 8);
  };

  Utils.hexDec = function (input) {
    this.REGEX_HEXADECIMAL.lastIndex = 0;
    input = this.trim(input);
    if ((input + '').slice(0, 2) === '0x') {
      input = (input + '').slice(2);
    }
    return parseInt((input + '').replace(this.REGEX_HEXADECIMAL, ''), 16);
  };

  Utils.utf8chr = function (c) {
    var ch;
    ch = String.fromCharCode;
    if (0x80 > (c %= 0x200000)) {
      return ch(c);
    }
    if (0x800 > c) {
      return ch(0xC0 | c >> 6) + ch(0x80 | c & 0x3F);
    }
    if (0x10000 > c) {
      return ch(0xE0 | c >> 12) + ch(0x80 | c >> 6 & 0x3F) + ch(0x80 | c & 0x3F);
    }
    return ch(0xF0 | c >> 18) + ch(0x80 | c >> 12 & 0x3F) + ch(0x80 | c >> 6 & 0x3F) + ch(0x80 | c & 0x3F);
  };

  Utils.parseBoolean = function (input, strict) {
    var lowerInput;
    if (strict == null) {
      strict = true;
    }
    if (typeof input === 'string') {
      lowerInput = input.toLowerCase();
      if (!strict) {
        if (lowerInput === 'no') {
          return false;
        }
      }
      if (lowerInput === '0') {
        return false;
      }
      if (lowerInput === 'false') {
        return false;
      }
      if (lowerInput === '') {
        return false;
      }
      return true;
    }
    return !!input;
  };

  Utils.isNumeric = function (input) {
    this.REGEX_SPACES.lastIndex = 0;
    return typeof input === 'number' || typeof input === 'string' && !isNaN(input) && input.replace(this.REGEX_SPACES, '') !== '';
  };

  Utils.stringToDate = function (str) {
    var date, day, fraction, hour, info, minute, month, second, tz_hour, tz_minute, tz_offset, year;
    if (!(str != null ? str.length : void 0)) {
      return null;
    }
    info = this.PATTERN_DATE.exec(str);
    if (!info) {
      return null;
    }
    year = parseInt(info.year, 10);
    month = parseInt(info.month, 10) - 1;
    day = parseInt(info.day, 10);
    if (info.hour == null) {
      date = new Date(Date.UTC(year, month, day));
      return date;
    }
    hour = parseInt(info.hour, 10);
    minute = parseInt(info.minute, 10);
    second = parseInt(info.second, 10);
    if (info.fraction != null) {
      fraction = info.fraction.slice(0, 3);
      while (fraction.length < 3) {
        fraction += '0';
      }
      fraction = parseInt(fraction, 10);
    } else {
      fraction = 0;
    }
    if (info.tz != null) {
      tz_hour = parseInt(info.tz_hour, 10);
      if (info.tz_minute != null) {
        tz_minute = parseInt(info.tz_minute, 10);
      } else {
        tz_minute = 0;
      }
      tz_offset = (tz_hour * 60 + tz_minute) * 60000;
      if ('-' === info.tz_sign) {
        tz_offset *= -1;
      }
    }
    date = new Date(Date.UTC(year, month, day, hour, minute, second, fraction));
    if (tz_offset) {
      date.setTime(date.getTime() - tz_offset);
    }
    return date;
  };

  Utils.strRepeat = function (str, number) {
    var i, res;
    res = '';
    i = 0;
    while (i < number) {
      res += str;
      i++;
    }
    return res;
  };

  Utils.getStringFromFile = function (path, callback) {
    var data, fs, j, len1, name, ref, req, xhr;
    if (callback == null) {
      callback = null;
    }
    xhr = null;
    if (typeof window !== "undefined" && window !== null) {
      if (window.XMLHttpRequest) {
        xhr = new XMLHttpRequest();
      } else if (window.ActiveXObject) {
        ref = ["Msxml2.XMLHTTP.6.0", "Msxml2.XMLHTTP.3.0", "Msxml2.XMLHTTP", "Microsoft.XMLHTTP"];
        for (j = 0, len1 = ref.length; j < len1; j++) {
          name = ref[j];
          try {
            xhr = new ActiveXObject(name);
          } catch (error) {}
        }
      }
    }
    if (xhr != null) {
      if (callback != null) {
        xhr.onreadystatechange = function () {
          if (xhr.readyState === 4) {
            if (xhr.status === 200 || xhr.status === 0) {
              return callback(xhr.responseText);
            } else {
              return callback(null);
            }
          }
        };
        xhr.open('GET', path, true);
        return xhr.send(null);
      } else {
        xhr.open('GET', path, false);
        xhr.send(null);
        if (xhr.status === 200 || xhr.status === 0) {
          return xhr.responseText;
        }
        return null;
      }
    } else {
      req = require;
      fs = req('fs');
      if (callback != null) {
        return fs.readFile(path, function (err, data) {
          if (err) {
            return callback(null);
          } else {
            return callback(String(data));
          }
        });
      } else {
        data = fs.readFileSync(path);
        if (data != null) {
          return String(data);
        }
        return null;
      }
    }
  };

  return Utils;
}();

module.exports = Utils;

},{"./Pattern":129}],132:[function(require,module,exports){
'use strict';

// Generated by CoffeeScript 1.12.4
var Dumper, Parser, Utils, Yaml;

Parser = require('./Parser');

Dumper = require('./Dumper');

Utils = require('./Utils');

Yaml = function () {
  function Yaml() {}

  Yaml.parse = function (input, exceptionOnInvalidType, objectDecoder) {
    if (exceptionOnInvalidType == null) {
      exceptionOnInvalidType = false;
    }
    if (objectDecoder == null) {
      objectDecoder = null;
    }
    return new Parser().parse(input, exceptionOnInvalidType, objectDecoder);
  };

  Yaml.parseFile = function (path, callback, exceptionOnInvalidType, objectDecoder) {
    var input;
    if (callback == null) {
      callback = null;
    }
    if (exceptionOnInvalidType == null) {
      exceptionOnInvalidType = false;
    }
    if (objectDecoder == null) {
      objectDecoder = null;
    }
    if (callback != null) {
      return Utils.getStringFromFile(path, function (_this) {
        return function (input) {
          var result;
          result = null;
          if (input != null) {
            result = _this.parse(input, exceptionOnInvalidType, objectDecoder);
          }
          callback(result);
        };
      }(this));
    } else {
      input = Utils.getStringFromFile(path);
      if (input != null) {
        return this.parse(input, exceptionOnInvalidType, objectDecoder);
      }
      return null;
    }
  };

  Yaml.dump = function (input, inline, indent, exceptionOnInvalidType, objectEncoder) {
    var yaml;
    if (inline == null) {
      inline = 2;
    }
    if (indent == null) {
      indent = 4;
    }
    if (exceptionOnInvalidType == null) {
      exceptionOnInvalidType = false;
    }
    if (objectEncoder == null) {
      objectEncoder = null;
    }
    yaml = new Dumper();
    yaml.indentation = indent;
    return yaml.dump(input, inline, 0, exceptionOnInvalidType, objectEncoder);
  };

  Yaml.stringify = function (input, inline, indent, exceptionOnInvalidType, objectEncoder) {
    return this.dump(input, inline, indent, exceptionOnInvalidType, objectEncoder);
  };

  Yaml.load = function (path, callback, exceptionOnInvalidType, objectDecoder) {
    return this.parseFile(path, callback, exceptionOnInvalidType, objectDecoder);
  };

  return Yaml;
}();

if (typeof window !== "undefined" && window !== null) {
  window.YAML = Yaml;
}

if (typeof window === "undefined" || window === null) {
  undefined.YAML = Yaml;
}

module.exports = Yaml;

},{"./Dumper":122,"./Parser":128,"./Utils":131}],133:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
function base10_to_base64(num) {
  var order = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_-';
  var base = order.length;
  var str = '',
      r;
  while (num) {
    r = num % base;
    num -= r;
    num /= base;
    str = order.charAt(r) + str;
  }
  return str;
}

exports.default = base10_to_base64;

},{}],134:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stringify = require('babel-runtime/core-js/json/stringify');

var _stringify2 = _interopRequireDefault(_stringify);

var _typeof2 = require('babel-runtime/helpers/typeof');

var _typeof3 = _interopRequireDefault(_typeof2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// https://github.com/userpixel/micromustache/blob/master/lib/render.js

/**
 * @callback ResolverFn
 * @param {string} varName - variable name before being parsed.
 *        For example: {a.b.c} ->  'a.b.c', {  x  } -> 'x'
 * @param {Object} view - the view object that was passed to .render() function
 * @returns {string|number|boolean|Object|undefined} the value to be
 *        interpolated. If the function returns undefined, the value resolution
 *        algorithm will go ahead with the default behaviour (resolving the
 *        variable name from the provided object).
 */

var VAR_MATCH_REGEX = /\{\{\s*(.*?)\s*\}\}/g;

function _valueToString(value) {
  switch (typeof value === 'undefined' ? 'undefined' : (0, _typeof3.default)(value)) {
    case 'string':
    case 'number':
    case 'boolean':
      return value;
    case 'object':
      try {
        // null is an object but is falsy. Swallow it.
        return value === null ? '' : (0, _stringify2.default)(value);
      } catch (jsonError) {
        return '{...}';
      }
    default:
      // Anything else will be replaced with an empty string
      // For example: undefined, Symbol, etc.
      return '';
  }
}

/**
 * Recursively goes through an object trying to resolve a path.
 *
 * @param {Object} scope - The object to traverse (in each recursive call we dig into this object)
 * @param {string[]} path - An array of property names to traverse one-by-one
 * @param {number} [pathIndex=0] - The current index in the path array
 */
function _recursivePathResolver(scope, path) {
  var pathIndex = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;

  if ((typeof scope === 'undefined' ? 'undefined' : (0, _typeof3.default)(scope)) !== 'object' || scope === null || scope === undefined) {
    return '';
  }

  var varName = path[pathIndex];
  var value = scope[varName];

  if (pathIndex === path.length - 1) {
    // It's a leaf, return whatever it is
    return value;
  }

  return _recursivePathResolver(value, path, ++pathIndex);
}

function defaultResolver(varName, view) {
  return _recursivePathResolver(view, varName.split('.'));
}

/**
 * Replaces every {{variable}} inside the template with values provided by view.
 *
 * @param {string} template - The template containing one or more {{variableNames}} every variable
 *        names that is used in the template. If it's omitted, it'll be assumed an empty object.
 * @param {Object} [view={}] - An object containing values for every variable names that is used in
 *        the template. If it's omitted, it'll be set to an empty object essentially removing all
 *        {{varName}}s in the template.
 * @param {ResolverFn} [resolver] - An optional function that will be
 *        called for every {{varName}} to generate a value. If the resolver throws an error
 *        we'll proceed with the default value resolution algorithm (find the value from the view
 *        object).
 * @returns {string} - Template where its variable names replaced with
 *        corresponding values. If a value is not found or is invalid, it will
 *        be assumed empty string ''. If the value is an object itself, it'll
 *        be stringified by JSON.
 *        In case of a JSON stringify error the result will look like "{...}".
 */
function render(template) {
  var view = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var resolver = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : defaultResolver;

  // don't touch the template if it is not a string
  if (typeof template !== 'string') {
    return template;
  }

  return template.replace(VAR_MATCH_REGEX, function (match, varName) {
    try {
      // defaultResolver never throws
      return _valueToString(resolver(varName, view));
    } catch (e) {
      // if your resolver throws, we proceed with the default resolver
      return _valueToString(defaultResolver(varName, view));
    }
  });
}

exports.default = render;

},{"babel-runtime/core-js/json/stringify":1,"babel-runtime/helpers/typeof":16}],135:[function(require,module,exports){
'use strict';

var _assign = require('babel-runtime/core-js/object/assign');

var _assign2 = _interopRequireDefault(_assign);

var _Actions = require('./Actions');

var _Actions2 = _interopRequireDefault(_Actions);

var _List = require('./List');

var _List2 = _interopRequireDefault(_List);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Created by Tamer on 19/10/2017.
 */

Stage.defineWidget({
  id: 'visual-input',
  name: 'Visualization Deployment Creation Input',
  description: 'Visualization Deployment Creation Input Widget',
  initialWidth: 12,
  initialHeight: 16,
  color: 'purple',
  hasStyle: true,
  isReact: true,

  permission: Stage.GenericConfig.CUSTOM_WIDGET_PERMISSIONS.CUSTOM_ALL,
  categories: [Stage.GenericConfig.CATEGORY.SYSTEM_RESOURCES],

  initialConfiguration: [{ id: 'blueprintId', name: 'Blueprint Id', default: 'request', type: Stage.Basic.GenericField.STRING }, { id: 'allowNameEdit', name: 'Allow User to change Deployment Name', default: true, type: Stage.Basic.GenericField.BOOLEAN_TYPE }, { id: 'onFinishRedirect', name: 'Redirect to Page on finish', default: false, type: Stage.Basic.GenericField.BOOLEAN_TYPE }, { id: 'template', name: 'Template to Redirect to, after finish', default: 'deployment', type: Stage.Basic.GenericField.STRING_TYPE }],

  fetchData: function fetchData(widget, toolbox, params) {
    var actions = new _Actions2.default((0, _assign2.default)({ toolbox: toolbox }, widget.configuration));

    return actions.doGetInputDescriptor();
  },


  render: function render(widget, data, error, toolbox) {

    if (_.isEmpty(data)) {
      return React.createElement(Stage.Basic.Loading, null);
    }

    var actions = new _Actions2.default((0, _assign2.default)({ toolbox: toolbox }, widget.configuration));

    return React.createElement(_List2.default, {
      widget: widget,
      data: data,
      toolbox: toolbox,
      actions: actions
    });
  }
});

},{"./Actions":118,"./List":119,"babel-runtime/core-js/object/assign":2}]},{},[118,120,119,133,134,121,122,123,124,125,126,127,128,129,130,131,132,135])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJub2RlX21vZHVsZXMvYmFiZWwtcnVudGltZS9jb3JlLWpzL2pzb24vc3RyaW5naWZ5LmpzIiwibm9kZV9tb2R1bGVzL2JhYmVsLXJ1bnRpbWUvY29yZS1qcy9vYmplY3QvYXNzaWduLmpzIiwibm9kZV9tb2R1bGVzL2JhYmVsLXJ1bnRpbWUvY29yZS1qcy9vYmplY3QvY3JlYXRlLmpzIiwibm9kZV9tb2R1bGVzL2JhYmVsLXJ1bnRpbWUvY29yZS1qcy9vYmplY3QvZGVmaW5lLXByb3BlcnR5LmpzIiwibm9kZV9tb2R1bGVzL2JhYmVsLXJ1bnRpbWUvY29yZS1qcy9vYmplY3QvZ2V0LXByb3RvdHlwZS1vZi5qcyIsIm5vZGVfbW9kdWxlcy9iYWJlbC1ydW50aW1lL2NvcmUtanMvb2JqZWN0L2tleXMuanMiLCJub2RlX21vZHVsZXMvYmFiZWwtcnVudGltZS9jb3JlLWpzL29iamVjdC9zZXQtcHJvdG90eXBlLW9mLmpzIiwibm9kZV9tb2R1bGVzL2JhYmVsLXJ1bnRpbWUvY29yZS1qcy9wcm9taXNlLmpzIiwibm9kZV9tb2R1bGVzL2JhYmVsLXJ1bnRpbWUvY29yZS1qcy9zeW1ib2wuanMiLCJub2RlX21vZHVsZXMvYmFiZWwtcnVudGltZS9jb3JlLWpzL3N5bWJvbC9pdGVyYXRvci5qcyIsIm5vZGVfbW9kdWxlcy9iYWJlbC1ydW50aW1lL2hlbHBlcnMvY2xhc3NDYWxsQ2hlY2suanMiLCJub2RlX21vZHVsZXMvYmFiZWwtcnVudGltZS9oZWxwZXJzL2NyZWF0ZUNsYXNzLmpzIiwibm9kZV9tb2R1bGVzL2JhYmVsLXJ1bnRpbWUvaGVscGVycy9kZWZpbmVQcm9wZXJ0eS5qcyIsIm5vZGVfbW9kdWxlcy9iYWJlbC1ydW50aW1lL2hlbHBlcnMvaW5oZXJpdHMuanMiLCJub2RlX21vZHVsZXMvYmFiZWwtcnVudGltZS9oZWxwZXJzL3Bvc3NpYmxlQ29uc3RydWN0b3JSZXR1cm4uanMiLCJub2RlX21vZHVsZXMvYmFiZWwtcnVudGltZS9oZWxwZXJzL3R5cGVvZi5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvZm4vanNvbi9zdHJpbmdpZnkuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L2ZuL29iamVjdC9hc3NpZ24uanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L2ZuL29iamVjdC9jcmVhdGUuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L2ZuL29iamVjdC9kZWZpbmUtcHJvcGVydHkuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L2ZuL29iamVjdC9nZXQtcHJvdG90eXBlLW9mLmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9mbi9vYmplY3Qva2V5cy5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvZm4vb2JqZWN0L3NldC1wcm90b3R5cGUtb2YuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L2ZuL3Byb21pc2UuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L2ZuL3N5bWJvbC9pbmRleC5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvZm4vc3ltYm9sL2l0ZXJhdG9yLmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL19hLWZ1bmN0aW9uLmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL19hZGQtdG8tdW5zY29wYWJsZXMuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX2FuLWluc3RhbmNlLmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL19hbi1vYmplY3QuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX2FycmF5LWluY2x1ZGVzLmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL19jbGFzc29mLmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL19jb2YuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX2NvcmUuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX2N0eC5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9fZGVmaW5lZC5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9fZGVzY3JpcHRvcnMuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX2RvbS1jcmVhdGUuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX2VudW0tYnVnLWtleXMuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX2VudW0ta2V5cy5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9fZXhwb3J0LmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL19mYWlscy5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9fZm9yLW9mLmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL19nbG9iYWwuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX2hhcy5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9faGlkZS5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9faHRtbC5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9faWU4LWRvbS1kZWZpbmUuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX2ludm9rZS5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9faW9iamVjdC5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9faXMtYXJyYXktaXRlci5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9faXMtYXJyYXkuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX2lzLW9iamVjdC5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9faXRlci1jYWxsLmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL19pdGVyLWNyZWF0ZS5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9faXRlci1kZWZpbmUuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX2l0ZXItZGV0ZWN0LmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL19pdGVyLXN0ZXAuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX2l0ZXJhdG9ycy5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9fbGlicmFyeS5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9fbWV0YS5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9fbWljcm90YXNrLmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL19uZXctcHJvbWlzZS1jYXBhYmlsaXR5LmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL19vYmplY3QtYXNzaWduLmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL19vYmplY3QtY3JlYXRlLmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL19vYmplY3QtZHAuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX29iamVjdC1kcHMuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX29iamVjdC1nb3BkLmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL19vYmplY3QtZ29wbi1leHQuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX29iamVjdC1nb3BuLmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL19vYmplY3QtZ29wcy5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9fb2JqZWN0LWdwby5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9fb2JqZWN0LWtleXMtaW50ZXJuYWwuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX29iamVjdC1rZXlzLmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL19vYmplY3QtcGllLmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL19vYmplY3Qtc2FwLmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL19wZXJmb3JtLmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL19wcm9taXNlLXJlc29sdmUuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX3Byb3BlcnR5LWRlc2MuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX3JlZGVmaW5lLWFsbC5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9fcmVkZWZpbmUuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX3NldC1wcm90by5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9fc2V0LXNwZWNpZXMuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX3NldC10by1zdHJpbmctdGFnLmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL19zaGFyZWQta2V5LmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL19zaGFyZWQuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX3NwZWNpZXMtY29uc3RydWN0b3IuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX3N0cmluZy1hdC5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9fdGFzay5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9fdG8tYWJzb2x1dGUtaW5kZXguanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX3RvLWludGVnZXIuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX3RvLWlvYmplY3QuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX3RvLWxlbmd0aC5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9fdG8tb2JqZWN0LmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL190by1wcmltaXRpdmUuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvX3VpZC5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9fdXNlci1hZ2VudC5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9fd2tzLWRlZmluZS5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9fd2tzLWV4dC5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9fd2tzLmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL2NvcmUuZ2V0LWl0ZXJhdG9yLW1ldGhvZC5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9lczYuYXJyYXkuaXRlcmF0b3IuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvZXM2Lm9iamVjdC5hc3NpZ24uanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvZXM2Lm9iamVjdC5jcmVhdGUuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvZXM2Lm9iamVjdC5kZWZpbmUtcHJvcGVydHkuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvZXM2Lm9iamVjdC5nZXQtcHJvdG90eXBlLW9mLmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL2VzNi5vYmplY3Qua2V5cy5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9lczYub2JqZWN0LnNldC1wcm90b3R5cGUtb2YuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvZXM2Lm9iamVjdC50by1zdHJpbmcuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvZXM2LnByb21pc2UuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvZXM2LnN0cmluZy5pdGVyYXRvci5qcyIsIm5vZGVfbW9kdWxlcy9jb3JlLWpzL2xpYnJhcnkvbW9kdWxlcy9lczYuc3ltYm9sLmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL2VzNy5wcm9taXNlLmZpbmFsbHkuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvZXM3LnByb21pc2UudHJ5LmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL2VzNy5zeW1ib2wuYXN5bmMtaXRlcmF0b3IuanMiLCJub2RlX21vZHVsZXMvY29yZS1qcy9saWJyYXJ5L21vZHVsZXMvZXM3LnN5bWJvbC5vYnNlcnZhYmxlLmpzIiwibm9kZV9tb2R1bGVzL2NvcmUtanMvbGlicmFyeS9tb2R1bGVzL3dlYi5kb20uaXRlcmFibGUuanMiLCJ3aWRnZXRzL3VzZXItZGVwbG95bWVudC1jcmVhdGlvbi13aWRnZXQvc3JjL0FjdGlvbnMuanMiLCJ3aWRnZXRzL3VzZXItZGVwbG95bWVudC1jcmVhdGlvbi13aWRnZXQvc3JjL0xpc3QuanMiLCJ3aWRnZXRzL3VzZXItZGVwbG95bWVudC1jcmVhdGlvbi13aWRnZXQvc3JjL2NvbXBvbmVudHMvU2VsZWN0Qm94LmpzIiwid2lkZ2V0cy91c2VyLWRlcGxveW1lbnQtY3JlYXRpb24td2lkZ2V0L3NyYy91dGlscy9ZQU1ML2luZGV4LmpzIiwid2lkZ2V0cy91c2VyLWRlcGxveW1lbnQtY3JlYXRpb24td2lkZ2V0L3NyYy91dGlscy9ZQU1ML2xpYi9EdW1wZXIuanMiLCJ3aWRnZXRzL3VzZXItZGVwbG95bWVudC1jcmVhdGlvbi13aWRnZXQvc3JjL3V0aWxzL1lBTUwvbGliL0VzY2FwZXIuanMiLCJ3aWRnZXRzL3VzZXItZGVwbG95bWVudC1jcmVhdGlvbi13aWRnZXQvc3JjL3V0aWxzL1lBTUwvbGliL0V4Y2VwdGlvbi9EdW1wRXhjZXB0aW9uLmpzIiwid2lkZ2V0cy91c2VyLWRlcGxveW1lbnQtY3JlYXRpb24td2lkZ2V0L3NyYy91dGlscy9ZQU1ML2xpYi9FeGNlcHRpb24vUGFyc2VFeGNlcHRpb24uanMiLCJ3aWRnZXRzL3VzZXItZGVwbG95bWVudC1jcmVhdGlvbi13aWRnZXQvc3JjL3V0aWxzL1lBTUwvbGliL0V4Y2VwdGlvbi9QYXJzZU1vcmUuanMiLCJ3aWRnZXRzL3VzZXItZGVwbG95bWVudC1jcmVhdGlvbi13aWRnZXQvc3JjL3V0aWxzL1lBTUwvbGliL0lubGluZS5qcyIsIndpZGdldHMvdXNlci1kZXBsb3ltZW50LWNyZWF0aW9uLXdpZGdldC9zcmMvdXRpbHMvWUFNTC9saWIvUGFyc2VyLmpzIiwid2lkZ2V0cy91c2VyLWRlcGxveW1lbnQtY3JlYXRpb24td2lkZ2V0L3NyYy91dGlscy9ZQU1ML2xpYi9QYXR0ZXJuLmpzIiwid2lkZ2V0cy91c2VyLWRlcGxveW1lbnQtY3JlYXRpb24td2lkZ2V0L3NyYy91dGlscy9ZQU1ML2xpYi9VbmVzY2FwZXIuanMiLCJ3aWRnZXRzL3VzZXItZGVwbG95bWVudC1jcmVhdGlvbi13aWRnZXQvc3JjL3V0aWxzL1lBTUwvbGliL1V0aWxzLmpzIiwid2lkZ2V0cy91c2VyLWRlcGxveW1lbnQtY3JlYXRpb24td2lkZ2V0L3NyYy91dGlscy9ZQU1ML2xpYi9ZYW1sLmpzIiwid2lkZ2V0cy91c2VyLWRlcGxveW1lbnQtY3JlYXRpb24td2lkZ2V0L3NyYy91dGlscy9iYXNlMTB0bzY0LmpzIiwid2lkZ2V0cy91c2VyLWRlcGxveW1lbnQtY3JlYXRpb24td2lkZ2V0L3NyYy91dGlscy9tdXN0YWNoZS5qcyIsIndpZGdldHMvdXNlci1kZXBsb3ltZW50LWNyZWF0aW9uLXdpZGdldC9zcmMvd2lkZ2V0LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7O0FDQUE7O0FDQUE7O0FDQUE7O0FDQUE7O0FDQUE7O0FDQUE7O0FDQUE7O0FDQUE7O0FDQUE7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ1JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUMxQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3ZCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDaENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDaEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNwQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ0xBO0FBQ0E7QUFDQTs7QUNGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDTEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ0xBO0FBQ0E7QUFDQTs7QUNGQTtBQUNBO0FBQ0E7O0FDRkE7QUFDQTtBQUNBOztBQ0ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDUEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ0xBO0FBQ0E7QUFDQTtBQUNBOztBQ0hBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDSkE7QUFDQTs7QUNEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDTEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ0xBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN2QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3ZCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDTEE7QUFDQTtBQUNBOztBQ0ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNwQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ0xBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDSkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNQQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ0pBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM5REE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNQQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3pCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNOQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ0pBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNSQTtBQUNBO0FBQ0E7O0FDRkE7QUFDQTtBQUNBO0FBQ0E7O0FDSEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNoQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDTkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ1JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNMQTtBQUNBO0FBQ0E7QUFDQTs7QUNIQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNaQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3JFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3RCQTtBQUNBO0FBQ0E7QUFDQTs7QUNIQTtBQUNBOztBQ0RBO0FBQ0E7O0FDREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3JEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNyRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDbEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDbENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN6Q0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNoQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNiQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2hCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ25CQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ1BBO0FBQ0E7O0FDREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNiQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDakJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDUEE7QUFDQTs7QUNEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ1ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDUEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDWkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ1JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDUEE7QUFDQTs7QUNEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3pCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDZEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNQQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDTEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDWkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDVEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2pCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNwRkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNQQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNOQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNOQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNOQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDTEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDWkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ0xBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDSkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDVEE7QUFDQTs7QUNEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDWEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ1JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDbENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDSkE7QUFDQTtBQUNBO0FBQ0E7O0FDSEE7QUFDQTtBQUNBO0FBQ0E7O0FDSEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDVEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDVEE7QUFDQTtBQUNBO0FBQ0E7O0FDSEE7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM5UkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2pCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUMxT0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3BCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNaQTtBQUNBOztBQ0RBO0FBQ0E7O0FDREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25CQTs7OztBQUlBOzs7SUFHcUIsTztBQUNuQjs7Ozs7OztBQU9BLG1CQUFZLENBQVosRUFBZTtBQUFBOztBQUNiLFNBQUssT0FBTCxHQUFlLEVBQUUsT0FBakI7QUFDQSxTQUFLLFlBQUwsR0FBb0IsRUFBRSxZQUF0QjtBQUNBLFNBQUssV0FBTCxHQUFtQixFQUFFLFdBQXJCO0FBQ0Q7O0FBRUQ7Ozs7Ozs7Ozs7O3NDQU9rQjtBQUNoQixhQUFPLGtCQUFRLE9BQVIsQ0FBZ0IsQ0FDckI7QUFDRSxZQUFJLElBRE47QUFFRSxjQUFNLFVBRlI7QUFHRSxjQUFNLEdBSFI7QUFJRSxrQkFBVSxFQUpaO0FBS0UsZ0JBQVE7QUFDTixpQkFBTyxrQkFERDtBQUVOLHVCQUFhLHNCQUZQO0FBR04sb0JBQVUsS0FISjtBQUlOLG1CQUFTLENBQ1AsRUFBRSxNQUFNLFNBQVIsRUFBbUIsT0FBTyxTQUExQixFQURPLEVBRVAsRUFBRSxNQUFNLE9BQVIsRUFBaUIsT0FBTyxPQUF4QixFQUZPO0FBSkg7QUFMVixPQURxQixFQWdCckI7QUFDRSxZQUFJLFdBRE47QUFFRSxjQUFNLFFBRlI7QUFHRSxjQUFNLEdBSFI7QUFJRSxrQkFBVSxHQUpaO0FBS0UsZ0JBQVE7QUFDTixpQkFBTyxXQUREO0FBRU4sb0JBQVUsS0FGSjtBQUdOLGdCQUFNLFVBSEEsRUFHWTtBQUNsQixpQkFBTyxPQUpELEVBSVU7QUFDaEIsa0JBQVE7QUFMRjtBQUxWLE9BaEJxQixFQTZCckI7QUFDRSxZQUFJLFVBRE47QUFFRSxjQUFNLE9BRlI7QUFHRSxjQUFNLEVBSFI7QUFJRSxrQkFBVSxFQUpaO0FBS0UsZ0JBQVE7QUFDTixpQkFBTyxVQUREO0FBRU4sbUJBQVMsYUFGSDtBQUdOLHVCQUFhLHdCQUhQO0FBSU4sc0JBQVk7QUFKTjtBQUxWLE9BN0JxQixFQXlDckI7QUFDRSxZQUFJLGFBRE47QUFFRSxjQUFNLFVBRlI7QUFHRSxjQUFNLEVBSFI7QUFJRSxrQkFBVSxFQUpaO0FBS0UsZ0JBQVE7QUFDTixpQkFBTyxhQUREO0FBRU4sbUJBQVM7QUFGSDtBQUxWLE9BekNxQixFQW1EckI7QUFDRSxZQUFJLFdBRE47QUFFRSxjQUFNLFFBRlI7QUFHRSxjQUFNLEVBSFI7QUFJRSxrQkFBVSxFQUpaO0FBS0UsZ0JBQVE7QUFDTixpQkFBTyxXQUREO0FBRU4sbUJBQVM7QUFGSDtBQUxWLE9BbkRxQixFQTZEckI7QUFDRSxZQUFJLFVBRE47QUFFRSxjQUFNLE9BRlI7QUFHRSxjQUFNLEVBSFI7QUFJRSxrQkFBVSxFQUpaO0FBS0UsZ0JBQVE7QUFDTixpQkFBTyxVQUREO0FBRU4sbUJBQVMsS0FGSDtBQUdOLG1CQUFTLENBQ1AsRUFBRSxNQUFNLFVBQVIsRUFBb0IsT0FBTyxLQUEzQixFQURPLEVBRVAsRUFBRSxNQUFNLFVBQVIsRUFBb0IsT0FBTyxLQUEzQixFQUZPLEVBR1AsRUFBRSxNQUFNLFVBQVIsRUFBb0IsT0FBTyxLQUEzQixFQUhPO0FBSEg7QUFMVixPQTdEcUIsRUE0RXJCO0FBQ0UsWUFBSSxhQUROO0FBRUUsY0FBTSxVQUZSO0FBR0UsY0FBTSxFQUhSO0FBSUUsa0JBQVUsRUFKWjtBQUtFLGdCQUFRO0FBQ04saUJBQU8sYUFERDtBQUVOLHVCQUFhLGdCQUZQO0FBR04sb0JBQVUsSUFISjtBQUlOLG1CQUFTLENBQUMsS0FBRCxDQUpIO0FBS04sbUJBQVMsQ0FDUCxFQUFFLE1BQU0sVUFBUixFQUFvQixPQUFPLEtBQTNCLEVBRE8sRUFFUCxFQUFFLE1BQU0sVUFBUixFQUFvQixPQUFPLEtBQTNCLEVBRk8sRUFHUCxFQUFFLE1BQU0sVUFBUixFQUFvQixPQUFPLEtBQTNCLEVBSE87QUFMSDtBQUxWLE9BNUVxQixFQTZGckI7QUFDRSxZQUFJLFVBRE47QUFFRSxjQUFNLE9BRlI7QUFHRSxjQUFNLEVBSFI7QUFJRSxrQkFBVSxFQUpaO0FBS0UsZ0JBQVE7QUFDTixpQkFBTyxVQUREO0FBRU4sbUJBQVMsRUFGSDtBQUdOLGdCQUFNLENBSEE7QUFJTixlQUFLLENBSkM7QUFLTixlQUFLO0FBTEM7QUFMVixPQTdGcUIsRUEwR3JCO0FBQ0UsY0FBTSxTQURSO0FBRUUsY0FBTSxFQUZSO0FBR0Usa0JBQVUsRUFIWjtBQUlFLGdCQUFRO0FBQ04saUJBQU8sc0JBREQ7QUFFTixpQkFBTztBQUZEO0FBSlYsT0ExR3FCLEVBbUhyQjtBQUNFLFlBQUksY0FETjtBQUVFLGNBQU0sV0FGUjtBQUdFLGNBQU0sR0FIUjtBQUlFLGtCQUFVLEVBSlo7QUFLRSxnQkFBUTtBQUNOLGlCQUFPLGNBREQ7QUFFTixvQkFBVSxtQ0FGSjtBQUdOLGlCQUFPLENBSEQsRUFHSTtBQUNWLG1CQUFTLElBSkg7QUFLTixtQkFBUyxDQUNQLEVBQUUsTUFBTSxTQUFSLEVBQW1CLE9BQU8sSUFBMUIsRUFETyxFQUVQLEVBQUUsTUFBTSxPQUFSLEVBQWlCLE9BQU8sSUFBeEIsRUFGTyxFQUdQLEVBQUUsTUFBTSxRQUFSLEVBQWtCLE9BQU8sSUFBekIsRUFITyxFQUlQLEVBQUUsTUFBTSxPQUFSLEVBQWlCLE9BQU8sSUFBeEIsRUFKTztBQUxIO0FBTFYsT0FuSHFCLENBQWhCLENBQVA7QUFzSUE7QUFDRDs7OzJDQUVvRDtBQUFBOztBQUFBLFVBQWhDLElBQWdDLHVFQUF6Qix1QkFBeUI7O0FBQ25ELGNBQVEsR0FBUixDQUFZLEVBQUMsVUFBRCxFQUFaO0FBQ0EsYUFBTyxLQUFLLGNBQUwsQ0FBb0IsS0FBSyxXQUF6QixFQUFzQyxJQUF0QyxDQUEyQyxpQkFBUztBQUN6RCxZQUFJLE9BQU8sTUFBTSxRQUFOLENBQWUsQ0FBZixFQUFrQixRQUFsQixDQUEyQixJQUEzQixDQUFnQztBQUFBLGlCQUFRLEtBQUssS0FBTCxLQUFlLElBQXZCO0FBQUEsU0FBaEMsQ0FBWDtBQUNBLFlBQUcsSUFBSCxFQUFRO0FBQ04saUJBQU8sTUFBSyxnQkFBTCxDQUFzQixLQUFLLEdBQTNCLENBQVA7QUFDRCxTQUZELE1BRUs7QUFDSCxpQkFBTyxrQkFBUSxNQUFSLENBQWtCLElBQWxCLGlCQUFQO0FBQ0Q7QUFDRixPQVBNLENBQVA7QUFRRDs7O3FDQUVnQixZLEVBQWM7QUFDN0IsYUFBTyxLQUFLLE9BQUwsQ0FBYSxVQUFiLEdBQTBCLEtBQTFCLG1CQUFnRCxZQUFoRCwrQkFBUDtBQUNEOzs7bUNBRWMsVyxFQUFhO0FBQzFCLGFBQU8sS0FBSyxPQUFMLENBQWEsV0FBYixHQUEyQixLQUEzQixxQkFBbUQsV0FBbkQsY0FBUDtBQUNEOzs7cUNBRWdCLEksRUFBTTtBQUNyQixhQUFPLEtBQUssT0FBTCxDQUFhLFdBQWIsR0FBMkIsS0FBM0IsQ0FBaUMscUJBQWpDLEVBQXdELEVBQUUsVUFBRixFQUF4RCxDQUFQO0FBQ0Q7Ozs7O2tCQXJMa0IsTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNKckI7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7QUFFQTs7OztJQUlxQixJOzs7QUFDbkI7Ozs7O0FBS0EsZ0JBQVksS0FBWixFQUFtQixPQUFuQixFQUE0QjtBQUFBOztBQUFBLGtJQUNwQixLQURvQixFQUNiLE9BRGE7O0FBQUEsVUEyRTVCLFlBM0U0QixHQTJFYixVQUFDLEVBQUQsRUFBSyxLQUFMLEVBQWU7QUFDNUI7QUFDQSxZQUFLLFFBQUwsQ0FBYyxFQUFFLE1BQU0sc0JBQWMsTUFBSyxLQUFMLENBQVcsSUFBekIsb0NBQWtDLEVBQWxDLEVBQXVDLEtBQXZDLEVBQVIsRUFBZDtBQUNBLGNBQVEsR0FBUixDQUFZLFlBQVosRUFBMEIsTUFBSyxLQUFMLENBQVcsSUFBckM7QUFDRCxLQS9FMkI7O0FBQUEsVUFpRjVCLGlCQWpGNEIsR0FpRlIsWUFBTTtBQUN4QixVQUFJLFNBQVMsRUFBYjtBQUNBLDBCQUFZLE1BQUssS0FBTCxDQUFXLElBQXZCLEVBQTZCLE9BQTdCLENBQXFDLGdCQUFRO0FBQzNDO0FBQ0EsWUFBSSxFQUFFLEtBQUYsQ0FBUSxNQUFLLEtBQUwsQ0FBVyxJQUFYLENBQWdCLElBQWhCLENBQVIsS0FBa0MsTUFBSyxLQUFMLENBQVcsSUFBWCxDQUFnQixJQUFoQixNQUEwQixFQUFoRSxFQUFvRTtBQUNsRSxpQkFBTyxJQUFQLElBQWUsVUFBZjtBQUNEO0FBQ0YsT0FMRDtBQU1BLFVBQUksb0JBQVksTUFBWixFQUFvQixNQUFwQixLQUErQixDQUFuQyxFQUFzQztBQUNwQyxlQUFPLEtBQVAsR0FBZSxpQ0FBZjtBQUNEO0FBQ0QsWUFBSyxRQUFMLENBQWMsRUFBRSxjQUFGLEVBQWQ7QUFDQSxVQUFJLG9CQUFZLE1BQVosRUFBb0IsTUFBcEIsS0FBK0IsQ0FBbkMsRUFBc0M7O0FBRXBDLFlBQU0sWUFBWSxNQUFLLEtBQUwsQ0FBVyxNQUFYLENBQWtCLGFBQWxCLENBQWdDLFdBQWxEO0FBQ0EsWUFBTSxhQUFhLE1BQUssS0FBTCxDQUFXLGVBQTlCO0FBQ0EsWUFBTSxhQUFhLFFBQW5CO0FBQ0EsWUFBTSx3QkFBd0IsS0FBOUI7O0FBRUEsWUFBTSxlQUFlLE1BQUssS0FBTCxDQUFXLElBQVgsQ0FBZ0IsWUFBaEIsSUFBZ0MsU0FBckQ7QUFDQSxZQUFJLG9CQUFvQixNQUFLLEtBQUwsQ0FBVyxJQUFuQztBQUNBLFlBQUcsa0JBQWtCLFlBQXJCLEVBQWtDO0FBQ2hDLGlCQUFPLGtCQUFrQixZQUF6QjtBQUNEOztBQUVELFlBQU0sU0FBUztBQUNiLG9DQURhO0FBRWI7QUFGYSxTQUFmO0FBSUEsZ0JBQVEsR0FBUixDQUFZLFFBQVosRUFBc0IsTUFBdEI7QUFDQSxjQUFLLFFBQUwsQ0FBYyxFQUFFLFNBQVMsSUFBWCxFQUFkO0FBQ0EsWUFBSSxVQUFVLElBQUksTUFBTSxNQUFOLENBQWEsZ0JBQWpCLENBQWtDLE1BQUssS0FBTCxDQUFXLE9BQTdDLENBQWQ7QUFDQSxnQkFBUSxRQUFSLENBQWlCLEVBQUUsSUFBSSxTQUFOLEVBQWpCLEVBQW9DLFVBQXBDLEVBQWdELE1BQWhELEVBQXdELFVBQXhELEVBQW9FLHFCQUFwRSxFQUNHLElBREgsQ0FDUSxVQUFDLFVBQUQsRUFBZ0I7QUFDcEIsZ0JBQUssb0JBQUw7QUFDQSxnQkFBSyxRQUFMLENBQWMsRUFBRSxTQUFTLEtBQVgsRUFBa0IsUUFBUSxFQUExQixFQUE4QixTQUFTLHVEQUF2QyxFQUFkO0FBQ0EsY0FBTSxtQkFBbUIsTUFBSyxLQUFMLENBQVcsTUFBWCxDQUFrQixhQUFsQixDQUFnQyxnQkFBekQ7QUFDQSxjQUFNLFdBQVcsTUFBSyxLQUFMLENBQVcsTUFBWCxDQUFrQixhQUFsQixDQUFnQyxRQUFqRDtBQUNBLGNBQUksZ0JBQUosRUFBc0I7QUFDcEIsa0JBQUssS0FBTCxDQUFXLE9BQVgsQ0FBbUIsU0FBbkIsQ0FBNkIsTUFBSyxLQUFMLENBQVcsTUFBeEMsRUFBZ0QsUUFBaEQsRUFBMEQsRUFBRSxjQUFjLFdBQVcsRUFBM0IsRUFBMUQsRUFBMkYsV0FBVyxFQUF0RztBQUNEO0FBQ0YsU0FUSCxFQVVHLEtBVkgsQ0FVUyxVQUFDLEdBQUQsRUFBUztBQUNkLGdCQUFLLFFBQUwsQ0FBYyxFQUFFLFNBQVMsS0FBWCxFQUFrQixRQUFRLEVBQUUsT0FBTyxJQUFJLE9BQWIsRUFBMUIsRUFBZDtBQUNELFNBWkg7QUFhRDtBQUNGLEtBL0gyQjs7QUFHMUIsVUFBSyxLQUFMLEdBQWE7QUFDWCxZQUFNLEVBREs7QUFFWCxtQkFBYSxFQUZGO0FBR1gsY0FBUSxFQUhHO0FBSVgsZUFBUyxJQUpFO0FBS1gsdUJBQWlCLEVBTE47QUFNWCxlQUFTLEtBTkU7QUFPWCxpQkFBVztBQVBBLEtBQWI7QUFIMEI7QUFZM0I7Ozs7eUNBRW9CO0FBQUE7O0FBQ25CLFVBQUksT0FBTyxLQUFLLEtBQUwsQ0FBVyxJQUF0QjtBQUNBLFdBQUssS0FBTCxDQUFXLE9BQVgsQ0FBbUIsV0FBbkIsR0FBaUMsRUFBakMsQ0FBb0MsZ0JBQXBDLEVBQXNEO0FBQUEsZUFBTyxJQUFJLFFBQUosS0FBaUIsT0FBSyxLQUFMLENBQVcsTUFBWCxDQUFrQixFQUFuQyxJQUF5QyxPQUFLLGVBQUwsQ0FBcUIsSUFBSSxJQUF6QixDQUFoRDtBQUFBLE9BQXRELEVBQXNJLElBQXRJO0FBQ0EsV0FBSyxLQUFMLENBQVcsT0FBWCxDQUFtQixXQUFuQixHQUFpQyxPQUFqQyxDQUF5QyxnQkFBekMsRUFBMkQsSUFBM0QsRUFBaUUsS0FBSyxLQUFMLENBQVcsTUFBNUU7O0FBRUEsV0FBSyxvQkFBTDtBQUNBLFdBQUssZUFBTCxDQUFxQixJQUFyQjtBQUNEOzs7MkNBQ3NCO0FBQ3JCLFdBQUssS0FBTCxDQUFXLE9BQVgsQ0FBbUIsV0FBbkIsR0FBaUMsR0FBakMsQ0FBcUMsZ0JBQXJDLEVBQXVELEtBQUssUUFBNUQsRUFBc0UsSUFBdEU7QUFDRDs7OzJDQUVxQjtBQUNwQixVQUFNLE9BQU8sS0FBSyxLQUFMLENBQVcsT0FBWCxDQUFtQixVQUFuQixHQUFnQyxrQkFBaEMsRUFBYjtBQUNBLFVBQU0sWUFBWSxLQUFLLEtBQUwsQ0FBVyxNQUFYLENBQWtCLGFBQWxCLENBQWdDLFdBQWxEO0FBQ0EsVUFBTSxTQUFTLHdCQUFXLEtBQUssS0FBTCxDQUFXLEtBQUssR0FBTCxLQUFhLElBQXhCLENBQVgsQ0FBZjtBQUNBLFVBQU0sd0NBQXNDLElBQXRDLFNBQThDLFNBQTlDLFNBQTJELE1BQWpFO0FBQ0EsV0FBSyxRQUFMLENBQWMsRUFBQyxnQ0FBRCxFQUFkO0FBQ0Q7OztvQ0FFZSxLLEVBQU87QUFDckIsV0FBSyxRQUFMLENBQWMsRUFBRSxXQUFXLElBQWIsRUFBZDtBQUNBLFVBQUk7QUFDRixZQUFJLE9BQU8sZUFBSyxLQUFMLENBQVcsS0FBWCxDQUFYO0FBQ0EsYUFBSyxXQUFMLENBQWlCLElBQWpCO0FBQ0QsT0FIRCxDQUdFLE9BQU8sQ0FBUCxFQUFVO0FBQ1YsYUFBSyxRQUFMLENBQWMsRUFBRSxXQUFXLEVBQUUsT0FBZixFQUFkO0FBQ0Q7QUFDRjs7O2dDQUVXLEksRUFBTTs7QUFFaEI7QUFDQSxVQUFNLGNBQWMsS0FBSyxNQUFMLENBQVk7QUFBQSxlQUFLLENBQ25DLFFBRG1DLEVBRW5DLE9BRm1DLEVBR25DLFVBSG1DLEVBSW5DLFVBSm1DLEVBS25DLFFBTG1DLEVBTW5DLE9BTm1DLEVBT25DLFVBUG1DLEVBUW5DLE9BUm1DLEVBU25DLFNBVG1DLEVBVW5DLFdBVm1DLEVBV25DLFFBWG1DLENBVzFCLEVBQUUsSUFYd0IsQ0FBTDtBQUFBLE9BQVosQ0FBcEI7O0FBYUEsY0FBUSxHQUFSLENBQVksRUFBRSx3QkFBRixFQUFaOztBQUVBO0FBQ0Esa0JBQVksSUFBWixDQUFpQixVQUFDLENBQUQsRUFBSSxDQUFKO0FBQUEsZUFBVSxFQUFFLFFBQUYsR0FBYSxFQUFFLFFBQXpCO0FBQUEsT0FBakI7O0FBRUE7QUFDQSxVQUFJLE9BQU8sRUFBWDtBQUNBLGtCQUFZLE9BQVosQ0FBb0IsZ0JBQVE7QUFDMUIsWUFBSSxLQUFLLEVBQUwsSUFBVyxLQUFLLElBQUwsS0FBYyxRQUE3QixFQUF1QztBQUNyQyxlQUFLLEtBQUssRUFBVixJQUFnQixLQUFLLE1BQUwsQ0FBWSxPQUE1QjtBQUNEO0FBQ0YsT0FKRDtBQUtBLFdBQUssUUFBTCxDQUFjLEVBQUUsVUFBRixFQUFRLHdCQUFSLEVBQWQ7QUFDRDs7Ozs7QUF3REQ7Ozs7OzZCQUtTO0FBQUE7O0FBQ1AsVUFBSSxLQUFLLEtBQUwsQ0FBVyxPQUFmLEVBQXdCO0FBQ3RCLGVBQU8sb0JBQUMsS0FBRCxDQUFPLEtBQVAsQ0FBYSxPQUFiLE9BQVA7QUFDRDs7QUFITSx5QkFLb0QsTUFBTSxLQUwxRDtBQUFBLFVBS0EsTUFMQSxnQkFLQSxNQUxBO0FBQUEsVUFLUSxLQUxSLGdCQUtRLEtBTFI7QUFBQSxVQUtlLFFBTGYsZ0JBS2UsUUFMZjtBQUFBLFVBS3lCLFFBTHpCLGdCQUt5QixRQUx6QjtBQUFBLFVBS21DLE9BTG5DLGdCQUttQyxPQUxuQztBQUFBLFVBSzRDLElBTDVDLGdCQUs0QyxJQUw1Qzs7QUFPUDs7OztBQUdBLFVBQU0sVUFBVSxLQUFLLEtBQUwsQ0FBVyxXQUFYLENBQXVCLEdBQXZCLENBQTJCLFVBQUMsSUFBRCxFQUFPLEdBQVA7QUFBQSxlQUFlO0FBQUE7QUFBQSxZQUFLLFdBQVUsV0FBZixFQUEyQixLQUFLLEdBQWhDLEVBQXFDLE9BQU8sRUFBRSxXQUFXLENBQUMsS0FBSyxJQUFMLElBQWEsRUFBZCxJQUFvQixHQUFqQyxFQUE1QztBQUV2RCxlQUFLLElBQUwsS0FBYyxRQUFkLElBQTBCO0FBQUMsa0JBQUQ7QUFBQTtBQUN6QixxQkFBTyxDQUFDLEtBQUssTUFBTCxDQUFZLFFBREs7QUFFekIscUJBQU8sS0FBSyxNQUFMLENBQVksS0FGTTtBQUd6Qix3QkFBVSxLQUFLLE1BQUwsQ0FBWSxRQUhHO0FBSXpCLG9CQUFNLEtBQUssTUFBTCxDQUFZLEtBQVosR0FBb0IsS0FBcEIsR0FBNEIsS0FBSyxNQUFMLENBQVksSUFKckI7QUFLekIsdUJBQVMsbUJBQU07QUFDYixxQkFBSyxNQUFMLENBQVksTUFBWixLQUF1QixrQkFBdkIsSUFBNkMsT0FBSyxpQkFBTCxDQUF1QixJQUF2QixDQUE0QixNQUE1QixDQUE3QztBQUNEO0FBUHdCO0FBU3hCLGlCQUFLLE1BQUwsQ0FBWTtBQVRZLFdBRjZCO0FBY3ZELGVBQUssSUFBTCxLQUFjLE9BQWQsSUFBeUIsb0JBQUMsS0FBRDtBQUN4Qix1QkFEd0I7QUFFeEIsa0JBQU0sS0FBSyxNQUFMLENBQVksVUFBWixHQUF5QixVQUF6QixHQUFzQyxNQUZwQjtBQUd4QixtQkFBTyxLQUFLLE1BQUwsQ0FBWSxLQUhLO0FBSXhCLHlCQUFhLEtBQUssTUFBTCxDQUFZLFdBSkQ7QUFLeEIsbUJBQU8sT0FBSyxLQUFMLENBQVcsSUFBWCxDQUFnQixLQUFLLEVBQXJCLENBTGlCO0FBTXhCLHNCQUFVLGtCQUFDLEtBQUQsRUFBUSxPQUFSO0FBQUEscUJBQW9CLE9BQUssWUFBTCxDQUFrQixJQUFsQixDQUF1QixNQUF2QixFQUE2QixLQUFLLEVBQWxDLEVBQXNDLFFBQVEsS0FBOUMsQ0FBcEI7QUFBQTtBQU5jLFlBZDhCO0FBdUJ2RCxlQUFLLElBQUwsS0FBYyxVQUFkLElBQTRCLG9CQUFDLFFBQUQ7QUFDM0IsbUJBQU8sS0FBSyxNQUFMLENBQVksS0FEUTtBQUUzQixxQkFBUyxPQUFLLEtBQUwsQ0FBVyxJQUFYLENBQWdCLEtBQUssRUFBckIsQ0FGa0I7QUFHM0Isc0JBQVUsa0JBQUMsS0FBRCxFQUFRLE9BQVI7QUFBQSxxQkFBb0IsT0FBSyxZQUFMLENBQWtCLElBQWxCLENBQXVCLE1BQXZCLEVBQTZCLEtBQUssRUFBbEMsRUFBc0MsUUFBUSxPQUE5QyxDQUFwQjtBQUFBO0FBSGlCLFlBdkIyQjtBQTZCdkQsZUFBSyxJQUFMLEtBQWMsUUFBZCxJQUEwQixvQkFBQyxRQUFEO0FBQ3pCLHdCQUR5QjtBQUV6QixtQkFBTyxLQUFLLE1BQUwsQ0FBWSxLQUZNO0FBR3pCLHFCQUFTLE9BQUssS0FBTCxDQUFXLElBQVgsQ0FBZ0IsS0FBSyxFQUFyQixDQUhnQjtBQUl6QixzQkFBVSxrQkFBQyxLQUFELEVBQVEsT0FBUjtBQUFBLHFCQUFvQixPQUFLLFlBQUwsQ0FBa0IsSUFBbEIsQ0FBdUIsTUFBdkIsRUFBNkIsS0FBSyxFQUFsQyxFQUFzQyxRQUFRLE9BQTlDLENBQXBCO0FBQUE7QUFKZSxZQTdCNkI7QUFvQ3ZELGVBQUssSUFBTCxLQUFjLE9BQWQsSUFBeUI7QUFBQTtBQUFBO0FBQ3hCO0FBQUE7QUFBQTtBQUFJLG1CQUFLLE1BQUwsQ0FBWTtBQUFoQixhQUR3QjtBQUV4QiwyQ0FGd0I7QUFHeEIsMkNBSHdCO0FBSXZCLGlCQUFLLE1BQUwsQ0FBWSxPQUFaLENBQW9CLEdBQXBCLENBQXdCLFVBQUMsTUFBRCxFQUFTLEdBQVQ7QUFBQSxxQkFBaUI7QUFBQTtBQUFBLGtCQUFLLEtBQUssR0FBVjtBQUN4QyxvQ0FBQyxRQUFEO0FBQ0UsNkJBREY7QUFFRSx3QkFBTSxLQUFLLEVBRmI7QUFHRSx5QkFBTyxPQUFPLElBSGhCO0FBSUUseUJBQU8sT0FBTyxLQUpoQjtBQUtFLDJCQUFTLE9BQUssS0FBTCxDQUFXLElBQVgsQ0FBZ0IsS0FBSyxFQUFyQixNQUE2QixPQUFPLEtBTC9DO0FBTUUsNEJBQVUsa0JBQUMsS0FBRCxFQUFRLE9BQVI7QUFBQSwyQkFBb0IsT0FBSyxZQUFMLENBQWtCLElBQWxCLENBQXVCLE1BQXZCLEVBQTZCLEtBQUssRUFBbEMsRUFBc0MsUUFBUSxLQUE5QyxDQUFwQjtBQUFBO0FBTlo7QUFEd0MsZUFBakI7QUFBQSxhQUF4QjtBQUp1QixXQXBDOEI7QUFvRHZELGVBQUssSUFBTCxLQUFjLFVBQWQsSUFBNEI7QUFBQTtBQUFBO0FBQzNCO0FBQUE7QUFBQTtBQUFJLG1CQUFLLE1BQUwsQ0FBWTtBQUFoQixhQUQyQjtBQUUzQiwyQ0FGMkI7QUFHM0IsMkNBSDJCO0FBSTNCLGdDQUFDLFFBQUQ7QUFDRSx5QkFERjtBQUVFLDZCQUZGO0FBR0Usd0JBQVUsS0FBSyxNQUFMLENBQVksUUFIeEI7QUFJRSwyQkFBYSxLQUFLLE1BQUwsQ0FBWSxXQUozQjtBQUtFLHVCQUFTLEtBQUssTUFBTCxDQUFZLE9BTHZCO0FBTUUscUJBQU8sT0FBSyxLQUFMLENBQVcsSUFBWCxDQUFnQixLQUFLLEVBQXJCLENBTlQ7QUFPRSx3QkFBVSxrQkFBQyxLQUFELEVBQVEsT0FBUjtBQUFBLHVCQUFvQixPQUFLLFlBQUwsQ0FBa0IsSUFBbEIsQ0FBdUIsTUFBdkIsRUFBNkIsS0FBSyxFQUFsQyxFQUFzQyxRQUFRLEtBQTlDLENBQXBCO0FBQUE7QUFQWjtBQUoyQixXQXBEMkI7QUFtRXZELGVBQUssSUFBTCxLQUFjLE9BQWQsSUFBeUI7QUFBQTtBQUFBO0FBQ3hCO0FBQUE7QUFBQTtBQUFJLG1CQUFLLE1BQUwsQ0FBWTtBQUFoQixhQUR3QjtBQUV4QiwyQ0FGd0I7QUFHeEIsMkNBSHdCO0FBSXhCO0FBQ0Usb0JBQUssT0FEUDtBQUVFLG9CQUFNLEtBQUssTUFBTCxDQUFZLElBQVosSUFBb0IsQ0FGNUI7QUFHRSxtQkFBSyxLQUFLLE1BQUwsQ0FBWSxHQUFaLElBQW1CLENBSDFCO0FBSUUsbUJBQUssS0FBSyxNQUFMLENBQVksR0FBWixJQUFtQixHQUoxQjtBQUtFLHFCQUFPLE9BQUssS0FBTCxDQUFXLElBQVgsQ0FBZ0IsS0FBSyxFQUFyQixDQUxUO0FBTUUsd0JBQVU7QUFBQSx1QkFBUyxPQUFLLFlBQUwsQ0FBa0IsSUFBbEIsQ0FBdUIsTUFBdkIsRUFBNkIsS0FBSyxFQUFsQyxFQUFzQyxNQUFNLE1BQU4sQ0FBYSxLQUFuRCxDQUFUO0FBQUEsZUFOWjtBQU9FLHFCQUFPLEVBQUUsT0FBTyxNQUFUO0FBUFQ7QUFKd0IsV0FuRThCO0FBa0Z2RCxlQUFLLElBQUwsS0FBYyxTQUFkLElBQTJCO0FBQUMsbUJBQUQ7QUFBQTtBQUMxQixxQkFBTyxLQUFLLE1BQUwsQ0FBWTtBQURPO0FBRXhCLGlCQUFLLE1BQUwsQ0FBWTtBQUZZLFdBbEY0QjtBQXNGdkQsZUFBSyxJQUFMLEtBQWMsV0FBZCxJQUE2QjtBQUFBO0FBQUE7QUFDNUI7QUFBQTtBQUFBO0FBQUksbUJBQUssTUFBTCxDQUFZO0FBQWhCLGFBRDRCO0FBRTVCLDJDQUY0QjtBQUV0QixnQ0FBQyxtQkFBRDtBQUNKLHFCQUFPLEtBQUssTUFBTCxDQUFZLEtBRGY7QUFFSix3QkFBVSxLQUFLLE1BQUwsQ0FBWSxRQUZsQjtBQUdKLHVCQUFTLEtBQUssTUFBTCxDQUFZLE9BSGpCO0FBSUoscUJBQU8sT0FBSyxLQUFMLENBQVcsSUFBWCxDQUFnQixLQUFLLEVBQXJCLENBSkg7QUFLSix3QkFBVTtBQUFBLHVCQUFTLE9BQUssWUFBTCxDQUFrQixJQUFsQixDQUF1QixNQUF2QixFQUE2QixLQUFLLEVBQWxDLEVBQXNDLEtBQXRDLENBQVQ7QUFBQTtBQUxOO0FBRnNCLFdBdEYwQjtBQWtHdEQsaUJBQUssS0FBTCxDQUFXLE1BQVgsQ0FBa0IsS0FBSyxFQUF2QixLQUNBLE9BQUssS0FBTCxDQUFXLE1BQVgsQ0FBa0IsS0FBSyxFQUF2QixFQUEyQixLQUEzQixDQUFpQyxHQUFqQyxFQUFzQyxRQUF0QyxDQUErQyxVQUEvQyxDQURBLElBRUE7QUFBQTtBQUFBLGNBQUssV0FBVSxLQUFmO0FBQUE7QUFBa0MsaUJBQUssTUFBTCxDQUFZLEtBQVosSUFBcUIsT0FBdkQ7QUFBZ0UsZUFBaEU7QUFBQTtBQUFBO0FBcEdzRCxTQUFmO0FBQUEsT0FBM0IsQ0FBaEI7O0FBeUdBLFVBQU0sZUFBZSxLQUFLLEtBQUwsQ0FBVyxNQUFYLENBQWtCLEtBQWxCLElBQTRCO0FBQUMsZUFBRDtBQUFBLFVBQVMsT0FBTSxLQUFmLEVBQXFCLFdBQVc7QUFBQSxtQkFBTSxPQUFLLFFBQUwsQ0FBYyxFQUFFLFFBQVEsc0JBQWMsT0FBSyxLQUFMLENBQVcsTUFBekIsRUFBaUMsRUFBRSxPQUFPLElBQVQsRUFBakMsQ0FBVixFQUFkLENBQU47QUFBQSxXQUFoQztBQUM5QyxhQUFLLEtBQUwsQ0FBVyxNQUFYLENBQWtCO0FBRDRCLE9BQWpEOztBQUlBLFVBQU0saUJBQWlCLEtBQUssS0FBTCxDQUFXLE9BQVgsSUFBc0I7QUFBQyxlQUFEO0FBQUEsVUFBUyxPQUFNLE9BQWYsRUFBdUIsV0FBVztBQUFBLG1CQUFNLE9BQUssUUFBTCxDQUFjLEVBQUUsU0FBUyxJQUFYLEVBQWQsQ0FBTjtBQUFBLFdBQWxDO0FBQzFDLGFBQUssS0FBTCxDQUFXO0FBRCtCLE9BQTdDO0FBR0EsVUFBTSxZQUFZLEtBQUssS0FBTCxDQUFXLFNBQVgsSUFBd0I7QUFBQyxlQUFEO0FBQUEsVUFBUyxPQUFNLFFBQWYsRUFBd0IsV0FBVztBQUFBLG1CQUFNLE9BQUssUUFBTCxDQUFjLEVBQUUsV0FBVyxJQUFiLEVBQWQsQ0FBTjtBQUFBLFdBQW5DO0FBQ3ZDLGFBQUssS0FBTCxDQUFXO0FBRDRCLE9BQTFDOztBQUlBLFVBQU0sZ0JBQWdCLEtBQUssS0FBTCxDQUFXLE1BQVgsQ0FBa0IsYUFBbEIsQ0FBZ0MsYUFBdEQ7O0FBRUEsYUFBTztBQUFBO0FBQUE7QUFDSixvQkFESTtBQUVKLHNCQUZJO0FBR0osaUJBSEk7QUFLSixTQUFDLEtBQUssS0FBTCxDQUFXLE9BQVosSUFBdUIsYUFBdkIsSUFBd0Msb0JBQUMsS0FBRDtBQUN2QyxxQkFEdUM7QUFFdkMsZ0JBQU0sTUFGaUM7QUFHdkMsaUJBQU0sa0JBSGlDO0FBSXZDLHVCQUFZLDJEQUoyQjtBQUt2QyxpQkFBTyxLQUFLLEtBQUwsQ0FBVyxlQUxxQjtBQU12QyxvQkFBVSxrQkFBQyxLQUFELEVBQVEsT0FBUjtBQUFBLG1CQUFvQixPQUFLLFFBQUwsQ0FBYyxFQUFFLGlCQUFpQixRQUFRLEtBQTNCLEVBQWQsQ0FBcEI7QUFBQTtBQU42QixVQUxwQztBQWNMO0FBQUE7QUFBQSxZQUFLLFdBQVUsNEJBQWY7QUFDRyxXQUFDLEtBQUssS0FBTCxDQUFXLE9BQVosSUFBdUI7QUFEMUI7QUFkSyxPQUFQO0FBa0JEOzs7RUE5UitCLE1BQU0sUyxHQVh4Qzs7Ozs7a0JBV3FCLEk7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUnJCOzs7Ozs7QUFHQTs7OztJQUlxQixTOzs7QUFDbkI7Ozs7O0FBS0EscUJBQVksS0FBWixFQUFtQixPQUFuQixFQUE0QjtBQUFBOztBQUFBLDRJQUNwQixLQURvQixFQUNiLE9BRGE7O0FBRTFCLFVBQUssS0FBTCxHQUFhO0FBQ1gsZ0JBQVU7QUFEQyxLQUFiO0FBRjBCO0FBSzNCOztBQUVEOzs7Ozs7Ozs7NkJBS1M7QUFBQSxtQkFDMkMsS0FBSyxLQURoRDtBQUFBLFVBQ0YsT0FERSxVQUNGLE9BREU7QUFBQSxVQUNPLFFBRFAsVUFDTyxRQURQO0FBQUEsVUFDaUIsUUFEakIsVUFDaUIsUUFEakI7QUFBQSxVQUMyQixLQUQzQixVQUMyQixLQUQzQjtBQUFBLFVBQ2tDLEtBRGxDLFVBQ2tDLEtBRGxDOzs7QUFHUCxhQUFPO0FBQUE7QUFBQSxVQUFLLFdBQVcscUJBQW1CLFNBQVMsQ0FBNUIsQ0FBaEI7QUFDSixnQkFBUSxHQUFSLENBQVksVUFBQyxJQUFELEVBQU8sR0FBUDtBQUFBLGlCQUNYO0FBQ0UsaUJBQUssR0FEUDtBQUVFLHVCQUFXLENBQUMsTUFBRCxFQUFVLEtBQUssS0FBTCxLQUFlLEtBQWYsSUFBd0IsUUFBbEMsRUFBNkMsSUFBN0MsQ0FBa0QsR0FBbEQsQ0FGYjtBQUdFLHFCQUFTO0FBQUEscUJBQU0sS0FBSyxLQUFMLEtBQWUsS0FBZixJQUF3QixTQUFTLEtBQUssS0FBZCxDQUE5QjtBQUFBLGFBSFg7QUFJRSxxQ0FBeUIsRUFBRSxRQUFRLHdCQUFPLFFBQVAsRUFBaUIsSUFBakIsQ0FBVjtBQUozQixZQURXO0FBQUEsU0FBWjtBQURJLE9BQVA7QUFTRDs7O0VBOUJvQyxNQUFNLFMsR0FWN0M7Ozs7O2tCQVVxQixTOzs7OztBQ1RyQixJQUFJLE9BQU8sUUFBUSxZQUFSLENBQVg7QUFDQSxPQUFPLE9BQVAsR0FBaUIsSUFBakI7Ozs7Ozs7Ozs7O0FDRkE7QUFDQSxJQUFJLE1BQUosRUFBWSxNQUFaLEVBQW9CLEtBQXBCOztBQUVBLFFBQVEsUUFBUSxTQUFSLENBQVI7O0FBRUEsU0FBUyxRQUFRLFVBQVIsQ0FBVDs7QUFFQSxTQUFVLFlBQVc7QUFDbkIsV0FBUyxNQUFULEdBQWtCLENBQUU7O0FBRXBCLFNBQU8sV0FBUCxHQUFxQixDQUFyQjs7QUFFQSxTQUFPLFNBQVAsQ0FBaUIsSUFBakIsR0FBd0IsVUFBUyxLQUFULEVBQWdCLE1BQWhCLEVBQXdCLE1BQXhCLEVBQWdDLHNCQUFoQyxFQUF3RCxhQUF4RCxFQUF1RTtBQUM3RixRQUFJLENBQUosRUFBTyxHQUFQLEVBQVksR0FBWixFQUFpQixNQUFqQixFQUF5QixNQUF6QixFQUFpQyxLQUFqQyxFQUF3QyxhQUF4QztBQUNBLFFBQUksVUFBVSxJQUFkLEVBQW9CO0FBQ2xCLGVBQVMsQ0FBVDtBQUNEO0FBQ0QsUUFBSSxVQUFVLElBQWQsRUFBb0I7QUFDbEIsZUFBUyxDQUFUO0FBQ0Q7QUFDRCxRQUFJLDBCQUEwQixJQUE5QixFQUFvQztBQUNsQywrQkFBeUIsS0FBekI7QUFDRDtBQUNELFFBQUksaUJBQWlCLElBQXJCLEVBQTJCO0FBQ3pCLHNCQUFnQixJQUFoQjtBQUNEO0FBQ0QsYUFBUyxFQUFUO0FBQ0EsYUFBVSxTQUFTLE1BQU0sU0FBTixDQUFnQixHQUFoQixFQUFxQixNQUFyQixDQUFULEdBQXdDLEVBQWxEO0FBQ0EsUUFBSSxVQUFVLENBQVYsSUFBZSxRQUFPLEtBQVAsdURBQU8sS0FBUCxPQUFpQixRQUFoQyxJQUE0QyxpQkFBaUIsSUFBN0QsSUFBcUUsTUFBTSxPQUFOLENBQWMsS0FBZCxDQUF6RSxFQUErRjtBQUM3RixnQkFBVSxTQUFTLE9BQU8sSUFBUCxDQUFZLEtBQVosRUFBbUIsc0JBQW5CLEVBQTJDLGFBQTNDLENBQW5CO0FBQ0QsS0FGRCxNQUVPO0FBQ0wsVUFBSSxpQkFBaUIsS0FBckIsRUFBNEI7QUFDMUIsYUFBSyxJQUFJLENBQUosRUFBTyxNQUFNLE1BQU0sTUFBeEIsRUFBZ0MsSUFBSSxHQUFwQyxFQUF5QyxHQUF6QyxFQUE4QztBQUM1QyxrQkFBUSxNQUFNLENBQU4sQ0FBUjtBQUNBLDBCQUFnQixTQUFTLENBQVQsSUFBYyxDQUFkLElBQW1CLFFBQU8sS0FBUCx1REFBTyxLQUFQLE9BQWlCLFFBQXBDLElBQWdELE1BQU0sT0FBTixDQUFjLEtBQWQsQ0FBaEU7QUFDQSxvQkFBVSxTQUFTLEdBQVQsSUFBZ0IsZ0JBQWdCLEdBQWhCLEdBQXNCLElBQXRDLElBQThDLEtBQUssSUFBTCxDQUFVLEtBQVYsRUFBaUIsU0FBUyxDQUExQixFQUE4QixnQkFBZ0IsQ0FBaEIsR0FBb0IsU0FBUyxLQUFLLFdBQWhFLEVBQThFLHNCQUE5RSxFQUFzRyxhQUF0RyxDQUE5QyxJQUFzSyxnQkFBZ0IsSUFBaEIsR0FBdUIsRUFBN0wsQ0FBVjtBQUNEO0FBQ0YsT0FORCxNQU1PO0FBQ0wsYUFBSyxHQUFMLElBQVksS0FBWixFQUFtQjtBQUNqQixrQkFBUSxNQUFNLEdBQU4sQ0FBUjtBQUNBLDBCQUFnQixTQUFTLENBQVQsSUFBYyxDQUFkLElBQW1CLFFBQU8sS0FBUCx1REFBTyxLQUFQLE9BQWlCLFFBQXBDLElBQWdELE1BQU0sT0FBTixDQUFjLEtBQWQsQ0FBaEU7QUFDQSxvQkFBVSxTQUFTLE9BQU8sSUFBUCxDQUFZLEdBQVosRUFBaUIsc0JBQWpCLEVBQXlDLGFBQXpDLENBQVQsR0FBbUUsR0FBbkUsSUFBMEUsZ0JBQWdCLEdBQWhCLEdBQXNCLElBQWhHLElBQXdHLEtBQUssSUFBTCxDQUFVLEtBQVYsRUFBaUIsU0FBUyxDQUExQixFQUE4QixnQkFBZ0IsQ0FBaEIsR0FBb0IsU0FBUyxLQUFLLFdBQWhFLEVBQThFLHNCQUE5RSxFQUFzRyxhQUF0RyxDQUF4RyxJQUFnTyxnQkFBZ0IsSUFBaEIsR0FBdUIsRUFBdlAsQ0FBVjtBQUNEO0FBQ0Y7QUFDRjtBQUNELFdBQU8sTUFBUDtBQUNELEdBbENEOztBQW9DQSxTQUFPLE1BQVA7QUFFRCxDQTNDUSxFQUFUOztBQTZDQSxPQUFPLE9BQVAsR0FBaUIsTUFBakI7Ozs7O0FDcERBO0FBQ0EsSUFBSSxPQUFKLEVBQWEsT0FBYjs7QUFFQSxVQUFVLFFBQVEsV0FBUixDQUFWOztBQUVBLFVBQVcsWUFBVztBQUNwQixNQUFJLEVBQUo7O0FBRUEsV0FBUyxPQUFULEdBQW1CLENBQUU7O0FBRXJCLFVBQVEsYUFBUixHQUF3QixDQUFDLElBQUQsRUFBTyxNQUFQLEVBQWUsS0FBZixFQUFzQixHQUF0QixFQUEyQixNQUEzQixFQUFtQyxNQUFuQyxFQUEyQyxNQUEzQyxFQUFtRCxNQUFuRCxFQUEyRCxNQUEzRCxFQUFtRSxNQUFuRSxFQUEyRSxNQUEzRSxFQUFtRixNQUFuRixFQUEyRixNQUEzRixFQUFtRyxNQUFuRyxFQUEyRyxNQUEzRyxFQUFtSCxNQUFuSCxFQUEySCxNQUEzSCxFQUFtSSxNQUFuSSxFQUEySSxNQUEzSSxFQUFtSixNQUFuSixFQUEySixNQUEzSixFQUFtSyxNQUFuSyxFQUEySyxNQUEzSyxFQUFtTCxNQUFuTCxFQUEyTCxNQUEzTCxFQUFtTSxNQUFuTSxFQUEyTSxNQUEzTSxFQUFtTixNQUFuTixFQUEyTixNQUEzTixFQUFtTyxNQUFuTyxFQUEyTyxNQUEzTyxFQUFtUCxNQUFuUCxFQUEyUCxNQUEzUCxFQUFtUSxNQUFuUSxFQUEyUSxNQUEzUSxFQUFtUixNQUFuUixFQUEyUixDQUFDLEtBQUssT0FBTyxZQUFiLEVBQTJCLE1BQTNCLENBQTNSLEVBQStULEdBQUcsTUFBSCxDQUEvVCxFQUEyVSxHQUFHLE1BQUgsQ0FBM1UsRUFBdVYsR0FBRyxNQUFILENBQXZWLENBQXhCOztBQUVBLFVBQVEsWUFBUixHQUF1QixDQUFDLE1BQUQsRUFBUyxLQUFULEVBQWdCLEtBQWhCLEVBQXVCLEtBQXZCLEVBQThCLEtBQTlCLEVBQXFDLE9BQXJDLEVBQThDLE9BQTlDLEVBQXVELE9BQXZELEVBQWdFLE9BQWhFLEVBQXlFLE9BQXpFLEVBQWtGLE9BQWxGLEVBQTJGLEtBQTNGLEVBQWtHLEtBQWxHLEVBQXlHLEtBQXpHLEVBQWdILEtBQWhILEVBQXVILEtBQXZILEVBQThILEtBQTlILEVBQXFJLEtBQXJJLEVBQTRJLE9BQTVJLEVBQXFKLE9BQXJKLEVBQThKLE9BQTlKLEVBQXVLLE9BQXZLLEVBQWdMLE9BQWhMLEVBQXlMLE9BQXpMLEVBQWtNLE9BQWxNLEVBQTJNLE9BQTNNLEVBQW9OLE9BQXBOLEVBQTZOLE9BQTdOLEVBQXNPLE9BQXRPLEVBQStPLE9BQS9PLEVBQXdQLE9BQXhQLEVBQWlRLEtBQWpRLEVBQXdRLE9BQXhRLEVBQWlSLE9BQWpSLEVBQTBSLE9BQTFSLEVBQW1TLE9BQW5TLEVBQTRTLEtBQTVTLEVBQW1ULEtBQW5ULEVBQTBULEtBQTFULEVBQWlVLEtBQWpVLENBQXZCOztBQUVBLFVBQVEsMkJBQVIsR0FBdUMsWUFBVztBQUNoRCxRQUFJLENBQUosRUFBTyxDQUFQLEVBQVUsT0FBVixFQUFtQixHQUFuQjtBQUNBLGNBQVUsRUFBVjtBQUNBLFNBQUssSUFBSSxJQUFJLENBQVIsRUFBVyxNQUFNLFFBQVEsYUFBUixDQUFzQixNQUE1QyxFQUFvRCxLQUFLLEdBQUwsR0FBVyxJQUFJLEdBQWYsR0FBcUIsSUFBSSxHQUE3RSxFQUFrRixJQUFJLEtBQUssR0FBTCxHQUFXLEVBQUUsQ0FBYixHQUFpQixFQUFFLENBQXpHLEVBQTRHO0FBQzFHLGNBQVEsUUFBUSxhQUFSLENBQXNCLENBQXRCLENBQVIsSUFBb0MsUUFBUSxZQUFSLENBQXFCLENBQXJCLENBQXBDO0FBQ0Q7QUFDRCxXQUFPLE9BQVA7QUFDRCxHQVBxQyxFQUF0Qzs7QUFTQSxVQUFRLDRCQUFSLEdBQXVDLElBQUksT0FBSixDQUFZLDJEQUFaLENBQXZDOztBQUVBLFVBQVEsd0JBQVIsR0FBbUMsSUFBSSxPQUFKLENBQVksUUFBUSxhQUFSLENBQXNCLElBQXRCLENBQTJCLEdBQTNCLEVBQWdDLEtBQWhDLENBQXNDLElBQXRDLEVBQTRDLElBQTVDLENBQWlELE1BQWpELENBQVosQ0FBbkM7O0FBRUEsVUFBUSxzQkFBUixHQUFpQyxJQUFJLE9BQUosQ0FBWSxvQ0FBWixDQUFqQzs7QUFFQSxVQUFRLHFCQUFSLEdBQWdDLFVBQVMsS0FBVCxFQUFnQjtBQUM5QyxXQUFPLEtBQUssNEJBQUwsQ0FBa0MsSUFBbEMsQ0FBdUMsS0FBdkMsQ0FBUDtBQUNELEdBRkQ7O0FBSUEsVUFBUSxzQkFBUixHQUFpQyxVQUFTLEtBQVQsRUFBZ0I7QUFDL0MsUUFBSSxNQUFKO0FBQ0EsYUFBUyxLQUFLLHdCQUFMLENBQThCLE9BQTlCLENBQXNDLEtBQXRDLEVBQThDLFVBQVMsS0FBVCxFQUFnQjtBQUNyRSxhQUFPLFVBQVMsR0FBVCxFQUFjO0FBQ25CLGVBQU8sTUFBTSwyQkFBTixDQUFrQyxHQUFsQyxDQUFQO0FBQ0QsT0FGRDtBQUdELEtBSnFELENBSW5ELElBSm1ELENBQTdDLENBQVQ7QUFLQSxXQUFPLE1BQU0sTUFBTixHQUFlLEdBQXRCO0FBQ0QsR0FSRDs7QUFVQSxVQUFRLHFCQUFSLEdBQWdDLFVBQVMsS0FBVCxFQUFnQjtBQUM5QyxXQUFPLEtBQUssc0JBQUwsQ0FBNEIsSUFBNUIsQ0FBaUMsS0FBakMsQ0FBUDtBQUNELEdBRkQ7O0FBSUEsVUFBUSxzQkFBUixHQUFpQyxVQUFTLEtBQVQsRUFBZ0I7QUFDL0MsV0FBTyxNQUFNLE1BQU0sT0FBTixDQUFjLElBQWQsRUFBb0IsSUFBcEIsQ0FBTixHQUFrQyxHQUF6QztBQUNELEdBRkQ7O0FBSUEsU0FBTyxPQUFQO0FBRUQsQ0FoRFMsRUFBVjs7QUFrREEsT0FBTyxPQUFQLEdBQWlCLE9BQWpCOzs7OztBQ3ZEQTtBQUNBLElBQUksYUFBSjtBQUFBLElBQ0UsU0FBUyxTQUFULE1BQVMsQ0FBUyxLQUFULEVBQWdCLE1BQWhCLEVBQXdCO0FBQUUsT0FBSyxJQUFJLEdBQVQsSUFBZ0IsTUFBaEIsRUFBd0I7QUFBRSxRQUFJLFFBQVEsSUFBUixDQUFhLE1BQWIsRUFBcUIsR0FBckIsQ0FBSixFQUErQixNQUFNLEdBQU4sSUFBYSxPQUFPLEdBQVAsQ0FBYjtBQUEyQixHQUFDLFNBQVMsSUFBVCxHQUFnQjtBQUFFLFNBQUssV0FBTCxHQUFtQixLQUFuQjtBQUEyQixHQUFDLEtBQUssU0FBTCxHQUFpQixPQUFPLFNBQXhCLENBQW1DLE1BQU0sU0FBTixHQUFrQixJQUFJLElBQUosRUFBbEIsQ0FBOEIsTUFBTSxTQUFOLEdBQWtCLE9BQU8sU0FBekIsQ0FBb0MsT0FBTyxLQUFQO0FBQWUsQ0FENVI7QUFBQSxJQUVFLFVBQVUsR0FBRyxjQUZmOztBQUlBLGdCQUFpQixVQUFTLFVBQVQsRUFBcUI7QUFDcEMsU0FBTyxhQUFQLEVBQXNCLFVBQXRCOztBQUVBLFdBQVMsYUFBVCxDQUF1QixPQUF2QixFQUFnQyxVQUFoQyxFQUE0QyxPQUE1QyxFQUFxRDtBQUNuRCxTQUFLLE9BQUwsR0FBZSxPQUFmO0FBQ0EsU0FBSyxVQUFMLEdBQWtCLFVBQWxCO0FBQ0EsU0FBSyxPQUFMLEdBQWUsT0FBZjtBQUNEOztBQUVELGdCQUFjLFNBQWQsQ0FBd0IsUUFBeEIsR0FBbUMsWUFBVztBQUM1QyxRQUFLLEtBQUssVUFBTCxJQUFtQixJQUFwQixJQUE4QixLQUFLLE9BQUwsSUFBZ0IsSUFBbEQsRUFBeUQ7QUFDdkQsYUFBTyxxQkFBcUIsS0FBSyxPQUExQixHQUFvQyxTQUFwQyxHQUFnRCxLQUFLLFVBQXJELEdBQWtFLE1BQWxFLEdBQTJFLEtBQUssT0FBaEYsR0FBMEYsS0FBakc7QUFDRCxLQUZELE1BRU87QUFDTCxhQUFPLHFCQUFxQixLQUFLLE9BQWpDO0FBQ0Q7QUFDRixHQU5EOztBQVFBLFNBQU8sYUFBUDtBQUVELENBbkJlLENBbUJiLEtBbkJhLENBQWhCOztBQXFCQSxPQUFPLE9BQVAsR0FBaUIsYUFBakI7Ozs7O0FDMUJBO0FBQ0EsSUFBSSxjQUFKO0FBQUEsSUFDRSxTQUFTLFNBQVQsTUFBUyxDQUFTLEtBQVQsRUFBZ0IsTUFBaEIsRUFBd0I7QUFBRSxPQUFLLElBQUksR0FBVCxJQUFnQixNQUFoQixFQUF3QjtBQUFFLFFBQUksUUFBUSxJQUFSLENBQWEsTUFBYixFQUFxQixHQUFyQixDQUFKLEVBQStCLE1BQU0sR0FBTixJQUFhLE9BQU8sR0FBUCxDQUFiO0FBQTJCLEdBQUMsU0FBUyxJQUFULEdBQWdCO0FBQUUsU0FBSyxXQUFMLEdBQW1CLEtBQW5CO0FBQTJCLEdBQUMsS0FBSyxTQUFMLEdBQWlCLE9BQU8sU0FBeEIsQ0FBbUMsTUFBTSxTQUFOLEdBQWtCLElBQUksSUFBSixFQUFsQixDQUE4QixNQUFNLFNBQU4sR0FBa0IsT0FBTyxTQUF6QixDQUFvQyxPQUFPLEtBQVA7QUFBZSxDQUQ1UjtBQUFBLElBRUUsVUFBVSxHQUFHLGNBRmY7O0FBSUEsaUJBQWtCLFVBQVMsVUFBVCxFQUFxQjtBQUNyQyxTQUFPLGNBQVAsRUFBdUIsVUFBdkI7O0FBRUEsV0FBUyxjQUFULENBQXdCLE9BQXhCLEVBQWlDLFVBQWpDLEVBQTZDLE9BQTdDLEVBQXNEO0FBQ3BELFNBQUssT0FBTCxHQUFlLE9BQWY7QUFDQSxTQUFLLFVBQUwsR0FBa0IsVUFBbEI7QUFDQSxTQUFLLE9BQUwsR0FBZSxPQUFmO0FBQ0Q7O0FBRUQsaUJBQWUsU0FBZixDQUF5QixRQUF6QixHQUFvQyxZQUFXO0FBQzdDLFFBQUssS0FBSyxVQUFMLElBQW1CLElBQXBCLElBQThCLEtBQUssT0FBTCxJQUFnQixJQUFsRCxFQUF5RDtBQUN2RCxhQUFPLHNCQUFzQixLQUFLLE9BQTNCLEdBQXFDLFNBQXJDLEdBQWlELEtBQUssVUFBdEQsR0FBbUUsTUFBbkUsR0FBNEUsS0FBSyxPQUFqRixHQUEyRixLQUFsRztBQUNELEtBRkQsTUFFTztBQUNMLGFBQU8sc0JBQXNCLEtBQUssT0FBbEM7QUFDRDtBQUNGLEdBTkQ7O0FBUUEsU0FBTyxjQUFQO0FBRUQsQ0FuQmdCLENBbUJkLEtBbkJjLENBQWpCOztBQXFCQSxPQUFPLE9BQVAsR0FBaUIsY0FBakI7Ozs7O0FDMUJBO0FBQ0EsSUFBSSxTQUFKO0FBQUEsSUFDRSxTQUFTLFNBQVQsTUFBUyxDQUFTLEtBQVQsRUFBZ0IsTUFBaEIsRUFBd0I7QUFBRSxPQUFLLElBQUksR0FBVCxJQUFnQixNQUFoQixFQUF3QjtBQUFFLFFBQUksUUFBUSxJQUFSLENBQWEsTUFBYixFQUFxQixHQUFyQixDQUFKLEVBQStCLE1BQU0sR0FBTixJQUFhLE9BQU8sR0FBUCxDQUFiO0FBQTJCLEdBQUMsU0FBUyxJQUFULEdBQWdCO0FBQUUsU0FBSyxXQUFMLEdBQW1CLEtBQW5CO0FBQTJCLEdBQUMsS0FBSyxTQUFMLEdBQWlCLE9BQU8sU0FBeEIsQ0FBbUMsTUFBTSxTQUFOLEdBQWtCLElBQUksSUFBSixFQUFsQixDQUE4QixNQUFNLFNBQU4sR0FBa0IsT0FBTyxTQUF6QixDQUFvQyxPQUFPLEtBQVA7QUFBZSxDQUQ1UjtBQUFBLElBRUUsVUFBVSxHQUFHLGNBRmY7O0FBSUEsWUFBYSxVQUFTLFVBQVQsRUFBcUI7QUFDaEMsU0FBTyxTQUFQLEVBQWtCLFVBQWxCOztBQUVBLFdBQVMsU0FBVCxDQUFtQixPQUFuQixFQUE0QixVQUE1QixFQUF3QyxPQUF4QyxFQUFpRDtBQUMvQyxTQUFLLE9BQUwsR0FBZSxPQUFmO0FBQ0EsU0FBSyxVQUFMLEdBQWtCLFVBQWxCO0FBQ0EsU0FBSyxPQUFMLEdBQWUsT0FBZjtBQUNEOztBQUVELFlBQVUsU0FBVixDQUFvQixRQUFwQixHQUErQixZQUFXO0FBQ3hDLFFBQUssS0FBSyxVQUFMLElBQW1CLElBQXBCLElBQThCLEtBQUssT0FBTCxJQUFnQixJQUFsRCxFQUF5RDtBQUN2RCxhQUFPLGlCQUFpQixLQUFLLE9BQXRCLEdBQWdDLFNBQWhDLEdBQTRDLEtBQUssVUFBakQsR0FBOEQsTUFBOUQsR0FBdUUsS0FBSyxPQUE1RSxHQUFzRixLQUE3RjtBQUNELEtBRkQsTUFFTztBQUNMLGFBQU8saUJBQWlCLEtBQUssT0FBN0I7QUFDRDtBQUNGLEdBTkQ7O0FBUUEsU0FBTyxTQUFQO0FBRUQsQ0FuQlcsQ0FtQlQsS0FuQlMsQ0FBWjs7QUFxQkEsT0FBTyxPQUFQLEdBQWlCLFNBQWpCOzs7Ozs7Ozs7OztBQzFCQTtBQUNBLElBQUksYUFBSjtBQUFBLElBQW1CLE9BQW5CO0FBQUEsSUFBNEIsTUFBNUI7QUFBQSxJQUFvQyxjQUFwQztBQUFBLElBQW9ELFNBQXBEO0FBQUEsSUFBK0QsT0FBL0Q7QUFBQSxJQUF3RSxTQUF4RTtBQUFBLElBQW1GLEtBQW5GO0FBQUEsSUFDRSxVQUFVLEdBQUcsT0FBSCxJQUFjLFVBQVMsSUFBVCxFQUFlO0FBQUUsT0FBSyxJQUFJLElBQUksQ0FBUixFQUFXLElBQUksS0FBSyxNQUF6QixFQUFpQyxJQUFJLENBQXJDLEVBQXdDLEdBQXhDLEVBQTZDO0FBQUUsUUFBSSxLQUFLLElBQUwsSUFBYSxLQUFLLENBQUwsTUFBWSxJQUE3QixFQUFtQyxPQUFPLENBQVA7QUFBVyxHQUFDLE9BQU8sQ0FBQyxDQUFSO0FBQVksQ0FEcko7O0FBR0EsVUFBVSxRQUFRLFdBQVIsQ0FBVjs7QUFFQSxZQUFZLFFBQVEsYUFBUixDQUFaOztBQUVBLFVBQVUsUUFBUSxXQUFSLENBQVY7O0FBRUEsUUFBUSxRQUFRLFNBQVIsQ0FBUjs7QUFFQSxpQkFBaUIsUUFBUSw0QkFBUixDQUFqQjs7QUFFQSxZQUFZLFFBQVEsdUJBQVIsQ0FBWjs7QUFFQSxnQkFBZ0IsUUFBUSwyQkFBUixDQUFoQjs7QUFFQSxTQUFVLFlBQVc7QUFDbkIsV0FBUyxNQUFULEdBQWtCLENBQUU7O0FBRXBCLFNBQU8sbUJBQVAsR0FBNkIsc0VBQTdCOztBQUVBLFNBQU8seUJBQVAsR0FBbUMsSUFBSSxPQUFKLENBQVksV0FBWixDQUFuQzs7QUFFQSxTQUFPLHFCQUFQLEdBQStCLElBQUksT0FBSixDQUFZLE1BQU0sT0FBTyxtQkFBekIsQ0FBL0I7O0FBRUEsU0FBTywrQkFBUCxHQUF5QyxJQUFJLE9BQUosQ0FBWSwrQkFBWixDQUF6Qzs7QUFFQSxTQUFPLDRCQUFQLEdBQXNDLEVBQXRDOztBQUVBLFNBQU8sUUFBUCxHQUFrQixFQUFsQjs7QUFFQSxTQUFPLFNBQVAsR0FBbUIsVUFBUyxzQkFBVCxFQUFpQyxhQUFqQyxFQUFnRDtBQUNqRSxRQUFJLDBCQUEwQixJQUE5QixFQUFvQztBQUNsQywrQkFBeUIsSUFBekI7QUFDRDtBQUNELFFBQUksaUJBQWlCLElBQXJCLEVBQTJCO0FBQ3pCLHNCQUFnQixJQUFoQjtBQUNEO0FBQ0QsU0FBSyxRQUFMLENBQWMsc0JBQWQsR0FBdUMsc0JBQXZDO0FBQ0EsU0FBSyxRQUFMLENBQWMsYUFBZCxHQUE4QixhQUE5QjtBQUNELEdBVEQ7O0FBV0EsU0FBTyxLQUFQLEdBQWUsVUFBUyxLQUFULEVBQWdCLHNCQUFoQixFQUF3QyxhQUF4QyxFQUF1RDtBQUNwRSxRQUFJLE9BQUosRUFBYSxNQUFiO0FBQ0EsUUFBSSwwQkFBMEIsSUFBOUIsRUFBb0M7QUFDbEMsK0JBQXlCLEtBQXpCO0FBQ0Q7QUFDRCxRQUFJLGlCQUFpQixJQUFyQixFQUEyQjtBQUN6QixzQkFBZ0IsSUFBaEI7QUFDRDtBQUNELFNBQUssUUFBTCxDQUFjLHNCQUFkLEdBQXVDLHNCQUF2QztBQUNBLFNBQUssUUFBTCxDQUFjLGFBQWQsR0FBOEIsYUFBOUI7QUFDQSxRQUFJLFNBQVMsSUFBYixFQUFtQjtBQUNqQixhQUFPLEVBQVA7QUFDRDtBQUNELFlBQVEsTUFBTSxJQUFOLENBQVcsS0FBWCxDQUFSO0FBQ0EsUUFBSSxNQUFNLE1BQU0sTUFBaEIsRUFBd0I7QUFDdEIsYUFBTyxFQUFQO0FBQ0Q7QUFDRCxjQUFVO0FBQ1IsOEJBQXdCLHNCQURoQjtBQUVSLHFCQUFlLGFBRlA7QUFHUixTQUFHO0FBSEssS0FBVjtBQUtBLFlBQVEsTUFBTSxNQUFOLENBQWEsQ0FBYixDQUFSO0FBQ0UsV0FBSyxHQUFMO0FBQ0UsaUJBQVMsS0FBSyxhQUFMLENBQW1CLEtBQW5CLEVBQTBCLE9BQTFCLENBQVQ7QUFDQSxVQUFFLFFBQVEsQ0FBVjtBQUNBO0FBQ0YsV0FBSyxHQUFMO0FBQ0UsaUJBQVMsS0FBSyxZQUFMLENBQWtCLEtBQWxCLEVBQXlCLE9BQXpCLENBQVQ7QUFDQSxVQUFFLFFBQVEsQ0FBVjtBQUNBO0FBQ0Y7QUFDRSxpQkFBUyxLQUFLLFdBQUwsQ0FBaUIsS0FBakIsRUFBd0IsSUFBeEIsRUFBOEIsQ0FBQyxHQUFELEVBQU0sR0FBTixDQUE5QixFQUEwQyxPQUExQyxDQUFUO0FBVko7QUFZQSxRQUFJLEtBQUsseUJBQUwsQ0FBK0IsT0FBL0IsQ0FBdUMsTUFBTSxLQUFOLENBQVksUUFBUSxDQUFwQixDQUF2QyxFQUErRCxFQUEvRCxNQUF1RSxFQUEzRSxFQUErRTtBQUM3RSxZQUFNLElBQUksY0FBSixDQUFtQixpQ0FBaUMsTUFBTSxLQUFOLENBQVksUUFBUSxDQUFwQixDQUFqQyxHQUEwRCxJQUE3RSxDQUFOO0FBQ0Q7QUFDRCxXQUFPLE1BQVA7QUFDRCxHQXRDRDs7QUF3Q0EsU0FBTyxJQUFQLEdBQWMsVUFBUyxLQUFULEVBQWdCLHNCQUFoQixFQUF3QyxhQUF4QyxFQUF1RDtBQUNuRSxRQUFJLEdBQUosRUFBUyxNQUFULEVBQWlCLElBQWpCO0FBQ0EsUUFBSSwwQkFBMEIsSUFBOUIsRUFBb0M7QUFDbEMsK0JBQXlCLEtBQXpCO0FBQ0Q7QUFDRCxRQUFJLGlCQUFpQixJQUFyQixFQUEyQjtBQUN6QixzQkFBZ0IsSUFBaEI7QUFDRDtBQUNELFFBQUksU0FBUyxJQUFiLEVBQW1CO0FBQ2pCLGFBQU8sTUFBUDtBQUNEO0FBQ0Qsa0JBQWMsS0FBZCx1REFBYyxLQUFkO0FBQ0EsUUFBSSxTQUFTLFFBQWIsRUFBdUI7QUFDckIsVUFBSSxpQkFBaUIsSUFBckIsRUFBMkI7QUFDekIsZUFBTyxNQUFNLFdBQU4sRUFBUDtBQUNELE9BRkQsTUFFTyxJQUFJLGlCQUFpQixJQUFyQixFQUEyQjtBQUNoQyxpQkFBUyxjQUFjLEtBQWQsQ0FBVDtBQUNBLFlBQUksT0FBTyxNQUFQLEtBQWtCLFFBQWxCLElBQStCLFVBQVUsSUFBN0MsRUFBb0Q7QUFDbEQsaUJBQU8sTUFBUDtBQUNEO0FBQ0Y7QUFDRCxhQUFPLEtBQUssVUFBTCxDQUFnQixLQUFoQixDQUFQO0FBQ0Q7QUFDRCxRQUFJLFNBQVMsU0FBYixFQUF3QjtBQUN0QixhQUFRLFFBQVEsTUFBUixHQUFpQixPQUF6QjtBQUNEO0FBQ0QsUUFBSSxNQUFNLFFBQU4sQ0FBZSxLQUFmLENBQUosRUFBMkI7QUFDekIsYUFBUSxTQUFTLFFBQVQsR0FBb0IsTUFBTSxLQUFOLEdBQWMsR0FBbEMsR0FBd0MsT0FBTyxTQUFTLEtBQVQsQ0FBUCxDQUFoRDtBQUNEO0FBQ0QsUUFBSSxNQUFNLFNBQU4sQ0FBZ0IsS0FBaEIsQ0FBSixFQUE0QjtBQUMxQixhQUFRLFNBQVMsUUFBVCxHQUFvQixNQUFNLEtBQU4sR0FBYyxHQUFsQyxHQUF3QyxPQUFPLFdBQVcsS0FBWCxDQUFQLENBQWhEO0FBQ0Q7QUFDRCxRQUFJLFNBQVMsUUFBYixFQUF1QjtBQUNyQixhQUFRLFVBQVUsS0FBVixHQUFrQixNQUFsQixHQUE0QixVQUFVLENBQUMsS0FBWCxHQUFtQixPQUFuQixHQUE4QixNQUFNLEtBQU4sSUFBZSxNQUFmLEdBQXdCLEtBQTFGO0FBQ0Q7QUFDRCxRQUFJLFFBQVEscUJBQVIsQ0FBOEIsS0FBOUIsQ0FBSixFQUEwQztBQUN4QyxhQUFPLFFBQVEsc0JBQVIsQ0FBK0IsS0FBL0IsQ0FBUDtBQUNEO0FBQ0QsUUFBSSxRQUFRLHFCQUFSLENBQThCLEtBQTlCLENBQUosRUFBMEM7QUFDeEMsYUFBTyxRQUFRLHNCQUFSLENBQStCLEtBQS9CLENBQVA7QUFDRDtBQUNELFFBQUksT0FBTyxLQUFYLEVBQWtCO0FBQ2hCLGFBQU8sSUFBUDtBQUNEO0FBQ0QsUUFBSSxNQUFNLFlBQU4sQ0FBbUIsSUFBbkIsQ0FBd0IsS0FBeEIsQ0FBSixFQUFvQztBQUNsQyxhQUFPLE1BQU0sS0FBTixHQUFjLEdBQXJCO0FBQ0Q7QUFDRCxRQUFJLENBQUMsTUFBTSxNQUFNLFdBQU4sRUFBUCxNQUFnQyxNQUFoQyxJQUEwQyxRQUFRLEdBQWxELElBQXlELFFBQVEsTUFBakUsSUFBMkUsUUFBUSxPQUF2RixFQUFnRztBQUM5RixhQUFPLE1BQU0sS0FBTixHQUFjLEdBQXJCO0FBQ0Q7QUFDRCxXQUFPLEtBQVA7QUFDRCxHQW5ERDs7QUFxREEsU0FBTyxVQUFQLEdBQW9CLFVBQVMsS0FBVCxFQUFnQixzQkFBaEIsRUFBd0MsYUFBeEMsRUFBdUQ7QUFDekUsUUFBSSxDQUFKLEVBQU8sR0FBUCxFQUFZLElBQVosRUFBa0IsTUFBbEIsRUFBMEIsR0FBMUI7QUFDQSxRQUFJLGlCQUFpQixJQUFyQixFQUEyQjtBQUN6QixzQkFBZ0IsSUFBaEI7QUFDRDtBQUNELFFBQUksaUJBQWlCLEtBQXJCLEVBQTRCO0FBQzFCLGVBQVMsRUFBVDtBQUNBLFdBQUssSUFBSSxDQUFKLEVBQU8sT0FBTyxNQUFNLE1BQXpCLEVBQWlDLElBQUksSUFBckMsRUFBMkMsR0FBM0MsRUFBZ0Q7QUFDOUMsY0FBTSxNQUFNLENBQU4sQ0FBTjtBQUNBLGVBQU8sSUFBUCxDQUFZLEtBQUssSUFBTCxDQUFVLEdBQVYsQ0FBWjtBQUNEO0FBQ0QsYUFBTyxNQUFNLE9BQU8sSUFBUCxDQUFZLElBQVosQ0FBTixHQUEwQixHQUFqQztBQUNELEtBUEQsTUFPTztBQUNMLGVBQVMsRUFBVDtBQUNBLFdBQUssR0FBTCxJQUFZLEtBQVosRUFBbUI7QUFDakIsY0FBTSxNQUFNLEdBQU4sQ0FBTjtBQUNBLGVBQU8sSUFBUCxDQUFZLEtBQUssSUFBTCxDQUFVLEdBQVYsSUFBaUIsSUFBakIsR0FBd0IsS0FBSyxJQUFMLENBQVUsR0FBVixDQUFwQztBQUNEO0FBQ0QsYUFBTyxNQUFNLE9BQU8sSUFBUCxDQUFZLElBQVosQ0FBTixHQUEwQixHQUFqQztBQUNEO0FBQ0YsR0FwQkQ7O0FBc0JBLFNBQU8sV0FBUCxHQUFxQixVQUFTLE1BQVQsRUFBaUIsVUFBakIsRUFBNkIsZ0JBQTdCLEVBQStDLE9BQS9DLEVBQXdELFFBQXhELEVBQWtFO0FBQ3JGLFFBQUksQ0FBSixFQUFPLGdCQUFQLEVBQXlCLEtBQXpCLEVBQWdDLE1BQWhDLEVBQXdDLE9BQXhDLEVBQWlELEdBQWpELEVBQXNELElBQXRELEVBQTRELE1BQTVELEVBQW9FLEdBQXBFO0FBQ0EsUUFBSSxjQUFjLElBQWxCLEVBQXdCO0FBQ3RCLG1CQUFhLElBQWI7QUFDRDtBQUNELFFBQUksb0JBQW9CLElBQXhCLEVBQThCO0FBQzVCLHlCQUFtQixDQUFDLEdBQUQsRUFBTSxHQUFOLENBQW5CO0FBQ0Q7QUFDRCxRQUFJLFdBQVcsSUFBZixFQUFxQjtBQUNuQixnQkFBVSxJQUFWO0FBQ0Q7QUFDRCxRQUFJLFlBQVksSUFBaEIsRUFBc0I7QUFDcEIsaUJBQVcsSUFBWDtBQUNEO0FBQ0QsUUFBSSxXQUFXLElBQWYsRUFBcUI7QUFDbkIsZ0JBQVU7QUFDUixnQ0FBd0IsS0FBSyxRQUFMLENBQWMsc0JBRDlCO0FBRVIsdUJBQWUsS0FBSyxRQUFMLENBQWMsYUFGckI7QUFHUixXQUFHO0FBSEssT0FBVjtBQUtEO0FBQ0QsUUFBSSxRQUFRLENBQVo7QUFDQSxRQUFJLE1BQU0sT0FBTyxNQUFQLENBQWMsQ0FBZCxDQUFOLEVBQXdCLFFBQVEsSUFBUixDQUFhLGdCQUFiLEVBQStCLEdBQS9CLEtBQXVDLENBQW5FLEVBQXNFO0FBQ3BFLGVBQVMsS0FBSyxpQkFBTCxDQUF1QixNQUF2QixFQUErQixPQUEvQixDQUFUO0FBQ0EsVUFBSSxRQUFRLENBQVo7QUFDQSxVQUFJLGNBQWMsSUFBbEIsRUFBd0I7QUFDdEIsY0FBTSxNQUFNLEtBQU4sQ0FBWSxPQUFPLEtBQVAsQ0FBYSxDQUFiLENBQVosRUFBNkIsR0FBN0IsQ0FBTjtBQUNBLFlBQUksRUFBRSxPQUFPLElBQUksTUFBSixDQUFXLENBQVgsQ0FBUCxFQUFzQixRQUFRLElBQVIsQ0FBYSxVQUFiLEVBQXlCLElBQXpCLEtBQWtDLENBQTFELENBQUosRUFBa0U7QUFDaEUsZ0JBQU0sSUFBSSxjQUFKLENBQW1CLDRCQUE0QixPQUFPLEtBQVAsQ0FBYSxDQUFiLENBQTVCLEdBQThDLElBQWpFLENBQU47QUFDRDtBQUNGO0FBQ0YsS0FURCxNQVNPO0FBQ0wsVUFBSSxDQUFDLFVBQUwsRUFBaUI7QUFDZixpQkFBUyxPQUFPLEtBQVAsQ0FBYSxDQUFiLENBQVQ7QUFDQSxhQUFLLE9BQU8sTUFBWjtBQUNBLGlCQUFTLE9BQU8sT0FBUCxDQUFlLElBQWYsQ0FBVDtBQUNBLFlBQUksV0FBVyxDQUFDLENBQWhCLEVBQW1CO0FBQ2pCLG1CQUFTLE1BQU0sS0FBTixDQUFZLE9BQU8sS0FBUCxDQUFhLENBQWIsRUFBZ0IsTUFBaEIsQ0FBWixDQUFUO0FBQ0Q7QUFDRixPQVBELE1BT087QUFDTCwyQkFBbUIsV0FBVyxJQUFYLENBQWdCLEdBQWhCLENBQW5CO0FBQ0Esa0JBQVUsS0FBSyw0QkFBTCxDQUFrQyxnQkFBbEMsQ0FBVjtBQUNBLFlBQUksV0FBVyxJQUFmLEVBQXFCO0FBQ25CLG9CQUFVLElBQUksT0FBSixDQUFZLFlBQVksZ0JBQVosR0FBK0IsR0FBM0MsQ0FBVjtBQUNBLGVBQUssNEJBQUwsQ0FBa0MsZ0JBQWxDLElBQXNELE9BQXREO0FBQ0Q7QUFDRCxZQUFJLFFBQVEsUUFBUSxJQUFSLENBQWEsT0FBTyxLQUFQLENBQWEsQ0FBYixDQUFiLENBQVosRUFBMkM7QUFDekMsbUJBQVMsTUFBTSxDQUFOLENBQVQ7QUFDQSxlQUFLLE9BQU8sTUFBWjtBQUNELFNBSEQsTUFHTztBQUNMLGdCQUFNLElBQUksY0FBSixDQUFtQixtQ0FBbUMsTUFBbkMsR0FBNEMsSUFBL0QsQ0FBTjtBQUNEO0FBQ0Y7QUFDRCxVQUFJLFFBQUosRUFBYztBQUNaLGlCQUFTLEtBQUssY0FBTCxDQUFvQixNQUFwQixFQUE0QixPQUE1QixDQUFUO0FBQ0Q7QUFDRjtBQUNELFlBQVEsQ0FBUixHQUFZLENBQVo7QUFDQSxXQUFPLE1BQVA7QUFDRCxHQTNERDs7QUE2REEsU0FBTyxpQkFBUCxHQUEyQixVQUFTLE1BQVQsRUFBaUIsT0FBakIsRUFBMEI7QUFDbkQsUUFBSSxDQUFKLEVBQU8sS0FBUCxFQUFjLE1BQWQ7QUFDQSxRQUFJLFFBQVEsQ0FBWjtBQUNBLFFBQUksRUFBRSxRQUFRLEtBQUsscUJBQUwsQ0FBMkIsSUFBM0IsQ0FBZ0MsT0FBTyxLQUFQLENBQWEsQ0FBYixDQUFoQyxDQUFWLENBQUosRUFBaUU7QUFDL0QsWUFBTSxJQUFJLFNBQUosQ0FBYyxtQ0FBbUMsT0FBTyxLQUFQLENBQWEsQ0FBYixDQUFuQyxHQUFxRCxJQUFuRSxDQUFOO0FBQ0Q7QUFDRCxhQUFTLE1BQU0sQ0FBTixFQUFTLE1BQVQsQ0FBZ0IsQ0FBaEIsRUFBbUIsTUFBTSxDQUFOLEVBQVMsTUFBVCxHQUFrQixDQUFyQyxDQUFUO0FBQ0EsUUFBSSxRQUFRLE9BQU8sTUFBUCxDQUFjLENBQWQsQ0FBWixFQUE4QjtBQUM1QixlQUFTLFVBQVUsMEJBQVYsQ0FBcUMsTUFBckMsQ0FBVDtBQUNELEtBRkQsTUFFTztBQUNMLGVBQVMsVUFBVSwwQkFBVixDQUFxQyxNQUFyQyxDQUFUO0FBQ0Q7QUFDRCxTQUFLLE1BQU0sQ0FBTixFQUFTLE1BQWQ7QUFDQSxZQUFRLENBQVIsR0FBWSxDQUFaO0FBQ0EsV0FBTyxNQUFQO0FBQ0QsR0FmRDs7QUFpQkEsU0FBTyxhQUFQLEdBQXVCLFVBQVMsUUFBVCxFQUFtQixPQUFuQixFQUE0QjtBQUNqRCxRQUFJLENBQUosRUFBTyxDQUFQLEVBQVUsUUFBVixFQUFvQixHQUFwQixFQUF5QixNQUF6QixFQUFpQyxHQUFqQyxFQUFzQyxLQUF0QztBQUNBLGFBQVMsRUFBVDtBQUNBLFVBQU0sU0FBUyxNQUFmO0FBQ0EsUUFBSSxRQUFRLENBQVo7QUFDQSxTQUFLLENBQUw7QUFDQSxXQUFPLElBQUksR0FBWCxFQUFnQjtBQUNkLGNBQVEsQ0FBUixHQUFZLENBQVo7QUFDQSxjQUFRLFNBQVMsTUFBVCxDQUFnQixDQUFoQixDQUFSO0FBQ0UsYUFBSyxHQUFMO0FBQ0UsaUJBQU8sSUFBUCxDQUFZLEtBQUssYUFBTCxDQUFtQixRQUFuQixFQUE2QixPQUE3QixDQUFaO0FBQ0EsY0FBSSxRQUFRLENBQVo7QUFDQTtBQUNGLGFBQUssR0FBTDtBQUNFLGlCQUFPLElBQVAsQ0FBWSxLQUFLLFlBQUwsQ0FBa0IsUUFBbEIsRUFBNEIsT0FBNUIsQ0FBWjtBQUNBLGNBQUksUUFBUSxDQUFaO0FBQ0E7QUFDRixhQUFLLEdBQUw7QUFDRSxpQkFBTyxNQUFQO0FBQ0YsYUFBSyxHQUFMO0FBQ0EsYUFBSyxHQUFMO0FBQ0EsYUFBSyxJQUFMO0FBQ0U7QUFDRjtBQUNFLHFCQUFZLENBQUMsTUFBTSxTQUFTLE1BQVQsQ0FBZ0IsQ0FBaEIsQ0FBUCxNQUErQixHQUEvQixJQUFzQyxRQUFRLEdBQTFEO0FBQ0Esa0JBQVEsS0FBSyxXQUFMLENBQWlCLFFBQWpCLEVBQTJCLENBQUMsR0FBRCxFQUFNLEdBQU4sQ0FBM0IsRUFBdUMsQ0FBQyxHQUFELEVBQU0sR0FBTixDQUF2QyxFQUFtRCxPQUFuRCxDQUFSO0FBQ0EsY0FBSSxRQUFRLENBQVo7QUFDQSxjQUFJLENBQUMsUUFBRCxJQUFhLE9BQU8sS0FBUCxLQUFpQixRQUE5QixLQUEyQyxNQUFNLE9BQU4sQ0FBYyxJQUFkLE1BQXdCLENBQUMsQ0FBekIsSUFBOEIsTUFBTSxPQUFOLENBQWMsS0FBZCxNQUF5QixDQUFDLENBQW5HLENBQUosRUFBMkc7QUFDekcsZ0JBQUk7QUFDRixzQkFBUSxLQUFLLFlBQUwsQ0FBa0IsTUFBTSxLQUFOLEdBQWMsR0FBaEMsQ0FBUjtBQUNELGFBRkQsQ0FFRSxPQUFPLEtBQVAsRUFBYztBQUNkLGtCQUFJLEtBQUo7QUFDRDtBQUNGO0FBQ0QsaUJBQU8sSUFBUCxDQUFZLEtBQVo7QUFDQSxZQUFFLENBQUY7QUEzQko7QUE2QkEsUUFBRSxDQUFGO0FBQ0Q7QUFDRCxVQUFNLElBQUksU0FBSixDQUFjLGtDQUFrQyxRQUFoRCxDQUFOO0FBQ0QsR0F4Q0Q7O0FBMENBLFNBQU8sWUFBUCxHQUFzQixVQUFTLE9BQVQsRUFBa0IsT0FBbEIsRUFBMkI7QUFDL0MsUUFBSSxJQUFKLEVBQVUsQ0FBVixFQUFhLEdBQWIsRUFBa0IsR0FBbEIsRUFBdUIsTUFBdkIsRUFBK0IsdUJBQS9CLEVBQXdELEtBQXhEO0FBQ0EsYUFBUyxFQUFUO0FBQ0EsVUFBTSxRQUFRLE1BQWQ7QUFDQSxRQUFJLFFBQVEsQ0FBWjtBQUNBLFNBQUssQ0FBTDtBQUNBLDhCQUEwQixLQUExQjtBQUNBLFdBQU8sSUFBSSxHQUFYLEVBQWdCO0FBQ2QsY0FBUSxDQUFSLEdBQVksQ0FBWjtBQUNBLGNBQVEsUUFBUSxNQUFSLENBQWUsQ0FBZixDQUFSO0FBQ0UsYUFBSyxHQUFMO0FBQ0EsYUFBSyxHQUFMO0FBQ0EsYUFBSyxJQUFMO0FBQ0UsWUFBRSxDQUFGO0FBQ0Esa0JBQVEsQ0FBUixHQUFZLENBQVo7QUFDQSxvQ0FBMEIsSUFBMUI7QUFDQTtBQUNGLGFBQUssR0FBTDtBQUNFLGlCQUFPLE1BQVA7QUFUSjtBQVdBLFVBQUksdUJBQUosRUFBNkI7QUFDM0Isa0NBQTBCLEtBQTFCO0FBQ0E7QUFDRDtBQUNELFlBQU0sS0FBSyxXQUFMLENBQWlCLE9BQWpCLEVBQTBCLENBQUMsR0FBRCxFQUFNLEdBQU4sRUFBVyxJQUFYLENBQTFCLEVBQTRDLENBQUMsR0FBRCxFQUFNLEdBQU4sQ0FBNUMsRUFBd0QsT0FBeEQsRUFBaUUsS0FBakUsQ0FBTjtBQUNBLFVBQUksUUFBUSxDQUFaO0FBQ0EsYUFBTyxLQUFQO0FBQ0EsYUFBTyxJQUFJLEdBQVgsRUFBZ0I7QUFDZCxnQkFBUSxDQUFSLEdBQVksQ0FBWjtBQUNBLGdCQUFRLFFBQVEsTUFBUixDQUFlLENBQWYsQ0FBUjtBQUNFLGVBQUssR0FBTDtBQUNFLG9CQUFRLEtBQUssYUFBTCxDQUFtQixPQUFuQixFQUE0QixPQUE1QixDQUFSO0FBQ0EsZ0JBQUksUUFBUSxDQUFaO0FBQ0EsZ0JBQUksT0FBTyxHQUFQLE1BQWdCLEtBQUssQ0FBekIsRUFBNEI7QUFDMUIscUJBQU8sR0FBUCxJQUFjLEtBQWQ7QUFDRDtBQUNELG1CQUFPLElBQVA7QUFDQTtBQUNGLGVBQUssR0FBTDtBQUNFLG9CQUFRLEtBQUssWUFBTCxDQUFrQixPQUFsQixFQUEyQixPQUEzQixDQUFSO0FBQ0EsZ0JBQUksUUFBUSxDQUFaO0FBQ0EsZ0JBQUksT0FBTyxHQUFQLE1BQWdCLEtBQUssQ0FBekIsRUFBNEI7QUFDMUIscUJBQU8sR0FBUCxJQUFjLEtBQWQ7QUFDRDtBQUNELG1CQUFPLElBQVA7QUFDQTtBQUNGLGVBQUssR0FBTDtBQUNBLGVBQUssR0FBTDtBQUNBLGVBQUssSUFBTDtBQUNFO0FBQ0Y7QUFDRSxvQkFBUSxLQUFLLFdBQUwsQ0FBaUIsT0FBakIsRUFBMEIsQ0FBQyxHQUFELEVBQU0sR0FBTixDQUExQixFQUFzQyxDQUFDLEdBQUQsRUFBTSxHQUFOLENBQXRDLEVBQWtELE9BQWxELENBQVI7QUFDQSxnQkFBSSxRQUFRLENBQVo7QUFDQSxnQkFBSSxPQUFPLEdBQVAsTUFBZ0IsS0FBSyxDQUF6QixFQUE0QjtBQUMxQixxQkFBTyxHQUFQLElBQWMsS0FBZDtBQUNEO0FBQ0QsbUJBQU8sSUFBUDtBQUNBLGNBQUUsQ0FBRjtBQTVCSjtBQThCQSxVQUFFLENBQUY7QUFDQSxZQUFJLElBQUosRUFBVTtBQUNSO0FBQ0Q7QUFDRjtBQUNGO0FBQ0QsVUFBTSxJQUFJLFNBQUosQ0FBYyxrQ0FBa0MsT0FBaEQsQ0FBTjtBQUNELEdBbEVEOztBQW9FQSxTQUFPLGNBQVAsR0FBd0IsVUFBUyxNQUFULEVBQWlCLE9BQWpCLEVBQTBCO0FBQ2hELFFBQUksSUFBSixFQUFVLElBQVYsRUFBZ0Isc0JBQWhCLEVBQXdDLFNBQXhDLEVBQW1ELFVBQW5ELEVBQStELFNBQS9ELEVBQTBFLGFBQTFFLEVBQXlGLEdBQXpGLEVBQThGLFdBQTlGLEVBQTJHLFFBQTNHLEVBQXFILGFBQXJIO0FBQ0EsYUFBUyxNQUFNLElBQU4sQ0FBVyxNQUFYLENBQVQ7QUFDQSxrQkFBYyxPQUFPLFdBQVAsRUFBZDtBQUNBLFlBQVEsV0FBUjtBQUNFLFdBQUssTUFBTDtBQUNBLFdBQUssRUFBTDtBQUNBLFdBQUssR0FBTDtBQUNFLGVBQU8sSUFBUDtBQUNGLFdBQUssTUFBTDtBQUNFLGVBQU8sSUFBUDtBQUNGLFdBQUssT0FBTDtBQUNFLGVBQU8sS0FBUDtBQUNGLFdBQUssTUFBTDtBQUNFLGVBQU8sS0FBUDtBQUNGLFdBQUssTUFBTDtBQUNFLGVBQU8sSUFBRSxDQUFUO0FBQ0YsV0FBSyxPQUFMO0FBQ0UsZUFBTyxLQUFQO0FBQ0Y7QUFDRSxvQkFBWSxZQUFZLE1BQVosQ0FBbUIsQ0FBbkIsQ0FBWjtBQUNBLGdCQUFRLFNBQVI7QUFDRSxlQUFLLEdBQUw7QUFDRSx5QkFBYSxPQUFPLE9BQVAsQ0FBZSxHQUFmLENBQWI7QUFDQSxnQkFBSSxlQUFlLENBQUMsQ0FBcEIsRUFBdUI7QUFDckIsMEJBQVksV0FBWjtBQUNELGFBRkQsTUFFTztBQUNMLDBCQUFZLFlBQVksS0FBWixDQUFrQixDQUFsQixFQUFxQixVQUFyQixDQUFaO0FBQ0Q7QUFDRCxvQkFBUSxTQUFSO0FBQ0UsbUJBQUssR0FBTDtBQUNFLG9CQUFJLGVBQWUsQ0FBQyxDQUFwQixFQUF1QjtBQUNyQix5QkFBTyxTQUFTLEtBQUssV0FBTCxDQUFpQixPQUFPLEtBQVAsQ0FBYSxDQUFiLENBQWpCLENBQVQsQ0FBUDtBQUNEO0FBQ0QsdUJBQU8sSUFBUDtBQUNGLG1CQUFLLE1BQUw7QUFDRSx1QkFBTyxNQUFNLEtBQU4sQ0FBWSxPQUFPLEtBQVAsQ0FBYSxDQUFiLENBQVosQ0FBUDtBQUNGLG1CQUFLLE9BQUw7QUFDRSx1QkFBTyxNQUFNLEtBQU4sQ0FBWSxPQUFPLEtBQVAsQ0FBYSxDQUFiLENBQVosQ0FBUDtBQUNGLG1CQUFLLE9BQUw7QUFDRSx1QkFBTyxTQUFTLEtBQUssV0FBTCxDQUFpQixPQUFPLEtBQVAsQ0FBYSxDQUFiLENBQWpCLENBQVQsQ0FBUDtBQUNGLG1CQUFLLFFBQUw7QUFDRSx1QkFBTyxNQUFNLFlBQU4sQ0FBbUIsS0FBSyxXQUFMLENBQWlCLE9BQU8sS0FBUCxDQUFhLENBQWIsQ0FBakIsQ0FBbkIsRUFBc0QsS0FBdEQsQ0FBUDtBQUNGLG1CQUFLLFNBQUw7QUFDRSx1QkFBTyxXQUFXLEtBQUssV0FBTCxDQUFpQixPQUFPLEtBQVAsQ0FBYSxDQUFiLENBQWpCLENBQVgsQ0FBUDtBQUNGLG1CQUFLLGFBQUw7QUFDRSx1QkFBTyxNQUFNLFlBQU4sQ0FBbUIsTUFBTSxLQUFOLENBQVksT0FBTyxLQUFQLENBQWEsRUFBYixDQUFaLENBQW5CLENBQVA7QUFDRjtBQUNFLG9CQUFJLFdBQVcsSUFBZixFQUFxQjtBQUNuQiw0QkFBVTtBQUNSLDRDQUF3QixLQUFLLFFBQUwsQ0FBYyxzQkFEOUI7QUFFUixtQ0FBZSxLQUFLLFFBQUwsQ0FBYyxhQUZyQjtBQUdSLHVCQUFHO0FBSEssbUJBQVY7QUFLRDtBQUNELGdDQUFnQixRQUFRLGFBQXhCLEVBQXVDLHlCQUF5QixRQUFRLHNCQUF4RTtBQUNBLG9CQUFJLGFBQUosRUFBbUI7QUFDakIsa0NBQWdCLE1BQU0sS0FBTixDQUFZLE1BQVosQ0FBaEI7QUFDQSwrQkFBYSxjQUFjLE9BQWQsQ0FBc0IsR0FBdEIsQ0FBYjtBQUNBLHNCQUFJLGVBQWUsQ0FBQyxDQUFwQixFQUF1QjtBQUNyQiwyQkFBTyxjQUFjLGFBQWQsRUFBNkIsSUFBN0IsQ0FBUDtBQUNELG1CQUZELE1BRU87QUFDTCwrQkFBVyxNQUFNLEtBQU4sQ0FBWSxjQUFjLEtBQWQsQ0FBb0IsYUFBYSxDQUFqQyxDQUFaLENBQVg7QUFDQSx3QkFBSSxFQUFFLFNBQVMsTUFBVCxHQUFrQixDQUFwQixDQUFKLEVBQTRCO0FBQzFCLGlDQUFXLElBQVg7QUFDRDtBQUNELDJCQUFPLGNBQWMsY0FBYyxLQUFkLENBQW9CLENBQXBCLEVBQXVCLFVBQXZCLENBQWQsRUFBa0QsUUFBbEQsQ0FBUDtBQUNEO0FBQ0Y7QUFDRCxvQkFBSSxzQkFBSixFQUE0QjtBQUMxQix3QkFBTSxJQUFJLGNBQUosQ0FBbUIsbUVBQW5CLENBQU47QUFDRDtBQUNELHVCQUFPLElBQVA7QUEzQ0o7QUE2Q0E7QUFDRixlQUFLLEdBQUw7QUFDRSxnQkFBSSxTQUFTLE9BQU8sS0FBUCxDQUFhLENBQWIsRUFBZ0IsQ0FBaEIsQ0FBYixFQUFpQztBQUMvQixxQkFBTyxNQUFNLE1BQU4sQ0FBYSxNQUFiLENBQVA7QUFDRCxhQUZELE1BRU8sSUFBSSxNQUFNLFFBQU4sQ0FBZSxNQUFmLENBQUosRUFBNEI7QUFDakMscUJBQU8sTUFBTSxNQUFOLENBQWEsTUFBYixDQUFQO0FBQ0QsYUFGTSxNQUVBLElBQUksTUFBTSxTQUFOLENBQWdCLE1BQWhCLENBQUosRUFBNkI7QUFDbEMscUJBQU8sV0FBVyxNQUFYLENBQVA7QUFDRCxhQUZNLE1BRUE7QUFDTCxxQkFBTyxNQUFQO0FBQ0Q7QUFDRDtBQUNGLGVBQUssR0FBTDtBQUNFLGdCQUFJLE1BQU0sUUFBTixDQUFlLE1BQWYsQ0FBSixFQUE0QjtBQUMxQixvQkFBTSxNQUFOO0FBQ0EscUJBQU8sU0FBUyxHQUFULENBQVA7QUFDQSxrQkFBSSxRQUFRLE9BQU8sSUFBUCxDQUFaLEVBQTBCO0FBQ3hCLHVCQUFPLElBQVA7QUFDRCxlQUZELE1BRU87QUFDTCx1QkFBTyxHQUFQO0FBQ0Q7QUFDRixhQVJELE1BUU8sSUFBSSxNQUFNLFNBQU4sQ0FBZ0IsTUFBaEIsQ0FBSixFQUE2QjtBQUNsQyxxQkFBTyxXQUFXLE1BQVgsQ0FBUDtBQUNELGFBRk0sTUFFQSxJQUFJLEtBQUssK0JBQUwsQ0FBcUMsSUFBckMsQ0FBMEMsTUFBMUMsQ0FBSixFQUF1RDtBQUM1RCxxQkFBTyxXQUFXLE9BQU8sT0FBUCxDQUFlLEdBQWYsRUFBb0IsRUFBcEIsQ0FBWCxDQUFQO0FBQ0Q7QUFDRCxtQkFBTyxNQUFQO0FBQ0YsZUFBSyxHQUFMO0FBQ0UsZ0JBQUksTUFBTSxRQUFOLENBQWUsT0FBTyxLQUFQLENBQWEsQ0FBYixDQUFmLENBQUosRUFBcUM7QUFDbkMsa0JBQUksUUFBUSxPQUFPLE1BQVAsQ0FBYyxDQUFkLENBQVosRUFBOEI7QUFDNUIsdUJBQU8sQ0FBQyxNQUFNLE1BQU4sQ0FBYSxPQUFPLEtBQVAsQ0FBYSxDQUFiLENBQWIsQ0FBUjtBQUNELGVBRkQsTUFFTztBQUNMLHNCQUFNLE9BQU8sS0FBUCxDQUFhLENBQWIsQ0FBTjtBQUNBLHVCQUFPLFNBQVMsR0FBVCxDQUFQO0FBQ0Esb0JBQUksUUFBUSxPQUFPLElBQVAsQ0FBWixFQUEwQjtBQUN4Qix5QkFBTyxDQUFDLElBQVI7QUFDRCxpQkFGRCxNQUVPO0FBQ0wseUJBQU8sQ0FBQyxHQUFSO0FBQ0Q7QUFDRjtBQUNGLGFBWkQsTUFZTyxJQUFJLE1BQU0sU0FBTixDQUFnQixNQUFoQixDQUFKLEVBQTZCO0FBQ2xDLHFCQUFPLFdBQVcsTUFBWCxDQUFQO0FBQ0QsYUFGTSxNQUVBLElBQUksS0FBSywrQkFBTCxDQUFxQyxJQUFyQyxDQUEwQyxNQUExQyxDQUFKLEVBQXVEO0FBQzVELHFCQUFPLFdBQVcsT0FBTyxPQUFQLENBQWUsR0FBZixFQUFvQixFQUFwQixDQUFYLENBQVA7QUFDRDtBQUNELG1CQUFPLE1BQVA7QUFDRjtBQUNFLGdCQUFJLE9BQU8sTUFBTSxZQUFOLENBQW1CLE1BQW5CLENBQVgsRUFBdUM7QUFDckMscUJBQU8sSUFBUDtBQUNELGFBRkQsTUFFTyxJQUFJLE1BQU0sU0FBTixDQUFnQixNQUFoQixDQUFKLEVBQTZCO0FBQ2xDLHFCQUFPLFdBQVcsTUFBWCxDQUFQO0FBQ0QsYUFGTSxNQUVBLElBQUksS0FBSywrQkFBTCxDQUFxQyxJQUFyQyxDQUEwQyxNQUExQyxDQUFKLEVBQXVEO0FBQzVELHFCQUFPLFdBQVcsT0FBTyxPQUFQLENBQWUsR0FBZixFQUFvQixFQUFwQixDQUFYLENBQVA7QUFDRDtBQUNELG1CQUFPLE1BQVA7QUEzR0o7QUFqQko7QUErSEQsR0FuSUQ7O0FBcUlBLFNBQU8sTUFBUDtBQUVELENBaGRRLEVBQVQ7O0FBa2RBLE9BQU8sT0FBUCxHQUFpQixNQUFqQjs7Ozs7Ozs7Ozs7QUNwZUE7QUFDQSxJQUFJLE1BQUosRUFBWSxjQUFaLEVBQTRCLFNBQTVCLEVBQXVDLE1BQXZDLEVBQStDLE9BQS9DLEVBQXdELEtBQXhEOztBQUVBLFNBQVMsUUFBUSxVQUFSLENBQVQ7O0FBRUEsVUFBVSxRQUFRLFdBQVIsQ0FBVjs7QUFFQSxRQUFRLFFBQVEsU0FBUixDQUFSOztBQUVBLGlCQUFpQixRQUFRLDRCQUFSLENBQWpCOztBQUVBLFlBQVksUUFBUSx1QkFBUixDQUFaOztBQUVBLFNBQVUsWUFBVztBQUNuQixTQUFPLFNBQVAsQ0FBaUIseUJBQWpCLEdBQTZDLElBQUksT0FBSixDQUFZLGdJQUFaLENBQTdDOztBQUVBLFNBQU8sU0FBUCxDQUFpQix5QkFBakIsR0FBNkMsSUFBSSxPQUFKLENBQVksb0dBQVosQ0FBN0M7O0FBRUEsU0FBTyxTQUFQLENBQWlCLHFCQUFqQixHQUF5QyxJQUFJLE9BQUosQ0FBWSw4Q0FBWixDQUF6Qzs7QUFFQSxTQUFPLFNBQVAsQ0FBaUIsb0JBQWpCLEdBQXdDLElBQUksT0FBSixDQUFZLCtCQUFaLENBQXhDOztBQUVBLFNBQU8sU0FBUCxDQUFpQix3QkFBakIsR0FBNEMsSUFBSSxPQUFKLENBQVksYUFBYSxPQUFPLG1CQUFwQixHQUEwQyxrREFBdEQsQ0FBNUM7O0FBRUEsU0FBTyxTQUFQLENBQWlCLG9CQUFqQixHQUF3QyxJQUFJLE9BQUosQ0FBWSxhQUFhLE9BQU8sbUJBQXBCLEdBQTBDLGtEQUF0RCxDQUF4Qzs7QUFFQSxTQUFPLFNBQVAsQ0FBaUIsZUFBakIsR0FBbUMsSUFBSSxPQUFKLENBQVksTUFBWixDQUFuQzs7QUFFQSxTQUFPLFNBQVAsQ0FBaUIscUJBQWpCLEdBQXlDLElBQUksT0FBSixDQUFZLEtBQVosQ0FBekM7O0FBRUEsU0FBTyxTQUFQLENBQWlCLHNCQUFqQixHQUEwQyxJQUFJLE9BQUosQ0FBWSxRQUFaLENBQTFDOztBQUVBLFNBQU8sU0FBUCxDQUFpQixtQkFBakIsR0FBdUMsSUFBSSxPQUFKLENBQVksMkJBQVosRUFBeUMsR0FBekMsQ0FBdkM7O0FBRUEsU0FBTyxTQUFQLENBQWlCLHdCQUFqQixHQUE0QyxJQUFJLE9BQUosQ0FBWSxjQUFaLEVBQTRCLEdBQTVCLENBQTVDOztBQUVBLFNBQU8sU0FBUCxDQUFpQiw2QkFBakIsR0FBaUQsSUFBSSxPQUFKLENBQVksaUJBQVosRUFBK0IsR0FBL0IsQ0FBakQ7O0FBRUEsU0FBTyxTQUFQLENBQWlCLDJCQUFqQixHQUErQyxJQUFJLE9BQUosQ0FBWSxpQkFBWixFQUErQixHQUEvQixDQUEvQzs7QUFFQSxTQUFPLFNBQVAsQ0FBaUIsb0NBQWpCLEdBQXdELEVBQXhEOztBQUVBLFNBQU8sU0FBUCxDQUFpQixZQUFqQixHQUFnQyxDQUFoQzs7QUFFQSxTQUFPLFNBQVAsQ0FBaUIsZ0JBQWpCLEdBQW9DLENBQXBDOztBQUVBLFNBQU8sU0FBUCxDQUFpQixlQUFqQixHQUFtQyxDQUFuQzs7QUFFQSxXQUFTLE1BQVQsQ0FBZ0IsTUFBaEIsRUFBd0I7QUFDdEIsU0FBSyxNQUFMLEdBQWMsVUFBVSxJQUFWLEdBQWlCLE1BQWpCLEdBQTBCLENBQXhDO0FBQ0EsU0FBSyxLQUFMLEdBQWEsRUFBYjtBQUNBLFNBQUssYUFBTCxHQUFxQixDQUFDLENBQXRCO0FBQ0EsU0FBSyxXQUFMLEdBQW1CLEVBQW5CO0FBQ0EsU0FBSyxJQUFMLEdBQVksRUFBWjtBQUNEOztBQUVELFNBQU8sU0FBUCxDQUFpQixLQUFqQixHQUF5QixVQUFTLEtBQVQsRUFBZ0Isc0JBQWhCLEVBQXdDLGFBQXhDLEVBQXVEO0FBQzlFLFFBQUksS0FBSixFQUFXLGNBQVgsRUFBMkIsS0FBM0IsRUFBa0MsQ0FBbEMsRUFBcUMsT0FBckMsRUFBOEMsSUFBOUMsRUFBb0QsQ0FBcEQsRUFBdUQsS0FBdkQsRUFBOEQsQ0FBOUQsRUFBaUUsTUFBakUsRUFBeUUsS0FBekUsRUFBZ0YsQ0FBaEYsRUFBbUYsQ0FBbkYsRUFBc0YsR0FBdEYsRUFBMkYsQ0FBM0YsRUFBOEYsT0FBOUYsRUFBdUcsR0FBdkcsRUFBNEcsSUFBNUcsRUFBa0gsSUFBbEgsRUFBd0gsSUFBeEgsRUFBOEgsU0FBOUgsRUFBeUksQ0FBekksRUFBNEksT0FBNUksRUFBcUosU0FBckosRUFBZ0ssQ0FBaEssRUFBbUssSUFBbkssRUFBeUssTUFBekssRUFBaUwsVUFBakwsRUFBNkwsTUFBN0wsRUFBcU0sR0FBck0sRUFBME0sSUFBMU0sRUFBZ04sSUFBaE4sRUFBc04sT0FBdE4sRUFBK04sUUFBL04sRUFBeU8sR0FBek8sRUFBOE8sTUFBOU87QUFDQSxRQUFJLDBCQUEwQixJQUE5QixFQUFvQztBQUNsQywrQkFBeUIsS0FBekI7QUFDRDtBQUNELFFBQUksaUJBQWlCLElBQXJCLEVBQTJCO0FBQ3pCLHNCQUFnQixJQUFoQjtBQUNEO0FBQ0QsU0FBSyxhQUFMLEdBQXFCLENBQUMsQ0FBdEI7QUFDQSxTQUFLLFdBQUwsR0FBbUIsRUFBbkI7QUFDQSxTQUFLLEtBQUwsR0FBYSxLQUFLLE9BQUwsQ0FBYSxLQUFiLEVBQW9CLEtBQXBCLENBQTBCLElBQTFCLENBQWI7QUFDQSxXQUFPLElBQVA7QUFDQSxjQUFVLEtBQUssWUFBZjtBQUNBLHFCQUFpQixLQUFqQjtBQUNBLFdBQU8sS0FBSyxjQUFMLEVBQVAsRUFBOEI7QUFDNUIsVUFBSSxLQUFLLGtCQUFMLEVBQUosRUFBK0I7QUFDN0I7QUFDRDtBQUNELFVBQUksU0FBUyxLQUFLLFdBQUwsQ0FBaUIsQ0FBakIsQ0FBYixFQUFrQztBQUNoQyxjQUFNLElBQUksY0FBSixDQUFtQixpREFBbkIsRUFBc0UsS0FBSyxvQkFBTCxLQUE4QixDQUFwRyxFQUF1RyxLQUFLLFdBQTVHLENBQU47QUFDRDtBQUNELGNBQVEsWUFBWSxLQUFwQjtBQUNBLFVBQUksU0FBUyxLQUFLLHFCQUFMLENBQTJCLElBQTNCLENBQWdDLEtBQUssV0FBckMsQ0FBYixFQUFnRTtBQUM5RCxZQUFJLEtBQUssZUFBTCxLQUF5QixPQUE3QixFQUFzQztBQUNwQyxnQkFBTSxJQUFJLGNBQUosQ0FBbUIscURBQW5CLENBQU47QUFDRDtBQUNELGtCQUFVLEtBQUssZ0JBQWY7QUFDQSxZQUFJLFFBQVEsSUFBWixFQUFrQjtBQUNoQixpQkFBTyxFQUFQO0FBQ0Q7QUFDRCxZQUFLLE9BQU8sS0FBUCxJQUFnQixJQUFqQixLQUEyQixVQUFVLEtBQUssb0JBQUwsQ0FBMEIsSUFBMUIsQ0FBK0IsT0FBTyxLQUF0QyxDQUFyQyxDQUFKLEVBQXdGO0FBQ3RGLGtCQUFRLFFBQVEsR0FBaEI7QUFDQSxpQkFBTyxLQUFQLEdBQWUsUUFBUSxLQUF2QjtBQUNEO0FBQ0QsWUFBSSxFQUFFLE9BQU8sS0FBUCxJQUFnQixJQUFsQixLQUEyQixPQUFPLE1BQU0sSUFBTixDQUFXLE9BQU8sS0FBbEIsRUFBeUIsR0FBekIsQ0FBbEMsSUFBbUUsTUFBTSxLQUFOLENBQVksT0FBTyxLQUFuQixFQUEwQixHQUExQixFQUErQixPQUEvQixDQUF1QyxHQUF2QyxNQUFnRCxDQUF2SCxFQUEwSDtBQUN4SCxjQUFJLEtBQUssYUFBTCxHQUFxQixLQUFLLEtBQUwsQ0FBVyxNQUFYLEdBQW9CLENBQXpDLElBQThDLENBQUMsS0FBSyw4QkFBTCxFQUFuRCxFQUEwRjtBQUN4RixnQkFBSSxLQUFLLG9CQUFMLEtBQThCLENBQWxDO0FBQ0EscUJBQVMsSUFBSSxNQUFKLENBQVcsQ0FBWCxDQUFUO0FBQ0EsbUJBQU8sSUFBUCxHQUFjLEtBQUssSUFBbkI7QUFDQSxpQkFBSyxJQUFMLENBQVUsT0FBTyxLQUFQLENBQWEsS0FBSyxpQkFBTCxDQUF1QixJQUF2QixFQUE2QixJQUE3QixDQUFiLEVBQWlELHNCQUFqRCxFQUF5RSxhQUF6RSxDQUFWO0FBQ0QsV0FMRCxNQUtPO0FBQ0wsaUJBQUssSUFBTCxDQUFVLElBQVY7QUFDRDtBQUNGLFNBVEQsTUFTTztBQUNMLGNBQUksQ0FBQyxDQUFDLE1BQU0sT0FBTyxVQUFkLEtBQTZCLElBQTdCLEdBQW9DLElBQUksTUFBeEMsR0FBaUQsS0FBSyxDQUF2RCxNQUE4RCxVQUFVLEtBQUssd0JBQUwsQ0FBOEIsSUFBOUIsQ0FBbUMsT0FBTyxLQUExQyxDQUF4RSxDQUFKLEVBQStIO0FBQzdILGdCQUFJLEtBQUssb0JBQUwsRUFBSjtBQUNBLHFCQUFTLElBQUksTUFBSixDQUFXLENBQVgsQ0FBVDtBQUNBLG1CQUFPLElBQVAsR0FBYyxLQUFLLElBQW5CO0FBQ0Esb0JBQVEsT0FBTyxLQUFmO0FBQ0EscUJBQVMsS0FBSyx5QkFBTCxFQUFUO0FBQ0EsZ0JBQUksS0FBSyxrQkFBTCxDQUF3QixLQUF4QixDQUFKLEVBQW9DO0FBQ2xDLHVCQUFTLE9BQU8sS0FBSyxpQkFBTCxDQUF1QixTQUFTLE9BQU8sVUFBUCxDQUFrQixNQUEzQixHQUFvQyxDQUEzRCxFQUE4RCxJQUE5RCxDQUFoQjtBQUNEO0FBQ0QsaUJBQUssSUFBTCxDQUFVLE9BQU8sS0FBUCxDQUFhLEtBQWIsRUFBb0Isc0JBQXBCLEVBQTRDLGFBQTVDLENBQVY7QUFDRCxXQVZELE1BVU87QUFDTCxpQkFBSyxJQUFMLENBQVUsS0FBSyxVQUFMLENBQWdCLE9BQU8sS0FBdkIsRUFBOEIsc0JBQTlCLEVBQXNELGFBQXRELENBQVY7QUFDRDtBQUNGO0FBQ0YsT0FwQ0QsTUFvQ08sSUFBSSxDQUFDLFNBQVMsS0FBSyxvQkFBTCxDQUEwQixJQUExQixDQUErQixLQUFLLFdBQXBDLENBQVYsS0FBK0QsT0FBTyxHQUFQLENBQVcsT0FBWCxDQUFtQixJQUFuQixNQUE2QixDQUFDLENBQWpHLEVBQW9HO0FBQ3pHLFlBQUksS0FBSyxnQkFBTCxLQUEwQixPQUE5QixFQUF1QztBQUNyQyxnQkFBTSxJQUFJLGNBQUosQ0FBbUIscURBQW5CLENBQU47QUFDRDtBQUNELGtCQUFVLEtBQUssZUFBZjtBQUNBLFlBQUksUUFBUSxJQUFaLEVBQWtCO0FBQ2hCLGlCQUFPLEVBQVA7QUFDRDtBQUNELGVBQU8sU0FBUCxDQUFpQixzQkFBakIsRUFBeUMsYUFBekM7QUFDQSxZQUFJO0FBQ0YsZ0JBQU0sT0FBTyxXQUFQLENBQW1CLE9BQU8sR0FBMUIsQ0FBTjtBQUNELFNBRkQsQ0FFRSxPQUFPLEtBQVAsRUFBYztBQUNkLGNBQUksS0FBSjtBQUNBLFlBQUUsVUFBRixHQUFlLEtBQUssb0JBQUwsS0FBOEIsQ0FBN0M7QUFDQSxZQUFFLE9BQUYsR0FBWSxLQUFLLFdBQWpCO0FBQ0EsZ0JBQU0sQ0FBTjtBQUNEO0FBQ0QsWUFBSSxTQUFTLEdBQWIsRUFBa0I7QUFDaEIsc0JBQVksSUFBWjtBQUNBLDJCQUFpQixJQUFqQjtBQUNBLGNBQUksQ0FBQyxDQUFDLE9BQU8sT0FBTyxLQUFmLEtBQXlCLElBQXpCLEdBQWdDLEtBQUssT0FBTCxDQUFhLEdBQWIsQ0FBaEMsR0FBb0QsS0FBSyxDQUExRCxNQUFpRSxDQUFyRSxFQUF3RTtBQUN0RSxzQkFBVSxPQUFPLEtBQVAsQ0FBYSxLQUFiLENBQW1CLENBQW5CLENBQVY7QUFDQSxnQkFBSSxLQUFLLElBQUwsQ0FBVSxPQUFWLEtBQXNCLElBQTFCLEVBQWdDO0FBQzlCLG9CQUFNLElBQUksY0FBSixDQUFtQixnQkFBZ0IsT0FBaEIsR0FBMEIsbUJBQTdDLEVBQWtFLEtBQUssb0JBQUwsS0FBOEIsQ0FBaEcsRUFBbUcsS0FBSyxXQUF4RyxDQUFOO0FBQ0Q7QUFDRCx1QkFBVyxLQUFLLElBQUwsQ0FBVSxPQUFWLENBQVg7QUFDQSxnQkFBSSxRQUFPLFFBQVAsdURBQU8sUUFBUCxPQUFvQixRQUF4QixFQUFrQztBQUNoQyxvQkFBTSxJQUFJLGNBQUosQ0FBbUIsZ0VBQW5CLEVBQXFGLEtBQUssb0JBQUwsS0FBOEIsQ0FBbkgsRUFBc0gsS0FBSyxXQUEzSCxDQUFOO0FBQ0Q7QUFDRCxnQkFBSSxvQkFBb0IsS0FBeEIsRUFBK0I7QUFDN0IsbUJBQUssSUFBSSxJQUFJLENBQVIsRUFBVyxNQUFNLFNBQVMsTUFBL0IsRUFBdUMsSUFBSSxHQUEzQyxFQUFnRCxJQUFJLEVBQUUsQ0FBdEQsRUFBeUQ7QUFDdkQsd0JBQVEsU0FBUyxDQUFULENBQVI7QUFDQSxvQkFBSSxLQUFLLE9BQU8sT0FBTyxDQUFQLENBQVosS0FBMEIsSUFBOUIsRUFBb0M7QUFDbEMsdUJBQUssSUFBTCxJQUFhLEtBQWI7QUFDRDtBQUNGO0FBQ0YsYUFQRCxNQU9PO0FBQ0wsbUJBQUssR0FBTCxJQUFZLFFBQVosRUFBc0I7QUFDcEIsd0JBQVEsU0FBUyxHQUFULENBQVI7QUFDQSxvQkFBSSxLQUFLLEdBQUwsS0FBYSxJQUFqQixFQUF1QjtBQUNyQix1QkFBSyxHQUFMLElBQVksS0FBWjtBQUNEO0FBQ0Y7QUFDRjtBQUNGLFdBeEJELE1Bd0JPO0FBQ0wsZ0JBQUssT0FBTyxLQUFQLElBQWdCLElBQWpCLElBQTBCLE9BQU8sS0FBUCxLQUFpQixFQUEvQyxFQUFtRDtBQUNqRCxzQkFBUSxPQUFPLEtBQWY7QUFDRCxhQUZELE1BRU87QUFDTCxzQkFBUSxLQUFLLGlCQUFMLEVBQVI7QUFDRDtBQUNELGdCQUFJLEtBQUssb0JBQUwsS0FBOEIsQ0FBbEM7QUFDQSxxQkFBUyxJQUFJLE1BQUosQ0FBVyxDQUFYLENBQVQ7QUFDQSxtQkFBTyxJQUFQLEdBQWMsS0FBSyxJQUFuQjtBQUNBLHFCQUFTLE9BQU8sS0FBUCxDQUFhLEtBQWIsRUFBb0Isc0JBQXBCLENBQVQ7QUFDQSxnQkFBSSxRQUFPLE1BQVAsdURBQU8sTUFBUCxPQUFrQixRQUF0QixFQUFnQztBQUM5QixvQkFBTSxJQUFJLGNBQUosQ0FBbUIsZ0VBQW5CLEVBQXFGLEtBQUssb0JBQUwsS0FBOEIsQ0FBbkgsRUFBc0gsS0FBSyxXQUEzSCxDQUFOO0FBQ0Q7QUFDRCxnQkFBSSxrQkFBa0IsS0FBdEIsRUFBNkI7QUFDM0IsbUJBQUssSUFBSSxDQUFKLEVBQU8sT0FBTyxPQUFPLE1BQTFCLEVBQWtDLElBQUksSUFBdEMsRUFBNEMsR0FBNUMsRUFBaUQ7QUFDL0MsNkJBQWEsT0FBTyxDQUFQLENBQWI7QUFDQSxvQkFBSSxRQUFPLFVBQVAsdURBQU8sVUFBUCxPQUFzQixRQUExQixFQUFvQztBQUNsQyx3QkFBTSxJQUFJLGNBQUosQ0FBbUIsOEJBQW5CLEVBQW1ELEtBQUssb0JBQUwsS0FBOEIsQ0FBakYsRUFBb0YsVUFBcEYsQ0FBTjtBQUNEO0FBQ0Qsb0JBQUksc0JBQXNCLEtBQTFCLEVBQWlDO0FBQy9CLHVCQUFLLElBQUksSUFBSSxDQUFSLEVBQVcsT0FBTyxXQUFXLE1BQWxDLEVBQTBDLElBQUksSUFBOUMsRUFBb0QsSUFBSSxFQUFFLENBQTFELEVBQTZEO0FBQzNELDRCQUFRLFdBQVcsQ0FBWCxDQUFSO0FBQ0Esd0JBQUksT0FBTyxDQUFQLENBQUo7QUFDQSx3QkFBSSxDQUFDLEtBQUssY0FBTCxDQUFvQixDQUFwQixDQUFMLEVBQTZCO0FBQzNCLDJCQUFLLENBQUwsSUFBVSxLQUFWO0FBQ0Q7QUFDRjtBQUNGLGlCQVJELE1BUU87QUFDTCx1QkFBSyxHQUFMLElBQVksVUFBWixFQUF3QjtBQUN0Qiw0QkFBUSxXQUFXLEdBQVgsQ0FBUjtBQUNBLHdCQUFJLENBQUMsS0FBSyxjQUFMLENBQW9CLEdBQXBCLENBQUwsRUFBK0I7QUFDN0IsMkJBQUssR0FBTCxJQUFZLEtBQVo7QUFDRDtBQUNGO0FBQ0Y7QUFDRjtBQUNGLGFBdkJELE1BdUJPO0FBQ0wsbUJBQUssR0FBTCxJQUFZLE1BQVosRUFBb0I7QUFDbEIsd0JBQVEsT0FBTyxHQUFQLENBQVI7QUFDQSxvQkFBSSxDQUFDLEtBQUssY0FBTCxDQUFvQixHQUFwQixDQUFMLEVBQStCO0FBQzdCLHVCQUFLLEdBQUwsSUFBWSxLQUFaO0FBQ0Q7QUFDRjtBQUNGO0FBQ0Y7QUFDRixTQXhFRCxNQXdFTyxJQUFLLE9BQU8sS0FBUCxJQUFnQixJQUFqQixLQUEyQixVQUFVLEtBQUssb0JBQUwsQ0FBMEIsSUFBMUIsQ0FBK0IsT0FBTyxLQUF0QyxDQUFyQyxDQUFKLEVBQXdGO0FBQzdGLGtCQUFRLFFBQVEsR0FBaEI7QUFDQSxpQkFBTyxLQUFQLEdBQWUsUUFBUSxLQUF2QjtBQUNEO0FBQ0QsWUFBSSxTQUFKLEVBQWUsQ0FFZCxDQUZELE1BRU8sSUFBSSxFQUFFLE9BQU8sS0FBUCxJQUFnQixJQUFsQixLQUEyQixPQUFPLE1BQU0sSUFBTixDQUFXLE9BQU8sS0FBbEIsRUFBeUIsR0FBekIsQ0FBbEMsSUFBbUUsTUFBTSxLQUFOLENBQVksT0FBTyxLQUFuQixFQUEwQixHQUExQixFQUErQixPQUEvQixDQUF1QyxHQUF2QyxNQUFnRCxDQUF2SCxFQUEwSDtBQUMvSCxjQUFJLENBQUUsS0FBSyxrQkFBTCxFQUFGLElBQWdDLENBQUUsS0FBSyw4QkFBTCxFQUF0QyxFQUE4RTtBQUM1RSxnQkFBSSxrQkFBa0IsS0FBSyxHQUFMLE1BQWMsS0FBSyxDQUF6QyxFQUE0QztBQUMxQyxtQkFBSyxHQUFMLElBQVksSUFBWjtBQUNEO0FBQ0YsV0FKRCxNQUlPO0FBQ0wsZ0JBQUksS0FBSyxvQkFBTCxLQUE4QixDQUFsQztBQUNBLHFCQUFTLElBQUksTUFBSixDQUFXLENBQVgsQ0FBVDtBQUNBLG1CQUFPLElBQVAsR0FBYyxLQUFLLElBQW5CO0FBQ0Esa0JBQU0sT0FBTyxLQUFQLENBQWEsS0FBSyxpQkFBTCxFQUFiLEVBQXVDLHNCQUF2QyxFQUErRCxhQUEvRCxDQUFOO0FBQ0EsZ0JBQUksa0JBQWtCLEtBQUssR0FBTCxNQUFjLEtBQUssQ0FBekMsRUFBNEM7QUFDMUMsbUJBQUssR0FBTCxJQUFZLEdBQVo7QUFDRDtBQUNGO0FBQ0YsU0FkTSxNQWNBO0FBQ0wsZ0JBQU0sS0FBSyxVQUFMLENBQWdCLE9BQU8sS0FBdkIsRUFBOEIsc0JBQTlCLEVBQXNELGFBQXRELENBQU47QUFDQSxjQUFJLGtCQUFrQixLQUFLLEdBQUwsTUFBYyxLQUFLLENBQXpDLEVBQTRDO0FBQzFDLGlCQUFLLEdBQUwsSUFBWSxHQUFaO0FBQ0Q7QUFDRjtBQUNGLE9BbkhNLE1BbUhBO0FBQ0wsb0JBQVksS0FBSyxLQUFMLENBQVcsTUFBdkI7QUFDQSxZQUFJLE1BQU0sU0FBTixJQUFvQixNQUFNLFNBQU4sSUFBbUIsTUFBTSxPQUFOLENBQWMsS0FBSyxLQUFMLENBQVcsQ0FBWCxDQUFkLENBQTNDLEVBQTBFO0FBQ3hFLGNBQUk7QUFDRixvQkFBUSxPQUFPLEtBQVAsQ0FBYSxLQUFLLEtBQUwsQ0FBVyxDQUFYLENBQWIsRUFBNEIsc0JBQTVCLEVBQW9ELGFBQXBELENBQVI7QUFDRCxXQUZELENBRUUsT0FBTyxLQUFQLEVBQWM7QUFDZCxnQkFBSSxLQUFKO0FBQ0EsY0FBRSxVQUFGLEdBQWUsS0FBSyxvQkFBTCxLQUE4QixDQUE3QztBQUNBLGNBQUUsT0FBRixHQUFZLEtBQUssV0FBakI7QUFDQSxrQkFBTSxDQUFOO0FBQ0Q7QUFDRCxjQUFJLFFBQU8sS0FBUCx1REFBTyxLQUFQLE9BQWlCLFFBQXJCLEVBQStCO0FBQzdCLGdCQUFJLGlCQUFpQixLQUFyQixFQUE0QjtBQUMxQixzQkFBUSxNQUFNLENBQU4sQ0FBUjtBQUNELGFBRkQsTUFFTztBQUNMLG1CQUFLLEdBQUwsSUFBWSxLQUFaLEVBQW1CO0FBQ2pCLHdCQUFRLE1BQU0sR0FBTixDQUFSO0FBQ0E7QUFDRDtBQUNGO0FBQ0QsZ0JBQUksT0FBTyxLQUFQLEtBQWlCLFFBQWpCLElBQTZCLE1BQU0sT0FBTixDQUFjLEdBQWQsTUFBdUIsQ0FBeEQsRUFBMkQ7QUFDekQscUJBQU8sRUFBUDtBQUNBLG1CQUFLLElBQUksQ0FBSixFQUFPLE9BQU8sTUFBTSxNQUF6QixFQUFpQyxJQUFJLElBQXJDLEVBQTJDLEdBQTNDLEVBQWdEO0FBQzlDLHdCQUFRLE1BQU0sQ0FBTixDQUFSO0FBQ0EscUJBQUssSUFBTCxDQUFVLEtBQUssSUFBTCxDQUFVLE1BQU0sS0FBTixDQUFZLENBQVosQ0FBVixDQUFWO0FBQ0Q7QUFDRCxzQkFBUSxJQUFSO0FBQ0Q7QUFDRjtBQUNELGlCQUFPLEtBQVA7QUFDRCxTQTVCRCxNQTRCTyxJQUFJLENBQUMsT0FBTyxNQUFNLEtBQU4sQ0FBWSxLQUFaLEVBQW1CLE1BQW5CLENBQTBCLENBQTFCLENBQVIsTUFBMEMsR0FBMUMsSUFBaUQsU0FBUyxHQUE5RCxFQUFtRTtBQUN4RSxjQUFJO0FBQ0YsbUJBQU8sT0FBTyxLQUFQLENBQWEsS0FBYixFQUFvQixzQkFBcEIsRUFBNEMsYUFBNUMsQ0FBUDtBQUNELFdBRkQsQ0FFRSxPQUFPLEtBQVAsRUFBYztBQUNkLGdCQUFJLEtBQUo7QUFDQSxjQUFFLFVBQUYsR0FBZSxLQUFLLG9CQUFMLEtBQThCLENBQTdDO0FBQ0EsY0FBRSxPQUFGLEdBQVksS0FBSyxXQUFqQjtBQUNBLGtCQUFNLENBQU47QUFDRDtBQUNGO0FBQ0QsY0FBTSxJQUFJLGNBQUosQ0FBbUIsa0JBQW5CLEVBQXVDLEtBQUssb0JBQUwsS0FBOEIsQ0FBckUsRUFBd0UsS0FBSyxXQUE3RSxDQUFOO0FBQ0Q7QUFDRCxVQUFJLEtBQUosRUFBVztBQUNULFlBQUksZ0JBQWdCLEtBQXBCLEVBQTJCO0FBQ3pCLGVBQUssSUFBTCxDQUFVLEtBQVYsSUFBbUIsS0FBSyxLQUFLLE1BQUwsR0FBYyxDQUFuQixDQUFuQjtBQUNELFNBRkQsTUFFTztBQUNMLG9CQUFVLElBQVY7QUFDQSxlQUFLLEdBQUwsSUFBWSxJQUFaLEVBQWtCO0FBQ2hCLHNCQUFVLEdBQVY7QUFDRDtBQUNELGVBQUssSUFBTCxDQUFVLEtBQVYsSUFBbUIsS0FBSyxPQUFMLENBQW5CO0FBQ0Q7QUFDRjtBQUNGO0FBQ0QsUUFBSSxNQUFNLE9BQU4sQ0FBYyxJQUFkLENBQUosRUFBeUI7QUFDdkIsYUFBTyxJQUFQO0FBQ0QsS0FGRCxNQUVPO0FBQ0wsYUFBTyxJQUFQO0FBQ0Q7QUFDRixHQXhPRDs7QUEwT0EsU0FBTyxTQUFQLENBQWlCLG9CQUFqQixHQUF3QyxZQUFXO0FBQ2pELFdBQU8sS0FBSyxhQUFMLEdBQXFCLEtBQUssTUFBakM7QUFDRCxHQUZEOztBQUlBLFNBQU8sU0FBUCxDQUFpQix5QkFBakIsR0FBNkMsWUFBVztBQUN0RCxXQUFPLEtBQUssV0FBTCxDQUFpQixNQUFqQixHQUEwQixNQUFNLEtBQU4sQ0FBWSxLQUFLLFdBQWpCLEVBQThCLEdBQTlCLEVBQW1DLE1BQXBFO0FBQ0QsR0FGRDs7QUFJQSxTQUFPLFNBQVAsQ0FBaUIsaUJBQWpCLEdBQXFDLFVBQVMsV0FBVCxFQUFzQiwyQkFBdEIsRUFBbUQ7QUFDdEYsUUFBSSxJQUFKLEVBQVUsTUFBVixFQUFrQix3QkFBbEIsRUFBNEMsU0FBNUMsRUFBdUQsY0FBdkQsRUFBdUUscUJBQXZFLEVBQThGLG9CQUE5RjtBQUNBLFFBQUksZUFBZSxJQUFuQixFQUF5QjtBQUN2QixvQkFBYyxJQUFkO0FBQ0Q7QUFDRCxRQUFJLCtCQUErQixJQUFuQyxFQUF5QztBQUN2QyxvQ0FBOEIsS0FBOUI7QUFDRDtBQUNELFNBQUssY0FBTDtBQUNBLFFBQUksZUFBZSxJQUFuQixFQUF5QjtBQUN2QixrQkFBWSxLQUFLLHlCQUFMLEVBQVo7QUFDQSw2QkFBdUIsS0FBSyxnQ0FBTCxDQUFzQyxLQUFLLFdBQTNDLENBQXZCO0FBQ0EsVUFBSSxDQUFFLEtBQUssa0JBQUwsRUFBRixJQUFnQyxNQUFNLFNBQXRDLElBQW1ELENBQUMsb0JBQXhELEVBQThFO0FBQzVFLGNBQU0sSUFBSSxjQUFKLENBQW1CLHNCQUFuQixFQUEyQyxLQUFLLG9CQUFMLEtBQThCLENBQXpFLEVBQTRFLEtBQUssV0FBakYsQ0FBTjtBQUNEO0FBQ0YsS0FORCxNQU1PO0FBQ0wsa0JBQVksV0FBWjtBQUNEO0FBQ0QsV0FBTyxDQUFDLEtBQUssV0FBTCxDQUFpQixLQUFqQixDQUF1QixTQUF2QixDQUFELENBQVA7QUFDQSxRQUFJLENBQUMsMkJBQUwsRUFBa0M7QUFDaEMsaUNBQTJCLEtBQUssZ0NBQUwsQ0FBc0MsS0FBSyxXQUEzQyxDQUEzQjtBQUNEO0FBQ0QsNEJBQXdCLEtBQUsseUJBQTdCO0FBQ0EscUJBQWlCLENBQUMsc0JBQXNCLElBQXRCLENBQTJCLEtBQUssV0FBaEMsQ0FBbEI7QUFDQSxXQUFPLEtBQUssY0FBTCxFQUFQLEVBQThCO0FBQzVCLGVBQVMsS0FBSyx5QkFBTCxFQUFUO0FBQ0EsVUFBSSxXQUFXLFNBQWYsRUFBMEI7QUFDeEIseUJBQWlCLENBQUMsc0JBQXNCLElBQXRCLENBQTJCLEtBQUssV0FBaEMsQ0FBbEI7QUFDRDtBQUNELFVBQUksa0JBQWtCLEtBQUssb0JBQUwsRUFBdEIsRUFBbUQ7QUFDakQ7QUFDRDtBQUNELFVBQUksS0FBSyxrQkFBTCxFQUFKLEVBQStCO0FBQzdCLGFBQUssSUFBTCxDQUFVLEtBQUssV0FBTCxDQUFpQixLQUFqQixDQUF1QixTQUF2QixDQUFWO0FBQ0E7QUFDRDtBQUNELFVBQUksNEJBQTRCLENBQUMsS0FBSyxnQ0FBTCxDQUFzQyxLQUFLLFdBQTNDLENBQTdCLElBQXdGLFdBQVcsU0FBdkcsRUFBa0g7QUFDaEgsYUFBSyxrQkFBTDtBQUNBO0FBQ0Q7QUFDRCxVQUFJLFVBQVUsU0FBZCxFQUF5QjtBQUN2QixhQUFLLElBQUwsQ0FBVSxLQUFLLFdBQUwsQ0FBaUIsS0FBakIsQ0FBdUIsU0FBdkIsQ0FBVjtBQUNELE9BRkQsTUFFTyxJQUFJLE1BQU0sS0FBTixDQUFZLEtBQUssV0FBakIsRUFBOEIsTUFBOUIsQ0FBcUMsQ0FBckMsTUFBNEMsR0FBaEQsRUFBcUQsQ0FFM0QsQ0FGTSxNQUVBLElBQUksTUFBTSxNQUFWLEVBQWtCO0FBQ3ZCLGFBQUssa0JBQUw7QUFDQTtBQUNELE9BSE0sTUFHQTtBQUNMLGNBQU0sSUFBSSxjQUFKLENBQW1CLHNCQUFuQixFQUEyQyxLQUFLLG9CQUFMLEtBQThCLENBQXpFLEVBQTRFLEtBQUssV0FBakYsQ0FBTjtBQUNEO0FBQ0Y7QUFDRCxXQUFPLEtBQUssSUFBTCxDQUFVLElBQVYsQ0FBUDtBQUNELEdBcEREOztBQXNEQSxTQUFPLFNBQVAsQ0FBaUIsY0FBakIsR0FBa0MsWUFBVztBQUMzQyxRQUFJLEtBQUssYUFBTCxJQUFzQixLQUFLLEtBQUwsQ0FBVyxNQUFYLEdBQW9CLENBQTlDLEVBQWlEO0FBQy9DLGFBQU8sS0FBUDtBQUNEO0FBQ0QsU0FBSyxXQUFMLEdBQW1CLEtBQUssS0FBTCxDQUFXLEVBQUUsS0FBSyxhQUFsQixDQUFuQjtBQUNBLFdBQU8sSUFBUDtBQUNELEdBTkQ7O0FBUUEsU0FBTyxTQUFQLENBQWlCLGtCQUFqQixHQUFzQyxZQUFXO0FBQy9DLFNBQUssV0FBTCxHQUFtQixLQUFLLEtBQUwsQ0FBVyxFQUFFLEtBQUssYUFBbEIsQ0FBbkI7QUFDRCxHQUZEOztBQUlBLFNBQU8sU0FBUCxDQUFpQixVQUFqQixHQUE4QixVQUFTLEtBQVQsRUFBZ0Isc0JBQWhCLEVBQXdDLGFBQXhDLEVBQXVEO0FBQ25GLFFBQUksQ0FBSixFQUFPLFlBQVAsRUFBcUIsT0FBckIsRUFBOEIsU0FBOUIsRUFBeUMsR0FBekMsRUFBOEMsR0FBOUMsRUFBbUQsSUFBbkQsRUFBeUQsR0FBekQ7QUFDQSxRQUFJLE1BQU0sTUFBTSxPQUFOLENBQWMsR0FBZCxDQUFWLEVBQThCO0FBQzVCLFlBQU0sTUFBTSxPQUFOLENBQWMsR0FBZCxDQUFOO0FBQ0EsVUFBSSxRQUFRLENBQUMsQ0FBYixFQUFnQjtBQUNkLGdCQUFRLE1BQU0sTUFBTixDQUFhLENBQWIsRUFBZ0IsTUFBTSxDQUF0QixDQUFSO0FBQ0QsT0FGRCxNQUVPO0FBQ0wsZ0JBQVEsTUFBTSxLQUFOLENBQVksQ0FBWixDQUFSO0FBQ0Q7QUFDRCxVQUFJLEtBQUssSUFBTCxDQUFVLEtBQVYsTUFBcUIsS0FBSyxDQUE5QixFQUFpQztBQUMvQixjQUFNLElBQUksY0FBSixDQUFtQixnQkFBZ0IsS0FBaEIsR0FBd0IsbUJBQTNDLEVBQWdFLEtBQUssV0FBckUsQ0FBTjtBQUNEO0FBQ0QsYUFBTyxLQUFLLElBQUwsQ0FBVSxLQUFWLENBQVA7QUFDRDtBQUNELFFBQUksVUFBVSxLQUFLLHlCQUFMLENBQStCLElBQS9CLENBQW9DLEtBQXBDLENBQWQsRUFBMEQ7QUFDeEQsa0JBQVksQ0FBQyxNQUFNLFFBQVEsU0FBZixLQUE2QixJQUE3QixHQUFvQyxHQUFwQyxHQUEwQyxFQUF0RDtBQUNBLHFCQUFlLEtBQUssR0FBTCxDQUFTLFNBQVMsU0FBVCxDQUFULENBQWY7QUFDQSxVQUFJLE1BQU0sWUFBTixDQUFKLEVBQXlCO0FBQ3ZCLHVCQUFlLENBQWY7QUFDRDtBQUNELFlBQU0sS0FBSyxpQkFBTCxDQUF1QixRQUFRLFNBQS9CLEVBQTBDLEtBQUssZUFBTCxDQUFxQixPQUFyQixDQUE2QixTQUE3QixFQUF3QyxFQUF4QyxDQUExQyxFQUF1RixZQUF2RixDQUFOO0FBQ0EsVUFBSSxRQUFRLElBQVIsSUFBZ0IsSUFBcEIsRUFBMEI7QUFDeEIsZUFBTyxTQUFQLENBQWlCLHNCQUFqQixFQUF5QyxhQUF6QztBQUNBLGVBQU8sT0FBTyxXQUFQLENBQW1CLFFBQVEsSUFBUixHQUFlLEdBQWYsR0FBcUIsR0FBeEMsQ0FBUDtBQUNELE9BSEQsTUFHTztBQUNMLGVBQU8sR0FBUDtBQUNEO0FBQ0Y7QUFDRCxRQUFJLENBQUMsT0FBTyxNQUFNLE1BQU4sQ0FBYSxDQUFiLENBQVIsTUFBNkIsR0FBN0IsSUFBb0MsU0FBUyxHQUE3QyxJQUFvRCxTQUFTLEdBQTdELElBQW9FLFNBQVMsR0FBakYsRUFBc0Y7QUFDcEYsYUFBTyxJQUFQLEVBQWE7QUFDWCxZQUFJO0FBQ0YsaUJBQU8sT0FBTyxLQUFQLENBQWEsS0FBYixFQUFvQixzQkFBcEIsRUFBNEMsYUFBNUMsQ0FBUDtBQUNELFNBRkQsQ0FFRSxPQUFPLEtBQVAsRUFBYztBQUNkLGNBQUksS0FBSjtBQUNBLGNBQUksYUFBYSxTQUFiLElBQTBCLEtBQUssY0FBTCxFQUE5QixFQUFxRDtBQUNuRCxxQkFBUyxPQUFPLE1BQU0sSUFBTixDQUFXLEtBQUssV0FBaEIsRUFBNkIsR0FBN0IsQ0FBaEI7QUFDRCxXQUZELE1BRU87QUFDTCxjQUFFLFVBQUYsR0FBZSxLQUFLLG9CQUFMLEtBQThCLENBQTdDO0FBQ0EsY0FBRSxPQUFGLEdBQVksS0FBSyxXQUFqQjtBQUNBLGtCQUFNLENBQU47QUFDRDtBQUNGO0FBQ0Y7QUFDRixLQWZELE1BZU87QUFDTCxVQUFJLEtBQUssa0JBQUwsRUFBSixFQUErQjtBQUM3QixpQkFBUyxPQUFPLEtBQUssaUJBQUwsRUFBaEI7QUFDRDtBQUNELGFBQU8sT0FBTyxLQUFQLENBQWEsS0FBYixFQUFvQixzQkFBcEIsRUFBNEMsYUFBNUMsQ0FBUDtBQUNEO0FBQ0YsR0FqREQ7O0FBbURBLFNBQU8sU0FBUCxDQUFpQixpQkFBakIsR0FBcUMsVUFBUyxTQUFULEVBQW9CLFNBQXBCLEVBQStCLFdBQS9CLEVBQTRDO0FBQy9FLFFBQUksa0JBQUosRUFBd0IsQ0FBeEIsRUFBMkIsR0FBM0IsRUFBZ0MsSUFBaEMsRUFBc0MsT0FBdEMsRUFBK0MsT0FBL0MsRUFBd0QsTUFBeEQsRUFBZ0UsT0FBaEUsRUFBeUUsR0FBekUsRUFBOEUsSUFBOUU7QUFDQSxRQUFJLGFBQWEsSUFBakIsRUFBdUI7QUFDckIsa0JBQVksRUFBWjtBQUNEO0FBQ0QsUUFBSSxlQUFlLElBQW5CLEVBQXlCO0FBQ3ZCLG9CQUFjLENBQWQ7QUFDRDtBQUNELGFBQVMsS0FBSyxjQUFMLEVBQVQ7QUFDQSxRQUFJLENBQUMsTUFBTCxFQUFhO0FBQ1gsYUFBTyxFQUFQO0FBQ0Q7QUFDRCx5QkFBcUIsS0FBSyxrQkFBTCxFQUFyQjtBQUNBLFdBQU8sRUFBUDtBQUNBLFdBQU8sVUFBVSxrQkFBakIsRUFBcUM7QUFDbkMsVUFBSSxTQUFTLEtBQUssY0FBTCxFQUFiLEVBQW9DO0FBQ2xDLGdCQUFRLElBQVI7QUFDQSw2QkFBcUIsS0FBSyxrQkFBTCxFQUFyQjtBQUNEO0FBQ0Y7QUFDRCxRQUFJLE1BQU0sV0FBVixFQUF1QjtBQUNyQixVQUFJLFVBQVUsS0FBSyxxQkFBTCxDQUEyQixJQUEzQixDQUFnQyxLQUFLLFdBQXJDLENBQWQsRUFBaUU7QUFDL0Qsc0JBQWMsUUFBUSxDQUFSLEVBQVcsTUFBekI7QUFDRDtBQUNGO0FBQ0QsUUFBSSxjQUFjLENBQWxCLEVBQXFCO0FBQ25CLGdCQUFVLEtBQUssb0NBQUwsQ0FBMEMsV0FBMUMsQ0FBVjtBQUNBLFVBQUksV0FBVyxJQUFmLEVBQXFCO0FBQ25CLGtCQUFVLElBQUksT0FBSixDQUFZLFFBQVEsV0FBUixHQUFzQixRQUFsQyxDQUFWO0FBQ0EsZUFBTyxTQUFQLENBQWlCLG9DQUFqQixDQUFzRCxXQUF0RCxJQUFxRSxPQUFyRTtBQUNEO0FBQ0QsYUFBTyxXQUFXLHVCQUF1QixVQUFVLFFBQVEsSUFBUixDQUFhLEtBQUssV0FBbEIsQ0FBakMsQ0FBWCxDQUFQLEVBQXFGO0FBQ25GLFlBQUksa0JBQUosRUFBd0I7QUFDdEIsa0JBQVEsS0FBSyxXQUFMLENBQWlCLEtBQWpCLENBQXVCLFdBQXZCLENBQVI7QUFDRCxTQUZELE1BRU87QUFDTCxrQkFBUSxRQUFRLENBQVIsQ0FBUjtBQUNEO0FBQ0QsWUFBSSxTQUFTLEtBQUssY0FBTCxFQUFiLEVBQW9DO0FBQ2xDLGtCQUFRLElBQVI7QUFDQSwrQkFBcUIsS0FBSyxrQkFBTCxFQUFyQjtBQUNEO0FBQ0Y7QUFDRixLQWpCRCxNQWlCTyxJQUFJLE1BQUosRUFBWTtBQUNqQixjQUFRLElBQVI7QUFDRDtBQUNELFFBQUksTUFBSixFQUFZO0FBQ1YsV0FBSyxrQkFBTDtBQUNEO0FBQ0QsUUFBSSxRQUFRLFNBQVosRUFBdUI7QUFDckIsZ0JBQVUsRUFBVjtBQUNBLFlBQU0sS0FBSyxLQUFMLENBQVcsSUFBWCxDQUFOO0FBQ0EsV0FBSyxJQUFJLENBQUosRUFBTyxNQUFNLElBQUksTUFBdEIsRUFBOEIsSUFBSSxHQUFsQyxFQUF1QyxHQUF2QyxFQUE0QztBQUMxQyxlQUFPLElBQUksQ0FBSixDQUFQO0FBQ0EsWUFBSSxLQUFLLE1BQUwsS0FBZ0IsQ0FBaEIsSUFBcUIsS0FBSyxNQUFMLENBQVksQ0FBWixNQUFtQixHQUE1QyxFQUFpRDtBQUMvQyxvQkFBVSxNQUFNLEtBQU4sQ0FBWSxPQUFaLEVBQXFCLEdBQXJCLElBQTRCLElBQTVCLEdBQW1DLElBQTdDO0FBQ0QsU0FGRCxNQUVPO0FBQ0wscUJBQVcsT0FBTyxHQUFsQjtBQUNEO0FBQ0Y7QUFDRCxhQUFPLE9BQVA7QUFDRDtBQUNELFFBQUksUUFBUSxTQUFaLEVBQXVCO0FBQ3JCLGFBQU8sTUFBTSxLQUFOLENBQVksSUFBWixDQUFQO0FBQ0Q7QUFDRCxRQUFJLE9BQU8sU0FBWCxFQUFzQjtBQUNwQixhQUFPLEtBQUssc0JBQUwsQ0FBNEIsT0FBNUIsQ0FBb0MsSUFBcEMsRUFBMEMsSUFBMUMsQ0FBUDtBQUNELEtBRkQsTUFFTyxJQUFJLFFBQVEsU0FBWixFQUF1QjtBQUM1QixhQUFPLEtBQUssc0JBQUwsQ0FBNEIsT0FBNUIsQ0FBb0MsSUFBcEMsRUFBMEMsRUFBMUMsQ0FBUDtBQUNEO0FBQ0QsV0FBTyxJQUFQO0FBQ0QsR0F0RUQ7O0FBd0VBLFNBQU8sU0FBUCxDQUFpQixrQkFBakIsR0FBc0MsVUFBUyxjQUFULEVBQXlCO0FBQzdELFFBQUksR0FBSixFQUFTLGtCQUFULEVBQTZCLEdBQTdCO0FBQ0EsUUFBSSxrQkFBa0IsSUFBdEIsRUFBNEI7QUFDMUIsdUJBQWlCLElBQWpCO0FBQ0Q7QUFDRCx5QkFBcUIsS0FBSyx5QkFBTCxFQUFyQjtBQUNBLFVBQU0sQ0FBQyxLQUFLLGNBQUwsRUFBUDtBQUNBLFFBQUksY0FBSixFQUFvQjtBQUNsQixhQUFPLENBQUMsR0FBRCxJQUFRLEtBQUssa0JBQUwsRUFBZixFQUEwQztBQUN4QyxjQUFNLENBQUMsS0FBSyxjQUFMLEVBQVA7QUFDRDtBQUNGLEtBSkQsTUFJTztBQUNMLGFBQU8sQ0FBQyxHQUFELElBQVEsS0FBSyxrQkFBTCxFQUFmLEVBQTBDO0FBQ3hDLGNBQU0sQ0FBQyxLQUFLLGNBQUwsRUFBUDtBQUNEO0FBQ0Y7QUFDRCxRQUFJLEdBQUosRUFBUztBQUNQLGFBQU8sS0FBUDtBQUNEO0FBQ0QsVUFBTSxLQUFOO0FBQ0EsUUFBSSxLQUFLLHlCQUFMLEtBQW1DLGtCQUF2QyxFQUEyRDtBQUN6RCxZQUFNLElBQU47QUFDRDtBQUNELFNBQUssa0JBQUw7QUFDQSxXQUFPLEdBQVA7QUFDRCxHQXpCRDs7QUEyQkEsU0FBTyxTQUFQLENBQWlCLGtCQUFqQixHQUFzQyxZQUFXO0FBQy9DLFFBQUksV0FBSjtBQUNBLGtCQUFjLE1BQU0sSUFBTixDQUFXLEtBQUssV0FBaEIsRUFBNkIsR0FBN0IsQ0FBZDtBQUNBLFdBQU8sWUFBWSxNQUFaLEtBQXVCLENBQXZCLElBQTRCLFlBQVksTUFBWixDQUFtQixDQUFuQixNQUEwQixHQUE3RDtBQUNELEdBSkQ7O0FBTUEsU0FBTyxTQUFQLENBQWlCLGtCQUFqQixHQUFzQyxZQUFXO0FBQy9DLFdBQU8sT0FBTyxNQUFNLElBQU4sQ0FBVyxLQUFLLFdBQWhCLEVBQTZCLEdBQTdCLENBQWQ7QUFDRCxHQUZEOztBQUlBLFNBQU8sU0FBUCxDQUFpQixvQkFBakIsR0FBd0MsWUFBVztBQUNqRCxRQUFJLFlBQUo7QUFDQSxtQkFBZSxNQUFNLEtBQU4sQ0FBWSxLQUFLLFdBQWpCLEVBQThCLEdBQTlCLENBQWY7QUFDQSxXQUFPLGFBQWEsTUFBYixDQUFvQixDQUFwQixNQUEyQixHQUFsQztBQUNELEdBSkQ7O0FBTUEsU0FBTyxTQUFQLENBQWlCLE9BQWpCLEdBQTJCLFVBQVMsS0FBVCxFQUFnQjtBQUN6QyxRQUFJLEtBQUosRUFBVyxDQUFYLEVBQWMsTUFBZCxFQUFzQixDQUF0QixFQUF5QixDQUF6QixFQUE0QixHQUE1QixFQUFpQyxJQUFqQyxFQUF1QyxJQUF2QyxFQUE2QyxLQUE3QyxFQUFvRCxHQUFwRCxFQUF5RCxJQUF6RCxFQUErRCxJQUEvRCxFQUFxRSxjQUFyRSxFQUFxRixZQUFyRjtBQUNBLFFBQUksTUFBTSxPQUFOLENBQWMsSUFBZCxNQUF3QixDQUFDLENBQTdCLEVBQWdDO0FBQzlCLGNBQVEsTUFBTSxLQUFOLENBQVksTUFBWixFQUFvQixJQUFwQixDQUF5QixJQUF6QixFQUErQixLQUEvQixDQUFxQyxJQUFyQyxFQUEyQyxJQUEzQyxDQUFnRCxJQUFoRCxDQUFSO0FBQ0Q7QUFDRCxZQUFRLENBQVI7QUFDQSxVQUFNLEtBQUssbUJBQUwsQ0FBeUIsVUFBekIsQ0FBb0MsS0FBcEMsRUFBMkMsRUFBM0MsQ0FBTixFQUFzRCxRQUFRLElBQUksQ0FBSixDQUE5RCxFQUFzRSxRQUFRLElBQUksQ0FBSixDQUE5RTtBQUNBLFNBQUssTUFBTCxJQUFlLEtBQWY7QUFDQSxXQUFPLEtBQUssd0JBQUwsQ0FBOEIsVUFBOUIsQ0FBeUMsS0FBekMsRUFBZ0QsRUFBaEQsRUFBb0QsQ0FBcEQsQ0FBUCxFQUErRCxlQUFlLEtBQUssQ0FBTCxDQUE5RSxFQUF1RixRQUFRLEtBQUssQ0FBTCxDQUEvRjtBQUNBLFFBQUksVUFBVSxDQUFkLEVBQWlCO0FBQ2YsV0FBSyxNQUFMLElBQWUsTUFBTSxXQUFOLENBQWtCLEtBQWxCLEVBQXlCLElBQXpCLElBQWlDLE1BQU0sV0FBTixDQUFrQixZQUFsQixFQUFnQyxJQUFoQyxDQUFoRDtBQUNBLGNBQVEsWUFBUjtBQUNEO0FBQ0QsV0FBTyxLQUFLLDZCQUFMLENBQW1DLFVBQW5DLENBQThDLEtBQTlDLEVBQXFELEVBQXJELEVBQXlELENBQXpELENBQVAsRUFBb0UsZUFBZSxLQUFLLENBQUwsQ0FBbkYsRUFBNEYsUUFBUSxLQUFLLENBQUwsQ0FBcEc7QUFDQSxRQUFJLFVBQVUsQ0FBZCxFQUFpQjtBQUNmLFdBQUssTUFBTCxJQUFlLE1BQU0sV0FBTixDQUFrQixLQUFsQixFQUF5QixJQUF6QixJQUFpQyxNQUFNLFdBQU4sQ0FBa0IsWUFBbEIsRUFBZ0MsSUFBaEMsQ0FBaEQ7QUFDQSxjQUFRLFlBQVI7QUFDQSxjQUFRLEtBQUssMkJBQUwsQ0FBaUMsT0FBakMsQ0FBeUMsS0FBekMsRUFBZ0QsRUFBaEQsQ0FBUjtBQUNEO0FBQ0QsWUFBUSxNQUFNLEtBQU4sQ0FBWSxJQUFaLENBQVI7QUFDQSxxQkFBaUIsQ0FBQyxDQUFsQjtBQUNBLFNBQUssSUFBSSxDQUFKLEVBQU8sTUFBTSxNQUFNLE1BQXhCLEVBQWdDLElBQUksR0FBcEMsRUFBeUMsR0FBekMsRUFBOEM7QUFDNUMsYUFBTyxNQUFNLENBQU4sQ0FBUDtBQUNBLFVBQUksTUFBTSxJQUFOLENBQVcsSUFBWCxFQUFpQixHQUFqQixFQUFzQixNQUF0QixLQUFpQyxDQUFyQyxFQUF3QztBQUN0QztBQUNEO0FBQ0QsZUFBUyxLQUFLLE1BQUwsR0FBYyxNQUFNLEtBQU4sQ0FBWSxJQUFaLEVBQWtCLE1BQXpDO0FBQ0EsVUFBSSxtQkFBbUIsQ0FBQyxDQUFwQixJQUF5QixTQUFTLGNBQXRDLEVBQXNEO0FBQ3BELHlCQUFpQixNQUFqQjtBQUNEO0FBQ0Y7QUFDRCxRQUFJLGlCQUFpQixDQUFyQixFQUF3QjtBQUN0QixXQUFLLElBQUksSUFBSSxDQUFSLEVBQVcsT0FBTyxNQUFNLE1BQTdCLEVBQXFDLElBQUksSUFBekMsRUFBK0MsSUFBSSxFQUFFLENBQXJELEVBQXdEO0FBQ3RELGVBQU8sTUFBTSxDQUFOLENBQVA7QUFDQSxjQUFNLENBQU4sSUFBVyxLQUFLLEtBQUwsQ0FBVyxjQUFYLENBQVg7QUFDRDtBQUNELGNBQVEsTUFBTSxJQUFOLENBQVcsSUFBWCxDQUFSO0FBQ0Q7QUFDRCxXQUFPLEtBQVA7QUFDRCxHQXZDRDs7QUF5Q0EsU0FBTyxTQUFQLENBQWlCLDhCQUFqQixHQUFrRCxVQUFTLGtCQUFULEVBQTZCO0FBQzdFLFFBQUksTUFBSixFQUFZLEdBQVo7QUFDQSxRQUFJLHNCQUFzQixJQUExQixFQUFnQztBQUM5QiwyQkFBcUIsSUFBckI7QUFDRDtBQUNELFFBQUksc0JBQXNCLElBQTFCLEVBQWdDO0FBQzlCLDJCQUFxQixLQUFLLHlCQUFMLEVBQXJCO0FBQ0Q7QUFDRCxhQUFTLEtBQUssY0FBTCxFQUFUO0FBQ0EsV0FBTyxVQUFVLEtBQUssa0JBQUwsRUFBakIsRUFBNEM7QUFDMUMsZUFBUyxLQUFLLGNBQUwsRUFBVDtBQUNEO0FBQ0QsUUFBSSxVQUFVLE1BQWQsRUFBc0I7QUFDcEIsYUFBTyxLQUFQO0FBQ0Q7QUFDRCxVQUFNLEtBQU47QUFDQSxRQUFJLEtBQUsseUJBQUwsT0FBcUMsa0JBQXJDLElBQTJELEtBQUssZ0NBQUwsQ0FBc0MsS0FBSyxXQUEzQyxDQUEvRCxFQUF3SDtBQUN0SCxZQUFNLElBQU47QUFDRDtBQUNELFNBQUssa0JBQUw7QUFDQSxXQUFPLEdBQVA7QUFDRCxHQXJCRDs7QUF1QkEsU0FBTyxTQUFQLENBQWlCLGdDQUFqQixHQUFvRCxZQUFXO0FBQzdELFdBQU8sS0FBSyxXQUFMLEtBQXFCLEdBQXJCLElBQTRCLEtBQUssV0FBTCxDQUFpQixLQUFqQixDQUF1QixDQUF2QixFQUEwQixDQUExQixNQUFpQyxJQUFwRTtBQUNELEdBRkQ7O0FBSUEsU0FBTyxNQUFQO0FBRUQsQ0Eza0JRLEVBQVQ7O0FBNmtCQSxPQUFPLE9BQVAsR0FBaUIsTUFBakI7Ozs7O0FDMWxCQTtBQUNBLElBQUksT0FBSjs7QUFFQSxVQUFXLFlBQVc7QUFDcEIsVUFBUSxTQUFSLENBQWtCLEtBQWxCLEdBQTBCLElBQTFCOztBQUVBLFVBQVEsU0FBUixDQUFrQixRQUFsQixHQUE2QixJQUE3Qjs7QUFFQSxVQUFRLFNBQVIsQ0FBa0IsWUFBbEIsR0FBaUMsSUFBakM7O0FBRUEsVUFBUSxTQUFSLENBQWtCLE9BQWxCLEdBQTRCLElBQTVCOztBQUVBLFdBQVMsT0FBVCxDQUFpQixRQUFqQixFQUEyQixTQUEzQixFQUFzQztBQUNwQyxRQUFJLEtBQUosRUFBVyxzQkFBWCxFQUFtQyxZQUFuQyxFQUFpRCxDQUFqRCxFQUFvRCxHQUFwRCxFQUF5RCxPQUF6RCxFQUFrRSxJQUFsRSxFQUF3RSxJQUF4RSxFQUE4RSxPQUE5RTtBQUNBLFFBQUksYUFBYSxJQUFqQixFQUF1QjtBQUNyQixrQkFBWSxFQUFaO0FBQ0Q7QUFDRCxtQkFBZSxFQUFmO0FBQ0EsVUFBTSxTQUFTLE1BQWY7QUFDQSxjQUFVLElBQVY7QUFDQSw2QkFBeUIsQ0FBekI7QUFDQSxRQUFJLENBQUo7QUFDQSxXQUFPLElBQUksR0FBWCxFQUFnQjtBQUNkLGNBQVEsU0FBUyxNQUFULENBQWdCLENBQWhCLENBQVI7QUFDQSxVQUFJLFVBQVUsSUFBZCxFQUFvQjtBQUNsQix3QkFBZ0IsU0FBUyxLQUFULENBQWUsQ0FBZixFQUFrQixFQUFFLElBQUksQ0FBTixJQUFXLENBQVgsSUFBZ0IsR0FBbEMsQ0FBaEI7QUFDQTtBQUNELE9BSEQsTUFHTyxJQUFJLFVBQVUsR0FBZCxFQUFtQjtBQUN4QixZQUFJLElBQUksTUFBTSxDQUFkLEVBQWlCO0FBQ2YsaUJBQU8sU0FBUyxLQUFULENBQWUsQ0FBZixFQUFrQixFQUFFLElBQUksQ0FBTixJQUFXLENBQVgsSUFBZ0IsR0FBbEMsQ0FBUDtBQUNBLGNBQUksU0FBUyxLQUFiLEVBQW9CO0FBQ2xCLGlCQUFLLENBQUw7QUFDQSw0QkFBZ0IsSUFBaEI7QUFDRCxXQUhELE1BR08sSUFBSSxTQUFTLEtBQWIsRUFBb0I7QUFDekI7QUFDQSxpQkFBSyxDQUFMO0FBQ0EsbUJBQU8sRUFBUDtBQUNBLG1CQUFPLElBQUksQ0FBSixHQUFRLEdBQWYsRUFBb0I7QUFDbEIsd0JBQVUsU0FBUyxNQUFULENBQWdCLElBQUksQ0FBcEIsQ0FBVjtBQUNBLGtCQUFJLFlBQVksR0FBaEIsRUFBcUI7QUFDbkIsZ0NBQWdCLEdBQWhCO0FBQ0E7QUFDQSxvQkFBSSxLQUFLLE1BQUwsR0FBYyxDQUFsQixFQUFxQjtBQUNuQixzQkFBSSxXQUFXLElBQWYsRUFBcUI7QUFDbkIsOEJBQVUsRUFBVjtBQUNEO0FBQ0QsMEJBQVEsSUFBUixJQUFnQixzQkFBaEI7QUFDRDtBQUNEO0FBQ0QsZUFWRCxNQVVPO0FBQ0wsd0JBQVEsT0FBUjtBQUNEO0FBQ0Q7QUFDRDtBQUNGLFdBckJNLE1BcUJBO0FBQ0wsNEJBQWdCLEtBQWhCO0FBQ0E7QUFDRDtBQUNGLFNBOUJELE1BOEJPO0FBQ0wsMEJBQWdCLEtBQWhCO0FBQ0Q7QUFDRixPQWxDTSxNQWtDQTtBQUNMLHdCQUFnQixLQUFoQjtBQUNEO0FBQ0Q7QUFDRDtBQUNELFNBQUssUUFBTCxHQUFnQixRQUFoQjtBQUNBLFNBQUssWUFBTCxHQUFvQixZQUFwQjtBQUNBLFNBQUssS0FBTCxHQUFhLElBQUksTUFBSixDQUFXLEtBQUssWUFBaEIsRUFBOEIsTUFBTSxVQUFVLE9BQVYsQ0FBa0IsR0FBbEIsRUFBdUIsRUFBdkIsQ0FBcEMsQ0FBYjtBQUNBLFNBQUssT0FBTCxHQUFlLE9BQWY7QUFDRDs7QUFFRCxVQUFRLFNBQVIsQ0FBa0IsSUFBbEIsR0FBeUIsVUFBUyxHQUFULEVBQWM7QUFDckMsUUFBSSxLQUFKLEVBQVcsT0FBWCxFQUFvQixJQUFwQixFQUEwQixHQUExQjtBQUNBLFNBQUssS0FBTCxDQUFXLFNBQVgsR0FBdUIsQ0FBdkI7QUFDQSxjQUFVLEtBQUssS0FBTCxDQUFXLElBQVgsQ0FBZ0IsR0FBaEIsQ0FBVjtBQUNBLFFBQUksV0FBVyxJQUFmLEVBQXFCO0FBQ25CLGFBQU8sSUFBUDtBQUNEO0FBQ0QsUUFBSSxLQUFLLE9BQUwsSUFBZ0IsSUFBcEIsRUFBMEI7QUFDeEIsWUFBTSxLQUFLLE9BQVg7QUFDQSxXQUFLLElBQUwsSUFBYSxHQUFiLEVBQWtCO0FBQ2hCLGdCQUFRLElBQUksSUFBSixDQUFSO0FBQ0EsZ0JBQVEsSUFBUixJQUFnQixRQUFRLEtBQVIsQ0FBaEI7QUFDRDtBQUNGO0FBQ0QsV0FBTyxPQUFQO0FBQ0QsR0FmRDs7QUFpQkEsVUFBUSxTQUFSLENBQWtCLElBQWxCLEdBQXlCLFVBQVMsR0FBVCxFQUFjO0FBQ3JDLFNBQUssS0FBTCxDQUFXLFNBQVgsR0FBdUIsQ0FBdkI7QUFDQSxXQUFPLEtBQUssS0FBTCxDQUFXLElBQVgsQ0FBZ0IsR0FBaEIsQ0FBUDtBQUNELEdBSEQ7O0FBS0EsVUFBUSxTQUFSLENBQWtCLE9BQWxCLEdBQTRCLFVBQVMsR0FBVCxFQUFjLFdBQWQsRUFBMkI7QUFDckQsU0FBSyxLQUFMLENBQVcsU0FBWCxHQUF1QixDQUF2QjtBQUNBLFdBQU8sSUFBSSxPQUFKLENBQVksS0FBSyxLQUFqQixFQUF3QixXQUF4QixDQUFQO0FBQ0QsR0FIRDs7QUFLQSxVQUFRLFNBQVIsQ0FBa0IsVUFBbEIsR0FBK0IsVUFBUyxHQUFULEVBQWMsV0FBZCxFQUEyQixLQUEzQixFQUFrQztBQUMvRCxRQUFJLEtBQUo7QUFDQSxRQUFJLFNBQVMsSUFBYixFQUFtQjtBQUNqQixjQUFRLENBQVI7QUFDRDtBQUNELFNBQUssS0FBTCxDQUFXLFNBQVgsR0FBdUIsQ0FBdkI7QUFDQSxZQUFRLENBQVI7QUFDQSxXQUFPLEtBQUssS0FBTCxDQUFXLElBQVgsQ0FBZ0IsR0FBaEIsTUFBeUIsVUFBVSxDQUFWLElBQWUsUUFBUSxLQUFoRCxDQUFQLEVBQStEO0FBQzdELFdBQUssS0FBTCxDQUFXLFNBQVgsR0FBdUIsQ0FBdkI7QUFDQSxZQUFNLElBQUksT0FBSixDQUFZLEtBQUssS0FBakIsRUFBd0IsV0FBeEIsQ0FBTjtBQUNBO0FBQ0Q7QUFDRCxXQUFPLENBQUMsR0FBRCxFQUFNLEtBQU4sQ0FBUDtBQUNELEdBYkQ7O0FBZUEsU0FBTyxPQUFQO0FBRUQsQ0FqSFMsRUFBVjs7QUFtSEEsT0FBTyxPQUFQLEdBQWlCLE9BQWpCOzs7OztBQ3RIQTtBQUNBLElBQUksT0FBSixFQUFhLFNBQWIsRUFBd0IsS0FBeEI7O0FBRUEsUUFBUSxRQUFRLFNBQVIsQ0FBUjs7QUFFQSxVQUFVLFFBQVEsV0FBUixDQUFWOztBQUVBLFlBQWEsWUFBVztBQUN0QixXQUFTLFNBQVQsR0FBcUIsQ0FBRTs7QUFFdkIsWUFBVSx5QkFBVixHQUFzQyxJQUFJLE9BQUosQ0FBWSxrRkFBWixDQUF0Qzs7QUFFQSxZQUFVLDBCQUFWLEdBQXVDLFVBQVMsS0FBVCxFQUFnQjtBQUNyRCxXQUFPLE1BQU0sT0FBTixDQUFjLE9BQWQsRUFBdUIsSUFBdkIsQ0FBUDtBQUNELEdBRkQ7O0FBSUEsWUFBVSwwQkFBVixHQUF1QyxVQUFTLEtBQVQsRUFBZ0I7QUFDckQsUUFBSSxLQUFLLGlCQUFMLElBQTBCLElBQTlCLEVBQW9DO0FBQ2xDLFdBQUssaUJBQUwsR0FBMEIsVUFBUyxLQUFULEVBQWdCO0FBQ3hDLGVBQU8sVUFBUyxHQUFULEVBQWM7QUFDbkIsaUJBQU8sTUFBTSxpQkFBTixDQUF3QixHQUF4QixDQUFQO0FBQ0QsU0FGRDtBQUdELE9BSndCLENBSXRCLElBSnNCLENBQXpCO0FBS0Q7QUFDRCxXQUFPLEtBQUsseUJBQUwsQ0FBK0IsT0FBL0IsQ0FBdUMsS0FBdkMsRUFBOEMsS0FBSyxpQkFBbkQsQ0FBUDtBQUNELEdBVEQ7O0FBV0EsWUFBVSxpQkFBVixHQUE4QixVQUFTLEtBQVQsRUFBZ0I7QUFDNUMsUUFBSSxFQUFKO0FBQ0EsU0FBSyxPQUFPLFlBQVo7QUFDQSxZQUFRLE1BQU0sTUFBTixDQUFhLENBQWIsQ0FBUjtBQUNFLFdBQUssR0FBTDtBQUNFLGVBQU8sR0FBRyxDQUFILENBQVA7QUFDRixXQUFLLEdBQUw7QUFDRSxlQUFPLEdBQUcsQ0FBSCxDQUFQO0FBQ0YsV0FBSyxHQUFMO0FBQ0UsZUFBTyxHQUFHLENBQUgsQ0FBUDtBQUNGLFdBQUssR0FBTDtBQUNFLGVBQU8sSUFBUDtBQUNGLFdBQUssSUFBTDtBQUNFLGVBQU8sSUFBUDtBQUNGLFdBQUssR0FBTDtBQUNFLGVBQU8sSUFBUDtBQUNGLFdBQUssR0FBTDtBQUNFLGVBQU8sR0FBRyxFQUFILENBQVA7QUFDRixXQUFLLEdBQUw7QUFDRSxlQUFPLEdBQUcsRUFBSCxDQUFQO0FBQ0YsV0FBSyxHQUFMO0FBQ0UsZUFBTyxHQUFHLEVBQUgsQ0FBUDtBQUNGLFdBQUssR0FBTDtBQUNFLGVBQU8sR0FBRyxFQUFILENBQVA7QUFDRixXQUFLLEdBQUw7QUFDRSxlQUFPLEdBQVA7QUFDRixXQUFLLEdBQUw7QUFDRSxlQUFPLEdBQVA7QUFDRixXQUFLLEdBQUw7QUFDRSxlQUFPLEdBQVA7QUFDRixXQUFLLElBQUw7QUFDRSxlQUFPLElBQVA7QUFDRixXQUFLLEdBQUw7QUFDRSxlQUFPLEdBQUcsTUFBSCxDQUFQO0FBQ0YsV0FBSyxHQUFMO0FBQ0UsZUFBTyxHQUFHLE1BQUgsQ0FBUDtBQUNGLFdBQUssR0FBTDtBQUNFLGVBQU8sR0FBRyxNQUFILENBQVA7QUFDRixXQUFLLEdBQUw7QUFDRSxlQUFPLEdBQUcsTUFBSCxDQUFQO0FBQ0YsV0FBSyxHQUFMO0FBQ0UsZUFBTyxNQUFNLE9BQU4sQ0FBYyxNQUFNLE1BQU4sQ0FBYSxNQUFNLE1BQU4sQ0FBYSxDQUFiLEVBQWdCLENBQWhCLENBQWIsQ0FBZCxDQUFQO0FBQ0YsV0FBSyxHQUFMO0FBQ0UsZUFBTyxNQUFNLE9BQU4sQ0FBYyxNQUFNLE1BQU4sQ0FBYSxNQUFNLE1BQU4sQ0FBYSxDQUFiLEVBQWdCLENBQWhCLENBQWIsQ0FBZCxDQUFQO0FBQ0YsV0FBSyxHQUFMO0FBQ0UsZUFBTyxNQUFNLE9BQU4sQ0FBYyxNQUFNLE1BQU4sQ0FBYSxNQUFNLE1BQU4sQ0FBYSxDQUFiLEVBQWdCLENBQWhCLENBQWIsQ0FBZCxDQUFQO0FBQ0Y7QUFDRSxlQUFPLEVBQVA7QUE1Q0o7QUE4Q0QsR0FqREQ7O0FBbURBLFNBQU8sU0FBUDtBQUVELENBekVXLEVBQVo7O0FBMkVBLE9BQU8sT0FBUCxHQUFpQixTQUFqQjs7Ozs7QUNsRkE7QUFDQSxJQUFJLE9BQUo7QUFBQSxJQUFhLEtBQWI7QUFBQSxJQUNFLFVBQVUsR0FBRyxjQURmOztBQUdBLFVBQVUsUUFBUSxXQUFSLENBQVY7O0FBRUEsUUFBUyxZQUFXO0FBQ2xCLFdBQVMsS0FBVCxHQUFpQixDQUFFOztBQUVuQixRQUFNLHVCQUFOLEdBQWdDLEVBQWhDOztBQUVBLFFBQU0sd0JBQU4sR0FBaUMsRUFBakM7O0FBRUEsUUFBTSxZQUFOLEdBQXFCLE1BQXJCOztBQUVBLFFBQU0sWUFBTixHQUFxQixPQUFyQjs7QUFFQSxRQUFNLFdBQU4sR0FBb0IsVUFBcEI7O0FBRUEsUUFBTSxpQkFBTixHQUEwQixhQUExQjs7QUFFQSxRQUFNLFlBQU4sR0FBcUIsSUFBSSxPQUFKLENBQVksTUFBTSwrQkFBTixHQUF3Qyx3QkFBeEMsR0FBbUUsc0JBQW5FLEdBQTRGLG9CQUE1RixHQUFtSCxzQkFBbkgsR0FBNEksd0JBQTVJLEdBQXVLLHdCQUF2SyxHQUFrTSw0QkFBbE0sR0FBaU8sMERBQWpPLEdBQThSLHFDQUE5UixHQUFzVSxHQUFsVixFQUF1VixHQUF2VixDQUFyQjs7QUFFQSxRQUFNLHFCQUFOLEdBQThCLElBQUksSUFBSixHQUFXLGlCQUFYLEtBQWlDLEVBQWpDLEdBQXNDLElBQXBFOztBQUVBLFFBQU0sSUFBTixHQUFhLFVBQVMsR0FBVCxFQUFjLEtBQWQsRUFBcUI7QUFDaEMsUUFBSSxTQUFKLEVBQWUsVUFBZjtBQUNBLFFBQUksU0FBUyxJQUFiLEVBQW1CO0FBQ2pCLGNBQVEsS0FBUjtBQUNEO0FBQ0QsZ0JBQVksS0FBSyx1QkFBTCxDQUE2QixLQUE3QixDQUFaO0FBQ0EsUUFBSSxhQUFhLElBQWpCLEVBQXVCO0FBQ3JCLFdBQUssdUJBQUwsQ0FBNkIsS0FBN0IsSUFBc0MsWUFBWSxJQUFJLE1BQUosQ0FBVyxNQUFNLEtBQU4sR0FBYyxFQUFkLEdBQW1CLEtBQW5CLEdBQTJCLEdBQXRDLENBQWxEO0FBQ0Q7QUFDRCxjQUFVLFNBQVYsR0FBc0IsQ0FBdEI7QUFDQSxpQkFBYSxLQUFLLHdCQUFMLENBQThCLEtBQTlCLENBQWI7QUFDQSxRQUFJLGNBQWMsSUFBbEIsRUFBd0I7QUFDdEIsV0FBSyx3QkFBTCxDQUE4QixLQUE5QixJQUF1QyxhQUFhLElBQUksTUFBSixDQUFXLFFBQVEsRUFBUixHQUFhLEtBQWIsR0FBcUIsSUFBaEMsQ0FBcEQ7QUFDRDtBQUNELGVBQVcsU0FBWCxHQUF1QixDQUF2QjtBQUNBLFdBQU8sSUFBSSxPQUFKLENBQVksU0FBWixFQUF1QixFQUF2QixFQUEyQixPQUEzQixDQUFtQyxVQUFuQyxFQUErQyxFQUEvQyxDQUFQO0FBQ0QsR0FoQkQ7O0FBa0JBLFFBQU0sS0FBTixHQUFjLFVBQVMsR0FBVCxFQUFjLEtBQWQsRUFBcUI7QUFDakMsUUFBSSxTQUFKO0FBQ0EsUUFBSSxTQUFTLElBQWIsRUFBbUI7QUFDakIsY0FBUSxLQUFSO0FBQ0Q7QUFDRCxnQkFBWSxLQUFLLHVCQUFMLENBQTZCLEtBQTdCLENBQVo7QUFDQSxRQUFJLGFBQWEsSUFBakIsRUFBdUI7QUFDckIsV0FBSyx1QkFBTCxDQUE2QixLQUE3QixJQUFzQyxZQUFZLElBQUksTUFBSixDQUFXLE1BQU0sS0FBTixHQUFjLEVBQWQsR0FBbUIsS0FBbkIsR0FBMkIsR0FBdEMsQ0FBbEQ7QUFDRDtBQUNELGNBQVUsU0FBVixHQUFzQixDQUF0QjtBQUNBLFdBQU8sSUFBSSxPQUFKLENBQVksU0FBWixFQUF1QixFQUF2QixDQUFQO0FBQ0QsR0FYRDs7QUFhQSxRQUFNLEtBQU4sR0FBYyxVQUFTLEdBQVQsRUFBYyxLQUFkLEVBQXFCO0FBQ2pDLFFBQUksVUFBSjtBQUNBLFFBQUksU0FBUyxJQUFiLEVBQW1CO0FBQ2pCLGNBQVEsS0FBUjtBQUNEO0FBQ0QsaUJBQWEsS0FBSyx3QkFBTCxDQUE4QixLQUE5QixDQUFiO0FBQ0EsUUFBSSxjQUFjLElBQWxCLEVBQXdCO0FBQ3RCLFdBQUssd0JBQUwsQ0FBOEIsS0FBOUIsSUFBdUMsYUFBYSxJQUFJLE1BQUosQ0FBVyxRQUFRLEVBQVIsR0FBYSxLQUFiLEdBQXFCLElBQWhDLENBQXBEO0FBQ0Q7QUFDRCxlQUFXLFNBQVgsR0FBdUIsQ0FBdkI7QUFDQSxXQUFPLElBQUksT0FBSixDQUFZLFVBQVosRUFBd0IsRUFBeEIsQ0FBUDtBQUNELEdBWEQ7O0FBYUEsUUFBTSxPQUFOLEdBQWdCLFVBQVMsS0FBVCxFQUFnQjtBQUM5QixXQUFPLENBQUMsS0FBRCxJQUFVLFVBQVUsRUFBcEIsSUFBMEIsVUFBVSxHQUFwQyxJQUE0QyxpQkFBaUIsS0FBakIsSUFBMEIsTUFBTSxNQUFOLEtBQWlCLENBQXZGLElBQTZGLEtBQUssYUFBTCxDQUFtQixLQUFuQixDQUFwRztBQUNELEdBRkQ7O0FBSUEsUUFBTSxhQUFOLEdBQXNCLFVBQVMsS0FBVCxFQUFnQjtBQUNwQyxRQUFJLENBQUo7QUFDQSxXQUFPLGlCQUFpQixNQUFqQixJQUE2QixZQUFXO0FBQzdDLFVBQUksT0FBSjtBQUNBLGdCQUFVLEVBQVY7QUFDQSxXQUFLLENBQUwsSUFBVSxLQUFWLEVBQWlCO0FBQ2YsWUFBSSxDQUFDLFFBQVEsSUFBUixDQUFhLEtBQWIsRUFBb0IsQ0FBcEIsQ0FBTCxFQUE2QjtBQUM3QixnQkFBUSxJQUFSLENBQWEsQ0FBYjtBQUNEO0FBQ0QsYUFBTyxPQUFQO0FBQ0QsS0FSa0MsRUFBRCxDQVE1QixNQVI0QixLQVFqQixDQVJqQjtBQVNELEdBWEQ7O0FBYUEsUUFBTSxXQUFOLEdBQW9CLFVBQVMsTUFBVCxFQUFpQixTQUFqQixFQUE0QixLQUE1QixFQUFtQyxNQUFuQyxFQUEyQztBQUM3RCxRQUFJLENBQUosRUFBTyxDQUFQLEVBQVUsQ0FBVixFQUFhLEdBQWIsRUFBa0IsR0FBbEIsRUFBdUIsTUFBdkI7QUFDQSxRQUFJLENBQUo7QUFDQSxhQUFTLEtBQUssTUFBZDtBQUNBLGdCQUFZLEtBQUssU0FBakI7QUFDQSxRQUFJLFNBQVMsSUFBYixFQUFtQjtBQUNqQixlQUFTLE9BQU8sS0FBUCxDQUFhLEtBQWIsQ0FBVDtBQUNEO0FBQ0QsUUFBSSxVQUFVLElBQWQsRUFBb0I7QUFDbEIsZUFBUyxPQUFPLEtBQVAsQ0FBYSxDQUFiLEVBQWdCLE1BQWhCLENBQVQ7QUFDRDtBQUNELFVBQU0sT0FBTyxNQUFiO0FBQ0EsYUFBUyxVQUFVLE1BQW5CO0FBQ0EsU0FBSyxJQUFJLElBQUksQ0FBUixFQUFXLE1BQU0sR0FBdEIsRUFBMkIsS0FBSyxHQUFMLEdBQVcsSUFBSSxHQUFmLEdBQXFCLElBQUksR0FBcEQsRUFBeUQsSUFBSSxLQUFLLEdBQUwsR0FBVyxFQUFFLENBQWIsR0FBaUIsRUFBRSxDQUFoRixFQUFtRjtBQUNqRixVQUFJLGNBQWMsT0FBTyxLQUFQLENBQWEsQ0FBYixFQUFnQixNQUFoQixDQUFsQixFQUEyQztBQUN6QztBQUNBLGFBQUssU0FBUyxDQUFkO0FBQ0Q7QUFDRjtBQUNELFdBQU8sQ0FBUDtBQUNELEdBcEJEOztBQXNCQSxRQUFNLFFBQU4sR0FBaUIsVUFBUyxLQUFULEVBQWdCO0FBQy9CLFNBQUssWUFBTCxDQUFrQixTQUFsQixHQUE4QixDQUE5QjtBQUNBLFdBQU8sS0FBSyxZQUFMLENBQWtCLElBQWxCLENBQXVCLEtBQXZCLENBQVA7QUFDRCxHQUhEOztBQUtBLFFBQU0sTUFBTixHQUFlLFVBQVMsS0FBVCxFQUFnQjtBQUM3QixTQUFLLFdBQUwsQ0FBaUIsU0FBakIsR0FBNkIsQ0FBN0I7QUFDQSxXQUFPLFNBQVMsQ0FBQyxRQUFRLEVBQVQsRUFBYSxPQUFiLENBQXFCLEtBQUssV0FBMUIsRUFBdUMsRUFBdkMsQ0FBVCxFQUFxRCxDQUFyRCxDQUFQO0FBQ0QsR0FIRDs7QUFLQSxRQUFNLE1BQU4sR0FBZSxVQUFTLEtBQVQsRUFBZ0I7QUFDN0IsU0FBSyxpQkFBTCxDQUF1QixTQUF2QixHQUFtQyxDQUFuQztBQUNBLFlBQVEsS0FBSyxJQUFMLENBQVUsS0FBVixDQUFSO0FBQ0EsUUFBSSxDQUFDLFFBQVEsRUFBVCxFQUFhLEtBQWIsQ0FBbUIsQ0FBbkIsRUFBc0IsQ0FBdEIsTUFBNkIsSUFBakMsRUFBdUM7QUFDckMsY0FBUSxDQUFDLFFBQVEsRUFBVCxFQUFhLEtBQWIsQ0FBbUIsQ0FBbkIsQ0FBUjtBQUNEO0FBQ0QsV0FBTyxTQUFTLENBQUMsUUFBUSxFQUFULEVBQWEsT0FBYixDQUFxQixLQUFLLGlCQUExQixFQUE2QyxFQUE3QyxDQUFULEVBQTJELEVBQTNELENBQVA7QUFDRCxHQVBEOztBQVNBLFFBQU0sT0FBTixHQUFnQixVQUFTLENBQVQsRUFBWTtBQUMxQixRQUFJLEVBQUo7QUFDQSxTQUFLLE9BQU8sWUFBWjtBQUNBLFFBQUksUUFBUSxLQUFLLFFBQWIsQ0FBSixFQUE0QjtBQUMxQixhQUFPLEdBQUcsQ0FBSCxDQUFQO0FBQ0Q7QUFDRCxRQUFJLFFBQVEsQ0FBWixFQUFlO0FBQ2IsYUFBTyxHQUFHLE9BQU8sS0FBSyxDQUFmLElBQW9CLEdBQUcsT0FBTyxJQUFJLElBQWQsQ0FBM0I7QUFDRDtBQUNELFFBQUksVUFBVSxDQUFkLEVBQWlCO0FBQ2YsYUFBTyxHQUFHLE9BQU8sS0FBSyxFQUFmLElBQXFCLEdBQUcsT0FBTyxLQUFLLENBQUwsR0FBUyxJQUFuQixDQUFyQixHQUFnRCxHQUFHLE9BQU8sSUFBSSxJQUFkLENBQXZEO0FBQ0Q7QUFDRCxXQUFPLEdBQUcsT0FBTyxLQUFLLEVBQWYsSUFBcUIsR0FBRyxPQUFPLEtBQUssRUFBTCxHQUFVLElBQXBCLENBQXJCLEdBQWlELEdBQUcsT0FBTyxLQUFLLENBQUwsR0FBUyxJQUFuQixDQUFqRCxHQUE0RSxHQUFHLE9BQU8sSUFBSSxJQUFkLENBQW5GO0FBQ0QsR0FiRDs7QUFlQSxRQUFNLFlBQU4sR0FBcUIsVUFBUyxLQUFULEVBQWdCLE1BQWhCLEVBQXdCO0FBQzNDLFFBQUksVUFBSjtBQUNBLFFBQUksVUFBVSxJQUFkLEVBQW9CO0FBQ2xCLGVBQVMsSUFBVDtBQUNEO0FBQ0QsUUFBSSxPQUFPLEtBQVAsS0FBaUIsUUFBckIsRUFBK0I7QUFDN0IsbUJBQWEsTUFBTSxXQUFOLEVBQWI7QUFDQSxVQUFJLENBQUMsTUFBTCxFQUFhO0FBQ1gsWUFBSSxlQUFlLElBQW5CLEVBQXlCO0FBQ3ZCLGlCQUFPLEtBQVA7QUFDRDtBQUNGO0FBQ0QsVUFBSSxlQUFlLEdBQW5CLEVBQXdCO0FBQ3RCLGVBQU8sS0FBUDtBQUNEO0FBQ0QsVUFBSSxlQUFlLE9BQW5CLEVBQTRCO0FBQzFCLGVBQU8sS0FBUDtBQUNEO0FBQ0QsVUFBSSxlQUFlLEVBQW5CLEVBQXVCO0FBQ3JCLGVBQU8sS0FBUDtBQUNEO0FBQ0QsYUFBTyxJQUFQO0FBQ0Q7QUFDRCxXQUFPLENBQUMsQ0FBQyxLQUFUO0FBQ0QsR0F4QkQ7O0FBMEJBLFFBQU0sU0FBTixHQUFrQixVQUFTLEtBQVQsRUFBZ0I7QUFDaEMsU0FBSyxZQUFMLENBQWtCLFNBQWxCLEdBQThCLENBQTlCO0FBQ0EsV0FBTyxPQUFPLEtBQVAsS0FBaUIsUUFBakIsSUFBNkIsT0FBTyxLQUFQLEtBQWlCLFFBQWpCLElBQTZCLENBQUMsTUFBTSxLQUFOLENBQTlCLElBQThDLE1BQU0sT0FBTixDQUFjLEtBQUssWUFBbkIsRUFBaUMsRUFBakMsTUFBeUMsRUFBM0g7QUFDRCxHQUhEOztBQUtBLFFBQU0sWUFBTixHQUFxQixVQUFTLEdBQVQsRUFBYztBQUNqQyxRQUFJLElBQUosRUFBVSxHQUFWLEVBQWUsUUFBZixFQUF5QixJQUF6QixFQUErQixJQUEvQixFQUFxQyxNQUFyQyxFQUE2QyxLQUE3QyxFQUFvRCxNQUFwRCxFQUE0RCxPQUE1RCxFQUFxRSxTQUFyRSxFQUFnRixTQUFoRixFQUEyRixJQUEzRjtBQUNBLFFBQUksRUFBRSxPQUFPLElBQVAsR0FBYyxJQUFJLE1BQWxCLEdBQTJCLEtBQUssQ0FBbEMsQ0FBSixFQUEwQztBQUN4QyxhQUFPLElBQVA7QUFDRDtBQUNELFdBQU8sS0FBSyxZQUFMLENBQWtCLElBQWxCLENBQXVCLEdBQXZCLENBQVA7QUFDQSxRQUFJLENBQUMsSUFBTCxFQUFXO0FBQ1QsYUFBTyxJQUFQO0FBQ0Q7QUFDRCxXQUFPLFNBQVMsS0FBSyxJQUFkLEVBQW9CLEVBQXBCLENBQVA7QUFDQSxZQUFRLFNBQVMsS0FBSyxLQUFkLEVBQXFCLEVBQXJCLElBQTJCLENBQW5DO0FBQ0EsVUFBTSxTQUFTLEtBQUssR0FBZCxFQUFtQixFQUFuQixDQUFOO0FBQ0EsUUFBSSxLQUFLLElBQUwsSUFBYSxJQUFqQixFQUF1QjtBQUNyQixhQUFPLElBQUksSUFBSixDQUFTLEtBQUssR0FBTCxDQUFTLElBQVQsRUFBZSxLQUFmLEVBQXNCLEdBQXRCLENBQVQsQ0FBUDtBQUNBLGFBQU8sSUFBUDtBQUNEO0FBQ0QsV0FBTyxTQUFTLEtBQUssSUFBZCxFQUFvQixFQUFwQixDQUFQO0FBQ0EsYUFBUyxTQUFTLEtBQUssTUFBZCxFQUFzQixFQUF0QixDQUFUO0FBQ0EsYUFBUyxTQUFTLEtBQUssTUFBZCxFQUFzQixFQUF0QixDQUFUO0FBQ0EsUUFBSSxLQUFLLFFBQUwsSUFBaUIsSUFBckIsRUFBMkI7QUFDekIsaUJBQVcsS0FBSyxRQUFMLENBQWMsS0FBZCxDQUFvQixDQUFwQixFQUF1QixDQUF2QixDQUFYO0FBQ0EsYUFBTyxTQUFTLE1BQVQsR0FBa0IsQ0FBekIsRUFBNEI7QUFDMUIsb0JBQVksR0FBWjtBQUNEO0FBQ0QsaUJBQVcsU0FBUyxRQUFULEVBQW1CLEVBQW5CLENBQVg7QUFDRCxLQU5ELE1BTU87QUFDTCxpQkFBVyxDQUFYO0FBQ0Q7QUFDRCxRQUFJLEtBQUssRUFBTCxJQUFXLElBQWYsRUFBcUI7QUFDbkIsZ0JBQVUsU0FBUyxLQUFLLE9BQWQsRUFBdUIsRUFBdkIsQ0FBVjtBQUNBLFVBQUksS0FBSyxTQUFMLElBQWtCLElBQXRCLEVBQTRCO0FBQzFCLG9CQUFZLFNBQVMsS0FBSyxTQUFkLEVBQXlCLEVBQXpCLENBQVo7QUFDRCxPQUZELE1BRU87QUFDTCxvQkFBWSxDQUFaO0FBQ0Q7QUFDRCxrQkFBWSxDQUFDLFVBQVUsRUFBVixHQUFlLFNBQWhCLElBQTZCLEtBQXpDO0FBQ0EsVUFBSSxRQUFRLEtBQUssT0FBakIsRUFBMEI7QUFDeEIscUJBQWEsQ0FBQyxDQUFkO0FBQ0Q7QUFDRjtBQUNELFdBQU8sSUFBSSxJQUFKLENBQVMsS0FBSyxHQUFMLENBQVMsSUFBVCxFQUFlLEtBQWYsRUFBc0IsR0FBdEIsRUFBMkIsSUFBM0IsRUFBaUMsTUFBakMsRUFBeUMsTUFBekMsRUFBaUQsUUFBakQsQ0FBVCxDQUFQO0FBQ0EsUUFBSSxTQUFKLEVBQWU7QUFDYixXQUFLLE9BQUwsQ0FBYSxLQUFLLE9BQUwsS0FBaUIsU0FBOUI7QUFDRDtBQUNELFdBQU8sSUFBUDtBQUNELEdBN0NEOztBQStDQSxRQUFNLFNBQU4sR0FBa0IsVUFBUyxHQUFULEVBQWMsTUFBZCxFQUFzQjtBQUN0QyxRQUFJLENBQUosRUFBTyxHQUFQO0FBQ0EsVUFBTSxFQUFOO0FBQ0EsUUFBSSxDQUFKO0FBQ0EsV0FBTyxJQUFJLE1BQVgsRUFBbUI7QUFDakIsYUFBTyxHQUFQO0FBQ0E7QUFDRDtBQUNELFdBQU8sR0FBUDtBQUNELEdBVEQ7O0FBV0EsUUFBTSxpQkFBTixHQUEwQixVQUFTLElBQVQsRUFBZSxRQUFmLEVBQXlCO0FBQ2pELFFBQUksSUFBSixFQUFVLEVBQVYsRUFBYyxDQUFkLEVBQWlCLElBQWpCLEVBQXVCLElBQXZCLEVBQTZCLEdBQTdCLEVBQWtDLEdBQWxDLEVBQXVDLEdBQXZDO0FBQ0EsUUFBSSxZQUFZLElBQWhCLEVBQXNCO0FBQ3BCLGlCQUFXLElBQVg7QUFDRDtBQUNELFVBQU0sSUFBTjtBQUNBLFFBQUksT0FBTyxNQUFQLEtBQWtCLFdBQWxCLElBQWlDLFdBQVcsSUFBaEQsRUFBc0Q7QUFDcEQsVUFBSSxPQUFPLGNBQVgsRUFBMkI7QUFDekIsY0FBTSxJQUFJLGNBQUosRUFBTjtBQUNELE9BRkQsTUFFTyxJQUFJLE9BQU8sYUFBWCxFQUEwQjtBQUMvQixjQUFNLENBQUMsb0JBQUQsRUFBdUIsb0JBQXZCLEVBQTZDLGdCQUE3QyxFQUErRCxtQkFBL0QsQ0FBTjtBQUNBLGFBQUssSUFBSSxDQUFKLEVBQU8sT0FBTyxJQUFJLE1BQXZCLEVBQStCLElBQUksSUFBbkMsRUFBeUMsR0FBekMsRUFBOEM7QUFDNUMsaUJBQU8sSUFBSSxDQUFKLENBQVA7QUFDQSxjQUFJO0FBQ0Ysa0JBQU0sSUFBSSxhQUFKLENBQWtCLElBQWxCLENBQU47QUFDRCxXQUZELENBRUUsT0FBTyxLQUFQLEVBQWMsQ0FBRTtBQUNuQjtBQUNGO0FBQ0Y7QUFDRCxRQUFJLE9BQU8sSUFBWCxFQUFpQjtBQUNmLFVBQUksWUFBWSxJQUFoQixFQUFzQjtBQUNwQixZQUFJLGtCQUFKLEdBQXlCLFlBQVc7QUFDbEMsY0FBSSxJQUFJLFVBQUosS0FBbUIsQ0FBdkIsRUFBMEI7QUFDeEIsZ0JBQUksSUFBSSxNQUFKLEtBQWUsR0FBZixJQUFzQixJQUFJLE1BQUosS0FBZSxDQUF6QyxFQUE0QztBQUMxQyxxQkFBTyxTQUFTLElBQUksWUFBYixDQUFQO0FBQ0QsYUFGRCxNQUVPO0FBQ0wscUJBQU8sU0FBUyxJQUFULENBQVA7QUFDRDtBQUNGO0FBQ0YsU0FSRDtBQVNBLFlBQUksSUFBSixDQUFTLEtBQVQsRUFBZ0IsSUFBaEIsRUFBc0IsSUFBdEI7QUFDQSxlQUFPLElBQUksSUFBSixDQUFTLElBQVQsQ0FBUDtBQUNELE9BWkQsTUFZTztBQUNMLFlBQUksSUFBSixDQUFTLEtBQVQsRUFBZ0IsSUFBaEIsRUFBc0IsS0FBdEI7QUFDQSxZQUFJLElBQUosQ0FBUyxJQUFUO0FBQ0EsWUFBSSxJQUFJLE1BQUosS0FBZSxHQUFmLElBQXNCLElBQUksTUFBSixLQUFlLENBQXpDLEVBQTRDO0FBQzFDLGlCQUFPLElBQUksWUFBWDtBQUNEO0FBQ0QsZUFBTyxJQUFQO0FBQ0Q7QUFDRixLQXJCRCxNQXFCTztBQUNMLFlBQU0sT0FBTjtBQUNBLFdBQUssSUFBSSxJQUFKLENBQUw7QUFDQSxVQUFJLFlBQVksSUFBaEIsRUFBc0I7QUFDcEIsZUFBTyxHQUFHLFFBQUgsQ0FBWSxJQUFaLEVBQWtCLFVBQVMsR0FBVCxFQUFjLElBQWQsRUFBb0I7QUFDM0MsY0FBSSxHQUFKLEVBQVM7QUFDUCxtQkFBTyxTQUFTLElBQVQsQ0FBUDtBQUNELFdBRkQsTUFFTztBQUNMLG1CQUFPLFNBQVMsT0FBTyxJQUFQLENBQVQsQ0FBUDtBQUNEO0FBQ0YsU0FOTSxDQUFQO0FBT0QsT0FSRCxNQVFPO0FBQ0wsZUFBTyxHQUFHLFlBQUgsQ0FBZ0IsSUFBaEIsQ0FBUDtBQUNBLFlBQUksUUFBUSxJQUFaLEVBQWtCO0FBQ2hCLGlCQUFPLE9BQU8sSUFBUCxDQUFQO0FBQ0Q7QUFDRCxlQUFPLElBQVA7QUFDRDtBQUNGO0FBQ0YsR0EzREQ7O0FBNkRBLFNBQU8sS0FBUDtBQUVELENBaFNPLEVBQVI7O0FBa1NBLE9BQU8sT0FBUCxHQUFpQixLQUFqQjs7Ozs7QUN4U0E7QUFDQSxJQUFJLE1BQUosRUFBWSxNQUFaLEVBQW9CLEtBQXBCLEVBQTJCLElBQTNCOztBQUVBLFNBQVMsUUFBUSxVQUFSLENBQVQ7O0FBRUEsU0FBUyxRQUFRLFVBQVIsQ0FBVDs7QUFFQSxRQUFRLFFBQVEsU0FBUixDQUFSOztBQUVBLE9BQVEsWUFBVztBQUNqQixXQUFTLElBQVQsR0FBZ0IsQ0FBRTs7QUFFbEIsT0FBSyxLQUFMLEdBQWEsVUFBUyxLQUFULEVBQWdCLHNCQUFoQixFQUF3QyxhQUF4QyxFQUF1RDtBQUNsRSxRQUFJLDBCQUEwQixJQUE5QixFQUFvQztBQUNsQywrQkFBeUIsS0FBekI7QUFDRDtBQUNELFFBQUksaUJBQWlCLElBQXJCLEVBQTJCO0FBQ3pCLHNCQUFnQixJQUFoQjtBQUNEO0FBQ0QsV0FBTyxJQUFJLE1BQUosR0FBYSxLQUFiLENBQW1CLEtBQW5CLEVBQTBCLHNCQUExQixFQUFrRCxhQUFsRCxDQUFQO0FBQ0QsR0FSRDs7QUFVQSxPQUFLLFNBQUwsR0FBaUIsVUFBUyxJQUFULEVBQWUsUUFBZixFQUF5QixzQkFBekIsRUFBaUQsYUFBakQsRUFBZ0U7QUFDL0UsUUFBSSxLQUFKO0FBQ0EsUUFBSSxZQUFZLElBQWhCLEVBQXNCO0FBQ3BCLGlCQUFXLElBQVg7QUFDRDtBQUNELFFBQUksMEJBQTBCLElBQTlCLEVBQW9DO0FBQ2xDLCtCQUF5QixLQUF6QjtBQUNEO0FBQ0QsUUFBSSxpQkFBaUIsSUFBckIsRUFBMkI7QUFDekIsc0JBQWdCLElBQWhCO0FBQ0Q7QUFDRCxRQUFJLFlBQVksSUFBaEIsRUFBc0I7QUFDcEIsYUFBTyxNQUFNLGlCQUFOLENBQXdCLElBQXhCLEVBQStCLFVBQVMsS0FBVCxFQUFnQjtBQUNwRCxlQUFPLFVBQVMsS0FBVCxFQUFnQjtBQUNyQixjQUFJLE1BQUo7QUFDQSxtQkFBUyxJQUFUO0FBQ0EsY0FBSSxTQUFTLElBQWIsRUFBbUI7QUFDakIscUJBQVMsTUFBTSxLQUFOLENBQVksS0FBWixFQUFtQixzQkFBbkIsRUFBMkMsYUFBM0MsQ0FBVDtBQUNEO0FBQ0QsbUJBQVMsTUFBVDtBQUNELFNBUEQ7QUFRRCxPQVRvQyxDQVNsQyxJQVRrQyxDQUE5QixDQUFQO0FBVUQsS0FYRCxNQVdPO0FBQ0wsY0FBUSxNQUFNLGlCQUFOLENBQXdCLElBQXhCLENBQVI7QUFDQSxVQUFJLFNBQVMsSUFBYixFQUFtQjtBQUNqQixlQUFPLEtBQUssS0FBTCxDQUFXLEtBQVgsRUFBa0Isc0JBQWxCLEVBQTBDLGFBQTFDLENBQVA7QUFDRDtBQUNELGFBQU8sSUFBUDtBQUNEO0FBQ0YsR0E3QkQ7O0FBK0JBLE9BQUssSUFBTCxHQUFZLFVBQVMsS0FBVCxFQUFnQixNQUFoQixFQUF3QixNQUF4QixFQUFnQyxzQkFBaEMsRUFBd0QsYUFBeEQsRUFBdUU7QUFDakYsUUFBSSxJQUFKO0FBQ0EsUUFBSSxVQUFVLElBQWQsRUFBb0I7QUFDbEIsZUFBUyxDQUFUO0FBQ0Q7QUFDRCxRQUFJLFVBQVUsSUFBZCxFQUFvQjtBQUNsQixlQUFTLENBQVQ7QUFDRDtBQUNELFFBQUksMEJBQTBCLElBQTlCLEVBQW9DO0FBQ2xDLCtCQUF5QixLQUF6QjtBQUNEO0FBQ0QsUUFBSSxpQkFBaUIsSUFBckIsRUFBMkI7QUFDekIsc0JBQWdCLElBQWhCO0FBQ0Q7QUFDRCxXQUFPLElBQUksTUFBSixFQUFQO0FBQ0EsU0FBSyxXQUFMLEdBQW1CLE1BQW5CO0FBQ0EsV0FBTyxLQUFLLElBQUwsQ0FBVSxLQUFWLEVBQWlCLE1BQWpCLEVBQXlCLENBQXpCLEVBQTRCLHNCQUE1QixFQUFvRCxhQUFwRCxDQUFQO0FBQ0QsR0FqQkQ7O0FBbUJBLE9BQUssU0FBTCxHQUFpQixVQUFTLEtBQVQsRUFBZ0IsTUFBaEIsRUFBd0IsTUFBeEIsRUFBZ0Msc0JBQWhDLEVBQXdELGFBQXhELEVBQXVFO0FBQ3RGLFdBQU8sS0FBSyxJQUFMLENBQVUsS0FBVixFQUFpQixNQUFqQixFQUF5QixNQUF6QixFQUFpQyxzQkFBakMsRUFBeUQsYUFBekQsQ0FBUDtBQUNELEdBRkQ7O0FBSUEsT0FBSyxJQUFMLEdBQVksVUFBUyxJQUFULEVBQWUsUUFBZixFQUF5QixzQkFBekIsRUFBaUQsYUFBakQsRUFBZ0U7QUFDMUUsV0FBTyxLQUFLLFNBQUwsQ0FBZSxJQUFmLEVBQXFCLFFBQXJCLEVBQStCLHNCQUEvQixFQUF1RCxhQUF2RCxDQUFQO0FBQ0QsR0FGRDs7QUFJQSxTQUFPLElBQVA7QUFFRCxDQXpFTSxFQUFQOztBQTJFQSxJQUFJLE9BQU8sTUFBUCxLQUFrQixXQUFsQixJQUFpQyxXQUFXLElBQWhELEVBQXNEO0FBQ3BELFNBQU8sSUFBUCxHQUFjLElBQWQ7QUFDRDs7QUFFRCxJQUFJLE9BQU8sTUFBUCxLQUFrQixXQUFsQixJQUFpQyxXQUFXLElBQWhELEVBQXNEO0FBQ3BELFlBQUssSUFBTCxHQUFZLElBQVo7QUFDRDs7QUFFRCxPQUFPLE9BQVAsR0FBaUIsSUFBakI7Ozs7Ozs7O0FDNUZBLFNBQVMsZ0JBQVQsQ0FBMEIsR0FBMUIsRUFBK0I7QUFDN0IsTUFBSSxRQUFRLGtFQUFaO0FBQ0EsTUFBSSxPQUFPLE1BQU0sTUFBakI7QUFDQSxNQUFJLE1BQU0sRUFBVjtBQUFBLE1BQWMsQ0FBZDtBQUNBLFNBQU8sR0FBUCxFQUFZO0FBQ1IsUUFBSSxNQUFNLElBQVY7QUFDQSxXQUFPLENBQVA7QUFDQSxXQUFPLElBQVA7QUFDQSxVQUFNLE1BQU0sTUFBTixDQUFhLENBQWIsSUFBa0IsR0FBeEI7QUFDSDtBQUNELFNBQU8sR0FBUDtBQUNEOztrQkFFYyxnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2JmOztBQUVBOzs7Ozs7Ozs7OztBQVdBLElBQU0sa0JBQWtCLHNCQUF4Qjs7QUFFQSxTQUFTLGNBQVQsQ0FBeUIsS0FBekIsRUFBZ0M7QUFDOUIsaUJBQWUsS0FBZix1REFBZSxLQUFmO0FBQ0EsU0FBSyxRQUFMO0FBQ0EsU0FBSyxRQUFMO0FBQ0EsU0FBSyxTQUFMO0FBQ0UsYUFBTyxLQUFQO0FBQ0YsU0FBSyxRQUFMO0FBQ0UsVUFBSTtBQUNGO0FBQ0EsZUFBTyxVQUFVLElBQVYsR0FBaUIsRUFBakIsR0FBc0IseUJBQWUsS0FBZixDQUE3QjtBQUNELE9BSEQsQ0FHRSxPQUFPLFNBQVAsRUFBa0I7QUFDbEIsZUFBTyxPQUFQO0FBQ0Q7QUFDSDtBQUNHO0FBQ0E7QUFDRCxhQUFPLEVBQVA7QUFmRjtBQWlCRDs7QUFFRDs7Ozs7OztBQU9BLFNBQVMsc0JBQVQsQ0FBZ0MsS0FBaEMsRUFBdUMsSUFBdkMsRUFBNEQ7QUFBQSxNQUFmLFNBQWUsdUVBQUgsQ0FBRzs7QUFDMUQsTUFBSSxRQUFPLEtBQVAsdURBQU8sS0FBUCxPQUFpQixRQUFqQixJQUE2QixVQUFVLElBQXZDLElBQStDLFVBQVUsU0FBN0QsRUFBd0U7QUFDdEUsV0FBTyxFQUFQO0FBQ0Q7O0FBRUQsTUFBTSxVQUFVLEtBQUssU0FBTCxDQUFoQjtBQUNBLE1BQU0sUUFBUSxNQUFNLE9BQU4sQ0FBZDs7QUFFQSxNQUFJLGNBQWMsS0FBSyxNQUFMLEdBQWMsQ0FBaEMsRUFBbUM7QUFDakM7QUFDQSxXQUFPLEtBQVA7QUFDRDs7QUFFRCxTQUFPLHVCQUF1QixLQUF2QixFQUE4QixJQUE5QixFQUFvQyxFQUFFLFNBQXRDLENBQVA7QUFDRDs7QUFFRCxTQUFTLGVBQVQsQ0FBeUIsT0FBekIsRUFBa0MsSUFBbEMsRUFBd0M7QUFDdEMsU0FBTyx1QkFBdUIsSUFBdkIsRUFBNkIsUUFBUSxLQUFSLENBQWMsR0FBZCxDQUE3QixDQUFQO0FBQ0Q7O0FBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWtCQSxTQUFTLE1BQVQsQ0FBaUIsUUFBakIsRUFBa0U7QUFBQSxNQUF2QyxJQUF1Qyx1RUFBaEMsRUFBZ0M7QUFBQSxNQUE1QixRQUE0Qix1RUFBakIsZUFBaUI7O0FBQ2hFO0FBQ0EsTUFBSSxPQUFPLFFBQVAsS0FBb0IsUUFBeEIsRUFBa0M7QUFDaEMsV0FBTyxRQUFQO0FBQ0Q7O0FBRUQsU0FBTyxTQUFTLE9BQVQsQ0FBaUIsZUFBakIsRUFBa0MsVUFBVSxLQUFWLEVBQWlCLE9BQWpCLEVBQTBCO0FBQ2pFLFFBQUk7QUFDRjtBQUNBLGFBQU8sZUFBZSxTQUFTLE9BQVQsRUFBa0IsSUFBbEIsQ0FBZixDQUFQO0FBQ0QsS0FIRCxDQUdFLE9BQU8sQ0FBUCxFQUFVO0FBQ1Y7QUFDQSxhQUFPLGVBQWUsZ0JBQWdCLE9BQWhCLEVBQXlCLElBQXpCLENBQWYsQ0FBUDtBQUNEO0FBQ0YsR0FSTSxDQUFQO0FBU0Q7O2tCQUVjLE07Ozs7Ozs7OztBQzdGZjs7OztBQUNBOzs7Ozs7QUFMQTs7OztBQU9BLE1BQU0sWUFBTixDQUFtQjtBQUNqQixNQUFJLGNBRGE7QUFFakIsUUFBTSx5Q0FGVztBQUdqQixlQUFhLGdEQUhJO0FBSWpCLGdCQUFjLEVBSkc7QUFLakIsaUJBQWUsRUFMRTtBQU1qQixTQUFPLFFBTlU7QUFPakIsWUFBVSxJQVBPO0FBUWpCLFdBQVMsSUFSUTs7QUFVakIsY0FBWSxNQUFNLGFBQU4sQ0FBb0IseUJBQXBCLENBQThDLFVBVnpDO0FBV2pCLGNBQVksQ0FBQyxNQUFNLGFBQU4sQ0FBb0IsUUFBcEIsQ0FBNkIsZ0JBQTlCLENBWEs7O0FBYWpCLHdCQUFzQixDQUNwQixFQUFFLElBQUksYUFBTixFQUFxQixNQUFNLGNBQTNCLEVBQTJDLFNBQVMsU0FBcEQsRUFBK0QsTUFBTSxNQUFNLEtBQU4sQ0FBWSxZQUFaLENBQXlCLE1BQTlGLEVBRG9CLEVBRXBCLEVBQUUsSUFBSSxlQUFOLEVBQXVCLE1BQU0sc0NBQTdCLEVBQXFFLFNBQVMsSUFBOUUsRUFBb0YsTUFBTSxNQUFNLEtBQU4sQ0FBWSxZQUFaLENBQXlCLFlBQW5ILEVBRm9CLEVBSXBCLEVBQUUsSUFBSSxrQkFBTixFQUEwQixNQUFNLDRCQUFoQyxFQUE4RCxTQUFTLEtBQXZFLEVBQThFLE1BQU0sTUFBTSxLQUFOLENBQVksWUFBWixDQUF5QixZQUE3RyxFQUpvQixFQUtwQixFQUFFLElBQUksVUFBTixFQUFrQixNQUFNLHVDQUF4QixFQUFpRSxTQUFTLFlBQTFFLEVBQXdGLE1BQU0sTUFBTSxLQUFOLENBQVksWUFBWixDQUF5QixXQUF2SCxFQUxvQixDQWJMOztBQXFCakIsV0FyQmlCLHFCQXFCUCxNQXJCTyxFQXFCQyxPQXJCRCxFQXFCVSxNQXJCVixFQXFCa0I7QUFDakMsUUFBSSxVQUFVLElBQUksaUJBQUosQ0FBWSxzQkFBYyxFQUFFLGdCQUFGLEVBQWQsRUFBMkIsT0FBTyxhQUFsQyxDQUFaLENBQWQ7O0FBRUEsV0FBTyxRQUFRLG9CQUFSLEVBQVA7QUFDRCxHQXpCZ0I7OztBQTJCakIsVUFBUSxnQkFBVSxNQUFWLEVBQWtCLElBQWxCLEVBQXdCLEtBQXhCLEVBQStCLE9BQS9CLEVBQXdDOztBQUU5QyxRQUFJLEVBQUUsT0FBRixDQUFVLElBQVYsQ0FBSixFQUFxQjtBQUNuQixhQUFPLG9CQUFDLEtBQUQsQ0FBTyxLQUFQLENBQWEsT0FBYixPQUFQO0FBQ0Q7O0FBRUQsUUFBSSxVQUFVLElBQUksaUJBQUosQ0FBWSxzQkFBYyxFQUFFLGdCQUFGLEVBQWQsRUFBMkIsT0FBTyxhQUFsQyxDQUFaLENBQWQ7O0FBR0EsV0FDRSxvQkFBQyxjQUFEO0FBQ0UsY0FBUSxNQURWO0FBRUUsWUFBTSxJQUZSO0FBR0UsZUFBUyxPQUhYO0FBSUUsZUFBUztBQUpYLE1BREY7QUFRRDtBQTVDZ0IsQ0FBbkIiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbigpe2Z1bmN0aW9uIHIoZSxuLHQpe2Z1bmN0aW9uIG8oaSxmKXtpZighbltpXSl7aWYoIWVbaV0pe3ZhciBjPVwiZnVuY3Rpb25cIj09dHlwZW9mIHJlcXVpcmUmJnJlcXVpcmU7aWYoIWYmJmMpcmV0dXJuIGMoaSwhMCk7aWYodSlyZXR1cm4gdShpLCEwKTt2YXIgYT1uZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK2krXCInXCIpO3Rocm93IGEuY29kZT1cIk1PRFVMRV9OT1RfRk9VTkRcIixhfXZhciBwPW5baV09e2V4cG9ydHM6e319O2VbaV1bMF0uY2FsbChwLmV4cG9ydHMsZnVuY3Rpb24ocil7dmFyIG49ZVtpXVsxXVtyXTtyZXR1cm4gbyhufHxyKX0scCxwLmV4cG9ydHMscixlLG4sdCl9cmV0dXJuIG5baV0uZXhwb3J0c31mb3IodmFyIHU9XCJmdW5jdGlvblwiPT10eXBlb2YgcmVxdWlyZSYmcmVxdWlyZSxpPTA7aTx0Lmxlbmd0aDtpKyspbyh0W2ldKTtyZXR1cm4gb31yZXR1cm4gcn0pKCkiLCJtb2R1bGUuZXhwb3J0cyA9IHsgXCJkZWZhdWx0XCI6IHJlcXVpcmUoXCJjb3JlLWpzL2xpYnJhcnkvZm4vanNvbi9zdHJpbmdpZnlcIiksIF9fZXNNb2R1bGU6IHRydWUgfTsiLCJtb2R1bGUuZXhwb3J0cyA9IHsgXCJkZWZhdWx0XCI6IHJlcXVpcmUoXCJjb3JlLWpzL2xpYnJhcnkvZm4vb2JqZWN0L2Fzc2lnblwiKSwgX19lc01vZHVsZTogdHJ1ZSB9OyIsIm1vZHVsZS5leHBvcnRzID0geyBcImRlZmF1bHRcIjogcmVxdWlyZShcImNvcmUtanMvbGlicmFyeS9mbi9vYmplY3QvY3JlYXRlXCIpLCBfX2VzTW9kdWxlOiB0cnVlIH07IiwibW9kdWxlLmV4cG9ydHMgPSB7IFwiZGVmYXVsdFwiOiByZXF1aXJlKFwiY29yZS1qcy9saWJyYXJ5L2ZuL29iamVjdC9kZWZpbmUtcHJvcGVydHlcIiksIF9fZXNNb2R1bGU6IHRydWUgfTsiLCJtb2R1bGUuZXhwb3J0cyA9IHsgXCJkZWZhdWx0XCI6IHJlcXVpcmUoXCJjb3JlLWpzL2xpYnJhcnkvZm4vb2JqZWN0L2dldC1wcm90b3R5cGUtb2ZcIiksIF9fZXNNb2R1bGU6IHRydWUgfTsiLCJtb2R1bGUuZXhwb3J0cyA9IHsgXCJkZWZhdWx0XCI6IHJlcXVpcmUoXCJjb3JlLWpzL2xpYnJhcnkvZm4vb2JqZWN0L2tleXNcIiksIF9fZXNNb2R1bGU6IHRydWUgfTsiLCJtb2R1bGUuZXhwb3J0cyA9IHsgXCJkZWZhdWx0XCI6IHJlcXVpcmUoXCJjb3JlLWpzL2xpYnJhcnkvZm4vb2JqZWN0L3NldC1wcm90b3R5cGUtb2ZcIiksIF9fZXNNb2R1bGU6IHRydWUgfTsiLCJtb2R1bGUuZXhwb3J0cyA9IHsgXCJkZWZhdWx0XCI6IHJlcXVpcmUoXCJjb3JlLWpzL2xpYnJhcnkvZm4vcHJvbWlzZVwiKSwgX19lc01vZHVsZTogdHJ1ZSB9OyIsIm1vZHVsZS5leHBvcnRzID0geyBcImRlZmF1bHRcIjogcmVxdWlyZShcImNvcmUtanMvbGlicmFyeS9mbi9zeW1ib2xcIiksIF9fZXNNb2R1bGU6IHRydWUgfTsiLCJtb2R1bGUuZXhwb3J0cyA9IHsgXCJkZWZhdWx0XCI6IHJlcXVpcmUoXCJjb3JlLWpzL2xpYnJhcnkvZm4vc3ltYm9sL2l0ZXJhdG9yXCIpLCBfX2VzTW9kdWxlOiB0cnVlIH07IiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbmV4cG9ydHMuX19lc01vZHVsZSA9IHRydWU7XG5cbmV4cG9ydHMuZGVmYXVsdCA9IGZ1bmN0aW9uIChpbnN0YW5jZSwgQ29uc3RydWN0b3IpIHtcbiAgaWYgKCEoaW5zdGFuY2UgaW5zdGFuY2VvZiBDb25zdHJ1Y3RvcikpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2Fubm90IGNhbGwgYSBjbGFzcyBhcyBhIGZ1bmN0aW9uXCIpO1xuICB9XG59OyIsIlwidXNlIHN0cmljdFwiO1xuXG5leHBvcnRzLl9fZXNNb2R1bGUgPSB0cnVlO1xuXG52YXIgX2RlZmluZVByb3BlcnR5ID0gcmVxdWlyZShcIi4uL2NvcmUtanMvb2JqZWN0L2RlZmluZS1wcm9wZXJ0eVwiKTtcblxudmFyIF9kZWZpbmVQcm9wZXJ0eTIgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KF9kZWZpbmVQcm9wZXJ0eSk7XG5cbmZ1bmN0aW9uIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQob2JqKSB7IHJldHVybiBvYmogJiYgb2JqLl9fZXNNb2R1bGUgPyBvYmogOiB7IGRlZmF1bHQ6IG9iaiB9OyB9XG5cbmV4cG9ydHMuZGVmYXVsdCA9IGZ1bmN0aW9uICgpIHtcbiAgZnVuY3Rpb24gZGVmaW5lUHJvcGVydGllcyh0YXJnZXQsIHByb3BzKSB7XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBwcm9wcy5sZW5ndGg7IGkrKykge1xuICAgICAgdmFyIGRlc2NyaXB0b3IgPSBwcm9wc1tpXTtcbiAgICAgIGRlc2NyaXB0b3IuZW51bWVyYWJsZSA9IGRlc2NyaXB0b3IuZW51bWVyYWJsZSB8fCBmYWxzZTtcbiAgICAgIGRlc2NyaXB0b3IuY29uZmlndXJhYmxlID0gdHJ1ZTtcbiAgICAgIGlmIChcInZhbHVlXCIgaW4gZGVzY3JpcHRvcikgZGVzY3JpcHRvci53cml0YWJsZSA9IHRydWU7XG4gICAgICAoMCwgX2RlZmluZVByb3BlcnR5Mi5kZWZhdWx0KSh0YXJnZXQsIGRlc2NyaXB0b3Iua2V5LCBkZXNjcmlwdG9yKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gZnVuY3Rpb24gKENvbnN0cnVjdG9yLCBwcm90b1Byb3BzLCBzdGF0aWNQcm9wcykge1xuICAgIGlmIChwcm90b1Byb3BzKSBkZWZpbmVQcm9wZXJ0aWVzKENvbnN0cnVjdG9yLnByb3RvdHlwZSwgcHJvdG9Qcm9wcyk7XG4gICAgaWYgKHN0YXRpY1Byb3BzKSBkZWZpbmVQcm9wZXJ0aWVzKENvbnN0cnVjdG9yLCBzdGF0aWNQcm9wcyk7XG4gICAgcmV0dXJuIENvbnN0cnVjdG9yO1xuICB9O1xufSgpOyIsIlwidXNlIHN0cmljdFwiO1xuXG5leHBvcnRzLl9fZXNNb2R1bGUgPSB0cnVlO1xuXG52YXIgX2RlZmluZVByb3BlcnR5ID0gcmVxdWlyZShcIi4uL2NvcmUtanMvb2JqZWN0L2RlZmluZS1wcm9wZXJ0eVwiKTtcblxudmFyIF9kZWZpbmVQcm9wZXJ0eTIgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KF9kZWZpbmVQcm9wZXJ0eSk7XG5cbmZ1bmN0aW9uIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQob2JqKSB7IHJldHVybiBvYmogJiYgb2JqLl9fZXNNb2R1bGUgPyBvYmogOiB7IGRlZmF1bHQ6IG9iaiB9OyB9XG5cbmV4cG9ydHMuZGVmYXVsdCA9IGZ1bmN0aW9uIChvYmosIGtleSwgdmFsdWUpIHtcbiAgaWYgKGtleSBpbiBvYmopIHtcbiAgICAoMCwgX2RlZmluZVByb3BlcnR5Mi5kZWZhdWx0KShvYmosIGtleSwge1xuICAgICAgdmFsdWU6IHZhbHVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlXG4gICAgfSk7XG4gIH0gZWxzZSB7XG4gICAgb2JqW2tleV0gPSB2YWx1ZTtcbiAgfVxuXG4gIHJldHVybiBvYmo7XG59OyIsIlwidXNlIHN0cmljdFwiO1xuXG5leHBvcnRzLl9fZXNNb2R1bGUgPSB0cnVlO1xuXG52YXIgX3NldFByb3RvdHlwZU9mID0gcmVxdWlyZShcIi4uL2NvcmUtanMvb2JqZWN0L3NldC1wcm90b3R5cGUtb2ZcIik7XG5cbnZhciBfc2V0UHJvdG90eXBlT2YyID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChfc2V0UHJvdG90eXBlT2YpO1xuXG52YXIgX2NyZWF0ZSA9IHJlcXVpcmUoXCIuLi9jb3JlLWpzL29iamVjdC9jcmVhdGVcIik7XG5cbnZhciBfY3JlYXRlMiA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQoX2NyZWF0ZSk7XG5cbnZhciBfdHlwZW9mMiA9IHJlcXVpcmUoXCIuLi9oZWxwZXJzL3R5cGVvZlwiKTtcblxudmFyIF90eXBlb2YzID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChfdHlwZW9mMik7XG5cbmZ1bmN0aW9uIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQob2JqKSB7IHJldHVybiBvYmogJiYgb2JqLl9fZXNNb2R1bGUgPyBvYmogOiB7IGRlZmF1bHQ6IG9iaiB9OyB9XG5cbmV4cG9ydHMuZGVmYXVsdCA9IGZ1bmN0aW9uIChzdWJDbGFzcywgc3VwZXJDbGFzcykge1xuICBpZiAodHlwZW9mIHN1cGVyQ2xhc3MgIT09IFwiZnVuY3Rpb25cIiAmJiBzdXBlckNsYXNzICE9PSBudWxsKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlN1cGVyIGV4cHJlc3Npb24gbXVzdCBlaXRoZXIgYmUgbnVsbCBvciBhIGZ1bmN0aW9uLCBub3QgXCIgKyAodHlwZW9mIHN1cGVyQ2xhc3MgPT09IFwidW5kZWZpbmVkXCIgPyBcInVuZGVmaW5lZFwiIDogKDAsIF90eXBlb2YzLmRlZmF1bHQpKHN1cGVyQ2xhc3MpKSk7XG4gIH1cblxuICBzdWJDbGFzcy5wcm90b3R5cGUgPSAoMCwgX2NyZWF0ZTIuZGVmYXVsdCkoc3VwZXJDbGFzcyAmJiBzdXBlckNsYXNzLnByb3RvdHlwZSwge1xuICAgIGNvbnN0cnVjdG9yOiB7XG4gICAgICB2YWx1ZTogc3ViQ2xhc3MsXG4gICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfVxuICB9KTtcbiAgaWYgKHN1cGVyQ2xhc3MpIF9zZXRQcm90b3R5cGVPZjIuZGVmYXVsdCA/ICgwLCBfc2V0UHJvdG90eXBlT2YyLmRlZmF1bHQpKHN1YkNsYXNzLCBzdXBlckNsYXNzKSA6IHN1YkNsYXNzLl9fcHJvdG9fXyA9IHN1cGVyQ2xhc3M7XG59OyIsIlwidXNlIHN0cmljdFwiO1xuXG5leHBvcnRzLl9fZXNNb2R1bGUgPSB0cnVlO1xuXG52YXIgX3R5cGVvZjIgPSByZXF1aXJlKFwiLi4vaGVscGVycy90eXBlb2ZcIik7XG5cbnZhciBfdHlwZW9mMyA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQoX3R5cGVvZjIpO1xuXG5mdW5jdGlvbiBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KG9iaikgeyByZXR1cm4gb2JqICYmIG9iai5fX2VzTW9kdWxlID8gb2JqIDogeyBkZWZhdWx0OiBvYmogfTsgfVxuXG5leHBvcnRzLmRlZmF1bHQgPSBmdW5jdGlvbiAoc2VsZiwgY2FsbCkge1xuICBpZiAoIXNlbGYpIHtcbiAgICB0aHJvdyBuZXcgUmVmZXJlbmNlRXJyb3IoXCJ0aGlzIGhhc24ndCBiZWVuIGluaXRpYWxpc2VkIC0gc3VwZXIoKSBoYXNuJ3QgYmVlbiBjYWxsZWRcIik7XG4gIH1cblxuICByZXR1cm4gY2FsbCAmJiAoKHR5cGVvZiBjYWxsID09PSBcInVuZGVmaW5lZFwiID8gXCJ1bmRlZmluZWRcIiA6ICgwLCBfdHlwZW9mMy5kZWZhdWx0KShjYWxsKSkgPT09IFwib2JqZWN0XCIgfHwgdHlwZW9mIGNhbGwgPT09IFwiZnVuY3Rpb25cIikgPyBjYWxsIDogc2VsZjtcbn07IiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbmV4cG9ydHMuX19lc01vZHVsZSA9IHRydWU7XG5cbnZhciBfaXRlcmF0b3IgPSByZXF1aXJlKFwiLi4vY29yZS1qcy9zeW1ib2wvaXRlcmF0b3JcIik7XG5cbnZhciBfaXRlcmF0b3IyID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChfaXRlcmF0b3IpO1xuXG52YXIgX3N5bWJvbCA9IHJlcXVpcmUoXCIuLi9jb3JlLWpzL3N5bWJvbFwiKTtcblxudmFyIF9zeW1ib2wyID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChfc3ltYm9sKTtcblxudmFyIF90eXBlb2YgPSB0eXBlb2YgX3N5bWJvbDIuZGVmYXVsdCA9PT0gXCJmdW5jdGlvblwiICYmIHR5cGVvZiBfaXRlcmF0b3IyLmRlZmF1bHQgPT09IFwic3ltYm9sXCIgPyBmdW5jdGlvbiAob2JqKSB7IHJldHVybiB0eXBlb2Ygb2JqOyB9IDogZnVuY3Rpb24gKG9iaikgeyByZXR1cm4gb2JqICYmIHR5cGVvZiBfc3ltYm9sMi5kZWZhdWx0ID09PSBcImZ1bmN0aW9uXCIgJiYgb2JqLmNvbnN0cnVjdG9yID09PSBfc3ltYm9sMi5kZWZhdWx0ICYmIG9iaiAhPT0gX3N5bWJvbDIuZGVmYXVsdC5wcm90b3R5cGUgPyBcInN5bWJvbFwiIDogdHlwZW9mIG9iajsgfTtcblxuZnVuY3Rpb24gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChvYmopIHsgcmV0dXJuIG9iaiAmJiBvYmouX19lc01vZHVsZSA/IG9iaiA6IHsgZGVmYXVsdDogb2JqIH07IH1cblxuZXhwb3J0cy5kZWZhdWx0ID0gdHlwZW9mIF9zeW1ib2wyLmRlZmF1bHQgPT09IFwiZnVuY3Rpb25cIiAmJiBfdHlwZW9mKF9pdGVyYXRvcjIuZGVmYXVsdCkgPT09IFwic3ltYm9sXCIgPyBmdW5jdGlvbiAob2JqKSB7XG4gIHJldHVybiB0eXBlb2Ygb2JqID09PSBcInVuZGVmaW5lZFwiID8gXCJ1bmRlZmluZWRcIiA6IF90eXBlb2Yob2JqKTtcbn0gOiBmdW5jdGlvbiAob2JqKSB7XG4gIHJldHVybiBvYmogJiYgdHlwZW9mIF9zeW1ib2wyLmRlZmF1bHQgPT09IFwiZnVuY3Rpb25cIiAmJiBvYmouY29uc3RydWN0b3IgPT09IF9zeW1ib2wyLmRlZmF1bHQgJiYgb2JqICE9PSBfc3ltYm9sMi5kZWZhdWx0LnByb3RvdHlwZSA/IFwic3ltYm9sXCIgOiB0eXBlb2Ygb2JqID09PSBcInVuZGVmaW5lZFwiID8gXCJ1bmRlZmluZWRcIiA6IF90eXBlb2Yob2JqKTtcbn07IiwidmFyIGNvcmUgPSByZXF1aXJlKCcuLi8uLi9tb2R1bGVzL19jb3JlJyk7XG52YXIgJEpTT04gPSBjb3JlLkpTT04gfHwgKGNvcmUuSlNPTiA9IHsgc3RyaW5naWZ5OiBKU09OLnN0cmluZ2lmeSB9KTtcbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gc3RyaW5naWZ5KGl0KSB7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tdW51c2VkLXZhcnNcbiAgcmV0dXJuICRKU09OLnN0cmluZ2lmeS5hcHBseSgkSlNPTiwgYXJndW1lbnRzKTtcbn07XG4iLCJyZXF1aXJlKCcuLi8uLi9tb2R1bGVzL2VzNi5vYmplY3QuYXNzaWduJyk7XG5tb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4uLy4uL21vZHVsZXMvX2NvcmUnKS5PYmplY3QuYXNzaWduO1xuIiwicmVxdWlyZSgnLi4vLi4vbW9kdWxlcy9lczYub2JqZWN0LmNyZWF0ZScpO1xudmFyICRPYmplY3QgPSByZXF1aXJlKCcuLi8uLi9tb2R1bGVzL19jb3JlJykuT2JqZWN0O1xubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBjcmVhdGUoUCwgRCkge1xuICByZXR1cm4gJE9iamVjdC5jcmVhdGUoUCwgRCk7XG59O1xuIiwicmVxdWlyZSgnLi4vLi4vbW9kdWxlcy9lczYub2JqZWN0LmRlZmluZS1wcm9wZXJ0eScpO1xudmFyICRPYmplY3QgPSByZXF1aXJlKCcuLi8uLi9tb2R1bGVzL19jb3JlJykuT2JqZWN0O1xubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBkZWZpbmVQcm9wZXJ0eShpdCwga2V5LCBkZXNjKSB7XG4gIHJldHVybiAkT2JqZWN0LmRlZmluZVByb3BlcnR5KGl0LCBrZXksIGRlc2MpO1xufTtcbiIsInJlcXVpcmUoJy4uLy4uL21vZHVsZXMvZXM2Lm9iamVjdC5nZXQtcHJvdG90eXBlLW9mJyk7XG5tb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4uLy4uL21vZHVsZXMvX2NvcmUnKS5PYmplY3QuZ2V0UHJvdG90eXBlT2Y7XG4iLCJyZXF1aXJlKCcuLi8uLi9tb2R1bGVzL2VzNi5vYmplY3Qua2V5cycpO1xubW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCcuLi8uLi9tb2R1bGVzL19jb3JlJykuT2JqZWN0LmtleXM7XG4iLCJyZXF1aXJlKCcuLi8uLi9tb2R1bGVzL2VzNi5vYmplY3Quc2V0LXByb3RvdHlwZS1vZicpO1xubW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCcuLi8uLi9tb2R1bGVzL19jb3JlJykuT2JqZWN0LnNldFByb3RvdHlwZU9mO1xuIiwicmVxdWlyZSgnLi4vbW9kdWxlcy9lczYub2JqZWN0LnRvLXN0cmluZycpO1xucmVxdWlyZSgnLi4vbW9kdWxlcy9lczYuc3RyaW5nLml0ZXJhdG9yJyk7XG5yZXF1aXJlKCcuLi9tb2R1bGVzL3dlYi5kb20uaXRlcmFibGUnKTtcbnJlcXVpcmUoJy4uL21vZHVsZXMvZXM2LnByb21pc2UnKTtcbnJlcXVpcmUoJy4uL21vZHVsZXMvZXM3LnByb21pc2UuZmluYWxseScpO1xucmVxdWlyZSgnLi4vbW9kdWxlcy9lczcucHJvbWlzZS50cnknKTtcbm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi4vbW9kdWxlcy9fY29yZScpLlByb21pc2U7XG4iLCJyZXF1aXJlKCcuLi8uLi9tb2R1bGVzL2VzNi5zeW1ib2wnKTtcbnJlcXVpcmUoJy4uLy4uL21vZHVsZXMvZXM2Lm9iamVjdC50by1zdHJpbmcnKTtcbnJlcXVpcmUoJy4uLy4uL21vZHVsZXMvZXM3LnN5bWJvbC5hc3luYy1pdGVyYXRvcicpO1xucmVxdWlyZSgnLi4vLi4vbW9kdWxlcy9lczcuc3ltYm9sLm9ic2VydmFibGUnKTtcbm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi4vLi4vbW9kdWxlcy9fY29yZScpLlN5bWJvbDtcbiIsInJlcXVpcmUoJy4uLy4uL21vZHVsZXMvZXM2LnN0cmluZy5pdGVyYXRvcicpO1xucmVxdWlyZSgnLi4vLi4vbW9kdWxlcy93ZWIuZG9tLml0ZXJhYmxlJyk7XG5tb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4uLy4uL21vZHVsZXMvX3drcy1leHQnKS5mKCdpdGVyYXRvcicpO1xuIiwibW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoaXQpIHtcbiAgaWYgKHR5cGVvZiBpdCAhPSAnZnVuY3Rpb24nKSB0aHJvdyBUeXBlRXJyb3IoaXQgKyAnIGlzIG5vdCBhIGZ1bmN0aW9uIScpO1xuICByZXR1cm4gaXQ7XG59O1xuIiwibW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoKSB7IC8qIGVtcHR5ICovIH07XG4iLCJtb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChpdCwgQ29uc3RydWN0b3IsIG5hbWUsIGZvcmJpZGRlbkZpZWxkKSB7XG4gIGlmICghKGl0IGluc3RhbmNlb2YgQ29uc3RydWN0b3IpIHx8IChmb3JiaWRkZW5GaWVsZCAhPT0gdW5kZWZpbmVkICYmIGZvcmJpZGRlbkZpZWxkIGluIGl0KSkge1xuICAgIHRocm93IFR5cGVFcnJvcihuYW1lICsgJzogaW5jb3JyZWN0IGludm9jYXRpb24hJyk7XG4gIH0gcmV0dXJuIGl0O1xufTtcbiIsInZhciBpc09iamVjdCA9IHJlcXVpcmUoJy4vX2lzLW9iamVjdCcpO1xubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoaXQpIHtcbiAgaWYgKCFpc09iamVjdChpdCkpIHRocm93IFR5cGVFcnJvcihpdCArICcgaXMgbm90IGFuIG9iamVjdCEnKTtcbiAgcmV0dXJuIGl0O1xufTtcbiIsIi8vIGZhbHNlIC0+IEFycmF5I2luZGV4T2Zcbi8vIHRydWUgIC0+IEFycmF5I2luY2x1ZGVzXG52YXIgdG9JT2JqZWN0ID0gcmVxdWlyZSgnLi9fdG8taW9iamVjdCcpO1xudmFyIHRvTGVuZ3RoID0gcmVxdWlyZSgnLi9fdG8tbGVuZ3RoJyk7XG52YXIgdG9BYnNvbHV0ZUluZGV4ID0gcmVxdWlyZSgnLi9fdG8tYWJzb2x1dGUtaW5kZXgnKTtcbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKElTX0lOQ0xVREVTKSB7XG4gIHJldHVybiBmdW5jdGlvbiAoJHRoaXMsIGVsLCBmcm9tSW5kZXgpIHtcbiAgICB2YXIgTyA9IHRvSU9iamVjdCgkdGhpcyk7XG4gICAgdmFyIGxlbmd0aCA9IHRvTGVuZ3RoKE8ubGVuZ3RoKTtcbiAgICB2YXIgaW5kZXggPSB0b0Fic29sdXRlSW5kZXgoZnJvbUluZGV4LCBsZW5ndGgpO1xuICAgIHZhciB2YWx1ZTtcbiAgICAvLyBBcnJheSNpbmNsdWRlcyB1c2VzIFNhbWVWYWx1ZVplcm8gZXF1YWxpdHkgYWxnb3JpdGhtXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXNlbGYtY29tcGFyZVxuICAgIGlmIChJU19JTkNMVURFUyAmJiBlbCAhPSBlbCkgd2hpbGUgKGxlbmd0aCA+IGluZGV4KSB7XG4gICAgICB2YWx1ZSA9IE9baW5kZXgrK107XG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tc2VsZi1jb21wYXJlXG4gICAgICBpZiAodmFsdWUgIT0gdmFsdWUpIHJldHVybiB0cnVlO1xuICAgIC8vIEFycmF5I2luZGV4T2YgaWdub3JlcyBob2xlcywgQXJyYXkjaW5jbHVkZXMgLSBub3RcbiAgICB9IGVsc2UgZm9yICg7bGVuZ3RoID4gaW5kZXg7IGluZGV4KyspIGlmIChJU19JTkNMVURFUyB8fCBpbmRleCBpbiBPKSB7XG4gICAgICBpZiAoT1tpbmRleF0gPT09IGVsKSByZXR1cm4gSVNfSU5DTFVERVMgfHwgaW5kZXggfHwgMDtcbiAgICB9IHJldHVybiAhSVNfSU5DTFVERVMgJiYgLTE7XG4gIH07XG59O1xuIiwiLy8gZ2V0dGluZyB0YWcgZnJvbSAxOS4xLjMuNiBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nKClcbnZhciBjb2YgPSByZXF1aXJlKCcuL19jb2YnKTtcbnZhciBUQUcgPSByZXF1aXJlKCcuL193a3MnKSgndG9TdHJpbmdUYWcnKTtcbi8vIEVTMyB3cm9uZyBoZXJlXG52YXIgQVJHID0gY29mKGZ1bmN0aW9uICgpIHsgcmV0dXJuIGFyZ3VtZW50czsgfSgpKSA9PSAnQXJndW1lbnRzJztcblxuLy8gZmFsbGJhY2sgZm9yIElFMTEgU2NyaXB0IEFjY2VzcyBEZW5pZWQgZXJyb3JcbnZhciB0cnlHZXQgPSBmdW5jdGlvbiAoaXQsIGtleSkge1xuICB0cnkge1xuICAgIHJldHVybiBpdFtrZXldO1xuICB9IGNhdGNoIChlKSB7IC8qIGVtcHR5ICovIH1cbn07XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGl0KSB7XG4gIHZhciBPLCBULCBCO1xuICByZXR1cm4gaXQgPT09IHVuZGVmaW5lZCA/ICdVbmRlZmluZWQnIDogaXQgPT09IG51bGwgPyAnTnVsbCdcbiAgICAvLyBAQHRvU3RyaW5nVGFnIGNhc2VcbiAgICA6IHR5cGVvZiAoVCA9IHRyeUdldChPID0gT2JqZWN0KGl0KSwgVEFHKSkgPT0gJ3N0cmluZycgPyBUXG4gICAgLy8gYnVpbHRpblRhZyBjYXNlXG4gICAgOiBBUkcgPyBjb2YoTylcbiAgICAvLyBFUzMgYXJndW1lbnRzIGZhbGxiYWNrXG4gICAgOiAoQiA9IGNvZihPKSkgPT0gJ09iamVjdCcgJiYgdHlwZW9mIE8uY2FsbGVlID09ICdmdW5jdGlvbicgPyAnQXJndW1lbnRzJyA6IEI7XG59O1xuIiwidmFyIHRvU3RyaW5nID0ge30udG9TdHJpbmc7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGl0KSB7XG4gIHJldHVybiB0b1N0cmluZy5jYWxsKGl0KS5zbGljZSg4LCAtMSk7XG59O1xuIiwidmFyIGNvcmUgPSBtb2R1bGUuZXhwb3J0cyA9IHsgdmVyc2lvbjogJzIuNi4zJyB9O1xuaWYgKHR5cGVvZiBfX2UgPT0gJ251bWJlcicpIF9fZSA9IGNvcmU7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tdW5kZWZcbiIsIi8vIG9wdGlvbmFsIC8gc2ltcGxlIGNvbnRleHQgYmluZGluZ1xudmFyIGFGdW5jdGlvbiA9IHJlcXVpcmUoJy4vX2EtZnVuY3Rpb24nKTtcbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGZuLCB0aGF0LCBsZW5ndGgpIHtcbiAgYUZ1bmN0aW9uKGZuKTtcbiAgaWYgKHRoYXQgPT09IHVuZGVmaW5lZCkgcmV0dXJuIGZuO1xuICBzd2l0Y2ggKGxlbmd0aCkge1xuICAgIGNhc2UgMTogcmV0dXJuIGZ1bmN0aW9uIChhKSB7XG4gICAgICByZXR1cm4gZm4uY2FsbCh0aGF0LCBhKTtcbiAgICB9O1xuICAgIGNhc2UgMjogcmV0dXJuIGZ1bmN0aW9uIChhLCBiKSB7XG4gICAgICByZXR1cm4gZm4uY2FsbCh0aGF0LCBhLCBiKTtcbiAgICB9O1xuICAgIGNhc2UgMzogcmV0dXJuIGZ1bmN0aW9uIChhLCBiLCBjKSB7XG4gICAgICByZXR1cm4gZm4uY2FsbCh0aGF0LCBhLCBiLCBjKTtcbiAgICB9O1xuICB9XG4gIHJldHVybiBmdW5jdGlvbiAoLyogLi4uYXJncyAqLykge1xuICAgIHJldHVybiBmbi5hcHBseSh0aGF0LCBhcmd1bWVudHMpO1xuICB9O1xufTtcbiIsIi8vIDcuMi4xIFJlcXVpcmVPYmplY3RDb2VyY2libGUoYXJndW1lbnQpXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChpdCkge1xuICBpZiAoaXQgPT0gdW5kZWZpbmVkKSB0aHJvdyBUeXBlRXJyb3IoXCJDYW4ndCBjYWxsIG1ldGhvZCBvbiAgXCIgKyBpdCk7XG4gIHJldHVybiBpdDtcbn07XG4iLCIvLyBUaGFuaydzIElFOCBmb3IgaGlzIGZ1bm55IGRlZmluZVByb3BlcnR5XG5tb2R1bGUuZXhwb3J0cyA9ICFyZXF1aXJlKCcuL19mYWlscycpKGZ1bmN0aW9uICgpIHtcbiAgcmV0dXJuIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh7fSwgJ2EnLCB7IGdldDogZnVuY3Rpb24gKCkgeyByZXR1cm4gNzsgfSB9KS5hICE9IDc7XG59KTtcbiIsInZhciBpc09iamVjdCA9IHJlcXVpcmUoJy4vX2lzLW9iamVjdCcpO1xudmFyIGRvY3VtZW50ID0gcmVxdWlyZSgnLi9fZ2xvYmFsJykuZG9jdW1lbnQ7XG4vLyB0eXBlb2YgZG9jdW1lbnQuY3JlYXRlRWxlbWVudCBpcyAnb2JqZWN0JyBpbiBvbGQgSUVcbnZhciBpcyA9IGlzT2JqZWN0KGRvY3VtZW50KSAmJiBpc09iamVjdChkb2N1bWVudC5jcmVhdGVFbGVtZW50KTtcbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGl0KSB7XG4gIHJldHVybiBpcyA/IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoaXQpIDoge307XG59O1xuIiwiLy8gSUUgOC0gZG9uJ3QgZW51bSBidWcga2V5c1xubW9kdWxlLmV4cG9ydHMgPSAoXG4gICdjb25zdHJ1Y3RvcixoYXNPd25Qcm9wZXJ0eSxpc1Byb3RvdHlwZU9mLHByb3BlcnR5SXNFbnVtZXJhYmxlLHRvTG9jYWxlU3RyaW5nLHRvU3RyaW5nLHZhbHVlT2YnXG4pLnNwbGl0KCcsJyk7XG4iLCIvLyBhbGwgZW51bWVyYWJsZSBvYmplY3Qga2V5cywgaW5jbHVkZXMgc3ltYm9sc1xudmFyIGdldEtleXMgPSByZXF1aXJlKCcuL19vYmplY3Qta2V5cycpO1xudmFyIGdPUFMgPSByZXF1aXJlKCcuL19vYmplY3QtZ29wcycpO1xudmFyIHBJRSA9IHJlcXVpcmUoJy4vX29iamVjdC1waWUnKTtcbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGl0KSB7XG4gIHZhciByZXN1bHQgPSBnZXRLZXlzKGl0KTtcbiAgdmFyIGdldFN5bWJvbHMgPSBnT1BTLmY7XG4gIGlmIChnZXRTeW1ib2xzKSB7XG4gICAgdmFyIHN5bWJvbHMgPSBnZXRTeW1ib2xzKGl0KTtcbiAgICB2YXIgaXNFbnVtID0gcElFLmY7XG4gICAgdmFyIGkgPSAwO1xuICAgIHZhciBrZXk7XG4gICAgd2hpbGUgKHN5bWJvbHMubGVuZ3RoID4gaSkgaWYgKGlzRW51bS5jYWxsKGl0LCBrZXkgPSBzeW1ib2xzW2krK10pKSByZXN1bHQucHVzaChrZXkpO1xuICB9IHJldHVybiByZXN1bHQ7XG59O1xuIiwidmFyIGdsb2JhbCA9IHJlcXVpcmUoJy4vX2dsb2JhbCcpO1xudmFyIGNvcmUgPSByZXF1aXJlKCcuL19jb3JlJyk7XG52YXIgY3R4ID0gcmVxdWlyZSgnLi9fY3R4Jyk7XG52YXIgaGlkZSA9IHJlcXVpcmUoJy4vX2hpZGUnKTtcbnZhciBoYXMgPSByZXF1aXJlKCcuL19oYXMnKTtcbnZhciBQUk9UT1RZUEUgPSAncHJvdG90eXBlJztcblxudmFyICRleHBvcnQgPSBmdW5jdGlvbiAodHlwZSwgbmFtZSwgc291cmNlKSB7XG4gIHZhciBJU19GT1JDRUQgPSB0eXBlICYgJGV4cG9ydC5GO1xuICB2YXIgSVNfR0xPQkFMID0gdHlwZSAmICRleHBvcnQuRztcbiAgdmFyIElTX1NUQVRJQyA9IHR5cGUgJiAkZXhwb3J0LlM7XG4gIHZhciBJU19QUk9UTyA9IHR5cGUgJiAkZXhwb3J0LlA7XG4gIHZhciBJU19CSU5EID0gdHlwZSAmICRleHBvcnQuQjtcbiAgdmFyIElTX1dSQVAgPSB0eXBlICYgJGV4cG9ydC5XO1xuICB2YXIgZXhwb3J0cyA9IElTX0dMT0JBTCA/IGNvcmUgOiBjb3JlW25hbWVdIHx8IChjb3JlW25hbWVdID0ge30pO1xuICB2YXIgZXhwUHJvdG8gPSBleHBvcnRzW1BST1RPVFlQRV07XG4gIHZhciB0YXJnZXQgPSBJU19HTE9CQUwgPyBnbG9iYWwgOiBJU19TVEFUSUMgPyBnbG9iYWxbbmFtZV0gOiAoZ2xvYmFsW25hbWVdIHx8IHt9KVtQUk9UT1RZUEVdO1xuICB2YXIga2V5LCBvd24sIG91dDtcbiAgaWYgKElTX0dMT0JBTCkgc291cmNlID0gbmFtZTtcbiAgZm9yIChrZXkgaW4gc291cmNlKSB7XG4gICAgLy8gY29udGFpbnMgaW4gbmF0aXZlXG4gICAgb3duID0gIUlTX0ZPUkNFRCAmJiB0YXJnZXQgJiYgdGFyZ2V0W2tleV0gIT09IHVuZGVmaW5lZDtcbiAgICBpZiAob3duICYmIGhhcyhleHBvcnRzLCBrZXkpKSBjb250aW51ZTtcbiAgICAvLyBleHBvcnQgbmF0aXZlIG9yIHBhc3NlZFxuICAgIG91dCA9IG93biA/IHRhcmdldFtrZXldIDogc291cmNlW2tleV07XG4gICAgLy8gcHJldmVudCBnbG9iYWwgcG9sbHV0aW9uIGZvciBuYW1lc3BhY2VzXG4gICAgZXhwb3J0c1trZXldID0gSVNfR0xPQkFMICYmIHR5cGVvZiB0YXJnZXRba2V5XSAhPSAnZnVuY3Rpb24nID8gc291cmNlW2tleV1cbiAgICAvLyBiaW5kIHRpbWVycyB0byBnbG9iYWwgZm9yIGNhbGwgZnJvbSBleHBvcnQgY29udGV4dFxuICAgIDogSVNfQklORCAmJiBvd24gPyBjdHgob3V0LCBnbG9iYWwpXG4gICAgLy8gd3JhcCBnbG9iYWwgY29uc3RydWN0b3JzIGZvciBwcmV2ZW50IGNoYW5nZSB0aGVtIGluIGxpYnJhcnlcbiAgICA6IElTX1dSQVAgJiYgdGFyZ2V0W2tleV0gPT0gb3V0ID8gKGZ1bmN0aW9uIChDKSB7XG4gICAgICB2YXIgRiA9IGZ1bmN0aW9uIChhLCBiLCBjKSB7XG4gICAgICAgIGlmICh0aGlzIGluc3RhbmNlb2YgQykge1xuICAgICAgICAgIHN3aXRjaCAoYXJndW1lbnRzLmxlbmd0aCkge1xuICAgICAgICAgICAgY2FzZSAwOiByZXR1cm4gbmV3IEMoKTtcbiAgICAgICAgICAgIGNhc2UgMTogcmV0dXJuIG5ldyBDKGEpO1xuICAgICAgICAgICAgY2FzZSAyOiByZXR1cm4gbmV3IEMoYSwgYik7XG4gICAgICAgICAgfSByZXR1cm4gbmV3IEMoYSwgYiwgYyk7XG4gICAgICAgIH0gcmV0dXJuIEMuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICAgIH07XG4gICAgICBGW1BST1RPVFlQRV0gPSBDW1BST1RPVFlQRV07XG4gICAgICByZXR1cm4gRjtcbiAgICAvLyBtYWtlIHN0YXRpYyB2ZXJzaW9ucyBmb3IgcHJvdG90eXBlIG1ldGhvZHNcbiAgICB9KShvdXQpIDogSVNfUFJPVE8gJiYgdHlwZW9mIG91dCA9PSAnZnVuY3Rpb24nID8gY3R4KEZ1bmN0aW9uLmNhbGwsIG91dCkgOiBvdXQ7XG4gICAgLy8gZXhwb3J0IHByb3RvIG1ldGhvZHMgdG8gY29yZS4lQ09OU1RSVUNUT1IlLm1ldGhvZHMuJU5BTUUlXG4gICAgaWYgKElTX1BST1RPKSB7XG4gICAgICAoZXhwb3J0cy52aXJ0dWFsIHx8IChleHBvcnRzLnZpcnR1YWwgPSB7fSkpW2tleV0gPSBvdXQ7XG4gICAgICAvLyBleHBvcnQgcHJvdG8gbWV0aG9kcyB0byBjb3JlLiVDT05TVFJVQ1RPUiUucHJvdG90eXBlLiVOQU1FJVxuICAgICAgaWYgKHR5cGUgJiAkZXhwb3J0LlIgJiYgZXhwUHJvdG8gJiYgIWV4cFByb3RvW2tleV0pIGhpZGUoZXhwUHJvdG8sIGtleSwgb3V0KTtcbiAgICB9XG4gIH1cbn07XG4vLyB0eXBlIGJpdG1hcFxuJGV4cG9ydC5GID0gMTsgICAvLyBmb3JjZWRcbiRleHBvcnQuRyA9IDI7ICAgLy8gZ2xvYmFsXG4kZXhwb3J0LlMgPSA0OyAgIC8vIHN0YXRpY1xuJGV4cG9ydC5QID0gODsgICAvLyBwcm90b1xuJGV4cG9ydC5CID0gMTY7ICAvLyBiaW5kXG4kZXhwb3J0LlcgPSAzMjsgIC8vIHdyYXBcbiRleHBvcnQuVSA9IDY0OyAgLy8gc2FmZVxuJGV4cG9ydC5SID0gMTI4OyAvLyByZWFsIHByb3RvIG1ldGhvZCBmb3IgYGxpYnJhcnlgXG5tb2R1bGUuZXhwb3J0cyA9ICRleHBvcnQ7XG4iLCJtb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChleGVjKSB7XG4gIHRyeSB7XG4gICAgcmV0dXJuICEhZXhlYygpO1xuICB9IGNhdGNoIChlKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbn07XG4iLCJ2YXIgY3R4ID0gcmVxdWlyZSgnLi9fY3R4Jyk7XG52YXIgY2FsbCA9IHJlcXVpcmUoJy4vX2l0ZXItY2FsbCcpO1xudmFyIGlzQXJyYXlJdGVyID0gcmVxdWlyZSgnLi9faXMtYXJyYXktaXRlcicpO1xudmFyIGFuT2JqZWN0ID0gcmVxdWlyZSgnLi9fYW4tb2JqZWN0Jyk7XG52YXIgdG9MZW5ndGggPSByZXF1aXJlKCcuL190by1sZW5ndGgnKTtcbnZhciBnZXRJdGVyRm4gPSByZXF1aXJlKCcuL2NvcmUuZ2V0LWl0ZXJhdG9yLW1ldGhvZCcpO1xudmFyIEJSRUFLID0ge307XG52YXIgUkVUVVJOID0ge307XG52YXIgZXhwb3J0cyA9IG1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGl0ZXJhYmxlLCBlbnRyaWVzLCBmbiwgdGhhdCwgSVRFUkFUT1IpIHtcbiAgdmFyIGl0ZXJGbiA9IElURVJBVE9SID8gZnVuY3Rpb24gKCkgeyByZXR1cm4gaXRlcmFibGU7IH0gOiBnZXRJdGVyRm4oaXRlcmFibGUpO1xuICB2YXIgZiA9IGN0eChmbiwgdGhhdCwgZW50cmllcyA/IDIgOiAxKTtcbiAgdmFyIGluZGV4ID0gMDtcbiAgdmFyIGxlbmd0aCwgc3RlcCwgaXRlcmF0b3IsIHJlc3VsdDtcbiAgaWYgKHR5cGVvZiBpdGVyRm4gIT0gJ2Z1bmN0aW9uJykgdGhyb3cgVHlwZUVycm9yKGl0ZXJhYmxlICsgJyBpcyBub3QgaXRlcmFibGUhJyk7XG4gIC8vIGZhc3QgY2FzZSBmb3IgYXJyYXlzIHdpdGggZGVmYXVsdCBpdGVyYXRvclxuICBpZiAoaXNBcnJheUl0ZXIoaXRlckZuKSkgZm9yIChsZW5ndGggPSB0b0xlbmd0aChpdGVyYWJsZS5sZW5ndGgpOyBsZW5ndGggPiBpbmRleDsgaW5kZXgrKykge1xuICAgIHJlc3VsdCA9IGVudHJpZXMgPyBmKGFuT2JqZWN0KHN0ZXAgPSBpdGVyYWJsZVtpbmRleF0pWzBdLCBzdGVwWzFdKSA6IGYoaXRlcmFibGVbaW5kZXhdKTtcbiAgICBpZiAocmVzdWx0ID09PSBCUkVBSyB8fCByZXN1bHQgPT09IFJFVFVSTikgcmV0dXJuIHJlc3VsdDtcbiAgfSBlbHNlIGZvciAoaXRlcmF0b3IgPSBpdGVyRm4uY2FsbChpdGVyYWJsZSk7ICEoc3RlcCA9IGl0ZXJhdG9yLm5leHQoKSkuZG9uZTspIHtcbiAgICByZXN1bHQgPSBjYWxsKGl0ZXJhdG9yLCBmLCBzdGVwLnZhbHVlLCBlbnRyaWVzKTtcbiAgICBpZiAocmVzdWx0ID09PSBCUkVBSyB8fCByZXN1bHQgPT09IFJFVFVSTikgcmV0dXJuIHJlc3VsdDtcbiAgfVxufTtcbmV4cG9ydHMuQlJFQUsgPSBCUkVBSztcbmV4cG9ydHMuUkVUVVJOID0gUkVUVVJOO1xuIiwiLy8gaHR0cHM6Ly9naXRodWIuY29tL3psb2lyb2NrL2NvcmUtanMvaXNzdWVzLzg2I2lzc3VlY29tbWVudC0xMTU3NTkwMjhcbnZhciBnbG9iYWwgPSBtb2R1bGUuZXhwb3J0cyA9IHR5cGVvZiB3aW5kb3cgIT0gJ3VuZGVmaW5lZCcgJiYgd2luZG93Lk1hdGggPT0gTWF0aFxuICA/IHdpbmRvdyA6IHR5cGVvZiBzZWxmICE9ICd1bmRlZmluZWQnICYmIHNlbGYuTWF0aCA9PSBNYXRoID8gc2VsZlxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tbmV3LWZ1bmNcbiAgOiBGdW5jdGlvbigncmV0dXJuIHRoaXMnKSgpO1xuaWYgKHR5cGVvZiBfX2cgPT0gJ251bWJlcicpIF9fZyA9IGdsb2JhbDsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby11bmRlZlxuIiwidmFyIGhhc093blByb3BlcnR5ID0ge30uaGFzT3duUHJvcGVydHk7XG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChpdCwga2V5KSB7XG4gIHJldHVybiBoYXNPd25Qcm9wZXJ0eS5jYWxsKGl0LCBrZXkpO1xufTtcbiIsInZhciBkUCA9IHJlcXVpcmUoJy4vX29iamVjdC1kcCcpO1xudmFyIGNyZWF0ZURlc2MgPSByZXF1aXJlKCcuL19wcm9wZXJ0eS1kZXNjJyk7XG5tb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vX2Rlc2NyaXB0b3JzJykgPyBmdW5jdGlvbiAob2JqZWN0LCBrZXksIHZhbHVlKSB7XG4gIHJldHVybiBkUC5mKG9iamVjdCwga2V5LCBjcmVhdGVEZXNjKDEsIHZhbHVlKSk7XG59IDogZnVuY3Rpb24gKG9iamVjdCwga2V5LCB2YWx1ZSkge1xuICBvYmplY3Rba2V5XSA9IHZhbHVlO1xuICByZXR1cm4gb2JqZWN0O1xufTtcbiIsInZhciBkb2N1bWVudCA9IHJlcXVpcmUoJy4vX2dsb2JhbCcpLmRvY3VtZW50O1xubW9kdWxlLmV4cG9ydHMgPSBkb2N1bWVudCAmJiBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQ7XG4iLCJtb2R1bGUuZXhwb3J0cyA9ICFyZXF1aXJlKCcuL19kZXNjcmlwdG9ycycpICYmICFyZXF1aXJlKCcuL19mYWlscycpKGZ1bmN0aW9uICgpIHtcbiAgcmV0dXJuIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShyZXF1aXJlKCcuL19kb20tY3JlYXRlJykoJ2RpdicpLCAnYScsIHsgZ2V0OiBmdW5jdGlvbiAoKSB7IHJldHVybiA3OyB9IH0pLmEgIT0gNztcbn0pO1xuIiwiLy8gZmFzdCBhcHBseSwgaHR0cDovL2pzcGVyZi5sbmtpdC5jb20vZmFzdC1hcHBseS81XG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChmbiwgYXJncywgdGhhdCkge1xuICB2YXIgdW4gPSB0aGF0ID09PSB1bmRlZmluZWQ7XG4gIHN3aXRjaCAoYXJncy5sZW5ndGgpIHtcbiAgICBjYXNlIDA6IHJldHVybiB1biA/IGZuKClcbiAgICAgICAgICAgICAgICAgICAgICA6IGZuLmNhbGwodGhhdCk7XG4gICAgY2FzZSAxOiByZXR1cm4gdW4gPyBmbihhcmdzWzBdKVxuICAgICAgICAgICAgICAgICAgICAgIDogZm4uY2FsbCh0aGF0LCBhcmdzWzBdKTtcbiAgICBjYXNlIDI6IHJldHVybiB1biA/IGZuKGFyZ3NbMF0sIGFyZ3NbMV0pXG4gICAgICAgICAgICAgICAgICAgICAgOiBmbi5jYWxsKHRoYXQsIGFyZ3NbMF0sIGFyZ3NbMV0pO1xuICAgIGNhc2UgMzogcmV0dXJuIHVuID8gZm4oYXJnc1swXSwgYXJnc1sxXSwgYXJnc1syXSlcbiAgICAgICAgICAgICAgICAgICAgICA6IGZuLmNhbGwodGhhdCwgYXJnc1swXSwgYXJnc1sxXSwgYXJnc1syXSk7XG4gICAgY2FzZSA0OiByZXR1cm4gdW4gPyBmbihhcmdzWzBdLCBhcmdzWzFdLCBhcmdzWzJdLCBhcmdzWzNdKVxuICAgICAgICAgICAgICAgICAgICAgIDogZm4uY2FsbCh0aGF0LCBhcmdzWzBdLCBhcmdzWzFdLCBhcmdzWzJdLCBhcmdzWzNdKTtcbiAgfSByZXR1cm4gZm4uYXBwbHkodGhhdCwgYXJncyk7XG59O1xuIiwiLy8gZmFsbGJhY2sgZm9yIG5vbi1hcnJheS1saWtlIEVTMyBhbmQgbm9uLWVudW1lcmFibGUgb2xkIFY4IHN0cmluZ3NcbnZhciBjb2YgPSByZXF1aXJlKCcuL19jb2YnKTtcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1wcm90b3R5cGUtYnVpbHRpbnNcbm1vZHVsZS5leHBvcnRzID0gT2JqZWN0KCd6JykucHJvcGVydHlJc0VudW1lcmFibGUoMCkgPyBPYmplY3QgOiBmdW5jdGlvbiAoaXQpIHtcbiAgcmV0dXJuIGNvZihpdCkgPT0gJ1N0cmluZycgPyBpdC5zcGxpdCgnJykgOiBPYmplY3QoaXQpO1xufTtcbiIsIi8vIGNoZWNrIG9uIGRlZmF1bHQgQXJyYXkgaXRlcmF0b3JcbnZhciBJdGVyYXRvcnMgPSByZXF1aXJlKCcuL19pdGVyYXRvcnMnKTtcbnZhciBJVEVSQVRPUiA9IHJlcXVpcmUoJy4vX3drcycpKCdpdGVyYXRvcicpO1xudmFyIEFycmF5UHJvdG8gPSBBcnJheS5wcm90b3R5cGU7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGl0KSB7XG4gIHJldHVybiBpdCAhPT0gdW5kZWZpbmVkICYmIChJdGVyYXRvcnMuQXJyYXkgPT09IGl0IHx8IEFycmF5UHJvdG9bSVRFUkFUT1JdID09PSBpdCk7XG59O1xuIiwiLy8gNy4yLjIgSXNBcnJheShhcmd1bWVudClcbnZhciBjb2YgPSByZXF1aXJlKCcuL19jb2YnKTtcbm1vZHVsZS5leHBvcnRzID0gQXJyYXkuaXNBcnJheSB8fCBmdW5jdGlvbiBpc0FycmF5KGFyZykge1xuICByZXR1cm4gY29mKGFyZykgPT0gJ0FycmF5Jztcbn07XG4iLCJtb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChpdCkge1xuICByZXR1cm4gdHlwZW9mIGl0ID09PSAnb2JqZWN0JyA/IGl0ICE9PSBudWxsIDogdHlwZW9mIGl0ID09PSAnZnVuY3Rpb24nO1xufTtcbiIsIi8vIGNhbGwgc29tZXRoaW5nIG9uIGl0ZXJhdG9yIHN0ZXAgd2l0aCBzYWZlIGNsb3Npbmcgb24gZXJyb3JcbnZhciBhbk9iamVjdCA9IHJlcXVpcmUoJy4vX2FuLW9iamVjdCcpO1xubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoaXRlcmF0b3IsIGZuLCB2YWx1ZSwgZW50cmllcykge1xuICB0cnkge1xuICAgIHJldHVybiBlbnRyaWVzID8gZm4oYW5PYmplY3QodmFsdWUpWzBdLCB2YWx1ZVsxXSkgOiBmbih2YWx1ZSk7XG4gIC8vIDcuNC42IEl0ZXJhdG9yQ2xvc2UoaXRlcmF0b3IsIGNvbXBsZXRpb24pXG4gIH0gY2F0Y2ggKGUpIHtcbiAgICB2YXIgcmV0ID0gaXRlcmF0b3JbJ3JldHVybiddO1xuICAgIGlmIChyZXQgIT09IHVuZGVmaW5lZCkgYW5PYmplY3QocmV0LmNhbGwoaXRlcmF0b3IpKTtcbiAgICB0aHJvdyBlO1xuICB9XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGNyZWF0ZSA9IHJlcXVpcmUoJy4vX29iamVjdC1jcmVhdGUnKTtcbnZhciBkZXNjcmlwdG9yID0gcmVxdWlyZSgnLi9fcHJvcGVydHktZGVzYycpO1xudmFyIHNldFRvU3RyaW5nVGFnID0gcmVxdWlyZSgnLi9fc2V0LXRvLXN0cmluZy10YWcnKTtcbnZhciBJdGVyYXRvclByb3RvdHlwZSA9IHt9O1xuXG4vLyAyNS4xLjIuMS4xICVJdGVyYXRvclByb3RvdHlwZSVbQEBpdGVyYXRvcl0oKVxucmVxdWlyZSgnLi9faGlkZScpKEl0ZXJhdG9yUHJvdG90eXBlLCByZXF1aXJlKCcuL193a3MnKSgnaXRlcmF0b3InKSwgZnVuY3Rpb24gKCkgeyByZXR1cm4gdGhpczsgfSk7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKENvbnN0cnVjdG9yLCBOQU1FLCBuZXh0KSB7XG4gIENvbnN0cnVjdG9yLnByb3RvdHlwZSA9IGNyZWF0ZShJdGVyYXRvclByb3RvdHlwZSwgeyBuZXh0OiBkZXNjcmlwdG9yKDEsIG5leHQpIH0pO1xuICBzZXRUb1N0cmluZ1RhZyhDb25zdHJ1Y3RvciwgTkFNRSArICcgSXRlcmF0b3InKTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG52YXIgTElCUkFSWSA9IHJlcXVpcmUoJy4vX2xpYnJhcnknKTtcbnZhciAkZXhwb3J0ID0gcmVxdWlyZSgnLi9fZXhwb3J0Jyk7XG52YXIgcmVkZWZpbmUgPSByZXF1aXJlKCcuL19yZWRlZmluZScpO1xudmFyIGhpZGUgPSByZXF1aXJlKCcuL19oaWRlJyk7XG52YXIgSXRlcmF0b3JzID0gcmVxdWlyZSgnLi9faXRlcmF0b3JzJyk7XG52YXIgJGl0ZXJDcmVhdGUgPSByZXF1aXJlKCcuL19pdGVyLWNyZWF0ZScpO1xudmFyIHNldFRvU3RyaW5nVGFnID0gcmVxdWlyZSgnLi9fc2V0LXRvLXN0cmluZy10YWcnKTtcbnZhciBnZXRQcm90b3R5cGVPZiA9IHJlcXVpcmUoJy4vX29iamVjdC1ncG8nKTtcbnZhciBJVEVSQVRPUiA9IHJlcXVpcmUoJy4vX3drcycpKCdpdGVyYXRvcicpO1xudmFyIEJVR0dZID0gIShbXS5rZXlzICYmICduZXh0JyBpbiBbXS5rZXlzKCkpOyAvLyBTYWZhcmkgaGFzIGJ1Z2d5IGl0ZXJhdG9ycyB3L28gYG5leHRgXG52YXIgRkZfSVRFUkFUT1IgPSAnQEBpdGVyYXRvcic7XG52YXIgS0VZUyA9ICdrZXlzJztcbnZhciBWQUxVRVMgPSAndmFsdWVzJztcblxudmFyIHJldHVyblRoaXMgPSBmdW5jdGlvbiAoKSB7IHJldHVybiB0aGlzOyB9O1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChCYXNlLCBOQU1FLCBDb25zdHJ1Y3RvciwgbmV4dCwgREVGQVVMVCwgSVNfU0VULCBGT1JDRUQpIHtcbiAgJGl0ZXJDcmVhdGUoQ29uc3RydWN0b3IsIE5BTUUsIG5leHQpO1xuICB2YXIgZ2V0TWV0aG9kID0gZnVuY3Rpb24gKGtpbmQpIHtcbiAgICBpZiAoIUJVR0dZICYmIGtpbmQgaW4gcHJvdG8pIHJldHVybiBwcm90b1traW5kXTtcbiAgICBzd2l0Y2ggKGtpbmQpIHtcbiAgICAgIGNhc2UgS0VZUzogcmV0dXJuIGZ1bmN0aW9uIGtleXMoKSB7IHJldHVybiBuZXcgQ29uc3RydWN0b3IodGhpcywga2luZCk7IH07XG4gICAgICBjYXNlIFZBTFVFUzogcmV0dXJuIGZ1bmN0aW9uIHZhbHVlcygpIHsgcmV0dXJuIG5ldyBDb25zdHJ1Y3Rvcih0aGlzLCBraW5kKTsgfTtcbiAgICB9IHJldHVybiBmdW5jdGlvbiBlbnRyaWVzKCkgeyByZXR1cm4gbmV3IENvbnN0cnVjdG9yKHRoaXMsIGtpbmQpOyB9O1xuICB9O1xuICB2YXIgVEFHID0gTkFNRSArICcgSXRlcmF0b3InO1xuICB2YXIgREVGX1ZBTFVFUyA9IERFRkFVTFQgPT0gVkFMVUVTO1xuICB2YXIgVkFMVUVTX0JVRyA9IGZhbHNlO1xuICB2YXIgcHJvdG8gPSBCYXNlLnByb3RvdHlwZTtcbiAgdmFyICRuYXRpdmUgPSBwcm90b1tJVEVSQVRPUl0gfHwgcHJvdG9bRkZfSVRFUkFUT1JdIHx8IERFRkFVTFQgJiYgcHJvdG9bREVGQVVMVF07XG4gIHZhciAkZGVmYXVsdCA9ICRuYXRpdmUgfHwgZ2V0TWV0aG9kKERFRkFVTFQpO1xuICB2YXIgJGVudHJpZXMgPSBERUZBVUxUID8gIURFRl9WQUxVRVMgPyAkZGVmYXVsdCA6IGdldE1ldGhvZCgnZW50cmllcycpIDogdW5kZWZpbmVkO1xuICB2YXIgJGFueU5hdGl2ZSA9IE5BTUUgPT0gJ0FycmF5JyA/IHByb3RvLmVudHJpZXMgfHwgJG5hdGl2ZSA6ICRuYXRpdmU7XG4gIHZhciBtZXRob2RzLCBrZXksIEl0ZXJhdG9yUHJvdG90eXBlO1xuICAvLyBGaXggbmF0aXZlXG4gIGlmICgkYW55TmF0aXZlKSB7XG4gICAgSXRlcmF0b3JQcm90b3R5cGUgPSBnZXRQcm90b3R5cGVPZigkYW55TmF0aXZlLmNhbGwobmV3IEJhc2UoKSkpO1xuICAgIGlmIChJdGVyYXRvclByb3RvdHlwZSAhPT0gT2JqZWN0LnByb3RvdHlwZSAmJiBJdGVyYXRvclByb3RvdHlwZS5uZXh0KSB7XG4gICAgICAvLyBTZXQgQEB0b1N0cmluZ1RhZyB0byBuYXRpdmUgaXRlcmF0b3JzXG4gICAgICBzZXRUb1N0cmluZ1RhZyhJdGVyYXRvclByb3RvdHlwZSwgVEFHLCB0cnVlKTtcbiAgICAgIC8vIGZpeCBmb3Igc29tZSBvbGQgZW5naW5lc1xuICAgICAgaWYgKCFMSUJSQVJZICYmIHR5cGVvZiBJdGVyYXRvclByb3RvdHlwZVtJVEVSQVRPUl0gIT0gJ2Z1bmN0aW9uJykgaGlkZShJdGVyYXRvclByb3RvdHlwZSwgSVRFUkFUT1IsIHJldHVyblRoaXMpO1xuICAgIH1cbiAgfVxuICAvLyBmaXggQXJyYXkje3ZhbHVlcywgQEBpdGVyYXRvcn0ubmFtZSBpbiBWOCAvIEZGXG4gIGlmIChERUZfVkFMVUVTICYmICRuYXRpdmUgJiYgJG5hdGl2ZS5uYW1lICE9PSBWQUxVRVMpIHtcbiAgICBWQUxVRVNfQlVHID0gdHJ1ZTtcbiAgICAkZGVmYXVsdCA9IGZ1bmN0aW9uIHZhbHVlcygpIHsgcmV0dXJuICRuYXRpdmUuY2FsbCh0aGlzKTsgfTtcbiAgfVxuICAvLyBEZWZpbmUgaXRlcmF0b3JcbiAgaWYgKCghTElCUkFSWSB8fCBGT1JDRUQpICYmIChCVUdHWSB8fCBWQUxVRVNfQlVHIHx8ICFwcm90b1tJVEVSQVRPUl0pKSB7XG4gICAgaGlkZShwcm90bywgSVRFUkFUT1IsICRkZWZhdWx0KTtcbiAgfVxuICAvLyBQbHVnIGZvciBsaWJyYXJ5XG4gIEl0ZXJhdG9yc1tOQU1FXSA9ICRkZWZhdWx0O1xuICBJdGVyYXRvcnNbVEFHXSA9IHJldHVyblRoaXM7XG4gIGlmIChERUZBVUxUKSB7XG4gICAgbWV0aG9kcyA9IHtcbiAgICAgIHZhbHVlczogREVGX1ZBTFVFUyA/ICRkZWZhdWx0IDogZ2V0TWV0aG9kKFZBTFVFUyksXG4gICAgICBrZXlzOiBJU19TRVQgPyAkZGVmYXVsdCA6IGdldE1ldGhvZChLRVlTKSxcbiAgICAgIGVudHJpZXM6ICRlbnRyaWVzXG4gICAgfTtcbiAgICBpZiAoRk9SQ0VEKSBmb3IgKGtleSBpbiBtZXRob2RzKSB7XG4gICAgICBpZiAoIShrZXkgaW4gcHJvdG8pKSByZWRlZmluZShwcm90bywga2V5LCBtZXRob2RzW2tleV0pO1xuICAgIH0gZWxzZSAkZXhwb3J0KCRleHBvcnQuUCArICRleHBvcnQuRiAqIChCVUdHWSB8fCBWQUxVRVNfQlVHKSwgTkFNRSwgbWV0aG9kcyk7XG4gIH1cbiAgcmV0dXJuIG1ldGhvZHM7XG59O1xuIiwidmFyIElURVJBVE9SID0gcmVxdWlyZSgnLi9fd2tzJykoJ2l0ZXJhdG9yJyk7XG52YXIgU0FGRV9DTE9TSU5HID0gZmFsc2U7XG5cbnRyeSB7XG4gIHZhciByaXRlciA9IFs3XVtJVEVSQVRPUl0oKTtcbiAgcml0ZXJbJ3JldHVybiddID0gZnVuY3Rpb24gKCkgeyBTQUZFX0NMT1NJTkcgPSB0cnVlOyB9O1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tdGhyb3ctbGl0ZXJhbFxuICBBcnJheS5mcm9tKHJpdGVyLCBmdW5jdGlvbiAoKSB7IHRocm93IDI7IH0pO1xufSBjYXRjaCAoZSkgeyAvKiBlbXB0eSAqLyB9XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGV4ZWMsIHNraXBDbG9zaW5nKSB7XG4gIGlmICghc2tpcENsb3NpbmcgJiYgIVNBRkVfQ0xPU0lORykgcmV0dXJuIGZhbHNlO1xuICB2YXIgc2FmZSA9IGZhbHNlO1xuICB0cnkge1xuICAgIHZhciBhcnIgPSBbN107XG4gICAgdmFyIGl0ZXIgPSBhcnJbSVRFUkFUT1JdKCk7XG4gICAgaXRlci5uZXh0ID0gZnVuY3Rpb24gKCkgeyByZXR1cm4geyBkb25lOiBzYWZlID0gdHJ1ZSB9OyB9O1xuICAgIGFycltJVEVSQVRPUl0gPSBmdW5jdGlvbiAoKSB7IHJldHVybiBpdGVyOyB9O1xuICAgIGV4ZWMoYXJyKTtcbiAgfSBjYXRjaCAoZSkgeyAvKiBlbXB0eSAqLyB9XG4gIHJldHVybiBzYWZlO1xufTtcbiIsIm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGRvbmUsIHZhbHVlKSB7XG4gIHJldHVybiB7IHZhbHVlOiB2YWx1ZSwgZG9uZTogISFkb25lIH07XG59O1xuIiwibW9kdWxlLmV4cG9ydHMgPSB7fTtcbiIsIm1vZHVsZS5leHBvcnRzID0gdHJ1ZTtcbiIsInZhciBNRVRBID0gcmVxdWlyZSgnLi9fdWlkJykoJ21ldGEnKTtcbnZhciBpc09iamVjdCA9IHJlcXVpcmUoJy4vX2lzLW9iamVjdCcpO1xudmFyIGhhcyA9IHJlcXVpcmUoJy4vX2hhcycpO1xudmFyIHNldERlc2MgPSByZXF1aXJlKCcuL19vYmplY3QtZHAnKS5mO1xudmFyIGlkID0gMDtcbnZhciBpc0V4dGVuc2libGUgPSBPYmplY3QuaXNFeHRlbnNpYmxlIHx8IGZ1bmN0aW9uICgpIHtcbiAgcmV0dXJuIHRydWU7XG59O1xudmFyIEZSRUVaRSA9ICFyZXF1aXJlKCcuL19mYWlscycpKGZ1bmN0aW9uICgpIHtcbiAgcmV0dXJuIGlzRXh0ZW5zaWJsZShPYmplY3QucHJldmVudEV4dGVuc2lvbnMoe30pKTtcbn0pO1xudmFyIHNldE1ldGEgPSBmdW5jdGlvbiAoaXQpIHtcbiAgc2V0RGVzYyhpdCwgTUVUQSwgeyB2YWx1ZToge1xuICAgIGk6ICdPJyArICsraWQsIC8vIG9iamVjdCBJRFxuICAgIHc6IHt9ICAgICAgICAgIC8vIHdlYWsgY29sbGVjdGlvbnMgSURzXG4gIH0gfSk7XG59O1xudmFyIGZhc3RLZXkgPSBmdW5jdGlvbiAoaXQsIGNyZWF0ZSkge1xuICAvLyByZXR1cm4gcHJpbWl0aXZlIHdpdGggcHJlZml4XG4gIGlmICghaXNPYmplY3QoaXQpKSByZXR1cm4gdHlwZW9mIGl0ID09ICdzeW1ib2wnID8gaXQgOiAodHlwZW9mIGl0ID09ICdzdHJpbmcnID8gJ1MnIDogJ1AnKSArIGl0O1xuICBpZiAoIWhhcyhpdCwgTUVUQSkpIHtcbiAgICAvLyBjYW4ndCBzZXQgbWV0YWRhdGEgdG8gdW5jYXVnaHQgZnJvemVuIG9iamVjdFxuICAgIGlmICghaXNFeHRlbnNpYmxlKGl0KSkgcmV0dXJuICdGJztcbiAgICAvLyBub3QgbmVjZXNzYXJ5IHRvIGFkZCBtZXRhZGF0YVxuICAgIGlmICghY3JlYXRlKSByZXR1cm4gJ0UnO1xuICAgIC8vIGFkZCBtaXNzaW5nIG1ldGFkYXRhXG4gICAgc2V0TWV0YShpdCk7XG4gIC8vIHJldHVybiBvYmplY3QgSURcbiAgfSByZXR1cm4gaXRbTUVUQV0uaTtcbn07XG52YXIgZ2V0V2VhayA9IGZ1bmN0aW9uIChpdCwgY3JlYXRlKSB7XG4gIGlmICghaGFzKGl0LCBNRVRBKSkge1xuICAgIC8vIGNhbid0IHNldCBtZXRhZGF0YSB0byB1bmNhdWdodCBmcm96ZW4gb2JqZWN0XG4gICAgaWYgKCFpc0V4dGVuc2libGUoaXQpKSByZXR1cm4gdHJ1ZTtcbiAgICAvLyBub3QgbmVjZXNzYXJ5IHRvIGFkZCBtZXRhZGF0YVxuICAgIGlmICghY3JlYXRlKSByZXR1cm4gZmFsc2U7XG4gICAgLy8gYWRkIG1pc3NpbmcgbWV0YWRhdGFcbiAgICBzZXRNZXRhKGl0KTtcbiAgLy8gcmV0dXJuIGhhc2ggd2VhayBjb2xsZWN0aW9ucyBJRHNcbiAgfSByZXR1cm4gaXRbTUVUQV0udztcbn07XG4vLyBhZGQgbWV0YWRhdGEgb24gZnJlZXplLWZhbWlseSBtZXRob2RzIGNhbGxpbmdcbnZhciBvbkZyZWV6ZSA9IGZ1bmN0aW9uIChpdCkge1xuICBpZiAoRlJFRVpFICYmIG1ldGEuTkVFRCAmJiBpc0V4dGVuc2libGUoaXQpICYmICFoYXMoaXQsIE1FVEEpKSBzZXRNZXRhKGl0KTtcbiAgcmV0dXJuIGl0O1xufTtcbnZhciBtZXRhID0gbW9kdWxlLmV4cG9ydHMgPSB7XG4gIEtFWTogTUVUQSxcbiAgTkVFRDogZmFsc2UsXG4gIGZhc3RLZXk6IGZhc3RLZXksXG4gIGdldFdlYWs6IGdldFdlYWssXG4gIG9uRnJlZXplOiBvbkZyZWV6ZVxufTtcbiIsInZhciBnbG9iYWwgPSByZXF1aXJlKCcuL19nbG9iYWwnKTtcbnZhciBtYWNyb3Rhc2sgPSByZXF1aXJlKCcuL190YXNrJykuc2V0O1xudmFyIE9ic2VydmVyID0gZ2xvYmFsLk11dGF0aW9uT2JzZXJ2ZXIgfHwgZ2xvYmFsLldlYktpdE11dGF0aW9uT2JzZXJ2ZXI7XG52YXIgcHJvY2VzcyA9IGdsb2JhbC5wcm9jZXNzO1xudmFyIFByb21pc2UgPSBnbG9iYWwuUHJvbWlzZTtcbnZhciBpc05vZGUgPSByZXF1aXJlKCcuL19jb2YnKShwcm9jZXNzKSA9PSAncHJvY2Vzcyc7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKCkge1xuICB2YXIgaGVhZCwgbGFzdCwgbm90aWZ5O1xuXG4gIHZhciBmbHVzaCA9IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgcGFyZW50LCBmbjtcbiAgICBpZiAoaXNOb2RlICYmIChwYXJlbnQgPSBwcm9jZXNzLmRvbWFpbikpIHBhcmVudC5leGl0KCk7XG4gICAgd2hpbGUgKGhlYWQpIHtcbiAgICAgIGZuID0gaGVhZC5mbjtcbiAgICAgIGhlYWQgPSBoZWFkLm5leHQ7XG4gICAgICB0cnkge1xuICAgICAgICBmbigpO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBpZiAoaGVhZCkgbm90aWZ5KCk7XG4gICAgICAgIGVsc2UgbGFzdCA9IHVuZGVmaW5lZDtcbiAgICAgICAgdGhyb3cgZTtcbiAgICAgIH1cbiAgICB9IGxhc3QgPSB1bmRlZmluZWQ7XG4gICAgaWYgKHBhcmVudCkgcGFyZW50LmVudGVyKCk7XG4gIH07XG5cbiAgLy8gTm9kZS5qc1xuICBpZiAoaXNOb2RlKSB7XG4gICAgbm90aWZ5ID0gZnVuY3Rpb24gKCkge1xuICAgICAgcHJvY2Vzcy5uZXh0VGljayhmbHVzaCk7XG4gICAgfTtcbiAgLy8gYnJvd3NlcnMgd2l0aCBNdXRhdGlvbk9ic2VydmVyLCBleGNlcHQgaU9TIFNhZmFyaSAtIGh0dHBzOi8vZ2l0aHViLmNvbS96bG9pcm9jay9jb3JlLWpzL2lzc3Vlcy8zMzlcbiAgfSBlbHNlIGlmIChPYnNlcnZlciAmJiAhKGdsb2JhbC5uYXZpZ2F0b3IgJiYgZ2xvYmFsLm5hdmlnYXRvci5zdGFuZGFsb25lKSkge1xuICAgIHZhciB0b2dnbGUgPSB0cnVlO1xuICAgIHZhciBub2RlID0gZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUoJycpO1xuICAgIG5ldyBPYnNlcnZlcihmbHVzaCkub2JzZXJ2ZShub2RlLCB7IGNoYXJhY3RlckRhdGE6IHRydWUgfSk7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tbmV3XG4gICAgbm90aWZ5ID0gZnVuY3Rpb24gKCkge1xuICAgICAgbm9kZS5kYXRhID0gdG9nZ2xlID0gIXRvZ2dsZTtcbiAgICB9O1xuICAvLyBlbnZpcm9ubWVudHMgd2l0aCBtYXliZSBub24tY29tcGxldGVseSBjb3JyZWN0LCBidXQgZXhpc3RlbnQgUHJvbWlzZVxuICB9IGVsc2UgaWYgKFByb21pc2UgJiYgUHJvbWlzZS5yZXNvbHZlKSB7XG4gICAgLy8gUHJvbWlzZS5yZXNvbHZlIHdpdGhvdXQgYW4gYXJndW1lbnQgdGhyb3dzIGFuIGVycm9yIGluIExHIFdlYk9TIDJcbiAgICB2YXIgcHJvbWlzZSA9IFByb21pc2UucmVzb2x2ZSh1bmRlZmluZWQpO1xuICAgIG5vdGlmeSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgIHByb21pc2UudGhlbihmbHVzaCk7XG4gICAgfTtcbiAgLy8gZm9yIG90aGVyIGVudmlyb25tZW50cyAtIG1hY3JvdGFzayBiYXNlZCBvbjpcbiAgLy8gLSBzZXRJbW1lZGlhdGVcbiAgLy8gLSBNZXNzYWdlQ2hhbm5lbFxuICAvLyAtIHdpbmRvdy5wb3N0TWVzc2FnXG4gIC8vIC0gb25yZWFkeXN0YXRlY2hhbmdlXG4gIC8vIC0gc2V0VGltZW91dFxuICB9IGVsc2Uge1xuICAgIG5vdGlmeSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgIC8vIHN0cmFuZ2UgSUUgKyB3ZWJwYWNrIGRldiBzZXJ2ZXIgYnVnIC0gdXNlIC5jYWxsKGdsb2JhbClcbiAgICAgIG1hY3JvdGFzay5jYWxsKGdsb2JhbCwgZmx1c2gpO1xuICAgIH07XG4gIH1cblxuICByZXR1cm4gZnVuY3Rpb24gKGZuKSB7XG4gICAgdmFyIHRhc2sgPSB7IGZuOiBmbiwgbmV4dDogdW5kZWZpbmVkIH07XG4gICAgaWYgKGxhc3QpIGxhc3QubmV4dCA9IHRhc2s7XG4gICAgaWYgKCFoZWFkKSB7XG4gICAgICBoZWFkID0gdGFzaztcbiAgICAgIG5vdGlmeSgpO1xuICAgIH0gbGFzdCA9IHRhc2s7XG4gIH07XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xuLy8gMjUuNC4xLjUgTmV3UHJvbWlzZUNhcGFiaWxpdHkoQylcbnZhciBhRnVuY3Rpb24gPSByZXF1aXJlKCcuL19hLWZ1bmN0aW9uJyk7XG5cbmZ1bmN0aW9uIFByb21pc2VDYXBhYmlsaXR5KEMpIHtcbiAgdmFyIHJlc29sdmUsIHJlamVjdDtcbiAgdGhpcy5wcm9taXNlID0gbmV3IEMoZnVuY3Rpb24gKCQkcmVzb2x2ZSwgJCRyZWplY3QpIHtcbiAgICBpZiAocmVzb2x2ZSAhPT0gdW5kZWZpbmVkIHx8IHJlamVjdCAhPT0gdW5kZWZpbmVkKSB0aHJvdyBUeXBlRXJyb3IoJ0JhZCBQcm9taXNlIGNvbnN0cnVjdG9yJyk7XG4gICAgcmVzb2x2ZSA9ICQkcmVzb2x2ZTtcbiAgICByZWplY3QgPSAkJHJlamVjdDtcbiAgfSk7XG4gIHRoaXMucmVzb2x2ZSA9IGFGdW5jdGlvbihyZXNvbHZlKTtcbiAgdGhpcy5yZWplY3QgPSBhRnVuY3Rpb24ocmVqZWN0KTtcbn1cblxubW9kdWxlLmV4cG9ydHMuZiA9IGZ1bmN0aW9uIChDKSB7XG4gIHJldHVybiBuZXcgUHJvbWlzZUNhcGFiaWxpdHkoQyk7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xuLy8gMTkuMS4yLjEgT2JqZWN0LmFzc2lnbih0YXJnZXQsIHNvdXJjZSwgLi4uKVxudmFyIGdldEtleXMgPSByZXF1aXJlKCcuL19vYmplY3Qta2V5cycpO1xudmFyIGdPUFMgPSByZXF1aXJlKCcuL19vYmplY3QtZ29wcycpO1xudmFyIHBJRSA9IHJlcXVpcmUoJy4vX29iamVjdC1waWUnKTtcbnZhciB0b09iamVjdCA9IHJlcXVpcmUoJy4vX3RvLW9iamVjdCcpO1xudmFyIElPYmplY3QgPSByZXF1aXJlKCcuL19pb2JqZWN0Jyk7XG52YXIgJGFzc2lnbiA9IE9iamVjdC5hc3NpZ247XG5cbi8vIHNob3VsZCB3b3JrIHdpdGggc3ltYm9scyBhbmQgc2hvdWxkIGhhdmUgZGV0ZXJtaW5pc3RpYyBwcm9wZXJ0eSBvcmRlciAoVjggYnVnKVxubW9kdWxlLmV4cG9ydHMgPSAhJGFzc2lnbiB8fCByZXF1aXJlKCcuL19mYWlscycpKGZ1bmN0aW9uICgpIHtcbiAgdmFyIEEgPSB7fTtcbiAgdmFyIEIgPSB7fTtcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVuZGVmXG4gIHZhciBTID0gU3ltYm9sKCk7XG4gIHZhciBLID0gJ2FiY2RlZmdoaWprbG1ub3BxcnN0JztcbiAgQVtTXSA9IDc7XG4gIEsuc3BsaXQoJycpLmZvckVhY2goZnVuY3Rpb24gKGspIHsgQltrXSA9IGs7IH0pO1xuICByZXR1cm4gJGFzc2lnbih7fSwgQSlbU10gIT0gNyB8fCBPYmplY3Qua2V5cygkYXNzaWduKHt9LCBCKSkuam9pbignJykgIT0gSztcbn0pID8gZnVuY3Rpb24gYXNzaWduKHRhcmdldCwgc291cmNlKSB7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tdW51c2VkLXZhcnNcbiAgdmFyIFQgPSB0b09iamVjdCh0YXJnZXQpO1xuICB2YXIgYUxlbiA9IGFyZ3VtZW50cy5sZW5ndGg7XG4gIHZhciBpbmRleCA9IDE7XG4gIHZhciBnZXRTeW1ib2xzID0gZ09QUy5mO1xuICB2YXIgaXNFbnVtID0gcElFLmY7XG4gIHdoaWxlIChhTGVuID4gaW5kZXgpIHtcbiAgICB2YXIgUyA9IElPYmplY3QoYXJndW1lbnRzW2luZGV4KytdKTtcbiAgICB2YXIga2V5cyA9IGdldFN5bWJvbHMgPyBnZXRLZXlzKFMpLmNvbmNhdChnZXRTeW1ib2xzKFMpKSA6IGdldEtleXMoUyk7XG4gICAgdmFyIGxlbmd0aCA9IGtleXMubGVuZ3RoO1xuICAgIHZhciBqID0gMDtcbiAgICB2YXIga2V5O1xuICAgIHdoaWxlIChsZW5ndGggPiBqKSBpZiAoaXNFbnVtLmNhbGwoUywga2V5ID0ga2V5c1tqKytdKSkgVFtrZXldID0gU1trZXldO1xuICB9IHJldHVybiBUO1xufSA6ICRhc3NpZ247XG4iLCIvLyAxOS4xLjIuMiAvIDE1LjIuMy41IE9iamVjdC5jcmVhdGUoTyBbLCBQcm9wZXJ0aWVzXSlcbnZhciBhbk9iamVjdCA9IHJlcXVpcmUoJy4vX2FuLW9iamVjdCcpO1xudmFyIGRQcyA9IHJlcXVpcmUoJy4vX29iamVjdC1kcHMnKTtcbnZhciBlbnVtQnVnS2V5cyA9IHJlcXVpcmUoJy4vX2VudW0tYnVnLWtleXMnKTtcbnZhciBJRV9QUk9UTyA9IHJlcXVpcmUoJy4vX3NoYXJlZC1rZXknKSgnSUVfUFJPVE8nKTtcbnZhciBFbXB0eSA9IGZ1bmN0aW9uICgpIHsgLyogZW1wdHkgKi8gfTtcbnZhciBQUk9UT1RZUEUgPSAncHJvdG90eXBlJztcblxuLy8gQ3JlYXRlIG9iamVjdCB3aXRoIGZha2UgYG51bGxgIHByb3RvdHlwZTogdXNlIGlmcmFtZSBPYmplY3Qgd2l0aCBjbGVhcmVkIHByb3RvdHlwZVxudmFyIGNyZWF0ZURpY3QgPSBmdW5jdGlvbiAoKSB7XG4gIC8vIFRocmFzaCwgd2FzdGUgYW5kIHNvZG9teTogSUUgR0MgYnVnXG4gIHZhciBpZnJhbWUgPSByZXF1aXJlKCcuL19kb20tY3JlYXRlJykoJ2lmcmFtZScpO1xuICB2YXIgaSA9IGVudW1CdWdLZXlzLmxlbmd0aDtcbiAgdmFyIGx0ID0gJzwnO1xuICB2YXIgZ3QgPSAnPic7XG4gIHZhciBpZnJhbWVEb2N1bWVudDtcbiAgaWZyYW1lLnN0eWxlLmRpc3BsYXkgPSAnbm9uZSc7XG4gIHJlcXVpcmUoJy4vX2h0bWwnKS5hcHBlbmRDaGlsZChpZnJhbWUpO1xuICBpZnJhbWUuc3JjID0gJ2phdmFzY3JpcHQ6JzsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby1zY3JpcHQtdXJsXG4gIC8vIGNyZWF0ZURpY3QgPSBpZnJhbWUuY29udGVudFdpbmRvdy5PYmplY3Q7XG4gIC8vIGh0bWwucmVtb3ZlQ2hpbGQoaWZyYW1lKTtcbiAgaWZyYW1lRG9jdW1lbnQgPSBpZnJhbWUuY29udGVudFdpbmRvdy5kb2N1bWVudDtcbiAgaWZyYW1lRG9jdW1lbnQub3BlbigpO1xuICBpZnJhbWVEb2N1bWVudC53cml0ZShsdCArICdzY3JpcHQnICsgZ3QgKyAnZG9jdW1lbnQuRj1PYmplY3QnICsgbHQgKyAnL3NjcmlwdCcgKyBndCk7XG4gIGlmcmFtZURvY3VtZW50LmNsb3NlKCk7XG4gIGNyZWF0ZURpY3QgPSBpZnJhbWVEb2N1bWVudC5GO1xuICB3aGlsZSAoaS0tKSBkZWxldGUgY3JlYXRlRGljdFtQUk9UT1RZUEVdW2VudW1CdWdLZXlzW2ldXTtcbiAgcmV0dXJuIGNyZWF0ZURpY3QoKTtcbn07XG5cbm1vZHVsZS5leHBvcnRzID0gT2JqZWN0LmNyZWF0ZSB8fCBmdW5jdGlvbiBjcmVhdGUoTywgUHJvcGVydGllcykge1xuICB2YXIgcmVzdWx0O1xuICBpZiAoTyAhPT0gbnVsbCkge1xuICAgIEVtcHR5W1BST1RPVFlQRV0gPSBhbk9iamVjdChPKTtcbiAgICByZXN1bHQgPSBuZXcgRW1wdHkoKTtcbiAgICBFbXB0eVtQUk9UT1RZUEVdID0gbnVsbDtcbiAgICAvLyBhZGQgXCJfX3Byb3RvX19cIiBmb3IgT2JqZWN0LmdldFByb3RvdHlwZU9mIHBvbHlmaWxsXG4gICAgcmVzdWx0W0lFX1BST1RPXSA9IE87XG4gIH0gZWxzZSByZXN1bHQgPSBjcmVhdGVEaWN0KCk7XG4gIHJldHVybiBQcm9wZXJ0aWVzID09PSB1bmRlZmluZWQgPyByZXN1bHQgOiBkUHMocmVzdWx0LCBQcm9wZXJ0aWVzKTtcbn07XG4iLCJ2YXIgYW5PYmplY3QgPSByZXF1aXJlKCcuL19hbi1vYmplY3QnKTtcbnZhciBJRThfRE9NX0RFRklORSA9IHJlcXVpcmUoJy4vX2llOC1kb20tZGVmaW5lJyk7XG52YXIgdG9QcmltaXRpdmUgPSByZXF1aXJlKCcuL190by1wcmltaXRpdmUnKTtcbnZhciBkUCA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcblxuZXhwb3J0cy5mID0gcmVxdWlyZSgnLi9fZGVzY3JpcHRvcnMnKSA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0eSA6IGZ1bmN0aW9uIGRlZmluZVByb3BlcnR5KE8sIFAsIEF0dHJpYnV0ZXMpIHtcbiAgYW5PYmplY3QoTyk7XG4gIFAgPSB0b1ByaW1pdGl2ZShQLCB0cnVlKTtcbiAgYW5PYmplY3QoQXR0cmlidXRlcyk7XG4gIGlmIChJRThfRE9NX0RFRklORSkgdHJ5IHtcbiAgICByZXR1cm4gZFAoTywgUCwgQXR0cmlidXRlcyk7XG4gIH0gY2F0Y2ggKGUpIHsgLyogZW1wdHkgKi8gfVxuICBpZiAoJ2dldCcgaW4gQXR0cmlidXRlcyB8fCAnc2V0JyBpbiBBdHRyaWJ1dGVzKSB0aHJvdyBUeXBlRXJyb3IoJ0FjY2Vzc29ycyBub3Qgc3VwcG9ydGVkIScpO1xuICBpZiAoJ3ZhbHVlJyBpbiBBdHRyaWJ1dGVzKSBPW1BdID0gQXR0cmlidXRlcy52YWx1ZTtcbiAgcmV0dXJuIE87XG59O1xuIiwidmFyIGRQID0gcmVxdWlyZSgnLi9fb2JqZWN0LWRwJyk7XG52YXIgYW5PYmplY3QgPSByZXF1aXJlKCcuL19hbi1vYmplY3QnKTtcbnZhciBnZXRLZXlzID0gcmVxdWlyZSgnLi9fb2JqZWN0LWtleXMnKTtcblxubW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCcuL19kZXNjcmlwdG9ycycpID8gT2JqZWN0LmRlZmluZVByb3BlcnRpZXMgOiBmdW5jdGlvbiBkZWZpbmVQcm9wZXJ0aWVzKE8sIFByb3BlcnRpZXMpIHtcbiAgYW5PYmplY3QoTyk7XG4gIHZhciBrZXlzID0gZ2V0S2V5cyhQcm9wZXJ0aWVzKTtcbiAgdmFyIGxlbmd0aCA9IGtleXMubGVuZ3RoO1xuICB2YXIgaSA9IDA7XG4gIHZhciBQO1xuICB3aGlsZSAobGVuZ3RoID4gaSkgZFAuZihPLCBQID0ga2V5c1tpKytdLCBQcm9wZXJ0aWVzW1BdKTtcbiAgcmV0dXJuIE87XG59O1xuIiwidmFyIHBJRSA9IHJlcXVpcmUoJy4vX29iamVjdC1waWUnKTtcbnZhciBjcmVhdGVEZXNjID0gcmVxdWlyZSgnLi9fcHJvcGVydHktZGVzYycpO1xudmFyIHRvSU9iamVjdCA9IHJlcXVpcmUoJy4vX3RvLWlvYmplY3QnKTtcbnZhciB0b1ByaW1pdGl2ZSA9IHJlcXVpcmUoJy4vX3RvLXByaW1pdGl2ZScpO1xudmFyIGhhcyA9IHJlcXVpcmUoJy4vX2hhcycpO1xudmFyIElFOF9ET01fREVGSU5FID0gcmVxdWlyZSgnLi9faWU4LWRvbS1kZWZpbmUnKTtcbnZhciBnT1BEID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcjtcblxuZXhwb3J0cy5mID0gcmVxdWlyZSgnLi9fZGVzY3JpcHRvcnMnKSA/IGdPUEQgOiBmdW5jdGlvbiBnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoTywgUCkge1xuICBPID0gdG9JT2JqZWN0KE8pO1xuICBQID0gdG9QcmltaXRpdmUoUCwgdHJ1ZSk7XG4gIGlmIChJRThfRE9NX0RFRklORSkgdHJ5IHtcbiAgICByZXR1cm4gZ09QRChPLCBQKTtcbiAgfSBjYXRjaCAoZSkgeyAvKiBlbXB0eSAqLyB9XG4gIGlmIChoYXMoTywgUCkpIHJldHVybiBjcmVhdGVEZXNjKCFwSUUuZi5jYWxsKE8sIFApLCBPW1BdKTtcbn07XG4iLCIvLyBmYWxsYmFjayBmb3IgSUUxMSBidWdneSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyB3aXRoIGlmcmFtZSBhbmQgd2luZG93XG52YXIgdG9JT2JqZWN0ID0gcmVxdWlyZSgnLi9fdG8taW9iamVjdCcpO1xudmFyIGdPUE4gPSByZXF1aXJlKCcuL19vYmplY3QtZ29wbicpLmY7XG52YXIgdG9TdHJpbmcgPSB7fS50b1N0cmluZztcblxudmFyIHdpbmRvd05hbWVzID0gdHlwZW9mIHdpbmRvdyA9PSAnb2JqZWN0JyAmJiB3aW5kb3cgJiYgT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXNcbiAgPyBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyh3aW5kb3cpIDogW107XG5cbnZhciBnZXRXaW5kb3dOYW1lcyA9IGZ1bmN0aW9uIChpdCkge1xuICB0cnkge1xuICAgIHJldHVybiBnT1BOKGl0KTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIHJldHVybiB3aW5kb3dOYW1lcy5zbGljZSgpO1xuICB9XG59O1xuXG5tb2R1bGUuZXhwb3J0cy5mID0gZnVuY3Rpb24gZ2V0T3duUHJvcGVydHlOYW1lcyhpdCkge1xuICByZXR1cm4gd2luZG93TmFtZXMgJiYgdG9TdHJpbmcuY2FsbChpdCkgPT0gJ1tvYmplY3QgV2luZG93XScgPyBnZXRXaW5kb3dOYW1lcyhpdCkgOiBnT1BOKHRvSU9iamVjdChpdCkpO1xufTtcbiIsIi8vIDE5LjEuMi43IC8gMTUuMi4zLjQgT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMoTylcbnZhciAka2V5cyA9IHJlcXVpcmUoJy4vX29iamVjdC1rZXlzLWludGVybmFsJyk7XG52YXIgaGlkZGVuS2V5cyA9IHJlcXVpcmUoJy4vX2VudW0tYnVnLWtleXMnKS5jb25jYXQoJ2xlbmd0aCcsICdwcm90b3R5cGUnKTtcblxuZXhwb3J0cy5mID0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMgfHwgZnVuY3Rpb24gZ2V0T3duUHJvcGVydHlOYW1lcyhPKSB7XG4gIHJldHVybiAka2V5cyhPLCBoaWRkZW5LZXlzKTtcbn07XG4iLCJleHBvcnRzLmYgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzO1xuIiwiLy8gMTkuMS4yLjkgLyAxNS4yLjMuMiBPYmplY3QuZ2V0UHJvdG90eXBlT2YoTylcbnZhciBoYXMgPSByZXF1aXJlKCcuL19oYXMnKTtcbnZhciB0b09iamVjdCA9IHJlcXVpcmUoJy4vX3RvLW9iamVjdCcpO1xudmFyIElFX1BST1RPID0gcmVxdWlyZSgnLi9fc2hhcmVkLWtleScpKCdJRV9QUk9UTycpO1xudmFyIE9iamVjdFByb3RvID0gT2JqZWN0LnByb3RvdHlwZTtcblxubW9kdWxlLmV4cG9ydHMgPSBPYmplY3QuZ2V0UHJvdG90eXBlT2YgfHwgZnVuY3Rpb24gKE8pIHtcbiAgTyA9IHRvT2JqZWN0KE8pO1xuICBpZiAoaGFzKE8sIElFX1BST1RPKSkgcmV0dXJuIE9bSUVfUFJPVE9dO1xuICBpZiAodHlwZW9mIE8uY29uc3RydWN0b3IgPT0gJ2Z1bmN0aW9uJyAmJiBPIGluc3RhbmNlb2YgTy5jb25zdHJ1Y3Rvcikge1xuICAgIHJldHVybiBPLmNvbnN0cnVjdG9yLnByb3RvdHlwZTtcbiAgfSByZXR1cm4gTyBpbnN0YW5jZW9mIE9iamVjdCA/IE9iamVjdFByb3RvIDogbnVsbDtcbn07XG4iLCJ2YXIgaGFzID0gcmVxdWlyZSgnLi9faGFzJyk7XG52YXIgdG9JT2JqZWN0ID0gcmVxdWlyZSgnLi9fdG8taW9iamVjdCcpO1xudmFyIGFycmF5SW5kZXhPZiA9IHJlcXVpcmUoJy4vX2FycmF5LWluY2x1ZGVzJykoZmFsc2UpO1xudmFyIElFX1BST1RPID0gcmVxdWlyZSgnLi9fc2hhcmVkLWtleScpKCdJRV9QUk9UTycpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChvYmplY3QsIG5hbWVzKSB7XG4gIHZhciBPID0gdG9JT2JqZWN0KG9iamVjdCk7XG4gIHZhciBpID0gMDtcbiAgdmFyIHJlc3VsdCA9IFtdO1xuICB2YXIga2V5O1xuICBmb3IgKGtleSBpbiBPKSBpZiAoa2V5ICE9IElFX1BST1RPKSBoYXMoTywga2V5KSAmJiByZXN1bHQucHVzaChrZXkpO1xuICAvLyBEb24ndCBlbnVtIGJ1ZyAmIGhpZGRlbiBrZXlzXG4gIHdoaWxlIChuYW1lcy5sZW5ndGggPiBpKSBpZiAoaGFzKE8sIGtleSA9IG5hbWVzW2krK10pKSB7XG4gICAgfmFycmF5SW5kZXhPZihyZXN1bHQsIGtleSkgfHwgcmVzdWx0LnB1c2goa2V5KTtcbiAgfVxuICByZXR1cm4gcmVzdWx0O1xufTtcbiIsIi8vIDE5LjEuMi4xNCAvIDE1LjIuMy4xNCBPYmplY3Qua2V5cyhPKVxudmFyICRrZXlzID0gcmVxdWlyZSgnLi9fb2JqZWN0LWtleXMtaW50ZXJuYWwnKTtcbnZhciBlbnVtQnVnS2V5cyA9IHJlcXVpcmUoJy4vX2VudW0tYnVnLWtleXMnKTtcblxubW9kdWxlLmV4cG9ydHMgPSBPYmplY3Qua2V5cyB8fCBmdW5jdGlvbiBrZXlzKE8pIHtcbiAgcmV0dXJuICRrZXlzKE8sIGVudW1CdWdLZXlzKTtcbn07XG4iLCJleHBvcnRzLmYgPSB7fS5wcm9wZXJ0eUlzRW51bWVyYWJsZTtcbiIsIi8vIG1vc3QgT2JqZWN0IG1ldGhvZHMgYnkgRVM2IHNob3VsZCBhY2NlcHQgcHJpbWl0aXZlc1xudmFyICRleHBvcnQgPSByZXF1aXJlKCcuL19leHBvcnQnKTtcbnZhciBjb3JlID0gcmVxdWlyZSgnLi9fY29yZScpO1xudmFyIGZhaWxzID0gcmVxdWlyZSgnLi9fZmFpbHMnKTtcbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKEtFWSwgZXhlYykge1xuICB2YXIgZm4gPSAoY29yZS5PYmplY3QgfHwge30pW0tFWV0gfHwgT2JqZWN0W0tFWV07XG4gIHZhciBleHAgPSB7fTtcbiAgZXhwW0tFWV0gPSBleGVjKGZuKTtcbiAgJGV4cG9ydCgkZXhwb3J0LlMgKyAkZXhwb3J0LkYgKiBmYWlscyhmdW5jdGlvbiAoKSB7IGZuKDEpOyB9KSwgJ09iamVjdCcsIGV4cCk7XG59O1xuIiwibW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoZXhlYykge1xuICB0cnkge1xuICAgIHJldHVybiB7IGU6IGZhbHNlLCB2OiBleGVjKCkgfTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIHJldHVybiB7IGU6IHRydWUsIHY6IGUgfTtcbiAgfVxufTtcbiIsInZhciBhbk9iamVjdCA9IHJlcXVpcmUoJy4vX2FuLW9iamVjdCcpO1xudmFyIGlzT2JqZWN0ID0gcmVxdWlyZSgnLi9faXMtb2JqZWN0Jyk7XG52YXIgbmV3UHJvbWlzZUNhcGFiaWxpdHkgPSByZXF1aXJlKCcuL19uZXctcHJvbWlzZS1jYXBhYmlsaXR5Jyk7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKEMsIHgpIHtcbiAgYW5PYmplY3QoQyk7XG4gIGlmIChpc09iamVjdCh4KSAmJiB4LmNvbnN0cnVjdG9yID09PSBDKSByZXR1cm4geDtcbiAgdmFyIHByb21pc2VDYXBhYmlsaXR5ID0gbmV3UHJvbWlzZUNhcGFiaWxpdHkuZihDKTtcbiAgdmFyIHJlc29sdmUgPSBwcm9taXNlQ2FwYWJpbGl0eS5yZXNvbHZlO1xuICByZXNvbHZlKHgpO1xuICByZXR1cm4gcHJvbWlzZUNhcGFiaWxpdHkucHJvbWlzZTtcbn07XG4iLCJtb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChiaXRtYXAsIHZhbHVlKSB7XG4gIHJldHVybiB7XG4gICAgZW51bWVyYWJsZTogIShiaXRtYXAgJiAxKSxcbiAgICBjb25maWd1cmFibGU6ICEoYml0bWFwICYgMiksXG4gICAgd3JpdGFibGU6ICEoYml0bWFwICYgNCksXG4gICAgdmFsdWU6IHZhbHVlXG4gIH07XG59O1xuIiwidmFyIGhpZGUgPSByZXF1aXJlKCcuL19oaWRlJyk7XG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uICh0YXJnZXQsIHNyYywgc2FmZSkge1xuICBmb3IgKHZhciBrZXkgaW4gc3JjKSB7XG4gICAgaWYgKHNhZmUgJiYgdGFyZ2V0W2tleV0pIHRhcmdldFtrZXldID0gc3JjW2tleV07XG4gICAgZWxzZSBoaWRlKHRhcmdldCwga2V5LCBzcmNba2V5XSk7XG4gIH0gcmV0dXJuIHRhcmdldDtcbn07XG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vX2hpZGUnKTtcbiIsIi8vIFdvcmtzIHdpdGggX19wcm90b19fIG9ubHkuIE9sZCB2OCBjYW4ndCB3b3JrIHdpdGggbnVsbCBwcm90byBvYmplY3RzLlxuLyogZXNsaW50LWRpc2FibGUgbm8tcHJvdG8gKi9cbnZhciBpc09iamVjdCA9IHJlcXVpcmUoJy4vX2lzLW9iamVjdCcpO1xudmFyIGFuT2JqZWN0ID0gcmVxdWlyZSgnLi9fYW4tb2JqZWN0Jyk7XG52YXIgY2hlY2sgPSBmdW5jdGlvbiAoTywgcHJvdG8pIHtcbiAgYW5PYmplY3QoTyk7XG4gIGlmICghaXNPYmplY3QocHJvdG8pICYmIHByb3RvICE9PSBudWxsKSB0aHJvdyBUeXBlRXJyb3IocHJvdG8gKyBcIjogY2FuJ3Qgc2V0IGFzIHByb3RvdHlwZSFcIik7XG59O1xubW9kdWxlLmV4cG9ydHMgPSB7XG4gIHNldDogT2JqZWN0LnNldFByb3RvdHlwZU9mIHx8ICgnX19wcm90b19fJyBpbiB7fSA/IC8vIGVzbGludC1kaXNhYmxlLWxpbmVcbiAgICBmdW5jdGlvbiAodGVzdCwgYnVnZ3ksIHNldCkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgc2V0ID0gcmVxdWlyZSgnLi9fY3R4JykoRnVuY3Rpb24uY2FsbCwgcmVxdWlyZSgnLi9fb2JqZWN0LWdvcGQnKS5mKE9iamVjdC5wcm90b3R5cGUsICdfX3Byb3RvX18nKS5zZXQsIDIpO1xuICAgICAgICBzZXQodGVzdCwgW10pO1xuICAgICAgICBidWdneSA9ICEodGVzdCBpbnN0YW5jZW9mIEFycmF5KTtcbiAgICAgIH0gY2F0Y2ggKGUpIHsgYnVnZ3kgPSB0cnVlOyB9XG4gICAgICByZXR1cm4gZnVuY3Rpb24gc2V0UHJvdG90eXBlT2YoTywgcHJvdG8pIHtcbiAgICAgICAgY2hlY2soTywgcHJvdG8pO1xuICAgICAgICBpZiAoYnVnZ3kpIE8uX19wcm90b19fID0gcHJvdG87XG4gICAgICAgIGVsc2Ugc2V0KE8sIHByb3RvKTtcbiAgICAgICAgcmV0dXJuIE87XG4gICAgICB9O1xuICAgIH0oe30sIGZhbHNlKSA6IHVuZGVmaW5lZCksXG4gIGNoZWNrOiBjaGVja1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbnZhciBnbG9iYWwgPSByZXF1aXJlKCcuL19nbG9iYWwnKTtcbnZhciBjb3JlID0gcmVxdWlyZSgnLi9fY29yZScpO1xudmFyIGRQID0gcmVxdWlyZSgnLi9fb2JqZWN0LWRwJyk7XG52YXIgREVTQ1JJUFRPUlMgPSByZXF1aXJlKCcuL19kZXNjcmlwdG9ycycpO1xudmFyIFNQRUNJRVMgPSByZXF1aXJlKCcuL193a3MnKSgnc3BlY2llcycpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChLRVkpIHtcbiAgdmFyIEMgPSB0eXBlb2YgY29yZVtLRVldID09ICdmdW5jdGlvbicgPyBjb3JlW0tFWV0gOiBnbG9iYWxbS0VZXTtcbiAgaWYgKERFU0NSSVBUT1JTICYmIEMgJiYgIUNbU1BFQ0lFU10pIGRQLmYoQywgU1BFQ0lFUywge1xuICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICBnZXQ6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH1cbiAgfSk7XG59O1xuIiwidmFyIGRlZiA9IHJlcXVpcmUoJy4vX29iamVjdC1kcCcpLmY7XG52YXIgaGFzID0gcmVxdWlyZSgnLi9faGFzJyk7XG52YXIgVEFHID0gcmVxdWlyZSgnLi9fd2tzJykoJ3RvU3RyaW5nVGFnJyk7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGl0LCB0YWcsIHN0YXQpIHtcbiAgaWYgKGl0ICYmICFoYXMoaXQgPSBzdGF0ID8gaXQgOiBpdC5wcm90b3R5cGUsIFRBRykpIGRlZihpdCwgVEFHLCB7IGNvbmZpZ3VyYWJsZTogdHJ1ZSwgdmFsdWU6IHRhZyB9KTtcbn07XG4iLCJ2YXIgc2hhcmVkID0gcmVxdWlyZSgnLi9fc2hhcmVkJykoJ2tleXMnKTtcbnZhciB1aWQgPSByZXF1aXJlKCcuL191aWQnKTtcbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGtleSkge1xuICByZXR1cm4gc2hhcmVkW2tleV0gfHwgKHNoYXJlZFtrZXldID0gdWlkKGtleSkpO1xufTtcbiIsInZhciBjb3JlID0gcmVxdWlyZSgnLi9fY29yZScpO1xudmFyIGdsb2JhbCA9IHJlcXVpcmUoJy4vX2dsb2JhbCcpO1xudmFyIFNIQVJFRCA9ICdfX2NvcmUtanNfc2hhcmVkX18nO1xudmFyIHN0b3JlID0gZ2xvYmFsW1NIQVJFRF0gfHwgKGdsb2JhbFtTSEFSRURdID0ge30pO1xuXG4obW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoa2V5LCB2YWx1ZSkge1xuICByZXR1cm4gc3RvcmVba2V5XSB8fCAoc3RvcmVba2V5XSA9IHZhbHVlICE9PSB1bmRlZmluZWQgPyB2YWx1ZSA6IHt9KTtcbn0pKCd2ZXJzaW9ucycsIFtdKS5wdXNoKHtcbiAgdmVyc2lvbjogY29yZS52ZXJzaW9uLFxuICBtb2RlOiByZXF1aXJlKCcuL19saWJyYXJ5JykgPyAncHVyZScgOiAnZ2xvYmFsJyxcbiAgY29weXJpZ2h0OiAnwqkgMjAxOSBEZW5pcyBQdXNoa2FyZXYgKHpsb2lyb2NrLnJ1KSdcbn0pO1xuIiwiLy8gNy4zLjIwIFNwZWNpZXNDb25zdHJ1Y3RvcihPLCBkZWZhdWx0Q29uc3RydWN0b3IpXG52YXIgYW5PYmplY3QgPSByZXF1aXJlKCcuL19hbi1vYmplY3QnKTtcbnZhciBhRnVuY3Rpb24gPSByZXF1aXJlKCcuL19hLWZ1bmN0aW9uJyk7XG52YXIgU1BFQ0lFUyA9IHJlcXVpcmUoJy4vX3drcycpKCdzcGVjaWVzJyk7XG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChPLCBEKSB7XG4gIHZhciBDID0gYW5PYmplY3QoTykuY29uc3RydWN0b3I7XG4gIHZhciBTO1xuICByZXR1cm4gQyA9PT0gdW5kZWZpbmVkIHx8IChTID0gYW5PYmplY3QoQylbU1BFQ0lFU10pID09IHVuZGVmaW5lZCA/IEQgOiBhRnVuY3Rpb24oUyk7XG59O1xuIiwidmFyIHRvSW50ZWdlciA9IHJlcXVpcmUoJy4vX3RvLWludGVnZXInKTtcbnZhciBkZWZpbmVkID0gcmVxdWlyZSgnLi9fZGVmaW5lZCcpO1xuLy8gdHJ1ZSAgLT4gU3RyaW5nI2F0XG4vLyBmYWxzZSAtPiBTdHJpbmcjY29kZVBvaW50QXRcbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKFRPX1NUUklORykge1xuICByZXR1cm4gZnVuY3Rpb24gKHRoYXQsIHBvcykge1xuICAgIHZhciBzID0gU3RyaW5nKGRlZmluZWQodGhhdCkpO1xuICAgIHZhciBpID0gdG9JbnRlZ2VyKHBvcyk7XG4gICAgdmFyIGwgPSBzLmxlbmd0aDtcbiAgICB2YXIgYSwgYjtcbiAgICBpZiAoaSA8IDAgfHwgaSA+PSBsKSByZXR1cm4gVE9fU1RSSU5HID8gJycgOiB1bmRlZmluZWQ7XG4gICAgYSA9IHMuY2hhckNvZGVBdChpKTtcbiAgICByZXR1cm4gYSA8IDB4ZDgwMCB8fCBhID4gMHhkYmZmIHx8IGkgKyAxID09PSBsIHx8IChiID0gcy5jaGFyQ29kZUF0KGkgKyAxKSkgPCAweGRjMDAgfHwgYiA+IDB4ZGZmZlxuICAgICAgPyBUT19TVFJJTkcgPyBzLmNoYXJBdChpKSA6IGFcbiAgICAgIDogVE9fU1RSSU5HID8gcy5zbGljZShpLCBpICsgMikgOiAoYSAtIDB4ZDgwMCA8PCAxMCkgKyAoYiAtIDB4ZGMwMCkgKyAweDEwMDAwO1xuICB9O1xufTtcbiIsInZhciBjdHggPSByZXF1aXJlKCcuL19jdHgnKTtcbnZhciBpbnZva2UgPSByZXF1aXJlKCcuL19pbnZva2UnKTtcbnZhciBodG1sID0gcmVxdWlyZSgnLi9faHRtbCcpO1xudmFyIGNlbCA9IHJlcXVpcmUoJy4vX2RvbS1jcmVhdGUnKTtcbnZhciBnbG9iYWwgPSByZXF1aXJlKCcuL19nbG9iYWwnKTtcbnZhciBwcm9jZXNzID0gZ2xvYmFsLnByb2Nlc3M7XG52YXIgc2V0VGFzayA9IGdsb2JhbC5zZXRJbW1lZGlhdGU7XG52YXIgY2xlYXJUYXNrID0gZ2xvYmFsLmNsZWFySW1tZWRpYXRlO1xudmFyIE1lc3NhZ2VDaGFubmVsID0gZ2xvYmFsLk1lc3NhZ2VDaGFubmVsO1xudmFyIERpc3BhdGNoID0gZ2xvYmFsLkRpc3BhdGNoO1xudmFyIGNvdW50ZXIgPSAwO1xudmFyIHF1ZXVlID0ge307XG52YXIgT05SRUFEWVNUQVRFQ0hBTkdFID0gJ29ucmVhZHlzdGF0ZWNoYW5nZSc7XG52YXIgZGVmZXIsIGNoYW5uZWwsIHBvcnQ7XG52YXIgcnVuID0gZnVuY3Rpb24gKCkge1xuICB2YXIgaWQgPSArdGhpcztcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXByb3RvdHlwZS1idWlsdGluc1xuICBpZiAocXVldWUuaGFzT3duUHJvcGVydHkoaWQpKSB7XG4gICAgdmFyIGZuID0gcXVldWVbaWRdO1xuICAgIGRlbGV0ZSBxdWV1ZVtpZF07XG4gICAgZm4oKTtcbiAgfVxufTtcbnZhciBsaXN0ZW5lciA9IGZ1bmN0aW9uIChldmVudCkge1xuICBydW4uY2FsbChldmVudC5kYXRhKTtcbn07XG4vLyBOb2RlLmpzIDAuOSsgJiBJRTEwKyBoYXMgc2V0SW1tZWRpYXRlLCBvdGhlcndpc2U6XG5pZiAoIXNldFRhc2sgfHwgIWNsZWFyVGFzaykge1xuICBzZXRUYXNrID0gZnVuY3Rpb24gc2V0SW1tZWRpYXRlKGZuKSB7XG4gICAgdmFyIGFyZ3MgPSBbXTtcbiAgICB2YXIgaSA9IDE7XG4gICAgd2hpbGUgKGFyZ3VtZW50cy5sZW5ndGggPiBpKSBhcmdzLnB1c2goYXJndW1lbnRzW2krK10pO1xuICAgIHF1ZXVlWysrY291bnRlcl0gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tbmV3LWZ1bmNcbiAgICAgIGludm9rZSh0eXBlb2YgZm4gPT0gJ2Z1bmN0aW9uJyA/IGZuIDogRnVuY3Rpb24oZm4pLCBhcmdzKTtcbiAgICB9O1xuICAgIGRlZmVyKGNvdW50ZXIpO1xuICAgIHJldHVybiBjb3VudGVyO1xuICB9O1xuICBjbGVhclRhc2sgPSBmdW5jdGlvbiBjbGVhckltbWVkaWF0ZShpZCkge1xuICAgIGRlbGV0ZSBxdWV1ZVtpZF07XG4gIH07XG4gIC8vIE5vZGUuanMgMC44LVxuICBpZiAocmVxdWlyZSgnLi9fY29mJykocHJvY2VzcykgPT0gJ3Byb2Nlc3MnKSB7XG4gICAgZGVmZXIgPSBmdW5jdGlvbiAoaWQpIHtcbiAgICAgIHByb2Nlc3MubmV4dFRpY2soY3R4KHJ1biwgaWQsIDEpKTtcbiAgICB9O1xuICAvLyBTcGhlcmUgKEpTIGdhbWUgZW5naW5lKSBEaXNwYXRjaCBBUElcbiAgfSBlbHNlIGlmIChEaXNwYXRjaCAmJiBEaXNwYXRjaC5ub3cpIHtcbiAgICBkZWZlciA9IGZ1bmN0aW9uIChpZCkge1xuICAgICAgRGlzcGF0Y2gubm93KGN0eChydW4sIGlkLCAxKSk7XG4gICAgfTtcbiAgLy8gQnJvd3NlcnMgd2l0aCBNZXNzYWdlQ2hhbm5lbCwgaW5jbHVkZXMgV2ViV29ya2Vyc1xuICB9IGVsc2UgaWYgKE1lc3NhZ2VDaGFubmVsKSB7XG4gICAgY2hhbm5lbCA9IG5ldyBNZXNzYWdlQ2hhbm5lbCgpO1xuICAgIHBvcnQgPSBjaGFubmVsLnBvcnQyO1xuICAgIGNoYW5uZWwucG9ydDEub25tZXNzYWdlID0gbGlzdGVuZXI7XG4gICAgZGVmZXIgPSBjdHgocG9ydC5wb3N0TWVzc2FnZSwgcG9ydCwgMSk7XG4gIC8vIEJyb3dzZXJzIHdpdGggcG9zdE1lc3NhZ2UsIHNraXAgV2ViV29ya2Vyc1xuICAvLyBJRTggaGFzIHBvc3RNZXNzYWdlLCBidXQgaXQncyBzeW5jICYgdHlwZW9mIGl0cyBwb3N0TWVzc2FnZSBpcyAnb2JqZWN0J1xuICB9IGVsc2UgaWYgKGdsb2JhbC5hZGRFdmVudExpc3RlbmVyICYmIHR5cGVvZiBwb3N0TWVzc2FnZSA9PSAnZnVuY3Rpb24nICYmICFnbG9iYWwuaW1wb3J0U2NyaXB0cykge1xuICAgIGRlZmVyID0gZnVuY3Rpb24gKGlkKSB7XG4gICAgICBnbG9iYWwucG9zdE1lc3NhZ2UoaWQgKyAnJywgJyonKTtcbiAgICB9O1xuICAgIGdsb2JhbC5hZGRFdmVudExpc3RlbmVyKCdtZXNzYWdlJywgbGlzdGVuZXIsIGZhbHNlKTtcbiAgLy8gSUU4LVxuICB9IGVsc2UgaWYgKE9OUkVBRFlTVEFURUNIQU5HRSBpbiBjZWwoJ3NjcmlwdCcpKSB7XG4gICAgZGVmZXIgPSBmdW5jdGlvbiAoaWQpIHtcbiAgICAgIGh0bWwuYXBwZW5kQ2hpbGQoY2VsKCdzY3JpcHQnKSlbT05SRUFEWVNUQVRFQ0hBTkdFXSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgaHRtbC5yZW1vdmVDaGlsZCh0aGlzKTtcbiAgICAgICAgcnVuLmNhbGwoaWQpO1xuICAgICAgfTtcbiAgICB9O1xuICAvLyBSZXN0IG9sZCBicm93c2Vyc1xuICB9IGVsc2Uge1xuICAgIGRlZmVyID0gZnVuY3Rpb24gKGlkKSB7XG4gICAgICBzZXRUaW1lb3V0KGN0eChydW4sIGlkLCAxKSwgMCk7XG4gICAgfTtcbiAgfVxufVxubW9kdWxlLmV4cG9ydHMgPSB7XG4gIHNldDogc2V0VGFzayxcbiAgY2xlYXI6IGNsZWFyVGFza1xufTtcbiIsInZhciB0b0ludGVnZXIgPSByZXF1aXJlKCcuL190by1pbnRlZ2VyJyk7XG52YXIgbWF4ID0gTWF0aC5tYXg7XG52YXIgbWluID0gTWF0aC5taW47XG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChpbmRleCwgbGVuZ3RoKSB7XG4gIGluZGV4ID0gdG9JbnRlZ2VyKGluZGV4KTtcbiAgcmV0dXJuIGluZGV4IDwgMCA/IG1heChpbmRleCArIGxlbmd0aCwgMCkgOiBtaW4oaW5kZXgsIGxlbmd0aCk7XG59O1xuIiwiLy8gNy4xLjQgVG9JbnRlZ2VyXG52YXIgY2VpbCA9IE1hdGguY2VpbDtcbnZhciBmbG9vciA9IE1hdGguZmxvb3I7XG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChpdCkge1xuICByZXR1cm4gaXNOYU4oaXQgPSAraXQpID8gMCA6IChpdCA+IDAgPyBmbG9vciA6IGNlaWwpKGl0KTtcbn07XG4iLCIvLyB0byBpbmRleGVkIG9iamVjdCwgdG9PYmplY3Qgd2l0aCBmYWxsYmFjayBmb3Igbm9uLWFycmF5LWxpa2UgRVMzIHN0cmluZ3NcbnZhciBJT2JqZWN0ID0gcmVxdWlyZSgnLi9faW9iamVjdCcpO1xudmFyIGRlZmluZWQgPSByZXF1aXJlKCcuL19kZWZpbmVkJyk7XG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChpdCkge1xuICByZXR1cm4gSU9iamVjdChkZWZpbmVkKGl0KSk7XG59O1xuIiwiLy8gNy4xLjE1IFRvTGVuZ3RoXG52YXIgdG9JbnRlZ2VyID0gcmVxdWlyZSgnLi9fdG8taW50ZWdlcicpO1xudmFyIG1pbiA9IE1hdGgubWluO1xubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoaXQpIHtcbiAgcmV0dXJuIGl0ID4gMCA/IG1pbih0b0ludGVnZXIoaXQpLCAweDFmZmZmZmZmZmZmZmZmKSA6IDA7IC8vIHBvdygyLCA1MykgLSAxID09IDkwMDcxOTkyNTQ3NDA5OTFcbn07XG4iLCIvLyA3LjEuMTMgVG9PYmplY3QoYXJndW1lbnQpXG52YXIgZGVmaW5lZCA9IHJlcXVpcmUoJy4vX2RlZmluZWQnKTtcbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGl0KSB7XG4gIHJldHVybiBPYmplY3QoZGVmaW5lZChpdCkpO1xufTtcbiIsIi8vIDcuMS4xIFRvUHJpbWl0aXZlKGlucHV0IFssIFByZWZlcnJlZFR5cGVdKVxudmFyIGlzT2JqZWN0ID0gcmVxdWlyZSgnLi9faXMtb2JqZWN0Jyk7XG4vLyBpbnN0ZWFkIG9mIHRoZSBFUzYgc3BlYyB2ZXJzaW9uLCB3ZSBkaWRuJ3QgaW1wbGVtZW50IEBAdG9QcmltaXRpdmUgY2FzZVxuLy8gYW5kIHRoZSBzZWNvbmQgYXJndW1lbnQgLSBmbGFnIC0gcHJlZmVycmVkIHR5cGUgaXMgYSBzdHJpbmdcbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGl0LCBTKSB7XG4gIGlmICghaXNPYmplY3QoaXQpKSByZXR1cm4gaXQ7XG4gIHZhciBmbiwgdmFsO1xuICBpZiAoUyAmJiB0eXBlb2YgKGZuID0gaXQudG9TdHJpbmcpID09ICdmdW5jdGlvbicgJiYgIWlzT2JqZWN0KHZhbCA9IGZuLmNhbGwoaXQpKSkgcmV0dXJuIHZhbDtcbiAgaWYgKHR5cGVvZiAoZm4gPSBpdC52YWx1ZU9mKSA9PSAnZnVuY3Rpb24nICYmICFpc09iamVjdCh2YWwgPSBmbi5jYWxsKGl0KSkpIHJldHVybiB2YWw7XG4gIGlmICghUyAmJiB0eXBlb2YgKGZuID0gaXQudG9TdHJpbmcpID09ICdmdW5jdGlvbicgJiYgIWlzT2JqZWN0KHZhbCA9IGZuLmNhbGwoaXQpKSkgcmV0dXJuIHZhbDtcbiAgdGhyb3cgVHlwZUVycm9yKFwiQ2FuJ3QgY29udmVydCBvYmplY3QgdG8gcHJpbWl0aXZlIHZhbHVlXCIpO1xufTtcbiIsInZhciBpZCA9IDA7XG52YXIgcHggPSBNYXRoLnJhbmRvbSgpO1xubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoa2V5KSB7XG4gIHJldHVybiAnU3ltYm9sKCcuY29uY2F0KGtleSA9PT0gdW5kZWZpbmVkID8gJycgOiBrZXksICcpXycsICgrK2lkICsgcHgpLnRvU3RyaW5nKDM2KSk7XG59O1xuIiwidmFyIGdsb2JhbCA9IHJlcXVpcmUoJy4vX2dsb2JhbCcpO1xudmFyIG5hdmlnYXRvciA9IGdsb2JhbC5uYXZpZ2F0b3I7XG5cbm1vZHVsZS5leHBvcnRzID0gbmF2aWdhdG9yICYmIG5hdmlnYXRvci51c2VyQWdlbnQgfHwgJyc7XG4iLCJ2YXIgZ2xvYmFsID0gcmVxdWlyZSgnLi9fZ2xvYmFsJyk7XG52YXIgY29yZSA9IHJlcXVpcmUoJy4vX2NvcmUnKTtcbnZhciBMSUJSQVJZID0gcmVxdWlyZSgnLi9fbGlicmFyeScpO1xudmFyIHdrc0V4dCA9IHJlcXVpcmUoJy4vX3drcy1leHQnKTtcbnZhciBkZWZpbmVQcm9wZXJ0eSA9IHJlcXVpcmUoJy4vX29iamVjdC1kcCcpLmY7XG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChuYW1lKSB7XG4gIHZhciAkU3ltYm9sID0gY29yZS5TeW1ib2wgfHwgKGNvcmUuU3ltYm9sID0gTElCUkFSWSA/IHt9IDogZ2xvYmFsLlN5bWJvbCB8fCB7fSk7XG4gIGlmIChuYW1lLmNoYXJBdCgwKSAhPSAnXycgJiYgIShuYW1lIGluICRTeW1ib2wpKSBkZWZpbmVQcm9wZXJ0eSgkU3ltYm9sLCBuYW1lLCB7IHZhbHVlOiB3a3NFeHQuZihuYW1lKSB9KTtcbn07XG4iLCJleHBvcnRzLmYgPSByZXF1aXJlKCcuL193a3MnKTtcbiIsInZhciBzdG9yZSA9IHJlcXVpcmUoJy4vX3NoYXJlZCcpKCd3a3MnKTtcbnZhciB1aWQgPSByZXF1aXJlKCcuL191aWQnKTtcbnZhciBTeW1ib2wgPSByZXF1aXJlKCcuL19nbG9iYWwnKS5TeW1ib2w7XG52YXIgVVNFX1NZTUJPTCA9IHR5cGVvZiBTeW1ib2wgPT0gJ2Z1bmN0aW9uJztcblxudmFyICRleHBvcnRzID0gbW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAobmFtZSkge1xuICByZXR1cm4gc3RvcmVbbmFtZV0gfHwgKHN0b3JlW25hbWVdID1cbiAgICBVU0VfU1lNQk9MICYmIFN5bWJvbFtuYW1lXSB8fCAoVVNFX1NZTUJPTCA/IFN5bWJvbCA6IHVpZCkoJ1N5bWJvbC4nICsgbmFtZSkpO1xufTtcblxuJGV4cG9ydHMuc3RvcmUgPSBzdG9yZTtcbiIsInZhciBjbGFzc29mID0gcmVxdWlyZSgnLi9fY2xhc3NvZicpO1xudmFyIElURVJBVE9SID0gcmVxdWlyZSgnLi9fd2tzJykoJ2l0ZXJhdG9yJyk7XG52YXIgSXRlcmF0b3JzID0gcmVxdWlyZSgnLi9faXRlcmF0b3JzJyk7XG5tb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vX2NvcmUnKS5nZXRJdGVyYXRvck1ldGhvZCA9IGZ1bmN0aW9uIChpdCkge1xuICBpZiAoaXQgIT0gdW5kZWZpbmVkKSByZXR1cm4gaXRbSVRFUkFUT1JdXG4gICAgfHwgaXRbJ0BAaXRlcmF0b3InXVxuICAgIHx8IEl0ZXJhdG9yc1tjbGFzc29mKGl0KV07XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIGFkZFRvVW5zY29wYWJsZXMgPSByZXF1aXJlKCcuL19hZGQtdG8tdW5zY29wYWJsZXMnKTtcbnZhciBzdGVwID0gcmVxdWlyZSgnLi9faXRlci1zdGVwJyk7XG52YXIgSXRlcmF0b3JzID0gcmVxdWlyZSgnLi9faXRlcmF0b3JzJyk7XG52YXIgdG9JT2JqZWN0ID0gcmVxdWlyZSgnLi9fdG8taW9iamVjdCcpO1xuXG4vLyAyMi4xLjMuNCBBcnJheS5wcm90b3R5cGUuZW50cmllcygpXG4vLyAyMi4xLjMuMTMgQXJyYXkucHJvdG90eXBlLmtleXMoKVxuLy8gMjIuMS4zLjI5IEFycmF5LnByb3RvdHlwZS52YWx1ZXMoKVxuLy8gMjIuMS4zLjMwIEFycmF5LnByb3RvdHlwZVtAQGl0ZXJhdG9yXSgpXG5tb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vX2l0ZXItZGVmaW5lJykoQXJyYXksICdBcnJheScsIGZ1bmN0aW9uIChpdGVyYXRlZCwga2luZCkge1xuICB0aGlzLl90ID0gdG9JT2JqZWN0KGl0ZXJhdGVkKTsgLy8gdGFyZ2V0XG4gIHRoaXMuX2kgPSAwOyAgICAgICAgICAgICAgICAgICAvLyBuZXh0IGluZGV4XG4gIHRoaXMuX2sgPSBraW5kOyAgICAgICAgICAgICAgICAvLyBraW5kXG4vLyAyMi4xLjUuMi4xICVBcnJheUl0ZXJhdG9yUHJvdG90eXBlJS5uZXh0KClcbn0sIGZ1bmN0aW9uICgpIHtcbiAgdmFyIE8gPSB0aGlzLl90O1xuICB2YXIga2luZCA9IHRoaXMuX2s7XG4gIHZhciBpbmRleCA9IHRoaXMuX2krKztcbiAgaWYgKCFPIHx8IGluZGV4ID49IE8ubGVuZ3RoKSB7XG4gICAgdGhpcy5fdCA9IHVuZGVmaW5lZDtcbiAgICByZXR1cm4gc3RlcCgxKTtcbiAgfVxuICBpZiAoa2luZCA9PSAna2V5cycpIHJldHVybiBzdGVwKDAsIGluZGV4KTtcbiAgaWYgKGtpbmQgPT0gJ3ZhbHVlcycpIHJldHVybiBzdGVwKDAsIE9baW5kZXhdKTtcbiAgcmV0dXJuIHN0ZXAoMCwgW2luZGV4LCBPW2luZGV4XV0pO1xufSwgJ3ZhbHVlcycpO1xuXG4vLyBhcmd1bWVudHNMaXN0W0BAaXRlcmF0b3JdIGlzICVBcnJheVByb3RvX3ZhbHVlcyUgKDkuNC40LjYsIDkuNC40LjcpXG5JdGVyYXRvcnMuQXJndW1lbnRzID0gSXRlcmF0b3JzLkFycmF5O1xuXG5hZGRUb1Vuc2NvcGFibGVzKCdrZXlzJyk7XG5hZGRUb1Vuc2NvcGFibGVzKCd2YWx1ZXMnKTtcbmFkZFRvVW5zY29wYWJsZXMoJ2VudHJpZXMnKTtcbiIsIi8vIDE5LjEuMy4xIE9iamVjdC5hc3NpZ24odGFyZ2V0LCBzb3VyY2UpXG52YXIgJGV4cG9ydCA9IHJlcXVpcmUoJy4vX2V4cG9ydCcpO1xuXG4kZXhwb3J0KCRleHBvcnQuUyArICRleHBvcnQuRiwgJ09iamVjdCcsIHsgYXNzaWduOiByZXF1aXJlKCcuL19vYmplY3QtYXNzaWduJykgfSk7XG4iLCJ2YXIgJGV4cG9ydCA9IHJlcXVpcmUoJy4vX2V4cG9ydCcpO1xuLy8gMTkuMS4yLjIgLyAxNS4yLjMuNSBPYmplY3QuY3JlYXRlKE8gWywgUHJvcGVydGllc10pXG4kZXhwb3J0KCRleHBvcnQuUywgJ09iamVjdCcsIHsgY3JlYXRlOiByZXF1aXJlKCcuL19vYmplY3QtY3JlYXRlJykgfSk7XG4iLCJ2YXIgJGV4cG9ydCA9IHJlcXVpcmUoJy4vX2V4cG9ydCcpO1xuLy8gMTkuMS4yLjQgLyAxNS4yLjMuNiBPYmplY3QuZGVmaW5lUHJvcGVydHkoTywgUCwgQXR0cmlidXRlcylcbiRleHBvcnQoJGV4cG9ydC5TICsgJGV4cG9ydC5GICogIXJlcXVpcmUoJy4vX2Rlc2NyaXB0b3JzJyksICdPYmplY3QnLCB7IGRlZmluZVByb3BlcnR5OiByZXF1aXJlKCcuL19vYmplY3QtZHAnKS5mIH0pO1xuIiwiLy8gMTkuMS4yLjkgT2JqZWN0LmdldFByb3RvdHlwZU9mKE8pXG52YXIgdG9PYmplY3QgPSByZXF1aXJlKCcuL190by1vYmplY3QnKTtcbnZhciAkZ2V0UHJvdG90eXBlT2YgPSByZXF1aXJlKCcuL19vYmplY3QtZ3BvJyk7XG5cbnJlcXVpcmUoJy4vX29iamVjdC1zYXAnKSgnZ2V0UHJvdG90eXBlT2YnLCBmdW5jdGlvbiAoKSB7XG4gIHJldHVybiBmdW5jdGlvbiBnZXRQcm90b3R5cGVPZihpdCkge1xuICAgIHJldHVybiAkZ2V0UHJvdG90eXBlT2YodG9PYmplY3QoaXQpKTtcbiAgfTtcbn0pO1xuIiwiLy8gMTkuMS4yLjE0IE9iamVjdC5rZXlzKE8pXG52YXIgdG9PYmplY3QgPSByZXF1aXJlKCcuL190by1vYmplY3QnKTtcbnZhciAka2V5cyA9IHJlcXVpcmUoJy4vX29iamVjdC1rZXlzJyk7XG5cbnJlcXVpcmUoJy4vX29iamVjdC1zYXAnKSgna2V5cycsIGZ1bmN0aW9uICgpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIGtleXMoaXQpIHtcbiAgICByZXR1cm4gJGtleXModG9PYmplY3QoaXQpKTtcbiAgfTtcbn0pO1xuIiwiLy8gMTkuMS4zLjE5IE9iamVjdC5zZXRQcm90b3R5cGVPZihPLCBwcm90bylcbnZhciAkZXhwb3J0ID0gcmVxdWlyZSgnLi9fZXhwb3J0Jyk7XG4kZXhwb3J0KCRleHBvcnQuUywgJ09iamVjdCcsIHsgc2V0UHJvdG90eXBlT2Y6IHJlcXVpcmUoJy4vX3NldC1wcm90bycpLnNldCB9KTtcbiIsIiIsIid1c2Ugc3RyaWN0JztcbnZhciBMSUJSQVJZID0gcmVxdWlyZSgnLi9fbGlicmFyeScpO1xudmFyIGdsb2JhbCA9IHJlcXVpcmUoJy4vX2dsb2JhbCcpO1xudmFyIGN0eCA9IHJlcXVpcmUoJy4vX2N0eCcpO1xudmFyIGNsYXNzb2YgPSByZXF1aXJlKCcuL19jbGFzc29mJyk7XG52YXIgJGV4cG9ydCA9IHJlcXVpcmUoJy4vX2V4cG9ydCcpO1xudmFyIGlzT2JqZWN0ID0gcmVxdWlyZSgnLi9faXMtb2JqZWN0Jyk7XG52YXIgYUZ1bmN0aW9uID0gcmVxdWlyZSgnLi9fYS1mdW5jdGlvbicpO1xudmFyIGFuSW5zdGFuY2UgPSByZXF1aXJlKCcuL19hbi1pbnN0YW5jZScpO1xudmFyIGZvck9mID0gcmVxdWlyZSgnLi9fZm9yLW9mJyk7XG52YXIgc3BlY2llc0NvbnN0cnVjdG9yID0gcmVxdWlyZSgnLi9fc3BlY2llcy1jb25zdHJ1Y3RvcicpO1xudmFyIHRhc2sgPSByZXF1aXJlKCcuL190YXNrJykuc2V0O1xudmFyIG1pY3JvdGFzayA9IHJlcXVpcmUoJy4vX21pY3JvdGFzaycpKCk7XG52YXIgbmV3UHJvbWlzZUNhcGFiaWxpdHlNb2R1bGUgPSByZXF1aXJlKCcuL19uZXctcHJvbWlzZS1jYXBhYmlsaXR5Jyk7XG52YXIgcGVyZm9ybSA9IHJlcXVpcmUoJy4vX3BlcmZvcm0nKTtcbnZhciB1c2VyQWdlbnQgPSByZXF1aXJlKCcuL191c2VyLWFnZW50Jyk7XG52YXIgcHJvbWlzZVJlc29sdmUgPSByZXF1aXJlKCcuL19wcm9taXNlLXJlc29sdmUnKTtcbnZhciBQUk9NSVNFID0gJ1Byb21pc2UnO1xudmFyIFR5cGVFcnJvciA9IGdsb2JhbC5UeXBlRXJyb3I7XG52YXIgcHJvY2VzcyA9IGdsb2JhbC5wcm9jZXNzO1xudmFyIHZlcnNpb25zID0gcHJvY2VzcyAmJiBwcm9jZXNzLnZlcnNpb25zO1xudmFyIHY4ID0gdmVyc2lvbnMgJiYgdmVyc2lvbnMudjggfHwgJyc7XG52YXIgJFByb21pc2UgPSBnbG9iYWxbUFJPTUlTRV07XG52YXIgaXNOb2RlID0gY2xhc3NvZihwcm9jZXNzKSA9PSAncHJvY2Vzcyc7XG52YXIgZW1wdHkgPSBmdW5jdGlvbiAoKSB7IC8qIGVtcHR5ICovIH07XG52YXIgSW50ZXJuYWwsIG5ld0dlbmVyaWNQcm9taXNlQ2FwYWJpbGl0eSwgT3duUHJvbWlzZUNhcGFiaWxpdHksIFdyYXBwZXI7XG52YXIgbmV3UHJvbWlzZUNhcGFiaWxpdHkgPSBuZXdHZW5lcmljUHJvbWlzZUNhcGFiaWxpdHkgPSBuZXdQcm9taXNlQ2FwYWJpbGl0eU1vZHVsZS5mO1xuXG52YXIgVVNFX05BVElWRSA9ICEhZnVuY3Rpb24gKCkge1xuICB0cnkge1xuICAgIC8vIGNvcnJlY3Qgc3ViY2xhc3Npbmcgd2l0aCBAQHNwZWNpZXMgc3VwcG9ydFxuICAgIHZhciBwcm9taXNlID0gJFByb21pc2UucmVzb2x2ZSgxKTtcbiAgICB2YXIgRmFrZVByb21pc2UgPSAocHJvbWlzZS5jb25zdHJ1Y3RvciA9IHt9KVtyZXF1aXJlKCcuL193a3MnKSgnc3BlY2llcycpXSA9IGZ1bmN0aW9uIChleGVjKSB7XG4gICAgICBleGVjKGVtcHR5LCBlbXB0eSk7XG4gICAgfTtcbiAgICAvLyB1bmhhbmRsZWQgcmVqZWN0aW9ucyB0cmFja2luZyBzdXBwb3J0LCBOb2RlSlMgUHJvbWlzZSB3aXRob3V0IGl0IGZhaWxzIEBAc3BlY2llcyB0ZXN0XG4gICAgcmV0dXJuIChpc05vZGUgfHwgdHlwZW9mIFByb21pc2VSZWplY3Rpb25FdmVudCA9PSAnZnVuY3Rpb24nKVxuICAgICAgJiYgcHJvbWlzZS50aGVuKGVtcHR5KSBpbnN0YW5jZW9mIEZha2VQcm9taXNlXG4gICAgICAvLyB2OCA2LjYgKE5vZGUgMTAgYW5kIENocm9tZSA2NikgaGF2ZSBhIGJ1ZyB3aXRoIHJlc29sdmluZyBjdXN0b20gdGhlbmFibGVzXG4gICAgICAvLyBodHRwczovL2J1Z3MuY2hyb21pdW0ub3JnL3AvY2hyb21pdW0vaXNzdWVzL2RldGFpbD9pZD04MzA1NjVcbiAgICAgIC8vIHdlIGNhbid0IGRldGVjdCBpdCBzeW5jaHJvbm91c2x5LCBzbyBqdXN0IGNoZWNrIHZlcnNpb25zXG4gICAgICAmJiB2OC5pbmRleE9mKCc2LjYnKSAhPT0gMFxuICAgICAgJiYgdXNlckFnZW50LmluZGV4T2YoJ0Nocm9tZS82NicpID09PSAtMTtcbiAgfSBjYXRjaCAoZSkgeyAvKiBlbXB0eSAqLyB9XG59KCk7XG5cbi8vIGhlbHBlcnNcbnZhciBpc1RoZW5hYmxlID0gZnVuY3Rpb24gKGl0KSB7XG4gIHZhciB0aGVuO1xuICByZXR1cm4gaXNPYmplY3QoaXQpICYmIHR5cGVvZiAodGhlbiA9IGl0LnRoZW4pID09ICdmdW5jdGlvbicgPyB0aGVuIDogZmFsc2U7XG59O1xudmFyIG5vdGlmeSA9IGZ1bmN0aW9uIChwcm9taXNlLCBpc1JlamVjdCkge1xuICBpZiAocHJvbWlzZS5fbikgcmV0dXJuO1xuICBwcm9taXNlLl9uID0gdHJ1ZTtcbiAgdmFyIGNoYWluID0gcHJvbWlzZS5fYztcbiAgbWljcm90YXNrKGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgdmFsdWUgPSBwcm9taXNlLl92O1xuICAgIHZhciBvayA9IHByb21pc2UuX3MgPT0gMTtcbiAgICB2YXIgaSA9IDA7XG4gICAgdmFyIHJ1biA9IGZ1bmN0aW9uIChyZWFjdGlvbikge1xuICAgICAgdmFyIGhhbmRsZXIgPSBvayA/IHJlYWN0aW9uLm9rIDogcmVhY3Rpb24uZmFpbDtcbiAgICAgIHZhciByZXNvbHZlID0gcmVhY3Rpb24ucmVzb2x2ZTtcbiAgICAgIHZhciByZWplY3QgPSByZWFjdGlvbi5yZWplY3Q7XG4gICAgICB2YXIgZG9tYWluID0gcmVhY3Rpb24uZG9tYWluO1xuICAgICAgdmFyIHJlc3VsdCwgdGhlbiwgZXhpdGVkO1xuICAgICAgdHJ5IHtcbiAgICAgICAgaWYgKGhhbmRsZXIpIHtcbiAgICAgICAgICBpZiAoIW9rKSB7XG4gICAgICAgICAgICBpZiAocHJvbWlzZS5faCA9PSAyKSBvbkhhbmRsZVVuaGFuZGxlZChwcm9taXNlKTtcbiAgICAgICAgICAgIHByb21pc2UuX2ggPSAxO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoaGFuZGxlciA9PT0gdHJ1ZSkgcmVzdWx0ID0gdmFsdWU7XG4gICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBpZiAoZG9tYWluKSBkb21haW4uZW50ZXIoKTtcbiAgICAgICAgICAgIHJlc3VsdCA9IGhhbmRsZXIodmFsdWUpOyAvLyBtYXkgdGhyb3dcbiAgICAgICAgICAgIGlmIChkb21haW4pIHtcbiAgICAgICAgICAgICAgZG9tYWluLmV4aXQoKTtcbiAgICAgICAgICAgICAgZXhpdGVkID0gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKHJlc3VsdCA9PT0gcmVhY3Rpb24ucHJvbWlzZSkge1xuICAgICAgICAgICAgcmVqZWN0KFR5cGVFcnJvcignUHJvbWlzZS1jaGFpbiBjeWNsZScpKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKHRoZW4gPSBpc1RoZW5hYmxlKHJlc3VsdCkpIHtcbiAgICAgICAgICAgIHRoZW4uY2FsbChyZXN1bHQsIHJlc29sdmUsIHJlamVjdCk7XG4gICAgICAgICAgfSBlbHNlIHJlc29sdmUocmVzdWx0KTtcbiAgICAgICAgfSBlbHNlIHJlamVjdCh2YWx1ZSk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGlmIChkb21haW4gJiYgIWV4aXRlZCkgZG9tYWluLmV4aXQoKTtcbiAgICAgICAgcmVqZWN0KGUpO1xuICAgICAgfVxuICAgIH07XG4gICAgd2hpbGUgKGNoYWluLmxlbmd0aCA+IGkpIHJ1bihjaGFpbltpKytdKTsgLy8gdmFyaWFibGUgbGVuZ3RoIC0gY2FuJ3QgdXNlIGZvckVhY2hcbiAgICBwcm9taXNlLl9jID0gW107XG4gICAgcHJvbWlzZS5fbiA9IGZhbHNlO1xuICAgIGlmIChpc1JlamVjdCAmJiAhcHJvbWlzZS5faCkgb25VbmhhbmRsZWQocHJvbWlzZSk7XG4gIH0pO1xufTtcbnZhciBvblVuaGFuZGxlZCA9IGZ1bmN0aW9uIChwcm9taXNlKSB7XG4gIHRhc2suY2FsbChnbG9iYWwsIGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgdmFsdWUgPSBwcm9taXNlLl92O1xuICAgIHZhciB1bmhhbmRsZWQgPSBpc1VuaGFuZGxlZChwcm9taXNlKTtcbiAgICB2YXIgcmVzdWx0LCBoYW5kbGVyLCBjb25zb2xlO1xuICAgIGlmICh1bmhhbmRsZWQpIHtcbiAgICAgIHJlc3VsdCA9IHBlcmZvcm0oZnVuY3Rpb24gKCkge1xuICAgICAgICBpZiAoaXNOb2RlKSB7XG4gICAgICAgICAgcHJvY2Vzcy5lbWl0KCd1bmhhbmRsZWRSZWplY3Rpb24nLCB2YWx1ZSwgcHJvbWlzZSk7XG4gICAgICAgIH0gZWxzZSBpZiAoaGFuZGxlciA9IGdsb2JhbC5vbnVuaGFuZGxlZHJlamVjdGlvbikge1xuICAgICAgICAgIGhhbmRsZXIoeyBwcm9taXNlOiBwcm9taXNlLCByZWFzb246IHZhbHVlIH0pO1xuICAgICAgICB9IGVsc2UgaWYgKChjb25zb2xlID0gZ2xvYmFsLmNvbnNvbGUpICYmIGNvbnNvbGUuZXJyb3IpIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKCdVbmhhbmRsZWQgcHJvbWlzZSByZWplY3Rpb24nLCB2YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgLy8gQnJvd3NlcnMgc2hvdWxkIG5vdCB0cmlnZ2VyIGByZWplY3Rpb25IYW5kbGVkYCBldmVudCBpZiBpdCB3YXMgaGFuZGxlZCBoZXJlLCBOb2RlSlMgLSBzaG91bGRcbiAgICAgIHByb21pc2UuX2ggPSBpc05vZGUgfHwgaXNVbmhhbmRsZWQocHJvbWlzZSkgPyAyIDogMTtcbiAgICB9IHByb21pc2UuX2EgPSB1bmRlZmluZWQ7XG4gICAgaWYgKHVuaGFuZGxlZCAmJiByZXN1bHQuZSkgdGhyb3cgcmVzdWx0LnY7XG4gIH0pO1xufTtcbnZhciBpc1VuaGFuZGxlZCA9IGZ1bmN0aW9uIChwcm9taXNlKSB7XG4gIHJldHVybiBwcm9taXNlLl9oICE9PSAxICYmIChwcm9taXNlLl9hIHx8IHByb21pc2UuX2MpLmxlbmd0aCA9PT0gMDtcbn07XG52YXIgb25IYW5kbGVVbmhhbmRsZWQgPSBmdW5jdGlvbiAocHJvbWlzZSkge1xuICB0YXNrLmNhbGwoZ2xvYmFsLCBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIGhhbmRsZXI7XG4gICAgaWYgKGlzTm9kZSkge1xuICAgICAgcHJvY2Vzcy5lbWl0KCdyZWplY3Rpb25IYW5kbGVkJywgcHJvbWlzZSk7XG4gICAgfSBlbHNlIGlmIChoYW5kbGVyID0gZ2xvYmFsLm9ucmVqZWN0aW9uaGFuZGxlZCkge1xuICAgICAgaGFuZGxlcih7IHByb21pc2U6IHByb21pc2UsIHJlYXNvbjogcHJvbWlzZS5fdiB9KTtcbiAgICB9XG4gIH0pO1xufTtcbnZhciAkcmVqZWN0ID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gIHZhciBwcm9taXNlID0gdGhpcztcbiAgaWYgKHByb21pc2UuX2QpIHJldHVybjtcbiAgcHJvbWlzZS5fZCA9IHRydWU7XG4gIHByb21pc2UgPSBwcm9taXNlLl93IHx8IHByb21pc2U7IC8vIHVud3JhcFxuICBwcm9taXNlLl92ID0gdmFsdWU7XG4gIHByb21pc2UuX3MgPSAyO1xuICBpZiAoIXByb21pc2UuX2EpIHByb21pc2UuX2EgPSBwcm9taXNlLl9jLnNsaWNlKCk7XG4gIG5vdGlmeShwcm9taXNlLCB0cnVlKTtcbn07XG52YXIgJHJlc29sdmUgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgdmFyIHByb21pc2UgPSB0aGlzO1xuICB2YXIgdGhlbjtcbiAgaWYgKHByb21pc2UuX2QpIHJldHVybjtcbiAgcHJvbWlzZS5fZCA9IHRydWU7XG4gIHByb21pc2UgPSBwcm9taXNlLl93IHx8IHByb21pc2U7IC8vIHVud3JhcFxuICB0cnkge1xuICAgIGlmIChwcm9taXNlID09PSB2YWx1ZSkgdGhyb3cgVHlwZUVycm9yKFwiUHJvbWlzZSBjYW4ndCBiZSByZXNvbHZlZCBpdHNlbGZcIik7XG4gICAgaWYgKHRoZW4gPSBpc1RoZW5hYmxlKHZhbHVlKSkge1xuICAgICAgbWljcm90YXNrKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIHdyYXBwZXIgPSB7IF93OiBwcm9taXNlLCBfZDogZmFsc2UgfTsgLy8gd3JhcFxuICAgICAgICB0cnkge1xuICAgICAgICAgIHRoZW4uY2FsbCh2YWx1ZSwgY3R4KCRyZXNvbHZlLCB3cmFwcGVyLCAxKSwgY3R4KCRyZWplY3QsIHdyYXBwZXIsIDEpKTtcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICRyZWplY3QuY2FsbCh3cmFwcGVyLCBlKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHByb21pc2UuX3YgPSB2YWx1ZTtcbiAgICAgIHByb21pc2UuX3MgPSAxO1xuICAgICAgbm90aWZ5KHByb21pc2UsIGZhbHNlKTtcbiAgICB9XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICAkcmVqZWN0LmNhbGwoeyBfdzogcHJvbWlzZSwgX2Q6IGZhbHNlIH0sIGUpOyAvLyB3cmFwXG4gIH1cbn07XG5cbi8vIGNvbnN0cnVjdG9yIHBvbHlmaWxsXG5pZiAoIVVTRV9OQVRJVkUpIHtcbiAgLy8gMjUuNC4zLjEgUHJvbWlzZShleGVjdXRvcilcbiAgJFByb21pc2UgPSBmdW5jdGlvbiBQcm9taXNlKGV4ZWN1dG9yKSB7XG4gICAgYW5JbnN0YW5jZSh0aGlzLCAkUHJvbWlzZSwgUFJPTUlTRSwgJ19oJyk7XG4gICAgYUZ1bmN0aW9uKGV4ZWN1dG9yKTtcbiAgICBJbnRlcm5hbC5jYWxsKHRoaXMpO1xuICAgIHRyeSB7XG4gICAgICBleGVjdXRvcihjdHgoJHJlc29sdmUsIHRoaXMsIDEpLCBjdHgoJHJlamVjdCwgdGhpcywgMSkpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgJHJlamVjdC5jYWxsKHRoaXMsIGVycik7XG4gICAgfVxuICB9O1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tdW51c2VkLXZhcnNcbiAgSW50ZXJuYWwgPSBmdW5jdGlvbiBQcm9taXNlKGV4ZWN1dG9yKSB7XG4gICAgdGhpcy5fYyA9IFtdOyAgICAgICAgICAgICAvLyA8LSBhd2FpdGluZyByZWFjdGlvbnNcbiAgICB0aGlzLl9hID0gdW5kZWZpbmVkOyAgICAgIC8vIDwtIGNoZWNrZWQgaW4gaXNVbmhhbmRsZWQgcmVhY3Rpb25zXG4gICAgdGhpcy5fcyA9IDA7ICAgICAgICAgICAgICAvLyA8LSBzdGF0ZVxuICAgIHRoaXMuX2QgPSBmYWxzZTsgICAgICAgICAgLy8gPC0gZG9uZVxuICAgIHRoaXMuX3YgPSB1bmRlZmluZWQ7ICAgICAgLy8gPC0gdmFsdWVcbiAgICB0aGlzLl9oID0gMDsgICAgICAgICAgICAgIC8vIDwtIHJlamVjdGlvbiBzdGF0ZSwgMCAtIGRlZmF1bHQsIDEgLSBoYW5kbGVkLCAyIC0gdW5oYW5kbGVkXG4gICAgdGhpcy5fbiA9IGZhbHNlOyAgICAgICAgICAvLyA8LSBub3RpZnlcbiAgfTtcbiAgSW50ZXJuYWwucHJvdG90eXBlID0gcmVxdWlyZSgnLi9fcmVkZWZpbmUtYWxsJykoJFByb21pc2UucHJvdG90eXBlLCB7XG4gICAgLy8gMjUuNC41LjMgUHJvbWlzZS5wcm90b3R5cGUudGhlbihvbkZ1bGZpbGxlZCwgb25SZWplY3RlZClcbiAgICB0aGVuOiBmdW5jdGlvbiB0aGVuKG9uRnVsZmlsbGVkLCBvblJlamVjdGVkKSB7XG4gICAgICB2YXIgcmVhY3Rpb24gPSBuZXdQcm9taXNlQ2FwYWJpbGl0eShzcGVjaWVzQ29uc3RydWN0b3IodGhpcywgJFByb21pc2UpKTtcbiAgICAgIHJlYWN0aW9uLm9rID0gdHlwZW9mIG9uRnVsZmlsbGVkID09ICdmdW5jdGlvbicgPyBvbkZ1bGZpbGxlZCA6IHRydWU7XG4gICAgICByZWFjdGlvbi5mYWlsID0gdHlwZW9mIG9uUmVqZWN0ZWQgPT0gJ2Z1bmN0aW9uJyAmJiBvblJlamVjdGVkO1xuICAgICAgcmVhY3Rpb24uZG9tYWluID0gaXNOb2RlID8gcHJvY2Vzcy5kb21haW4gOiB1bmRlZmluZWQ7XG4gICAgICB0aGlzLl9jLnB1c2gocmVhY3Rpb24pO1xuICAgICAgaWYgKHRoaXMuX2EpIHRoaXMuX2EucHVzaChyZWFjdGlvbik7XG4gICAgICBpZiAodGhpcy5fcykgbm90aWZ5KHRoaXMsIGZhbHNlKTtcbiAgICAgIHJldHVybiByZWFjdGlvbi5wcm9taXNlO1xuICAgIH0sXG4gICAgLy8gMjUuNC41LjEgUHJvbWlzZS5wcm90b3R5cGUuY2F0Y2gob25SZWplY3RlZClcbiAgICAnY2F0Y2gnOiBmdW5jdGlvbiAob25SZWplY3RlZCkge1xuICAgICAgcmV0dXJuIHRoaXMudGhlbih1bmRlZmluZWQsIG9uUmVqZWN0ZWQpO1xuICAgIH1cbiAgfSk7XG4gIE93blByb21pc2VDYXBhYmlsaXR5ID0gZnVuY3Rpb24gKCkge1xuICAgIHZhciBwcm9taXNlID0gbmV3IEludGVybmFsKCk7XG4gICAgdGhpcy5wcm9taXNlID0gcHJvbWlzZTtcbiAgICB0aGlzLnJlc29sdmUgPSBjdHgoJHJlc29sdmUsIHByb21pc2UsIDEpO1xuICAgIHRoaXMucmVqZWN0ID0gY3R4KCRyZWplY3QsIHByb21pc2UsIDEpO1xuICB9O1xuICBuZXdQcm9taXNlQ2FwYWJpbGl0eU1vZHVsZS5mID0gbmV3UHJvbWlzZUNhcGFiaWxpdHkgPSBmdW5jdGlvbiAoQykge1xuICAgIHJldHVybiBDID09PSAkUHJvbWlzZSB8fCBDID09PSBXcmFwcGVyXG4gICAgICA/IG5ldyBPd25Qcm9taXNlQ2FwYWJpbGl0eShDKVxuICAgICAgOiBuZXdHZW5lcmljUHJvbWlzZUNhcGFiaWxpdHkoQyk7XG4gIH07XG59XG5cbiRleHBvcnQoJGV4cG9ydC5HICsgJGV4cG9ydC5XICsgJGV4cG9ydC5GICogIVVTRV9OQVRJVkUsIHsgUHJvbWlzZTogJFByb21pc2UgfSk7XG5yZXF1aXJlKCcuL19zZXQtdG8tc3RyaW5nLXRhZycpKCRQcm9taXNlLCBQUk9NSVNFKTtcbnJlcXVpcmUoJy4vX3NldC1zcGVjaWVzJykoUFJPTUlTRSk7XG5XcmFwcGVyID0gcmVxdWlyZSgnLi9fY29yZScpW1BST01JU0VdO1xuXG4vLyBzdGF0aWNzXG4kZXhwb3J0KCRleHBvcnQuUyArICRleHBvcnQuRiAqICFVU0VfTkFUSVZFLCBQUk9NSVNFLCB7XG4gIC8vIDI1LjQuNC41IFByb21pc2UucmVqZWN0KHIpXG4gIHJlamVjdDogZnVuY3Rpb24gcmVqZWN0KHIpIHtcbiAgICB2YXIgY2FwYWJpbGl0eSA9IG5ld1Byb21pc2VDYXBhYmlsaXR5KHRoaXMpO1xuICAgIHZhciAkJHJlamVjdCA9IGNhcGFiaWxpdHkucmVqZWN0O1xuICAgICQkcmVqZWN0KHIpO1xuICAgIHJldHVybiBjYXBhYmlsaXR5LnByb21pc2U7XG4gIH1cbn0pO1xuJGV4cG9ydCgkZXhwb3J0LlMgKyAkZXhwb3J0LkYgKiAoTElCUkFSWSB8fCAhVVNFX05BVElWRSksIFBST01JU0UsIHtcbiAgLy8gMjUuNC40LjYgUHJvbWlzZS5yZXNvbHZlKHgpXG4gIHJlc29sdmU6IGZ1bmN0aW9uIHJlc29sdmUoeCkge1xuICAgIHJldHVybiBwcm9taXNlUmVzb2x2ZShMSUJSQVJZICYmIHRoaXMgPT09IFdyYXBwZXIgPyAkUHJvbWlzZSA6IHRoaXMsIHgpO1xuICB9XG59KTtcbiRleHBvcnQoJGV4cG9ydC5TICsgJGV4cG9ydC5GICogIShVU0VfTkFUSVZFICYmIHJlcXVpcmUoJy4vX2l0ZXItZGV0ZWN0JykoZnVuY3Rpb24gKGl0ZXIpIHtcbiAgJFByb21pc2UuYWxsKGl0ZXIpWydjYXRjaCddKGVtcHR5KTtcbn0pKSwgUFJPTUlTRSwge1xuICAvLyAyNS40LjQuMSBQcm9taXNlLmFsbChpdGVyYWJsZSlcbiAgYWxsOiBmdW5jdGlvbiBhbGwoaXRlcmFibGUpIHtcbiAgICB2YXIgQyA9IHRoaXM7XG4gICAgdmFyIGNhcGFiaWxpdHkgPSBuZXdQcm9taXNlQ2FwYWJpbGl0eShDKTtcbiAgICB2YXIgcmVzb2x2ZSA9IGNhcGFiaWxpdHkucmVzb2x2ZTtcbiAgICB2YXIgcmVqZWN0ID0gY2FwYWJpbGl0eS5yZWplY3Q7XG4gICAgdmFyIHJlc3VsdCA9IHBlcmZvcm0oZnVuY3Rpb24gKCkge1xuICAgICAgdmFyIHZhbHVlcyA9IFtdO1xuICAgICAgdmFyIGluZGV4ID0gMDtcbiAgICAgIHZhciByZW1haW5pbmcgPSAxO1xuICAgICAgZm9yT2YoaXRlcmFibGUsIGZhbHNlLCBmdW5jdGlvbiAocHJvbWlzZSkge1xuICAgICAgICB2YXIgJGluZGV4ID0gaW5kZXgrKztcbiAgICAgICAgdmFyIGFscmVhZHlDYWxsZWQgPSBmYWxzZTtcbiAgICAgICAgdmFsdWVzLnB1c2godW5kZWZpbmVkKTtcbiAgICAgICAgcmVtYWluaW5nKys7XG4gICAgICAgIEMucmVzb2x2ZShwcm9taXNlKS50aGVuKGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgIGlmIChhbHJlYWR5Q2FsbGVkKSByZXR1cm47XG4gICAgICAgICAgYWxyZWFkeUNhbGxlZCA9IHRydWU7XG4gICAgICAgICAgdmFsdWVzWyRpbmRleF0gPSB2YWx1ZTtcbiAgICAgICAgICAtLXJlbWFpbmluZyB8fCByZXNvbHZlKHZhbHVlcyk7XG4gICAgICAgIH0sIHJlamVjdCk7XG4gICAgICB9KTtcbiAgICAgIC0tcmVtYWluaW5nIHx8IHJlc29sdmUodmFsdWVzKTtcbiAgICB9KTtcbiAgICBpZiAocmVzdWx0LmUpIHJlamVjdChyZXN1bHQudik7XG4gICAgcmV0dXJuIGNhcGFiaWxpdHkucHJvbWlzZTtcbiAgfSxcbiAgLy8gMjUuNC40LjQgUHJvbWlzZS5yYWNlKGl0ZXJhYmxlKVxuICByYWNlOiBmdW5jdGlvbiByYWNlKGl0ZXJhYmxlKSB7XG4gICAgdmFyIEMgPSB0aGlzO1xuICAgIHZhciBjYXBhYmlsaXR5ID0gbmV3UHJvbWlzZUNhcGFiaWxpdHkoQyk7XG4gICAgdmFyIHJlamVjdCA9IGNhcGFiaWxpdHkucmVqZWN0O1xuICAgIHZhciByZXN1bHQgPSBwZXJmb3JtKGZ1bmN0aW9uICgpIHtcbiAgICAgIGZvck9mKGl0ZXJhYmxlLCBmYWxzZSwgZnVuY3Rpb24gKHByb21pc2UpIHtcbiAgICAgICAgQy5yZXNvbHZlKHByb21pc2UpLnRoZW4oY2FwYWJpbGl0eS5yZXNvbHZlLCByZWplY3QpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gICAgaWYgKHJlc3VsdC5lKSByZWplY3QocmVzdWx0LnYpO1xuICAgIHJldHVybiBjYXBhYmlsaXR5LnByb21pc2U7XG4gIH1cbn0pO1xuIiwiJ3VzZSBzdHJpY3QnO1xudmFyICRhdCA9IHJlcXVpcmUoJy4vX3N0cmluZy1hdCcpKHRydWUpO1xuXG4vLyAyMS4xLjMuMjcgU3RyaW5nLnByb3RvdHlwZVtAQGl0ZXJhdG9yXSgpXG5yZXF1aXJlKCcuL19pdGVyLWRlZmluZScpKFN0cmluZywgJ1N0cmluZycsIGZ1bmN0aW9uIChpdGVyYXRlZCkge1xuICB0aGlzLl90ID0gU3RyaW5nKGl0ZXJhdGVkKTsgLy8gdGFyZ2V0XG4gIHRoaXMuX2kgPSAwOyAgICAgICAgICAgICAgICAvLyBuZXh0IGluZGV4XG4vLyAyMS4xLjUuMi4xICVTdHJpbmdJdGVyYXRvclByb3RvdHlwZSUubmV4dCgpXG59LCBmdW5jdGlvbiAoKSB7XG4gIHZhciBPID0gdGhpcy5fdDtcbiAgdmFyIGluZGV4ID0gdGhpcy5faTtcbiAgdmFyIHBvaW50O1xuICBpZiAoaW5kZXggPj0gTy5sZW5ndGgpIHJldHVybiB7IHZhbHVlOiB1bmRlZmluZWQsIGRvbmU6IHRydWUgfTtcbiAgcG9pbnQgPSAkYXQoTywgaW5kZXgpO1xuICB0aGlzLl9pICs9IHBvaW50Lmxlbmd0aDtcbiAgcmV0dXJuIHsgdmFsdWU6IHBvaW50LCBkb25lOiBmYWxzZSB9O1xufSk7XG4iLCIndXNlIHN0cmljdCc7XG4vLyBFQ01BU2NyaXB0IDYgc3ltYm9scyBzaGltXG52YXIgZ2xvYmFsID0gcmVxdWlyZSgnLi9fZ2xvYmFsJyk7XG52YXIgaGFzID0gcmVxdWlyZSgnLi9faGFzJyk7XG52YXIgREVTQ1JJUFRPUlMgPSByZXF1aXJlKCcuL19kZXNjcmlwdG9ycycpO1xudmFyICRleHBvcnQgPSByZXF1aXJlKCcuL19leHBvcnQnKTtcbnZhciByZWRlZmluZSA9IHJlcXVpcmUoJy4vX3JlZGVmaW5lJyk7XG52YXIgTUVUQSA9IHJlcXVpcmUoJy4vX21ldGEnKS5LRVk7XG52YXIgJGZhaWxzID0gcmVxdWlyZSgnLi9fZmFpbHMnKTtcbnZhciBzaGFyZWQgPSByZXF1aXJlKCcuL19zaGFyZWQnKTtcbnZhciBzZXRUb1N0cmluZ1RhZyA9IHJlcXVpcmUoJy4vX3NldC10by1zdHJpbmctdGFnJyk7XG52YXIgdWlkID0gcmVxdWlyZSgnLi9fdWlkJyk7XG52YXIgd2tzID0gcmVxdWlyZSgnLi9fd2tzJyk7XG52YXIgd2tzRXh0ID0gcmVxdWlyZSgnLi9fd2tzLWV4dCcpO1xudmFyIHdrc0RlZmluZSA9IHJlcXVpcmUoJy4vX3drcy1kZWZpbmUnKTtcbnZhciBlbnVtS2V5cyA9IHJlcXVpcmUoJy4vX2VudW0ta2V5cycpO1xudmFyIGlzQXJyYXkgPSByZXF1aXJlKCcuL19pcy1hcnJheScpO1xudmFyIGFuT2JqZWN0ID0gcmVxdWlyZSgnLi9fYW4tb2JqZWN0Jyk7XG52YXIgaXNPYmplY3QgPSByZXF1aXJlKCcuL19pcy1vYmplY3QnKTtcbnZhciB0b0lPYmplY3QgPSByZXF1aXJlKCcuL190by1pb2JqZWN0Jyk7XG52YXIgdG9QcmltaXRpdmUgPSByZXF1aXJlKCcuL190by1wcmltaXRpdmUnKTtcbnZhciBjcmVhdGVEZXNjID0gcmVxdWlyZSgnLi9fcHJvcGVydHktZGVzYycpO1xudmFyIF9jcmVhdGUgPSByZXF1aXJlKCcuL19vYmplY3QtY3JlYXRlJyk7XG52YXIgZ09QTkV4dCA9IHJlcXVpcmUoJy4vX29iamVjdC1nb3BuLWV4dCcpO1xudmFyICRHT1BEID0gcmVxdWlyZSgnLi9fb2JqZWN0LWdvcGQnKTtcbnZhciAkRFAgPSByZXF1aXJlKCcuL19vYmplY3QtZHAnKTtcbnZhciAka2V5cyA9IHJlcXVpcmUoJy4vX29iamVjdC1rZXlzJyk7XG52YXIgZ09QRCA9ICRHT1BELmY7XG52YXIgZFAgPSAkRFAuZjtcbnZhciBnT1BOID0gZ09QTkV4dC5mO1xudmFyICRTeW1ib2wgPSBnbG9iYWwuU3ltYm9sO1xudmFyICRKU09OID0gZ2xvYmFsLkpTT047XG52YXIgX3N0cmluZ2lmeSA9ICRKU09OICYmICRKU09OLnN0cmluZ2lmeTtcbnZhciBQUk9UT1RZUEUgPSAncHJvdG90eXBlJztcbnZhciBISURERU4gPSB3a3MoJ19oaWRkZW4nKTtcbnZhciBUT19QUklNSVRJVkUgPSB3a3MoJ3RvUHJpbWl0aXZlJyk7XG52YXIgaXNFbnVtID0ge30ucHJvcGVydHlJc0VudW1lcmFibGU7XG52YXIgU3ltYm9sUmVnaXN0cnkgPSBzaGFyZWQoJ3N5bWJvbC1yZWdpc3RyeScpO1xudmFyIEFsbFN5bWJvbHMgPSBzaGFyZWQoJ3N5bWJvbHMnKTtcbnZhciBPUFN5bWJvbHMgPSBzaGFyZWQoJ29wLXN5bWJvbHMnKTtcbnZhciBPYmplY3RQcm90byA9IE9iamVjdFtQUk9UT1RZUEVdO1xudmFyIFVTRV9OQVRJVkUgPSB0eXBlb2YgJFN5bWJvbCA9PSAnZnVuY3Rpb24nO1xudmFyIFFPYmplY3QgPSBnbG9iYWwuUU9iamVjdDtcbi8vIERvbid0IHVzZSBzZXR0ZXJzIGluIFF0IFNjcmlwdCwgaHR0cHM6Ly9naXRodWIuY29tL3psb2lyb2NrL2NvcmUtanMvaXNzdWVzLzE3M1xudmFyIHNldHRlciA9ICFRT2JqZWN0IHx8ICFRT2JqZWN0W1BST1RPVFlQRV0gfHwgIVFPYmplY3RbUFJPVE9UWVBFXS5maW5kQ2hpbGQ7XG5cbi8vIGZhbGxiYWNrIGZvciBvbGQgQW5kcm9pZCwgaHR0cHM6Ly9jb2RlLmdvb2dsZS5jb20vcC92OC9pc3N1ZXMvZGV0YWlsP2lkPTY4N1xudmFyIHNldFN5bWJvbERlc2MgPSBERVNDUklQVE9SUyAmJiAkZmFpbHMoZnVuY3Rpb24gKCkge1xuICByZXR1cm4gX2NyZWF0ZShkUCh7fSwgJ2EnLCB7XG4gICAgZ2V0OiBmdW5jdGlvbiAoKSB7IHJldHVybiBkUCh0aGlzLCAnYScsIHsgdmFsdWU6IDcgfSkuYTsgfVxuICB9KSkuYSAhPSA3O1xufSkgPyBmdW5jdGlvbiAoaXQsIGtleSwgRCkge1xuICB2YXIgcHJvdG9EZXNjID0gZ09QRChPYmplY3RQcm90bywga2V5KTtcbiAgaWYgKHByb3RvRGVzYykgZGVsZXRlIE9iamVjdFByb3RvW2tleV07XG4gIGRQKGl0LCBrZXksIEQpO1xuICBpZiAocHJvdG9EZXNjICYmIGl0ICE9PSBPYmplY3RQcm90bykgZFAoT2JqZWN0UHJvdG8sIGtleSwgcHJvdG9EZXNjKTtcbn0gOiBkUDtcblxudmFyIHdyYXAgPSBmdW5jdGlvbiAodGFnKSB7XG4gIHZhciBzeW0gPSBBbGxTeW1ib2xzW3RhZ10gPSBfY3JlYXRlKCRTeW1ib2xbUFJPVE9UWVBFXSk7XG4gIHN5bS5fayA9IHRhZztcbiAgcmV0dXJuIHN5bTtcbn07XG5cbnZhciBpc1N5bWJvbCA9IFVTRV9OQVRJVkUgJiYgdHlwZW9mICRTeW1ib2wuaXRlcmF0b3IgPT0gJ3N5bWJvbCcgPyBmdW5jdGlvbiAoaXQpIHtcbiAgcmV0dXJuIHR5cGVvZiBpdCA9PSAnc3ltYm9sJztcbn0gOiBmdW5jdGlvbiAoaXQpIHtcbiAgcmV0dXJuIGl0IGluc3RhbmNlb2YgJFN5bWJvbDtcbn07XG5cbnZhciAkZGVmaW5lUHJvcGVydHkgPSBmdW5jdGlvbiBkZWZpbmVQcm9wZXJ0eShpdCwga2V5LCBEKSB7XG4gIGlmIChpdCA9PT0gT2JqZWN0UHJvdG8pICRkZWZpbmVQcm9wZXJ0eShPUFN5bWJvbHMsIGtleSwgRCk7XG4gIGFuT2JqZWN0KGl0KTtcbiAga2V5ID0gdG9QcmltaXRpdmUoa2V5LCB0cnVlKTtcbiAgYW5PYmplY3QoRCk7XG4gIGlmIChoYXMoQWxsU3ltYm9scywga2V5KSkge1xuICAgIGlmICghRC5lbnVtZXJhYmxlKSB7XG4gICAgICBpZiAoIWhhcyhpdCwgSElEREVOKSkgZFAoaXQsIEhJRERFTiwgY3JlYXRlRGVzYygxLCB7fSkpO1xuICAgICAgaXRbSElEREVOXVtrZXldID0gdHJ1ZTtcbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKGhhcyhpdCwgSElEREVOKSAmJiBpdFtISURERU5dW2tleV0pIGl0W0hJRERFTl1ba2V5XSA9IGZhbHNlO1xuICAgICAgRCA9IF9jcmVhdGUoRCwgeyBlbnVtZXJhYmxlOiBjcmVhdGVEZXNjKDAsIGZhbHNlKSB9KTtcbiAgICB9IHJldHVybiBzZXRTeW1ib2xEZXNjKGl0LCBrZXksIEQpO1xuICB9IHJldHVybiBkUChpdCwga2V5LCBEKTtcbn07XG52YXIgJGRlZmluZVByb3BlcnRpZXMgPSBmdW5jdGlvbiBkZWZpbmVQcm9wZXJ0aWVzKGl0LCBQKSB7XG4gIGFuT2JqZWN0KGl0KTtcbiAgdmFyIGtleXMgPSBlbnVtS2V5cyhQID0gdG9JT2JqZWN0KFApKTtcbiAgdmFyIGkgPSAwO1xuICB2YXIgbCA9IGtleXMubGVuZ3RoO1xuICB2YXIga2V5O1xuICB3aGlsZSAobCA+IGkpICRkZWZpbmVQcm9wZXJ0eShpdCwga2V5ID0ga2V5c1tpKytdLCBQW2tleV0pO1xuICByZXR1cm4gaXQ7XG59O1xudmFyICRjcmVhdGUgPSBmdW5jdGlvbiBjcmVhdGUoaXQsIFApIHtcbiAgcmV0dXJuIFAgPT09IHVuZGVmaW5lZCA/IF9jcmVhdGUoaXQpIDogJGRlZmluZVByb3BlcnRpZXMoX2NyZWF0ZShpdCksIFApO1xufTtcbnZhciAkcHJvcGVydHlJc0VudW1lcmFibGUgPSBmdW5jdGlvbiBwcm9wZXJ0eUlzRW51bWVyYWJsZShrZXkpIHtcbiAgdmFyIEUgPSBpc0VudW0uY2FsbCh0aGlzLCBrZXkgPSB0b1ByaW1pdGl2ZShrZXksIHRydWUpKTtcbiAgaWYgKHRoaXMgPT09IE9iamVjdFByb3RvICYmIGhhcyhBbGxTeW1ib2xzLCBrZXkpICYmICFoYXMoT1BTeW1ib2xzLCBrZXkpKSByZXR1cm4gZmFsc2U7XG4gIHJldHVybiBFIHx8ICFoYXModGhpcywga2V5KSB8fCAhaGFzKEFsbFN5bWJvbHMsIGtleSkgfHwgaGFzKHRoaXMsIEhJRERFTikgJiYgdGhpc1tISURERU5dW2tleV0gPyBFIDogdHJ1ZTtcbn07XG52YXIgJGdldE93blByb3BlcnR5RGVzY3JpcHRvciA9IGZ1bmN0aW9uIGdldE93blByb3BlcnR5RGVzY3JpcHRvcihpdCwga2V5KSB7XG4gIGl0ID0gdG9JT2JqZWN0KGl0KTtcbiAga2V5ID0gdG9QcmltaXRpdmUoa2V5LCB0cnVlKTtcbiAgaWYgKGl0ID09PSBPYmplY3RQcm90byAmJiBoYXMoQWxsU3ltYm9scywga2V5KSAmJiAhaGFzKE9QU3ltYm9scywga2V5KSkgcmV0dXJuO1xuICB2YXIgRCA9IGdPUEQoaXQsIGtleSk7XG4gIGlmIChEICYmIGhhcyhBbGxTeW1ib2xzLCBrZXkpICYmICEoaGFzKGl0LCBISURERU4pICYmIGl0W0hJRERFTl1ba2V5XSkpIEQuZW51bWVyYWJsZSA9IHRydWU7XG4gIHJldHVybiBEO1xufTtcbnZhciAkZ2V0T3duUHJvcGVydHlOYW1lcyA9IGZ1bmN0aW9uIGdldE93blByb3BlcnR5TmFtZXMoaXQpIHtcbiAgdmFyIG5hbWVzID0gZ09QTih0b0lPYmplY3QoaXQpKTtcbiAgdmFyIHJlc3VsdCA9IFtdO1xuICB2YXIgaSA9IDA7XG4gIHZhciBrZXk7XG4gIHdoaWxlIChuYW1lcy5sZW5ndGggPiBpKSB7XG4gICAgaWYgKCFoYXMoQWxsU3ltYm9scywga2V5ID0gbmFtZXNbaSsrXSkgJiYga2V5ICE9IEhJRERFTiAmJiBrZXkgIT0gTUVUQSkgcmVzdWx0LnB1c2goa2V5KTtcbiAgfSByZXR1cm4gcmVzdWx0O1xufTtcbnZhciAkZ2V0T3duUHJvcGVydHlTeW1ib2xzID0gZnVuY3Rpb24gZ2V0T3duUHJvcGVydHlTeW1ib2xzKGl0KSB7XG4gIHZhciBJU19PUCA9IGl0ID09PSBPYmplY3RQcm90bztcbiAgdmFyIG5hbWVzID0gZ09QTihJU19PUCA/IE9QU3ltYm9scyA6IHRvSU9iamVjdChpdCkpO1xuICB2YXIgcmVzdWx0ID0gW107XG4gIHZhciBpID0gMDtcbiAgdmFyIGtleTtcbiAgd2hpbGUgKG5hbWVzLmxlbmd0aCA+IGkpIHtcbiAgICBpZiAoaGFzKEFsbFN5bWJvbHMsIGtleSA9IG5hbWVzW2krK10pICYmIChJU19PUCA/IGhhcyhPYmplY3RQcm90bywga2V5KSA6IHRydWUpKSByZXN1bHQucHVzaChBbGxTeW1ib2xzW2tleV0pO1xuICB9IHJldHVybiByZXN1bHQ7XG59O1xuXG4vLyAxOS40LjEuMSBTeW1ib2woW2Rlc2NyaXB0aW9uXSlcbmlmICghVVNFX05BVElWRSkge1xuICAkU3ltYm9sID0gZnVuY3Rpb24gU3ltYm9sKCkge1xuICAgIGlmICh0aGlzIGluc3RhbmNlb2YgJFN5bWJvbCkgdGhyb3cgVHlwZUVycm9yKCdTeW1ib2wgaXMgbm90IGEgY29uc3RydWN0b3IhJyk7XG4gICAgdmFyIHRhZyA9IHVpZChhcmd1bWVudHMubGVuZ3RoID4gMCA/IGFyZ3VtZW50c1swXSA6IHVuZGVmaW5lZCk7XG4gICAgdmFyICRzZXQgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgIGlmICh0aGlzID09PSBPYmplY3RQcm90bykgJHNldC5jYWxsKE9QU3ltYm9scywgdmFsdWUpO1xuICAgICAgaWYgKGhhcyh0aGlzLCBISURERU4pICYmIGhhcyh0aGlzW0hJRERFTl0sIHRhZykpIHRoaXNbSElEREVOXVt0YWddID0gZmFsc2U7XG4gICAgICBzZXRTeW1ib2xEZXNjKHRoaXMsIHRhZywgY3JlYXRlRGVzYygxLCB2YWx1ZSkpO1xuICAgIH07XG4gICAgaWYgKERFU0NSSVBUT1JTICYmIHNldHRlcikgc2V0U3ltYm9sRGVzYyhPYmplY3RQcm90bywgdGFnLCB7IGNvbmZpZ3VyYWJsZTogdHJ1ZSwgc2V0OiAkc2V0IH0pO1xuICAgIHJldHVybiB3cmFwKHRhZyk7XG4gIH07XG4gIHJlZGVmaW5lKCRTeW1ib2xbUFJPVE9UWVBFXSwgJ3RvU3RyaW5nJywgZnVuY3Rpb24gdG9TdHJpbmcoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2s7XG4gIH0pO1xuXG4gICRHT1BELmYgPSAkZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yO1xuICAkRFAuZiA9ICRkZWZpbmVQcm9wZXJ0eTtcbiAgcmVxdWlyZSgnLi9fb2JqZWN0LWdvcG4nKS5mID0gZ09QTkV4dC5mID0gJGdldE93blByb3BlcnR5TmFtZXM7XG4gIHJlcXVpcmUoJy4vX29iamVjdC1waWUnKS5mID0gJHByb3BlcnR5SXNFbnVtZXJhYmxlO1xuICByZXF1aXJlKCcuL19vYmplY3QtZ29wcycpLmYgPSAkZ2V0T3duUHJvcGVydHlTeW1ib2xzO1xuXG4gIGlmIChERVNDUklQVE9SUyAmJiAhcmVxdWlyZSgnLi9fbGlicmFyeScpKSB7XG4gICAgcmVkZWZpbmUoT2JqZWN0UHJvdG8sICdwcm9wZXJ0eUlzRW51bWVyYWJsZScsICRwcm9wZXJ0eUlzRW51bWVyYWJsZSwgdHJ1ZSk7XG4gIH1cblxuICB3a3NFeHQuZiA9IGZ1bmN0aW9uIChuYW1lKSB7XG4gICAgcmV0dXJuIHdyYXAod2tzKG5hbWUpKTtcbiAgfTtcbn1cblxuJGV4cG9ydCgkZXhwb3J0LkcgKyAkZXhwb3J0LlcgKyAkZXhwb3J0LkYgKiAhVVNFX05BVElWRSwgeyBTeW1ib2w6ICRTeW1ib2wgfSk7XG5cbmZvciAodmFyIGVzNlN5bWJvbHMgPSAoXG4gIC8vIDE5LjQuMi4yLCAxOS40LjIuMywgMTkuNC4yLjQsIDE5LjQuMi42LCAxOS40LjIuOCwgMTkuNC4yLjksIDE5LjQuMi4xMCwgMTkuNC4yLjExLCAxOS40LjIuMTIsIDE5LjQuMi4xMywgMTkuNC4yLjE0XG4gICdoYXNJbnN0YW5jZSxpc0NvbmNhdFNwcmVhZGFibGUsaXRlcmF0b3IsbWF0Y2gscmVwbGFjZSxzZWFyY2gsc3BlY2llcyxzcGxpdCx0b1ByaW1pdGl2ZSx0b1N0cmluZ1RhZyx1bnNjb3BhYmxlcydcbikuc3BsaXQoJywnKSwgaiA9IDA7IGVzNlN5bWJvbHMubGVuZ3RoID4gajspd2tzKGVzNlN5bWJvbHNbaisrXSk7XG5cbmZvciAodmFyIHdlbGxLbm93blN5bWJvbHMgPSAka2V5cyh3a3Muc3RvcmUpLCBrID0gMDsgd2VsbEtub3duU3ltYm9scy5sZW5ndGggPiBrOykgd2tzRGVmaW5lKHdlbGxLbm93blN5bWJvbHNbaysrXSk7XG5cbiRleHBvcnQoJGV4cG9ydC5TICsgJGV4cG9ydC5GICogIVVTRV9OQVRJVkUsICdTeW1ib2wnLCB7XG4gIC8vIDE5LjQuMi4xIFN5bWJvbC5mb3Ioa2V5KVxuICAnZm9yJzogZnVuY3Rpb24gKGtleSkge1xuICAgIHJldHVybiBoYXMoU3ltYm9sUmVnaXN0cnksIGtleSArPSAnJylcbiAgICAgID8gU3ltYm9sUmVnaXN0cnlba2V5XVxuICAgICAgOiBTeW1ib2xSZWdpc3RyeVtrZXldID0gJFN5bWJvbChrZXkpO1xuICB9LFxuICAvLyAxOS40LjIuNSBTeW1ib2wua2V5Rm9yKHN5bSlcbiAga2V5Rm9yOiBmdW5jdGlvbiBrZXlGb3Ioc3ltKSB7XG4gICAgaWYgKCFpc1N5bWJvbChzeW0pKSB0aHJvdyBUeXBlRXJyb3Ioc3ltICsgJyBpcyBub3QgYSBzeW1ib2whJyk7XG4gICAgZm9yICh2YXIga2V5IGluIFN5bWJvbFJlZ2lzdHJ5KSBpZiAoU3ltYm9sUmVnaXN0cnlba2V5XSA9PT0gc3ltKSByZXR1cm4ga2V5O1xuICB9LFxuICB1c2VTZXR0ZXI6IGZ1bmN0aW9uICgpIHsgc2V0dGVyID0gdHJ1ZTsgfSxcbiAgdXNlU2ltcGxlOiBmdW5jdGlvbiAoKSB7IHNldHRlciA9IGZhbHNlOyB9XG59KTtcblxuJGV4cG9ydCgkZXhwb3J0LlMgKyAkZXhwb3J0LkYgKiAhVVNFX05BVElWRSwgJ09iamVjdCcsIHtcbiAgLy8gMTkuMS4yLjIgT2JqZWN0LmNyZWF0ZShPIFssIFByb3BlcnRpZXNdKVxuICBjcmVhdGU6ICRjcmVhdGUsXG4gIC8vIDE5LjEuMi40IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShPLCBQLCBBdHRyaWJ1dGVzKVxuICBkZWZpbmVQcm9wZXJ0eTogJGRlZmluZVByb3BlcnR5LFxuICAvLyAxOS4xLjIuMyBPYmplY3QuZGVmaW5lUHJvcGVydGllcyhPLCBQcm9wZXJ0aWVzKVxuICBkZWZpbmVQcm9wZXJ0aWVzOiAkZGVmaW5lUHJvcGVydGllcyxcbiAgLy8gMTkuMS4yLjYgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihPLCBQKVxuICBnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3I6ICRnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IsXG4gIC8vIDE5LjEuMi43IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKE8pXG4gIGdldE93blByb3BlcnR5TmFtZXM6ICRnZXRPd25Qcm9wZXJ0eU5hbWVzLFxuICAvLyAxOS4xLjIuOCBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKE8pXG4gIGdldE93blByb3BlcnR5U3ltYm9sczogJGdldE93blByb3BlcnR5U3ltYm9sc1xufSk7XG5cbi8vIDI0LjMuMiBKU09OLnN0cmluZ2lmeSh2YWx1ZSBbLCByZXBsYWNlciBbLCBzcGFjZV1dKVxuJEpTT04gJiYgJGV4cG9ydCgkZXhwb3J0LlMgKyAkZXhwb3J0LkYgKiAoIVVTRV9OQVRJVkUgfHwgJGZhaWxzKGZ1bmN0aW9uICgpIHtcbiAgdmFyIFMgPSAkU3ltYm9sKCk7XG4gIC8vIE1TIEVkZ2UgY29udmVydHMgc3ltYm9sIHZhbHVlcyB0byBKU09OIGFzIHt9XG4gIC8vIFdlYktpdCBjb252ZXJ0cyBzeW1ib2wgdmFsdWVzIHRvIEpTT04gYXMgbnVsbFxuICAvLyBWOCB0aHJvd3Mgb24gYm94ZWQgc3ltYm9sc1xuICByZXR1cm4gX3N0cmluZ2lmeShbU10pICE9ICdbbnVsbF0nIHx8IF9zdHJpbmdpZnkoeyBhOiBTIH0pICE9ICd7fScgfHwgX3N0cmluZ2lmeShPYmplY3QoUykpICE9ICd7fSc7XG59KSksICdKU09OJywge1xuICBzdHJpbmdpZnk6IGZ1bmN0aW9uIHN0cmluZ2lmeShpdCkge1xuICAgIHZhciBhcmdzID0gW2l0XTtcbiAgICB2YXIgaSA9IDE7XG4gICAgdmFyIHJlcGxhY2VyLCAkcmVwbGFjZXI7XG4gICAgd2hpbGUgKGFyZ3VtZW50cy5sZW5ndGggPiBpKSBhcmdzLnB1c2goYXJndW1lbnRzW2krK10pO1xuICAgICRyZXBsYWNlciA9IHJlcGxhY2VyID0gYXJnc1sxXTtcbiAgICBpZiAoIWlzT2JqZWN0KHJlcGxhY2VyKSAmJiBpdCA9PT0gdW5kZWZpbmVkIHx8IGlzU3ltYm9sKGl0KSkgcmV0dXJuOyAvLyBJRTggcmV0dXJucyBzdHJpbmcgb24gdW5kZWZpbmVkXG4gICAgaWYgKCFpc0FycmF5KHJlcGxhY2VyKSkgcmVwbGFjZXIgPSBmdW5jdGlvbiAoa2V5LCB2YWx1ZSkge1xuICAgICAgaWYgKHR5cGVvZiAkcmVwbGFjZXIgPT0gJ2Z1bmN0aW9uJykgdmFsdWUgPSAkcmVwbGFjZXIuY2FsbCh0aGlzLCBrZXksIHZhbHVlKTtcbiAgICAgIGlmICghaXNTeW1ib2wodmFsdWUpKSByZXR1cm4gdmFsdWU7XG4gICAgfTtcbiAgICBhcmdzWzFdID0gcmVwbGFjZXI7XG4gICAgcmV0dXJuIF9zdHJpbmdpZnkuYXBwbHkoJEpTT04sIGFyZ3MpO1xuICB9XG59KTtcblxuLy8gMTkuNC4zLjQgU3ltYm9sLnByb3RvdHlwZVtAQHRvUHJpbWl0aXZlXShoaW50KVxuJFN5bWJvbFtQUk9UT1RZUEVdW1RPX1BSSU1JVElWRV0gfHwgcmVxdWlyZSgnLi9faGlkZScpKCRTeW1ib2xbUFJPVE9UWVBFXSwgVE9fUFJJTUlUSVZFLCAkU3ltYm9sW1BST1RPVFlQRV0udmFsdWVPZik7XG4vLyAxOS40LjMuNSBTeW1ib2wucHJvdG90eXBlW0BAdG9TdHJpbmdUYWddXG5zZXRUb1N0cmluZ1RhZygkU3ltYm9sLCAnU3ltYm9sJyk7XG4vLyAyMC4yLjEuOSBNYXRoW0BAdG9TdHJpbmdUYWddXG5zZXRUb1N0cmluZ1RhZyhNYXRoLCAnTWF0aCcsIHRydWUpO1xuLy8gMjQuMy4zIEpTT05bQEB0b1N0cmluZ1RhZ11cbnNldFRvU3RyaW5nVGFnKGdsb2JhbC5KU09OLCAnSlNPTicsIHRydWUpO1xuIiwiLy8gaHR0cHM6Ly9naXRodWIuY29tL3RjMzkvcHJvcG9zYWwtcHJvbWlzZS1maW5hbGx5XG4ndXNlIHN0cmljdCc7XG52YXIgJGV4cG9ydCA9IHJlcXVpcmUoJy4vX2V4cG9ydCcpO1xudmFyIGNvcmUgPSByZXF1aXJlKCcuL19jb3JlJyk7XG52YXIgZ2xvYmFsID0gcmVxdWlyZSgnLi9fZ2xvYmFsJyk7XG52YXIgc3BlY2llc0NvbnN0cnVjdG9yID0gcmVxdWlyZSgnLi9fc3BlY2llcy1jb25zdHJ1Y3RvcicpO1xudmFyIHByb21pc2VSZXNvbHZlID0gcmVxdWlyZSgnLi9fcHJvbWlzZS1yZXNvbHZlJyk7XG5cbiRleHBvcnQoJGV4cG9ydC5QICsgJGV4cG9ydC5SLCAnUHJvbWlzZScsIHsgJ2ZpbmFsbHknOiBmdW5jdGlvbiAob25GaW5hbGx5KSB7XG4gIHZhciBDID0gc3BlY2llc0NvbnN0cnVjdG9yKHRoaXMsIGNvcmUuUHJvbWlzZSB8fCBnbG9iYWwuUHJvbWlzZSk7XG4gIHZhciBpc0Z1bmN0aW9uID0gdHlwZW9mIG9uRmluYWxseSA9PSAnZnVuY3Rpb24nO1xuICByZXR1cm4gdGhpcy50aGVuKFxuICAgIGlzRnVuY3Rpb24gPyBmdW5jdGlvbiAoeCkge1xuICAgICAgcmV0dXJuIHByb21pc2VSZXNvbHZlKEMsIG9uRmluYWxseSgpKS50aGVuKGZ1bmN0aW9uICgpIHsgcmV0dXJuIHg7IH0pO1xuICAgIH0gOiBvbkZpbmFsbHksXG4gICAgaXNGdW5jdGlvbiA/IGZ1bmN0aW9uIChlKSB7XG4gICAgICByZXR1cm4gcHJvbWlzZVJlc29sdmUoQywgb25GaW5hbGx5KCkpLnRoZW4oZnVuY3Rpb24gKCkgeyB0aHJvdyBlOyB9KTtcbiAgICB9IDogb25GaW5hbGx5XG4gICk7XG59IH0pO1xuIiwiJ3VzZSBzdHJpY3QnO1xuLy8gaHR0cHM6Ly9naXRodWIuY29tL3RjMzkvcHJvcG9zYWwtcHJvbWlzZS10cnlcbnZhciAkZXhwb3J0ID0gcmVxdWlyZSgnLi9fZXhwb3J0Jyk7XG52YXIgbmV3UHJvbWlzZUNhcGFiaWxpdHkgPSByZXF1aXJlKCcuL19uZXctcHJvbWlzZS1jYXBhYmlsaXR5Jyk7XG52YXIgcGVyZm9ybSA9IHJlcXVpcmUoJy4vX3BlcmZvcm0nKTtcblxuJGV4cG9ydCgkZXhwb3J0LlMsICdQcm9taXNlJywgeyAndHJ5JzogZnVuY3Rpb24gKGNhbGxiYWNrZm4pIHtcbiAgdmFyIHByb21pc2VDYXBhYmlsaXR5ID0gbmV3UHJvbWlzZUNhcGFiaWxpdHkuZih0aGlzKTtcbiAgdmFyIHJlc3VsdCA9IHBlcmZvcm0oY2FsbGJhY2tmbik7XG4gIChyZXN1bHQuZSA/IHByb21pc2VDYXBhYmlsaXR5LnJlamVjdCA6IHByb21pc2VDYXBhYmlsaXR5LnJlc29sdmUpKHJlc3VsdC52KTtcbiAgcmV0dXJuIHByb21pc2VDYXBhYmlsaXR5LnByb21pc2U7XG59IH0pO1xuIiwicmVxdWlyZSgnLi9fd2tzLWRlZmluZScpKCdhc3luY0l0ZXJhdG9yJyk7XG4iLCJyZXF1aXJlKCcuL193a3MtZGVmaW5lJykoJ29ic2VydmFibGUnKTtcbiIsInJlcXVpcmUoJy4vZXM2LmFycmF5Lml0ZXJhdG9yJyk7XG52YXIgZ2xvYmFsID0gcmVxdWlyZSgnLi9fZ2xvYmFsJyk7XG52YXIgaGlkZSA9IHJlcXVpcmUoJy4vX2hpZGUnKTtcbnZhciBJdGVyYXRvcnMgPSByZXF1aXJlKCcuL19pdGVyYXRvcnMnKTtcbnZhciBUT19TVFJJTkdfVEFHID0gcmVxdWlyZSgnLi9fd2tzJykoJ3RvU3RyaW5nVGFnJyk7XG5cbnZhciBET01JdGVyYWJsZXMgPSAoJ0NTU1J1bGVMaXN0LENTU1N0eWxlRGVjbGFyYXRpb24sQ1NTVmFsdWVMaXN0LENsaWVudFJlY3RMaXN0LERPTVJlY3RMaXN0LERPTVN0cmluZ0xpc3QsJyArXG4gICdET01Ub2tlbkxpc3QsRGF0YVRyYW5zZmVySXRlbUxpc3QsRmlsZUxpc3QsSFRNTEFsbENvbGxlY3Rpb24sSFRNTENvbGxlY3Rpb24sSFRNTEZvcm1FbGVtZW50LEhUTUxTZWxlY3RFbGVtZW50LCcgK1xuICAnTWVkaWFMaXN0LE1pbWVUeXBlQXJyYXksTmFtZWROb2RlTWFwLE5vZGVMaXN0LFBhaW50UmVxdWVzdExpc3QsUGx1Z2luLFBsdWdpbkFycmF5LFNWR0xlbmd0aExpc3QsU1ZHTnVtYmVyTGlzdCwnICtcbiAgJ1NWR1BhdGhTZWdMaXN0LFNWR1BvaW50TGlzdCxTVkdTdHJpbmdMaXN0LFNWR1RyYW5zZm9ybUxpc3QsU291cmNlQnVmZmVyTGlzdCxTdHlsZVNoZWV0TGlzdCxUZXh0VHJhY2tDdWVMaXN0LCcgK1xuICAnVGV4dFRyYWNrTGlzdCxUb3VjaExpc3QnKS5zcGxpdCgnLCcpO1xuXG5mb3IgKHZhciBpID0gMDsgaSA8IERPTUl0ZXJhYmxlcy5sZW5ndGg7IGkrKykge1xuICB2YXIgTkFNRSA9IERPTUl0ZXJhYmxlc1tpXTtcbiAgdmFyIENvbGxlY3Rpb24gPSBnbG9iYWxbTkFNRV07XG4gIHZhciBwcm90byA9IENvbGxlY3Rpb24gJiYgQ29sbGVjdGlvbi5wcm90b3R5cGU7XG4gIGlmIChwcm90byAmJiAhcHJvdG9bVE9fU1RSSU5HX1RBR10pIGhpZGUocHJvdG8sIFRPX1NUUklOR19UQUcsIE5BTUUpO1xuICBJdGVyYXRvcnNbTkFNRV0gPSBJdGVyYXRvcnMuQXJyYXk7XG59XG4iLCIvKipcbiAqIENyZWF0ZWQgYnkgVGFtZXIgb24gMDYvMTEvMjAxNy5cbiAqL1xuXG4vKipcbiAqIEBjbGFzcyBBY3Rpb25zXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEFjdGlvbnMge1xuICAvKipcbiAgICogQ3JlYXRlcyBhbiBpbnN0YW5jZSBvZiBBY3Rpb25zLlxuICAgKiBcbiAgICogQHBhcmFtIHtvYmplY3R9IFxuICAgKiBAbWVtYmVyb2YgQWN0aW9uc1xuICAgKiBAYWNjZXNzIHB1YmxpY1xuICAgKi9cbiAgY29uc3RydWN0b3Iobykge1xuICAgIHRoaXMudG9vbGJveCA9IG8udG9vbGJveDtcbiAgICB0aGlzLmRlcGxveW1lbnRJZCA9IG8uZGVwbG95bWVudElkO1xuICAgIHRoaXMuYmx1ZXByaW50SWQgPSBvLmJsdWVwcmludElkO1xuICB9XG5cbiAgLyoqXG4gICAqIGdldCBvdXRwdXQgZGF0YVxuICAgKiBcbiAgICogQHJldHVybnMgXG4gICAqIEBtZW1iZXJvZiBBY3Rpb25zXG4gICAqIEBhY2Nlc3MgcHVibGljXG4gICAqL1xuICBkb0dldERlcGxveW1lbnQoKSB7XG4gICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShbXG4gICAgICB7XG4gICAgICAgIGlkOiAnb3MnLFxuICAgICAgICB0eXBlOiAnZHJvcGRvd24nLFxuICAgICAgICBmbGV4OiAxMDAsXG4gICAgICAgIHBvc2l0aW9uOiA1MCxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgbGFiZWw6ICdPcGVyYXRpbmcgU3lzdGVtJyxcbiAgICAgICAgICBwbGFjZWhvbGRlcjogJ1BsZWFzZSBTZWxlY3QgdGhlIE9TJyxcbiAgICAgICAgICBtdWx0aXBsZTogZmFsc2UsXG4gICAgICAgICAgb3B0aW9uczogW1xuICAgICAgICAgICAgeyB0ZXh0OiAnV2luZG93cycsIHZhbHVlOiAnd2luZG93cycgfSxcbiAgICAgICAgICAgIHsgdGV4dDogJ0xpbnV4JywgdmFsdWU6ICdsaW51eCcgfVxuICAgICAgICAgIF1cbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgaWQ6ICdteV9idXR0b24nLFxuICAgICAgICB0eXBlOiAnYnV0dG9uJyxcbiAgICAgICAgZmxleDogMTAwLFxuICAgICAgICBwb3NpdGlvbjogMTAxLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICBsYWJlbDogJ015IEJ1dHRvbicsXG4gICAgICAgICAgY2lyY3VsYXI6IGZhbHNlLFxuICAgICAgICAgIGljb246ICdmYWNlYm9vaycsIC8vIGxpc3Qgb2YgaWNvbnMgaHR0cHM6Ly9yZWFjdC5zZW1hbnRpYy11aS5jb20vZWxlbWVudHMvaWNvbiBsYWJlbCB3aWxsIG92ZXJ3cml0ZVxuICAgICAgICAgIGNvbG9yOiAnZ3JlZW4nLCAvLyByZWQsIG9yYW5nZSwgeWVsbG93LCBvbGl2ZSwgZ3JlZW4sIHRlYWwsIGJsdWUsIHZpb2xldCwgcHVycGxlLCBwaW5rLCBicm93biwgZ3JleSwgYmxhY2ssXG4gICAgICAgICAgYWN0aW9uOiAnY3JlYXRlRGVwbG95bWVudCdcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGlkOiAnbXlfaW5wdXQnLFxuICAgICAgICB0eXBlOiAnaW5wdXQnLFxuICAgICAgICBmbGV4OiAzMyxcbiAgICAgICAgcG9zaXRpb246IDk5LFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICBsYWJlbDogJ015IElucHV0JyxcbiAgICAgICAgICBkZWZhdWx0OiAnSGVsbG8gSW5wdXQnLFxuICAgICAgICAgIHBsYWNlaG9sZGVyOiAnUGxlYXNlIEVudGVyIFlvdXIgRGF0YScsXG4gICAgICAgICAgaXNQYXNzd29yZDogZmFsc2VcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgaWQ6ICdteV9jaGVja2JveCcsXG4gICAgICAgIHR5cGU6ICdjaGVja2JveCcsXG4gICAgICAgIGZsZXg6IDMzLFxuICAgICAgICBwb3NpdGlvbjogOTksXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIGxhYmVsOiAnTXkgQ2hlY2tib3gnLFxuICAgICAgICAgIGRlZmF1bHQ6IHRydWVcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgaWQ6ICdteV90b2dnbGUnLFxuICAgICAgICB0eXBlOiAndG9nZ2xlJyxcbiAgICAgICAgZmxleDogMzMsXG4gICAgICAgIHBvc2l0aW9uOiA5OSxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgbGFiZWw6ICdNeSBUb2dnbGUnLFxuICAgICAgICAgIGRlZmF1bHQ6IHRydWVcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgaWQ6ICdteV9yYWRpbycsXG4gICAgICAgIHR5cGU6ICdyYWRpbycsXG4gICAgICAgIGZsZXg6IDMzLFxuICAgICAgICBwb3NpdGlvbjogOTksXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIGxhYmVsOiAnTXkgUmFkaW8nLFxuICAgICAgICAgIGRlZmF1bHQ6ICdvcDEnLFxuICAgICAgICAgIG9wdGlvbnM6IFtcbiAgICAgICAgICAgIHsgdGV4dDogJ09wdGlvbiAxJywgdmFsdWU6ICdvcDEnIH0sXG4gICAgICAgICAgICB7IHRleHQ6ICdPcHRpb24gMicsIHZhbHVlOiAnb3AyJyB9LFxuICAgICAgICAgICAgeyB0ZXh0OiAnT3B0aW9uIDMnLCB2YWx1ZTogJ29wMycgfVxuICAgICAgICAgIF1cbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgaWQ6ICdteV9kcm9wZG93bicsXG4gICAgICAgIHR5cGU6ICdkcm9wZG93bicsXG4gICAgICAgIGZsZXg6IDMzLFxuICAgICAgICBwb3NpdGlvbjogOTksXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIGxhYmVsOiAnTXkgRHJvcGRvd24nLFxuICAgICAgICAgIHBsYWNlaG9sZGVyOiAnSGVsbG8gRHJvcGRvd24nLFxuICAgICAgICAgIG11bHRpcGxlOiB0cnVlLFxuICAgICAgICAgIGRlZmF1bHQ6IFsnb3AxJ10sXG4gICAgICAgICAgb3B0aW9uczogW1xuICAgICAgICAgICAgeyB0ZXh0OiAnT3B0aW9uIDEnLCB2YWx1ZTogJ29wMScgfSxcbiAgICAgICAgICAgIHsgdGV4dDogJ09wdGlvbiAyJywgdmFsdWU6ICdvcDInIH0sXG4gICAgICAgICAgICB7IHRleHQ6ICdPcHRpb24gMycsIHZhbHVlOiAnb3AzJyB9XG4gICAgICAgICAgXVxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBpZDogJ215X3JhbmdlJyxcbiAgICAgICAgdHlwZTogJ3JhbmdlJyxcbiAgICAgICAgZmxleDogMzMsXG4gICAgICAgIHBvc2l0aW9uOiA5OSxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgbGFiZWw6ICdNeSBSYW5nZScsXG4gICAgICAgICAgZGVmYXVsdDogMjAsXG4gICAgICAgICAgc3RlcDogMSxcbiAgICAgICAgICBtaW46IDAsXG4gICAgICAgICAgbWF4OiAxMDBcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgdHlwZTogJ21lc3NhZ2UnLFxuICAgICAgICBmbGV4OiAzMyxcbiAgICAgICAgcG9zaXRpb246IDk5LFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICBsYWJlbDogJ0hlbGxvIGkgYW0gYSBNZXNzYWdlJyxcbiAgICAgICAgICBjb2xvcjogJ2dyZWVuJ1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBpZDogJ215X3NlbGVjdGJveCcsXG4gICAgICAgIHR5cGU6ICdzZWxlY3Rib3gnLFxuICAgICAgICBmbGV4OiAxMDAsXG4gICAgICAgIHBvc2l0aW9uOiA5NyxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgbGFiZWw6ICdNeSBTZWxlY3RCb3gnLFxuICAgICAgICAgIHRlbXBsYXRlOiAnPGgxPnt7dGV4dH19PC9oMT48cD57e3ZhbHVlfX08L3A+JyxcbiAgICAgICAgICBzdHlsZTogMSwgLy8gMSBvciAyXG4gICAgICAgICAgZGVmYXVsdDogJzJiJyxcbiAgICAgICAgICBvcHRpb25zOiBbXG4gICAgICAgICAgICB7IHRleHQ6ICd4LXNtYWxsJywgdmFsdWU6ICcxbScgfSxcbiAgICAgICAgICAgIHsgdGV4dDogJ3NtYWxsJywgdmFsdWU6ICcyYicgfSxcbiAgICAgICAgICAgIHsgdGV4dDogJ21lZGl1bScsIHZhbHVlOiAnM20nIH0sXG4gICAgICAgICAgICB7IHRleHQ6ICdsYXJnZScsIHZhbHVlOiAnNWwnIH1cbiAgICAgICAgICBdXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICBdKTtcbiAgICAvLyByZXR1cm4gdGhpcy50b29sYm94LmdldE1hbmFnZXIoKS5kb0dldChgL2RlcGxveW1lbnRzLyR7dGhpcy5kZXBsb3ltZW50SWR9YCk7XG4gIH1cblxuICBkb0dldElucHV0RGVzY3JpcHRvcihwYXRoID0gJ2lucHV0X2Rlc2NyaXB0b3IueWFtbCcpIHtcbiAgICBjb25zb2xlLmxvZyh7cGF0aH0pXG4gICAgcmV0dXJuIHRoaXMuZG9HZXRGaWxlc1RyZWUodGhpcy5ibHVlcHJpbnRJZCkudGhlbihmaWxlcyA9PiB7XG4gICAgICBsZXQgZmlsZSA9IGZpbGVzLmNoaWxkcmVuWzBdLmNoaWxkcmVuLmZpbmQoaXRlbSA9PiBpdGVtLnRpdGxlID09PSBwYXRoKTtcbiAgICAgIGlmKGZpbGUpe1xuICAgICAgICByZXR1cm4gdGhpcy5kb0dldEZpbGVDb250ZW50KGZpbGUua2V5KTtcbiAgICAgIH1lbHNle1xuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QoYCR7cGF0aH0gbm90IGZvdW5kLmApO1xuICAgICAgfVxuICAgIH0pXG4gIH1cblxuICBkb0dldEJsdWVwcmludElkKGRlcGxveW1lbnRJZCkge1xuICAgIHJldHVybiB0aGlzLnRvb2xib3guZ2V0TWFuYWdlcigpLmRvR2V0KGAvZGVwbG95bWVudHMvJHtkZXBsb3ltZW50SWR9P19pbmNsdWRlPWlkLGJsdWVwcmludF9pZGApO1xuICB9XG5cbiAgZG9HZXRGaWxlc1RyZWUoYmx1ZXByaW50SWQpIHtcbiAgICByZXR1cm4gdGhpcy50b29sYm94LmdldEludGVybmFsKCkuZG9HZXQoYC9zb3VyY2UvYnJvd3NlLyR7Ymx1ZXByaW50SWR9L2FyY2hpdmVgKTtcbiAgfVxuXG4gIGRvR2V0RmlsZUNvbnRlbnQocGF0aCkge1xuICAgIHJldHVybiB0aGlzLnRvb2xib3guZ2V0SW50ZXJuYWwoKS5kb0dldCgnL3NvdXJjZS9icm93c2UvZmlsZScsIHsgcGF0aCB9KTtcbiAgfVxufVxuIiwiLyoqXG4gKiBDcmVhdGVkIGJ5IFRhbWVyIG9uIDE5LzEwLzIwMTcuXG4gKi9cbmltcG9ydCBZQU1MIGZyb20gJy4vdXRpbHMvWUFNTCc7XG5pbXBvcnQgYmFzZTEwdG82NCBmcm9tICcuL3V0aWxzL2Jhc2UxMHRvNjQnO1xuaW1wb3J0IFNlbGVjdEJveCBmcm9tICcuL2NvbXBvbmVudHMvU2VsZWN0Qm94JztcblxuLyoqXG4gKiBAY2xhc3MgTGlzdFxuICogQGV4dGVuZHMge0NvbXBvbmVudH1cbiAqL1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTGlzdCBleHRlbmRzIFJlYWN0LkNvbXBvbmVudCB7XG4gIC8qKlxuICAgKiBDcmVhdGVzIGFuIGluc3RhbmNlIG9mIExpc3QuXG4gICAqIEBwYXJhbSB7YW55fSBwcm9wcyBcbiAgICogQHBhcmFtIHthbnl9IGNvbnRleHQgXG4gICAqL1xuICBjb25zdHJ1Y3Rvcihwcm9wcywgY29udGV4dCkge1xuICAgIHN1cGVyKHByb3BzLCBjb250ZXh0KTtcblxuICAgIHRoaXMuc3RhdGUgPSB7XG4gICAgICBmb3JtOiB7fSxcbiAgICAgIHZpc3VhbF9kYXRhOiB7fSxcbiAgICAgIGVycm9yczoge30sXG4gICAgICBzdWNjZXNzOiBudWxsLFxuICAgICAgZGVwbG95bWVudFRpdGxlOiAnJyxcbiAgICAgIGxvYWRpbmc6IGZhbHNlLFxuICAgICAgeWFtbEVycm9yOiBudWxsXG4gICAgfTtcbiAgfVxuXG4gIGNvbXBvbmVudFdpbGxNb3VudCgpIHtcbiAgICBsZXQgZGF0YSA9IHRoaXMucHJvcHMuZGF0YTtcbiAgICB0aGlzLnByb3BzLnRvb2xib3guZ2V0RXZlbnRCdXMoKS5vbignZGV2bW9kZTpyZW5kZXInLCByZXMgPT4gcmVzLndpZGdldElkID09PSB0aGlzLnByb3BzLndpZGdldC5pZCAmJiB0aGlzLnJlbmRlckpTT04yWUFNTChyZXMuZGF0YSksIHRoaXMpO1xuICAgIHRoaXMucHJvcHMudG9vbGJveC5nZXRFdmVudEJ1cygpLnRyaWdnZXIoJ2Rldm1vZGU6dXBkYXRlJywgZGF0YSwgdGhpcy5wcm9wcy53aWRnZXQpO1xuICAgIFxuICAgIHRoaXMudXBkYXRlRGVwbG95bWVudE5hbWUoKTtcbiAgICB0aGlzLnJlbmRlckpTT04yWUFNTChkYXRhKTtcbiAgfVxuICBjb21wb25lbnRXaWxsVW5tb3VudCgpIHtcbiAgICB0aGlzLnByb3BzLnRvb2xib3guZ2V0RXZlbnRCdXMoKS5vZmYoJ2Rldm1vZGU6cmVuZGVyJywgdGhpcy5fZGV2bW9kZSwgdGhpcyk7XG4gIH1cblxuICB1cGRhdGVEZXBsb3ltZW50TmFtZSgpe1xuICAgIGNvbnN0IHVzZXIgPSB0aGlzLnByb3BzLnRvb2xib3guZ2V0TWFuYWdlcigpLmdldEN1cnJlbnRVc2VybmFtZSgpO1xuICAgIGNvbnN0IGJsdWVwcmludCA9IHRoaXMucHJvcHMud2lkZ2V0LmNvbmZpZ3VyYXRpb24uYmx1ZXByaW50SWQ7XG4gICAgY29uc3QgdGltZTY0ID0gYmFzZTEwdG82NChNYXRoLmZsb29yKERhdGUubm93KCkgLyAxMDAwKSk7XG4gICAgY29uc3QgZGVwbG95bWVudFRpdGxlID0gYGFkbWluIGRlcGxveW1lbnQgJHt1c2VyfV8ke2JsdWVwcmludH1fJHt0aW1lNjR9YDtcbiAgICB0aGlzLnNldFN0YXRlKHtkZXBsb3ltZW50VGl0bGV9KTtcbiAgfVxuXG4gIHJlbmRlckpTT04yWUFNTCh2YWx1ZSkge1xuICAgIHRoaXMuc2V0U3RhdGUoeyB5YW1sRXJyb3I6IG51bGwgfSlcbiAgICB0cnkge1xuICAgICAgbGV0IGRhdGEgPSBZQU1MLnBhcnNlKHZhbHVlKTtcbiAgICAgIHRoaXMucHJlcGFyZURhdGEoZGF0YSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgdGhpcy5zZXRTdGF0ZSh7IHlhbWxFcnJvcjogZS5tZXNzYWdlIH0pXG4gICAgfVxuICB9XG5cbiAgcHJlcGFyZURhdGEoZGF0YSkge1xuXG4gICAgLy8gZXh0cmFjdCBhdmFpbGFibGUgaW5wdXRzIHRvIHRoZSBsb29wXG4gICAgY29uc3QgdmlzdWFsX2RhdGEgPSBkYXRhLmZpbHRlcihlID0+IFtcbiAgICAgICdidXR0b24nLFxuICAgICAgJ2lucHV0JyxcbiAgICAgICd0ZXh0YXJlYScsXG4gICAgICAnY2hlY2tib3gnLFxuICAgICAgJ3RvZ2dsZScsXG4gICAgICAncmFkaW8nLFxuICAgICAgJ2Ryb3Bkb3duJyxcbiAgICAgICdyYW5nZScsXG4gICAgICAnbWVzc2FnZScsXG4gICAgICAnc2VsZWN0Ym94J1xuICAgIF0uaW5jbHVkZXMoZS50eXBlKSk7XG5cbiAgICBjb25zb2xlLmxvZyh7IHZpc3VhbF9kYXRhIH0pXG5cbiAgICAvLyBzb3J0IGl0ZW1zIGJ5IHBvc2l0aW9uXG4gICAgdmlzdWFsX2RhdGEuc29ydCgoYSwgYikgPT4gYS5wb3NpdGlvbiAtIGIucG9zaXRpb24pO1xuXG4gICAgLy8gc2V0IGRlZmF1bHQgZGF0YVxuICAgIGxldCBmb3JtID0ge307XG4gICAgdmlzdWFsX2RhdGEuZm9yRWFjaChpdGVtID0+IHtcbiAgICAgIGlmIChpdGVtLmlkICYmIGl0ZW0udHlwZSAhPT0gJ2J1dHRvbicpIHtcbiAgICAgICAgZm9ybVtpdGVtLmlkXSA9IGl0ZW0ucGFyYW1zLmRlZmF1bHQ7XG4gICAgICB9XG4gICAgfSlcbiAgICB0aGlzLnNldFN0YXRlKHsgZm9ybSwgdmlzdWFsX2RhdGEgfSk7XG4gIH1cblxuICBoYW5kbGVDaGFuZ2UgPSAoaWQsIHZhbHVlKSA9PiB7XG4gICAgLy8gVE9ETzogYmVmb3JlIHN1Ym1pdCBjaGVjayBmb3IgYXJyYXlzIHRvIGpvaW4gdGhlbVxuICAgIHRoaXMuc2V0U3RhdGUoeyBmb3JtOiBPYmplY3QuYXNzaWduKHRoaXMuc3RhdGUuZm9ybSwgeyBbaWRdOiB2YWx1ZSB9KSB9KTtcbiAgICBjb25zb2xlLmxvZygnZm9ybSBzdGF0ZScsIHRoaXMuc3RhdGUuZm9ybSk7XG4gIH1cblxuICBfY3JlYXRlRGVwbG95bWVudCA9ICgpID0+IHtcbiAgICBsZXQgZXJyb3JzID0ge307XG4gICAgT2JqZWN0LmtleXModGhpcy5zdGF0ZS5mb3JtKS5mb3JFYWNoKGl0ZW0gPT4ge1xuICAgICAgLy8gVE9ETzogYWRkIG1vcmUgdmFsaWRhdGlvbnMgbWV0aG9kcywgYnkgZGVmYXVsdCBub3cgaXMgcmVxdWlyZWRcbiAgICAgIGlmIChfLmlzTmlsKHRoaXMuc3RhdGUuZm9ybVtpdGVtXSkgfHwgdGhpcy5zdGF0ZS5mb3JtW2l0ZW1dID09PSAnJykge1xuICAgICAgICBlcnJvcnNbaXRlbV0gPSAncmVxdWlyZWQnO1xuICAgICAgfVxuICAgIH0pO1xuICAgIGlmIChPYmplY3Qua2V5cyhlcnJvcnMpLmxlbmd0aCAhPT0gMCkge1xuICAgICAgZXJyb3JzLmVycm9yID0gJ1BsZWFzZSBjaGVjayBlcnJvcnMgZ2l2ZW4gYmVsb3cnO1xuICAgIH1cbiAgICB0aGlzLnNldFN0YXRlKHsgZXJyb3JzIH0pO1xuICAgIGlmIChPYmplY3Qua2V5cyhlcnJvcnMpLmxlbmd0aCA9PT0gMCkge1xuXG4gICAgICBjb25zdCBibHVlcHJpbnQgPSB0aGlzLnByb3BzLndpZGdldC5jb25maWd1cmF0aW9uLmJsdWVwcmludElkO1xuICAgICAgY29uc3QgZGVwbG95bWVudCA9IHRoaXMuc3RhdGUuZGVwbG95bWVudFRpdGxlO1xuICAgICAgY29uc3QgdmlzaWJpbGl0eSA9ICd0ZW5hbnQnO1xuICAgICAgY29uc3Qgc2tpcFBsdWdpbnNWYWxpZGF0aW9uID0gZmFsc2U7XG4gICAgICBcbiAgICAgIGNvbnN0IGJsdWVwcmludF9pZCA9IHRoaXMuc3RhdGUuZm9ybS5ibHVlcHJpbnRfaWQgfHwgJ3NlcnZpY2UnO1xuICAgICAgbGV0IGRlcGxveW1lbnRfaW5wdXRzID0gdGhpcy5zdGF0ZS5mb3JtO1xuICAgICAgaWYoZGVwbG95bWVudF9pbnB1dHMuYmx1ZXByaW50X2lkKXtcbiAgICAgICAgZGVsZXRlIGRlcGxveW1lbnRfaW5wdXRzLmJsdWVwcmludF9pZDtcbiAgICAgIH1cblxuICAgICAgY29uc3QgaW5wdXRzID0ge1xuICAgICAgICBibHVlcHJpbnRfaWQsXG4gICAgICAgIGRlcGxveW1lbnRfaW5wdXRzXG4gICAgICB9XG4gICAgICBjb25zb2xlLmxvZygnaW5wdXRzJywgaW5wdXRzKTtcbiAgICAgIHRoaXMuc2V0U3RhdGUoeyBsb2FkaW5nOiB0cnVlIH0pO1xuICAgICAgdmFyIGFjdGlvbnMgPSBuZXcgU3RhZ2UuQ29tbW9uLkJsdWVwcmludEFjdGlvbnModGhpcy5wcm9wcy50b29sYm94KTtcbiAgICAgIGFjdGlvbnMuZG9EZXBsb3koeyBpZDogYmx1ZXByaW50IH0sIGRlcGxveW1lbnQsIGlucHV0cywgdmlzaWJpbGl0eSwgc2tpcFBsdWdpbnNWYWxpZGF0aW9uKVxuICAgICAgICAudGhlbigoZGVwbG95bWVudCkgPT4ge1xuICAgICAgICAgIHRoaXMudXBkYXRlRGVwbG95bWVudE5hbWUoKTtcbiAgICAgICAgICB0aGlzLnNldFN0YXRlKHsgbG9hZGluZzogZmFsc2UsIGVycm9yczoge30sIHN1Y2Nlc3M6ICdZb3VyIHJlcXVlc3QgaGFzIGJlZW4gc3VibWl0dGVkIGFuZCBhd2FpdGluZyBhcHByb3ZhbCcgfSk7XG4gICAgICAgICAgY29uc3Qgb25GaW5pc2hSZWRpcmVjdCA9IHRoaXMucHJvcHMud2lkZ2V0LmNvbmZpZ3VyYXRpb24ub25GaW5pc2hSZWRpcmVjdDtcbiAgICAgICAgICBjb25zdCB0ZW1wbGF0ZSA9IHRoaXMucHJvcHMud2lkZ2V0LmNvbmZpZ3VyYXRpb24udGVtcGxhdGU7XG4gICAgICAgICAgaWYgKG9uRmluaXNoUmVkaXJlY3QpIHtcbiAgICAgICAgICAgIHRoaXMucHJvcHMudG9vbGJveC5kcmlsbERvd24odGhpcy5wcm9wcy53aWRnZXQsIHRlbXBsYXRlLCB7IGRlcGxveW1lbnRJZDogZGVwbG95bWVudC5pZCB9LCBkZXBsb3ltZW50LmlkKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgICAgIC5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7IGxvYWRpbmc6IGZhbHNlLCBlcnJvcnM6IHsgZXJyb3I6IGVyci5tZXNzYWdlIH0gfSk7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgfVxuXG4gIC8qXG4gIHwtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICB8IFJlYWN0IFJlbmRlcmVyXG4gIHwtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAqL1xuICByZW5kZXIoKSB7XG4gICAgaWYgKHRoaXMuc3RhdGUubG9hZGluZykge1xuICAgICAgcmV0dXJuIDxTdGFnZS5CYXNpYy5Mb2FkaW5nIC8+O1xuICAgIH1cblxuICAgIGNvbnN0IHtCdXR0b24sIElucHV0LCBDaGVja2JveCwgRHJvcGRvd24sIE1lc3NhZ2UsIENhcmR9ID0gU3RhZ2UuQmFzaWM7XG5cbiAgICAvKipcbiAgICAgKiBjaGFydHMgdmlzdWFsIG91dHB1dFxuICAgICAqL1xuICAgIGNvbnN0IHZpc3VhbHMgPSB0aGlzLnN0YXRlLnZpc3VhbF9kYXRhLm1hcCgoaXRlbSwgaWR4KSA9PiA8ZGl2IGNsYXNzTmFtZT0nY2hhcnQtYm94JyBrZXk9e2lkeH0gc3R5bGU9e3sgZmxleEJhc2lzOiAoaXRlbS5mbGV4IHx8IDMzKSArICclJyB9fT5cblxuICAgICAge2l0ZW0udHlwZSA9PT0gJ2J1dHRvbicgJiYgPEJ1dHRvblxuICAgICAgICBmbHVpZD17IWl0ZW0ucGFyYW1zLmNpcmN1bGFyfVxuICAgICAgICBjb2xvcj17aXRlbS5wYXJhbXMuY29sb3J9XG4gICAgICAgIGNpcmN1bGFyPXtpdGVtLnBhcmFtcy5jaXJjdWxhcn1cbiAgICAgICAgaWNvbj17aXRlbS5wYXJhbXMubGFiZWwgPyBmYWxzZSA6IGl0ZW0ucGFyYW1zLmljb259XG4gICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICBpdGVtLnBhcmFtcy5hY3Rpb24gPT09ICdjcmVhdGVEZXBsb3ltZW50JyAmJiB0aGlzLl9jcmVhdGVEZXBsb3ltZW50LmNhbGwodGhpcyk7XG4gICAgICAgIH0gfVxuICAgICAgICA+XG4gICAgICAgIHtpdGVtLnBhcmFtcy5sYWJlbH1cbiAgICAgIDwvQnV0dG9uPn1cblxuICAgICAge2l0ZW0udHlwZSA9PT0gJ2lucHV0JyAmJiA8SW5wdXRcbiAgICAgICAgZmx1aWRcbiAgICAgICAgdHlwZT17aXRlbS5wYXJhbXMuaXNQYXNzd29yZCA/ICdwYXNzd29yZCcgOiAndGV4dCd9XG4gICAgICAgIGxhYmVsPXtpdGVtLnBhcmFtcy5sYWJlbH1cbiAgICAgICAgcGxhY2Vob2xkZXI9e2l0ZW0ucGFyYW1zLnBsYWNlaG9sZGVyfVxuICAgICAgICB2YWx1ZT17dGhpcy5zdGF0ZS5mb3JtW2l0ZW0uaWRdfVxuICAgICAgICBvbkNoYW5nZT17KHByb3h5LCBvcHRpb25zKSA9PiB0aGlzLmhhbmRsZUNoYW5nZS5jYWxsKHRoaXMsIGl0ZW0uaWQsIG9wdGlvbnMudmFsdWUpfVxuICAgICAgICAvPn1cblxuICAgICAge2l0ZW0udHlwZSA9PT0gJ2NoZWNrYm94JyAmJiA8Q2hlY2tib3hcbiAgICAgICAgbGFiZWw9e2l0ZW0ucGFyYW1zLmxhYmVsfVxuICAgICAgICBjaGVja2VkPXt0aGlzLnN0YXRlLmZvcm1baXRlbS5pZF19XG4gICAgICAgIG9uQ2hhbmdlPXsocHJveHksIG9wdGlvbnMpID0+IHRoaXMuaGFuZGxlQ2hhbmdlLmNhbGwodGhpcywgaXRlbS5pZCwgb3B0aW9ucy5jaGVja2VkKX1cbiAgICAgICAgLz59XG5cbiAgICAgIHtpdGVtLnR5cGUgPT09ICd0b2dnbGUnICYmIDxDaGVja2JveFxuICAgICAgICB0b2dnbGVcbiAgICAgICAgbGFiZWw9e2l0ZW0ucGFyYW1zLmxhYmVsfVxuICAgICAgICBjaGVja2VkPXt0aGlzLnN0YXRlLmZvcm1baXRlbS5pZF19XG4gICAgICAgIG9uQ2hhbmdlPXsocHJveHksIG9wdGlvbnMpID0+IHRoaXMuaGFuZGxlQ2hhbmdlLmNhbGwodGhpcywgaXRlbS5pZCwgb3B0aW9ucy5jaGVja2VkKX1cbiAgICAgICAgLz59XG5cbiAgICAgIHtpdGVtLnR5cGUgPT09ICdyYWRpbycgJiYgPGRpdj5cbiAgICAgICAgPGI+e2l0ZW0ucGFyYW1zLmxhYmVsfTwvYj5cbiAgICAgICAgPGJyIC8+XG4gICAgICAgIDxiciAvPlxuICAgICAgICB7aXRlbS5wYXJhbXMub3B0aW9ucy5tYXAoKG9wdGlvbiwgaWR4KSA9PiA8ZGl2IGtleT17aWR4fT5cbiAgICAgICAgICA8Q2hlY2tib3hcbiAgICAgICAgICAgIHJhZGlvXG4gICAgICAgICAgICBuYW1lPXtpdGVtLmlkfVxuICAgICAgICAgICAgbGFiZWw9e29wdGlvbi50ZXh0fVxuICAgICAgICAgICAgdmFsdWU9e29wdGlvbi52YWx1ZX1cbiAgICAgICAgICAgIGNoZWNrZWQ9e3RoaXMuc3RhdGUuZm9ybVtpdGVtLmlkXSA9PT0gb3B0aW9uLnZhbHVlfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhwcm94eSwgb3B0aW9ucykgPT4gdGhpcy5oYW5kbGVDaGFuZ2UuY2FsbCh0aGlzLCBpdGVtLmlkLCBvcHRpb25zLnZhbHVlKX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2Pil9XG4gICAgICA8L2Rpdj59XG5cbiAgICAgIHtpdGVtLnR5cGUgPT09ICdkcm9wZG93bicgJiYgPGRpdj5cbiAgICAgICAgPGI+e2l0ZW0ucGFyYW1zLmxhYmVsfTwvYj5cbiAgICAgICAgPGJyIC8+XG4gICAgICAgIDxiciAvPlxuICAgICAgICA8RHJvcGRvd25cbiAgICAgICAgICBmbHVpZFxuICAgICAgICAgIHNlbGVjdGlvblxuICAgICAgICAgIG11bHRpcGxlPXtpdGVtLnBhcmFtcy5tdWx0aXBsZX1cbiAgICAgICAgICBwbGFjZWhvbGRlcj17aXRlbS5wYXJhbXMucGxhY2Vob2xkZXJ9XG4gICAgICAgICAgb3B0aW9ucz17aXRlbS5wYXJhbXMub3B0aW9uc31cbiAgICAgICAgICB2YWx1ZT17dGhpcy5zdGF0ZS5mb3JtW2l0ZW0uaWRdfVxuICAgICAgICAgIG9uQ2hhbmdlPXsocHJveHksIG9wdGlvbnMpID0+IHRoaXMuaGFuZGxlQ2hhbmdlLmNhbGwodGhpcywgaXRlbS5pZCwgb3B0aW9ucy52YWx1ZSl9XG4gICAgICAgICAgLz5cbiAgICAgIDwvZGl2Pn1cblxuICAgICAge2l0ZW0udHlwZSA9PT0gJ3JhbmdlJyAmJiA8ZGl2PlxuICAgICAgICA8Yj57aXRlbS5wYXJhbXMubGFiZWx9PC9iPlxuICAgICAgICA8YnIgLz5cbiAgICAgICAgPGJyIC8+XG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIHR5cGU9XCJyYW5nZVwiXG4gICAgICAgICAgc3RlcD17aXRlbS5wYXJhbXMuc3RlcCB8fCAxfVxuICAgICAgICAgIG1pbj17aXRlbS5wYXJhbXMubWluIHx8IDB9XG4gICAgICAgICAgbWF4PXtpdGVtLnBhcmFtcy5tYXggfHwgMTAwfVxuICAgICAgICAgIHZhbHVlPXt0aGlzLnN0YXRlLmZvcm1baXRlbS5pZF19XG4gICAgICAgICAgb25DaGFuZ2U9e3Byb3h5ID0+IHRoaXMuaGFuZGxlQ2hhbmdlLmNhbGwodGhpcywgaXRlbS5pZCwgcHJveHkudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICBzdHlsZT17eyB3aWR0aDogJzEwMCUnIH19XG4gICAgICAgICAgLz5cbiAgICAgIDwvZGl2Pn1cblxuICAgICAge2l0ZW0udHlwZSA9PT0gJ21lc3NhZ2UnICYmIDxNZXNzYWdlXG4gICAgICAgIGNvbG9yPXtpdGVtLnBhcmFtcy5jb2xvcn1cbiAgICAgICAgPntpdGVtLnBhcmFtcy5sYWJlbH08L01lc3NhZ2U+fVxuXG4gICAgICB7aXRlbS50eXBlID09PSAnc2VsZWN0Ym94JyAmJiA8ZGl2PlxuICAgICAgICA8Yj57aXRlbS5wYXJhbXMubGFiZWx9PC9iPlxuICAgICAgICA8YnIgLz48U2VsZWN0Qm94XG4gICAgICAgICAgc3R5bGU9e2l0ZW0ucGFyYW1zLnN0eWxlfVxuICAgICAgICAgIHRlbXBsYXRlPXtpdGVtLnBhcmFtcy50ZW1wbGF0ZX1cbiAgICAgICAgICBvcHRpb25zPXtpdGVtLnBhcmFtcy5vcHRpb25zfVxuICAgICAgICAgIHZhbHVlPXt0aGlzLnN0YXRlLmZvcm1baXRlbS5pZF19XG4gICAgICAgICAgb25DaGFuZ2U9e3ZhbHVlID0+IHRoaXMuaGFuZGxlQ2hhbmdlLmNhbGwodGhpcywgaXRlbS5pZCwgdmFsdWUpfVxuICAgICAgICAgIC8+XG4gICAgICA8L2Rpdj59XG5cbiAgICAgIHtcbiAgICAgICAgdGhpcy5zdGF0ZS5lcnJvcnNbaXRlbS5pZF0gJiZcbiAgICAgICAgdGhpcy5zdGF0ZS5lcnJvcnNbaXRlbS5pZF0uc3BsaXQoJywnKS5pbmNsdWRlcygncmVxdWlyZWQnKSAmJlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nZXJyJz5QbGVhc2UgRmlsbCB7aXRlbS5wYXJhbXMubGFiZWwgfHwgJ0ZpZWxkJ317JyAnfWl0cyBSZXF1aXJlZDwvZGl2PlxuICAgICAgfVxuXG4gICAgPC9kaXY+KTtcblxuICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IHRoaXMuc3RhdGUuZXJyb3JzLmVycm9yICYmICg8TWVzc2FnZSBjb2xvcj1cInJlZFwiIG9uRGlzbWlzcz17KCkgPT4gdGhpcy5zZXRTdGF0ZSh7IGVycm9yczogT2JqZWN0LmFzc2lnbih0aGlzLnN0YXRlLmVycm9ycywgeyBlcnJvcjogbnVsbCB9KSB9KX0gPlxuICAgICAge3RoaXMuc3RhdGUuZXJyb3JzLmVycm9yfVxuICAgIDwvTWVzc2FnZT4pO1xuXG4gICAgY29uc3Qgc3VjY2Vzc01lc3NhZ2UgPSB0aGlzLnN0YXRlLnN1Y2Nlc3MgJiYgPE1lc3NhZ2UgY29sb3I9XCJncmVlblwiIG9uRGlzbWlzcz17KCkgPT4gdGhpcy5zZXRTdGF0ZSh7IHN1Y2Nlc3M6IG51bGwgfSl9ID5cbiAgICAgIHt0aGlzLnN0YXRlLnN1Y2Nlc3N9XG4gICAgPC9NZXNzYWdlPjtcbiAgICBjb25zdCB5YW1sRXJyb3IgPSB0aGlzLnN0YXRlLnlhbWxFcnJvciAmJiA8TWVzc2FnZSBjb2xvcj1cInllbGxvd1wiIG9uRGlzbWlzcz17KCkgPT4gdGhpcy5zZXRTdGF0ZSh7IHlhbWxFcnJvcjogbnVsbCB9KX0gPlxuICAgICAge3RoaXMuc3RhdGUueWFtbEVycm9yfVxuICAgIDwvTWVzc2FnZT47XG5cbiAgICBjb25zdCBhbGxvd05hbWVFZGl0ID0gdGhpcy5wcm9wcy53aWRnZXQuY29uZmlndXJhdGlvbi5hbGxvd05hbWVFZGl0O1xuXG4gICAgcmV0dXJuIDxkaXY+XG4gICAgICB7ZXJyb3JNZXNzYWdlfVxuICAgICAge3N1Y2Nlc3NNZXNzYWdlfVxuICAgICAge3lhbWxFcnJvcn1cblxuICAgICAgeyF0aGlzLnN0YXRlLnN1Y2Nlc3MgJiYgYWxsb3dOYW1lRWRpdCAmJiA8SW5wdXRcbiAgICAgICAgZmx1aWRcbiAgICAgICAgdHlwZT17J3RleHQnfVxuICAgICAgICBsYWJlbD1cIkRlcGxveW1lbnQgVGl0bGVcIlxuICAgICAgICBwbGFjZWhvbGRlcj1cIlBsZWFzZSBFbnRlciBZb3VyIERlcGxveW1lbnQgVGl0bGUsIHNob3VsZCBiZSB1bmlxdWUgbmFtZVwiXG4gICAgICAgIHZhbHVlPXt0aGlzLnN0YXRlLmRlcGxveW1lbnRUaXRsZX1cbiAgICAgICAgb25DaGFuZ2U9eyhwcm94eSwgb3B0aW9ucykgPT4gdGhpcy5zZXRTdGF0ZSh7IGRlcGxveW1lbnRUaXRsZTogb3B0aW9ucy52YWx1ZSB9KX1cbiAgICAgICAgLz59XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPSdkZXBsb3ltZW50LXZpc3VhbC1jcmVhdGlvbic+XG4gICAgICAgIHshdGhpcy5zdGF0ZS5zdWNjZXNzICYmIHZpc3VhbHN9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj47XG4gIH1cbn1cbiIsIi8qKlxuICogQ3JlYXRlZCBieSBUYW1lciBvbiAxOS8xMC8yMDE3LlxuICovXG5pbXBvcnQgUmVuZGVyIGZyb20gJy4uL3V0aWxzL211c3RhY2hlJztcblxuXG4vKipcbiAqIEBjbGFzcyBMaXN0XG4gKiBAZXh0ZW5kcyB7Q29tcG9uZW50fVxuICovXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBTZWxlY3RCb3ggZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQge1xuICAvKipcbiAgICogQ3JlYXRlcyBhbiBpbnN0YW5jZSBvZiBMaXN0LlxuICAgKiBAcGFyYW0ge2FueX0gcHJvcHMgXG4gICAqIEBwYXJhbSB7YW55fSBjb250ZXh0IFxuICAgKi9cbiAgY29uc3RydWN0b3IocHJvcHMsIGNvbnRleHQpIHtcbiAgICBzdXBlcihwcm9wcywgY29udGV4dCk7XG4gICAgdGhpcy5zdGF0ZSA9IHtcbiAgICAgIGZvcm1EYXRhOiB7fVxuICAgIH07XG4gIH1cblxuICAvKlxuICB8LS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgfCBSZWFjdCBSZW5kZXJlclxuICB8LS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgKi9cbiAgcmVuZGVyKCkge1xuICAgIGxldCB7b3B0aW9ucywgdGVtcGxhdGUsIG9uQ2hhbmdlLCB2YWx1ZSwgc3R5bGV9ID0gdGhpcy5wcm9wcztcblxuICAgIHJldHVybiA8ZGl2IGNsYXNzTmFtZT17J3NlbGVjdGJveC1zdHlsZScrKHN0eWxlIHx8IDEpfT5cbiAgICAgIHtvcHRpb25zLm1hcCgoaXRlbSwgaWR4KSA9PlxuICAgICAgICA8ZGl2XG4gICAgICAgICAga2V5PXtpZHh9XG4gICAgICAgICAgY2xhc3NOYW1lPXtbJ2l0ZW0nLCAoaXRlbS52YWx1ZSA9PT0gdmFsdWUgJiYgJ2FjdGl2ZScpXS5qb2luKCcgJyl9XG4gICAgICAgICAgb25DbGljaz17KCkgPT4gaXRlbS52YWx1ZSAhPT0gdmFsdWUgJiYgb25DaGFuZ2UoaXRlbS52YWx1ZSl9XG4gICAgICAgICAgZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUw9e3sgX19odG1sOiBSZW5kZXIodGVtcGxhdGUsIGl0ZW0pIH19XG4gICAgICAgICAgLz4pfVxuICAgIDwvZGl2PjtcbiAgfVxufVxuIiwiXG52YXIgWWFtbCA9IHJlcXVpcmUoJy4vbGliL1lhbWwnKTtcbm1vZHVsZS5leHBvcnRzID0gWWFtbDtcbiIsIi8vIEdlbmVyYXRlZCBieSBDb2ZmZWVTY3JpcHQgMS4xMi40XG52YXIgRHVtcGVyLCBJbmxpbmUsIFV0aWxzO1xuXG5VdGlscyA9IHJlcXVpcmUoJy4vVXRpbHMnKTtcblxuSW5saW5lID0gcmVxdWlyZSgnLi9JbmxpbmUnKTtcblxuRHVtcGVyID0gKGZ1bmN0aW9uKCkge1xuICBmdW5jdGlvbiBEdW1wZXIoKSB7fVxuXG4gIER1bXBlci5pbmRlbnRhdGlvbiA9IDQ7XG5cbiAgRHVtcGVyLnByb3RvdHlwZS5kdW1wID0gZnVuY3Rpb24oaW5wdXQsIGlubGluZSwgaW5kZW50LCBleGNlcHRpb25PbkludmFsaWRUeXBlLCBvYmplY3RFbmNvZGVyKSB7XG4gICAgdmFyIGksIGtleSwgbGVuLCBvdXRwdXQsIHByZWZpeCwgdmFsdWUsIHdpbGxCZUlubGluZWQ7XG4gICAgaWYgKGlubGluZSA9PSBudWxsKSB7XG4gICAgICBpbmxpbmUgPSAwO1xuICAgIH1cbiAgICBpZiAoaW5kZW50ID09IG51bGwpIHtcbiAgICAgIGluZGVudCA9IDA7XG4gICAgfVxuICAgIGlmIChleGNlcHRpb25PbkludmFsaWRUeXBlID09IG51bGwpIHtcbiAgICAgIGV4Y2VwdGlvbk9uSW52YWxpZFR5cGUgPSBmYWxzZTtcbiAgICB9XG4gICAgaWYgKG9iamVjdEVuY29kZXIgPT0gbnVsbCkge1xuICAgICAgb2JqZWN0RW5jb2RlciA9IG51bGw7XG4gICAgfVxuICAgIG91dHB1dCA9ICcnO1xuICAgIHByZWZpeCA9IChpbmRlbnQgPyBVdGlscy5zdHJSZXBlYXQoJyAnLCBpbmRlbnQpIDogJycpO1xuICAgIGlmIChpbmxpbmUgPD0gMCB8fCB0eXBlb2YgaW5wdXQgIT09ICdvYmplY3QnIHx8IGlucHV0IGluc3RhbmNlb2YgRGF0ZSB8fCBVdGlscy5pc0VtcHR5KGlucHV0KSkge1xuICAgICAgb3V0cHV0ICs9IHByZWZpeCArIElubGluZS5kdW1wKGlucHV0LCBleGNlcHRpb25PbkludmFsaWRUeXBlLCBvYmplY3RFbmNvZGVyKTtcbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKGlucHV0IGluc3RhbmNlb2YgQXJyYXkpIHtcbiAgICAgICAgZm9yIChpID0gMCwgbGVuID0gaW5wdXQubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgICAgICB2YWx1ZSA9IGlucHV0W2ldO1xuICAgICAgICAgIHdpbGxCZUlubGluZWQgPSBpbmxpbmUgLSAxIDw9IDAgfHwgdHlwZW9mIHZhbHVlICE9PSAnb2JqZWN0JyB8fCBVdGlscy5pc0VtcHR5KHZhbHVlKTtcbiAgICAgICAgICBvdXRwdXQgKz0gcHJlZml4ICsgJy0nICsgKHdpbGxCZUlubGluZWQgPyAnICcgOiBcIlxcblwiKSArIHRoaXMuZHVtcCh2YWx1ZSwgaW5saW5lIC0gMSwgKHdpbGxCZUlubGluZWQgPyAwIDogaW5kZW50ICsgdGhpcy5pbmRlbnRhdGlvbiksIGV4Y2VwdGlvbk9uSW52YWxpZFR5cGUsIG9iamVjdEVuY29kZXIpICsgKHdpbGxCZUlubGluZWQgPyBcIlxcblwiIDogJycpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBmb3IgKGtleSBpbiBpbnB1dCkge1xuICAgICAgICAgIHZhbHVlID0gaW5wdXRba2V5XTtcbiAgICAgICAgICB3aWxsQmVJbmxpbmVkID0gaW5saW5lIC0gMSA8PSAwIHx8IHR5cGVvZiB2YWx1ZSAhPT0gJ29iamVjdCcgfHwgVXRpbHMuaXNFbXB0eSh2YWx1ZSk7XG4gICAgICAgICAgb3V0cHV0ICs9IHByZWZpeCArIElubGluZS5kdW1wKGtleSwgZXhjZXB0aW9uT25JbnZhbGlkVHlwZSwgb2JqZWN0RW5jb2RlcikgKyAnOicgKyAod2lsbEJlSW5saW5lZCA/ICcgJyA6IFwiXFxuXCIpICsgdGhpcy5kdW1wKHZhbHVlLCBpbmxpbmUgLSAxLCAod2lsbEJlSW5saW5lZCA/IDAgOiBpbmRlbnQgKyB0aGlzLmluZGVudGF0aW9uKSwgZXhjZXB0aW9uT25JbnZhbGlkVHlwZSwgb2JqZWN0RW5jb2RlcikgKyAod2lsbEJlSW5saW5lZCA/IFwiXFxuXCIgOiAnJyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG91dHB1dDtcbiAgfTtcblxuICByZXR1cm4gRHVtcGVyO1xuXG59KSgpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IER1bXBlcjtcbiIsIi8vIEdlbmVyYXRlZCBieSBDb2ZmZWVTY3JpcHQgMS4xMi40XG52YXIgRXNjYXBlciwgUGF0dGVybjtcblxuUGF0dGVybiA9IHJlcXVpcmUoJy4vUGF0dGVybicpO1xuXG5Fc2NhcGVyID0gKGZ1bmN0aW9uKCkge1xuICB2YXIgY2g7XG5cbiAgZnVuY3Rpb24gRXNjYXBlcigpIHt9XG5cbiAgRXNjYXBlci5MSVNUX0VTQ0FQRUVTID0gWydcXFxcJywgJ1xcXFxcXFxcJywgJ1xcXFxcIicsICdcIicsIFwiXFx4MDBcIiwgXCJcXHgwMVwiLCBcIlxceDAyXCIsIFwiXFx4MDNcIiwgXCJcXHgwNFwiLCBcIlxceDA1XCIsIFwiXFx4MDZcIiwgXCJcXHgwN1wiLCBcIlxceDA4XCIsIFwiXFx4MDlcIiwgXCJcXHgwYVwiLCBcIlxceDBiXCIsIFwiXFx4MGNcIiwgXCJcXHgwZFwiLCBcIlxceDBlXCIsIFwiXFx4MGZcIiwgXCJcXHgxMFwiLCBcIlxceDExXCIsIFwiXFx4MTJcIiwgXCJcXHgxM1wiLCBcIlxceDE0XCIsIFwiXFx4MTVcIiwgXCJcXHgxNlwiLCBcIlxceDE3XCIsIFwiXFx4MThcIiwgXCJcXHgxOVwiLCBcIlxceDFhXCIsIFwiXFx4MWJcIiwgXCJcXHgxY1wiLCBcIlxceDFkXCIsIFwiXFx4MWVcIiwgXCJcXHgxZlwiLCAoY2ggPSBTdHJpbmcuZnJvbUNoYXJDb2RlKSgweDAwODUpLCBjaCgweDAwQTApLCBjaCgweDIwMjgpLCBjaCgweDIwMjkpXTtcblxuICBFc2NhcGVyLkxJU1RfRVNDQVBFRCA9IFsnXFxcXFxcXFwnLCAnXFxcXFwiJywgJ1xcXFxcIicsICdcXFxcXCInLCBcIlxcXFwwXCIsIFwiXFxcXHgwMVwiLCBcIlxcXFx4MDJcIiwgXCJcXFxceDAzXCIsIFwiXFxcXHgwNFwiLCBcIlxcXFx4MDVcIiwgXCJcXFxceDA2XCIsIFwiXFxcXGFcIiwgXCJcXFxcYlwiLCBcIlxcXFx0XCIsIFwiXFxcXG5cIiwgXCJcXFxcdlwiLCBcIlxcXFxmXCIsIFwiXFxcXHJcIiwgXCJcXFxceDBlXCIsIFwiXFxcXHgwZlwiLCBcIlxcXFx4MTBcIiwgXCJcXFxceDExXCIsIFwiXFxcXHgxMlwiLCBcIlxcXFx4MTNcIiwgXCJcXFxceDE0XCIsIFwiXFxcXHgxNVwiLCBcIlxcXFx4MTZcIiwgXCJcXFxceDE3XCIsIFwiXFxcXHgxOFwiLCBcIlxcXFx4MTlcIiwgXCJcXFxceDFhXCIsIFwiXFxcXGVcIiwgXCJcXFxceDFjXCIsIFwiXFxcXHgxZFwiLCBcIlxcXFx4MWVcIiwgXCJcXFxceDFmXCIsIFwiXFxcXE5cIiwgXCJcXFxcX1wiLCBcIlxcXFxMXCIsIFwiXFxcXFBcIl07XG5cbiAgRXNjYXBlci5NQVBQSU5HX0VTQ0FQRUVTX1RPX0VTQ0FQRUQgPSAoZnVuY3Rpb24oKSB7XG4gICAgdmFyIGksIGosIG1hcHBpbmcsIHJlZjtcbiAgICBtYXBwaW5nID0ge307XG4gICAgZm9yIChpID0gaiA9IDAsIHJlZiA9IEVzY2FwZXIuTElTVF9FU0NBUEVFUy5sZW5ndGg7IDAgPD0gcmVmID8gaiA8IHJlZiA6IGogPiByZWY7IGkgPSAwIDw9IHJlZiA/ICsraiA6IC0taikge1xuICAgICAgbWFwcGluZ1tFc2NhcGVyLkxJU1RfRVNDQVBFRVNbaV1dID0gRXNjYXBlci5MSVNUX0VTQ0FQRURbaV07XG4gICAgfVxuICAgIHJldHVybiBtYXBwaW5nO1xuICB9KSgpO1xuXG4gIEVzY2FwZXIuUEFUVEVSTl9DSEFSQUNURVJTX1RPX0VTQ0FQRSA9IG5ldyBQYXR0ZXJuKCdbXFxcXHgwMC1cXFxceDFmXXxcXHhjMlxceDg1fFxceGMyXFx4YTB8XFx4ZTJcXHg4MFxceGE4fFxceGUyXFx4ODBcXHhhOScpO1xuXG4gIEVzY2FwZXIuUEFUVEVSTl9NQVBQSU5HX0VTQ0FQRUVTID0gbmV3IFBhdHRlcm4oRXNjYXBlci5MSVNUX0VTQ0FQRUVTLmpvaW4oJ3wnKS5zcGxpdCgnXFxcXCcpLmpvaW4oJ1xcXFxcXFxcJykpO1xuXG4gIEVzY2FwZXIuUEFUVEVSTl9TSU5HTEVfUVVPVElORyA9IG5ldyBQYXR0ZXJuKCdbXFxcXHNcXCdcIjp7fVtcXFxcXSwmKiM/XXxeWy0/fDw+PSElQGBdJyk7XG5cbiAgRXNjYXBlci5yZXF1aXJlc0RvdWJsZVF1b3RpbmcgPSBmdW5jdGlvbih2YWx1ZSkge1xuICAgIHJldHVybiB0aGlzLlBBVFRFUk5fQ0hBUkFDVEVSU19UT19FU0NBUEUudGVzdCh2YWx1ZSk7XG4gIH07XG5cbiAgRXNjYXBlci5lc2NhcGVXaXRoRG91YmxlUXVvdGVzID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgICB2YXIgcmVzdWx0O1xuICAgIHJlc3VsdCA9IHRoaXMuUEFUVEVSTl9NQVBQSU5HX0VTQ0FQRUVTLnJlcGxhY2UodmFsdWUsIChmdW5jdGlvbihfdGhpcykge1xuICAgICAgcmV0dXJuIGZ1bmN0aW9uKHN0cikge1xuICAgICAgICByZXR1cm4gX3RoaXMuTUFQUElOR19FU0NBUEVFU19UT19FU0NBUEVEW3N0cl07XG4gICAgICB9O1xuICAgIH0pKHRoaXMpKTtcbiAgICByZXR1cm4gJ1wiJyArIHJlc3VsdCArICdcIic7XG4gIH07XG5cbiAgRXNjYXBlci5yZXF1aXJlc1NpbmdsZVF1b3RpbmcgPSBmdW5jdGlvbih2YWx1ZSkge1xuICAgIHJldHVybiB0aGlzLlBBVFRFUk5fU0lOR0xFX1FVT1RJTkcudGVzdCh2YWx1ZSk7XG4gIH07XG5cbiAgRXNjYXBlci5lc2NhcGVXaXRoU2luZ2xlUXVvdGVzID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgICByZXR1cm4gXCInXCIgKyB2YWx1ZS5yZXBsYWNlKC8nL2csIFwiJydcIikgKyBcIidcIjtcbiAgfTtcblxuICByZXR1cm4gRXNjYXBlcjtcblxufSkoKTtcblxubW9kdWxlLmV4cG9ydHMgPSBFc2NhcGVyO1xuIiwiLy8gR2VuZXJhdGVkIGJ5IENvZmZlZVNjcmlwdCAxLjEyLjRcbnZhciBEdW1wRXhjZXB0aW9uLFxuICBleHRlbmQgPSBmdW5jdGlvbihjaGlsZCwgcGFyZW50KSB7IGZvciAodmFyIGtleSBpbiBwYXJlbnQpIHsgaWYgKGhhc1Byb3AuY2FsbChwYXJlbnQsIGtleSkpIGNoaWxkW2tleV0gPSBwYXJlbnRba2V5XTsgfSBmdW5jdGlvbiBjdG9yKCkgeyB0aGlzLmNvbnN0cnVjdG9yID0gY2hpbGQ7IH0gY3Rvci5wcm90b3R5cGUgPSBwYXJlbnQucHJvdG90eXBlOyBjaGlsZC5wcm90b3R5cGUgPSBuZXcgY3RvcigpOyBjaGlsZC5fX3N1cGVyX18gPSBwYXJlbnQucHJvdG90eXBlOyByZXR1cm4gY2hpbGQ7IH0sXG4gIGhhc1Byb3AgPSB7fS5oYXNPd25Qcm9wZXJ0eTtcblxuRHVtcEV4Y2VwdGlvbiA9IChmdW5jdGlvbihzdXBlckNsYXNzKSB7XG4gIGV4dGVuZChEdW1wRXhjZXB0aW9uLCBzdXBlckNsYXNzKTtcblxuICBmdW5jdGlvbiBEdW1wRXhjZXB0aW9uKG1lc3NhZ2UsIHBhcnNlZExpbmUsIHNuaXBwZXQpIHtcbiAgICB0aGlzLm1lc3NhZ2UgPSBtZXNzYWdlO1xuICAgIHRoaXMucGFyc2VkTGluZSA9IHBhcnNlZExpbmU7XG4gICAgdGhpcy5zbmlwcGV0ID0gc25pcHBldDtcbiAgfVxuXG4gIER1bXBFeGNlcHRpb24ucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24oKSB7XG4gICAgaWYgKCh0aGlzLnBhcnNlZExpbmUgIT0gbnVsbCkgJiYgKHRoaXMuc25pcHBldCAhPSBudWxsKSkge1xuICAgICAgcmV0dXJuICc8RHVtcEV4Y2VwdGlvbj4gJyArIHRoaXMubWVzc2FnZSArICcgKGxpbmUgJyArIHRoaXMucGFyc2VkTGluZSArICc6IFxcJycgKyB0aGlzLnNuaXBwZXQgKyAnXFwnKSc7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiAnPER1bXBFeGNlcHRpb24+ICcgKyB0aGlzLm1lc3NhZ2U7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiBEdW1wRXhjZXB0aW9uO1xuXG59KShFcnJvcik7XG5cbm1vZHVsZS5leHBvcnRzID0gRHVtcEV4Y2VwdGlvbjtcbiIsIi8vIEdlbmVyYXRlZCBieSBDb2ZmZWVTY3JpcHQgMS4xMi40XG52YXIgUGFyc2VFeGNlcHRpb24sXG4gIGV4dGVuZCA9IGZ1bmN0aW9uKGNoaWxkLCBwYXJlbnQpIHsgZm9yICh2YXIga2V5IGluIHBhcmVudCkgeyBpZiAoaGFzUHJvcC5jYWxsKHBhcmVudCwga2V5KSkgY2hpbGRba2V5XSA9IHBhcmVudFtrZXldOyB9IGZ1bmN0aW9uIGN0b3IoKSB7IHRoaXMuY29uc3RydWN0b3IgPSBjaGlsZDsgfSBjdG9yLnByb3RvdHlwZSA9IHBhcmVudC5wcm90b3R5cGU7IGNoaWxkLnByb3RvdHlwZSA9IG5ldyBjdG9yKCk7IGNoaWxkLl9fc3VwZXJfXyA9IHBhcmVudC5wcm90b3R5cGU7IHJldHVybiBjaGlsZDsgfSxcbiAgaGFzUHJvcCA9IHt9Lmhhc093blByb3BlcnR5O1xuXG5QYXJzZUV4Y2VwdGlvbiA9IChmdW5jdGlvbihzdXBlckNsYXNzKSB7XG4gIGV4dGVuZChQYXJzZUV4Y2VwdGlvbiwgc3VwZXJDbGFzcyk7XG5cbiAgZnVuY3Rpb24gUGFyc2VFeGNlcHRpb24obWVzc2FnZSwgcGFyc2VkTGluZSwgc25pcHBldCkge1xuICAgIHRoaXMubWVzc2FnZSA9IG1lc3NhZ2U7XG4gICAgdGhpcy5wYXJzZWRMaW5lID0gcGFyc2VkTGluZTtcbiAgICB0aGlzLnNuaXBwZXQgPSBzbmlwcGV0O1xuICB9XG5cbiAgUGFyc2VFeGNlcHRpb24ucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24oKSB7XG4gICAgaWYgKCh0aGlzLnBhcnNlZExpbmUgIT0gbnVsbCkgJiYgKHRoaXMuc25pcHBldCAhPSBudWxsKSkge1xuICAgICAgcmV0dXJuICc8UGFyc2VFeGNlcHRpb24+ICcgKyB0aGlzLm1lc3NhZ2UgKyAnIChsaW5lICcgKyB0aGlzLnBhcnNlZExpbmUgKyAnOiBcXCcnICsgdGhpcy5zbmlwcGV0ICsgJ1xcJyknO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gJzxQYXJzZUV4Y2VwdGlvbj4gJyArIHRoaXMubWVzc2FnZTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIFBhcnNlRXhjZXB0aW9uO1xuXG59KShFcnJvcik7XG5cbm1vZHVsZS5leHBvcnRzID0gUGFyc2VFeGNlcHRpb247XG4iLCIvLyBHZW5lcmF0ZWQgYnkgQ29mZmVlU2NyaXB0IDEuMTIuNFxudmFyIFBhcnNlTW9yZSxcbiAgZXh0ZW5kID0gZnVuY3Rpb24oY2hpbGQsIHBhcmVudCkgeyBmb3IgKHZhciBrZXkgaW4gcGFyZW50KSB7IGlmIChoYXNQcm9wLmNhbGwocGFyZW50LCBrZXkpKSBjaGlsZFtrZXldID0gcGFyZW50W2tleV07IH0gZnVuY3Rpb24gY3RvcigpIHsgdGhpcy5jb25zdHJ1Y3RvciA9IGNoaWxkOyB9IGN0b3IucHJvdG90eXBlID0gcGFyZW50LnByb3RvdHlwZTsgY2hpbGQucHJvdG90eXBlID0gbmV3IGN0b3IoKTsgY2hpbGQuX19zdXBlcl9fID0gcGFyZW50LnByb3RvdHlwZTsgcmV0dXJuIGNoaWxkOyB9LFxuICBoYXNQcm9wID0ge30uaGFzT3duUHJvcGVydHk7XG5cblBhcnNlTW9yZSA9IChmdW5jdGlvbihzdXBlckNsYXNzKSB7XG4gIGV4dGVuZChQYXJzZU1vcmUsIHN1cGVyQ2xhc3MpO1xuXG4gIGZ1bmN0aW9uIFBhcnNlTW9yZShtZXNzYWdlLCBwYXJzZWRMaW5lLCBzbmlwcGV0KSB7XG4gICAgdGhpcy5tZXNzYWdlID0gbWVzc2FnZTtcbiAgICB0aGlzLnBhcnNlZExpbmUgPSBwYXJzZWRMaW5lO1xuICAgIHRoaXMuc25pcHBldCA9IHNuaXBwZXQ7XG4gIH1cblxuICBQYXJzZU1vcmUucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24oKSB7XG4gICAgaWYgKCh0aGlzLnBhcnNlZExpbmUgIT0gbnVsbCkgJiYgKHRoaXMuc25pcHBldCAhPSBudWxsKSkge1xuICAgICAgcmV0dXJuICc8UGFyc2VNb3JlPiAnICsgdGhpcy5tZXNzYWdlICsgJyAobGluZSAnICsgdGhpcy5wYXJzZWRMaW5lICsgJzogXFwnJyArIHRoaXMuc25pcHBldCArICdcXCcpJztcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuICc8UGFyc2VNb3JlPiAnICsgdGhpcy5tZXNzYWdlO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gUGFyc2VNb3JlO1xuXG59KShFcnJvcik7XG5cbm1vZHVsZS5leHBvcnRzID0gUGFyc2VNb3JlO1xuIiwiLy8gR2VuZXJhdGVkIGJ5IENvZmZlZVNjcmlwdCAxLjEyLjRcbnZhciBEdW1wRXhjZXB0aW9uLCBFc2NhcGVyLCBJbmxpbmUsIFBhcnNlRXhjZXB0aW9uLCBQYXJzZU1vcmUsIFBhdHRlcm4sIFVuZXNjYXBlciwgVXRpbHMsXG4gIGluZGV4T2YgPSBbXS5pbmRleE9mIHx8IGZ1bmN0aW9uKGl0ZW0pIHsgZm9yICh2YXIgaSA9IDAsIGwgPSB0aGlzLmxlbmd0aDsgaSA8IGw7IGkrKykgeyBpZiAoaSBpbiB0aGlzICYmIHRoaXNbaV0gPT09IGl0ZW0pIHJldHVybiBpOyB9IHJldHVybiAtMTsgfTtcblxuUGF0dGVybiA9IHJlcXVpcmUoJy4vUGF0dGVybicpO1xuXG5VbmVzY2FwZXIgPSByZXF1aXJlKCcuL1VuZXNjYXBlcicpO1xuXG5Fc2NhcGVyID0gcmVxdWlyZSgnLi9Fc2NhcGVyJyk7XG5cblV0aWxzID0gcmVxdWlyZSgnLi9VdGlscycpO1xuXG5QYXJzZUV4Y2VwdGlvbiA9IHJlcXVpcmUoJy4vRXhjZXB0aW9uL1BhcnNlRXhjZXB0aW9uJyk7XG5cblBhcnNlTW9yZSA9IHJlcXVpcmUoJy4vRXhjZXB0aW9uL1BhcnNlTW9yZScpO1xuXG5EdW1wRXhjZXB0aW9uID0gcmVxdWlyZSgnLi9FeGNlcHRpb24vRHVtcEV4Y2VwdGlvbicpO1xuXG5JbmxpbmUgPSAoZnVuY3Rpb24oKSB7XG4gIGZ1bmN0aW9uIElubGluZSgpIHt9XG5cbiAgSW5saW5lLlJFR0VYX1FVT1RFRF9TVFJJTkcgPSAnKD86XCIoPzpbXlwiXFxcXFxcXFxdKig/OlxcXFxcXFxcLlteXCJcXFxcXFxcXF0qKSopXCJ8XFwnKD86W15cXCddKig/OlxcJ1xcJ1teXFwnXSopKilcXCcpJztcblxuICBJbmxpbmUuUEFUVEVSTl9UUkFJTElOR19DT01NRU5UUyA9IG5ldyBQYXR0ZXJuKCdeXFxcXHMqIy4qJCcpO1xuXG4gIElubGluZS5QQVRURVJOX1FVT1RFRF9TQ0FMQVIgPSBuZXcgUGF0dGVybignXicgKyBJbmxpbmUuUkVHRVhfUVVPVEVEX1NUUklORyk7XG5cbiAgSW5saW5lLlBBVFRFUk5fVEhPVVNBTkRfTlVNRVJJQ19TQ0FMQVIgPSBuZXcgUGF0dGVybignXigtfFxcXFwrKT9bMC05LF0rKFxcXFwuWzAtOV0rKT8kJyk7XG5cbiAgSW5saW5lLlBBVFRFUk5fU0NBTEFSX0JZX0RFTElNSVRFUlMgPSB7fTtcblxuICBJbmxpbmUuc2V0dGluZ3MgPSB7fTtcblxuICBJbmxpbmUuY29uZmlndXJlID0gZnVuY3Rpb24oZXhjZXB0aW9uT25JbnZhbGlkVHlwZSwgb2JqZWN0RGVjb2Rlcikge1xuICAgIGlmIChleGNlcHRpb25PbkludmFsaWRUeXBlID09IG51bGwpIHtcbiAgICAgIGV4Y2VwdGlvbk9uSW52YWxpZFR5cGUgPSBudWxsO1xuICAgIH1cbiAgICBpZiAob2JqZWN0RGVjb2RlciA9PSBudWxsKSB7XG4gICAgICBvYmplY3REZWNvZGVyID0gbnVsbDtcbiAgICB9XG4gICAgdGhpcy5zZXR0aW5ncy5leGNlcHRpb25PbkludmFsaWRUeXBlID0gZXhjZXB0aW9uT25JbnZhbGlkVHlwZTtcbiAgICB0aGlzLnNldHRpbmdzLm9iamVjdERlY29kZXIgPSBvYmplY3REZWNvZGVyO1xuICB9O1xuXG4gIElubGluZS5wYXJzZSA9IGZ1bmN0aW9uKHZhbHVlLCBleGNlcHRpb25PbkludmFsaWRUeXBlLCBvYmplY3REZWNvZGVyKSB7XG4gICAgdmFyIGNvbnRleHQsIHJlc3VsdDtcbiAgICBpZiAoZXhjZXB0aW9uT25JbnZhbGlkVHlwZSA9PSBudWxsKSB7XG4gICAgICBleGNlcHRpb25PbkludmFsaWRUeXBlID0gZmFsc2U7XG4gICAgfVxuICAgIGlmIChvYmplY3REZWNvZGVyID09IG51bGwpIHtcbiAgICAgIG9iamVjdERlY29kZXIgPSBudWxsO1xuICAgIH1cbiAgICB0aGlzLnNldHRpbmdzLmV4Y2VwdGlvbk9uSW52YWxpZFR5cGUgPSBleGNlcHRpb25PbkludmFsaWRUeXBlO1xuICAgIHRoaXMuc2V0dGluZ3Mub2JqZWN0RGVjb2RlciA9IG9iamVjdERlY29kZXI7XG4gICAgaWYgKHZhbHVlID09IG51bGwpIHtcbiAgICAgIHJldHVybiAnJztcbiAgICB9XG4gICAgdmFsdWUgPSBVdGlscy50cmltKHZhbHVlKTtcbiAgICBpZiAoMCA9PT0gdmFsdWUubGVuZ3RoKSB7XG4gICAgICByZXR1cm4gJyc7XG4gICAgfVxuICAgIGNvbnRleHQgPSB7XG4gICAgICBleGNlcHRpb25PbkludmFsaWRUeXBlOiBleGNlcHRpb25PbkludmFsaWRUeXBlLFxuICAgICAgb2JqZWN0RGVjb2Rlcjogb2JqZWN0RGVjb2RlcixcbiAgICAgIGk6IDBcbiAgICB9O1xuICAgIHN3aXRjaCAodmFsdWUuY2hhckF0KDApKSB7XG4gICAgICBjYXNlICdbJzpcbiAgICAgICAgcmVzdWx0ID0gdGhpcy5wYXJzZVNlcXVlbmNlKHZhbHVlLCBjb250ZXh0KTtcbiAgICAgICAgKytjb250ZXh0Lmk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAneyc6XG4gICAgICAgIHJlc3VsdCA9IHRoaXMucGFyc2VNYXBwaW5nKHZhbHVlLCBjb250ZXh0KTtcbiAgICAgICAgKytjb250ZXh0Lmk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgcmVzdWx0ID0gdGhpcy5wYXJzZVNjYWxhcih2YWx1ZSwgbnVsbCwgWydcIicsIFwiJ1wiXSwgY29udGV4dCk7XG4gICAgfVxuICAgIGlmICh0aGlzLlBBVFRFUk5fVFJBSUxJTkdfQ09NTUVOVFMucmVwbGFjZSh2YWx1ZS5zbGljZShjb250ZXh0LmkpLCAnJykgIT09ICcnKSB7XG4gICAgICB0aHJvdyBuZXcgUGFyc2VFeGNlcHRpb24oJ1VuZXhwZWN0ZWQgY2hhcmFjdGVycyBuZWFyIFwiJyArIHZhbHVlLnNsaWNlKGNvbnRleHQuaSkgKyAnXCIuJyk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG4gIH07XG5cbiAgSW5saW5lLmR1bXAgPSBmdW5jdGlvbih2YWx1ZSwgZXhjZXB0aW9uT25JbnZhbGlkVHlwZSwgb2JqZWN0RW5jb2Rlcikge1xuICAgIHZhciByZWYsIHJlc3VsdCwgdHlwZTtcbiAgICBpZiAoZXhjZXB0aW9uT25JbnZhbGlkVHlwZSA9PSBudWxsKSB7XG4gICAgICBleGNlcHRpb25PbkludmFsaWRUeXBlID0gZmFsc2U7XG4gICAgfVxuICAgIGlmIChvYmplY3RFbmNvZGVyID09IG51bGwpIHtcbiAgICAgIG9iamVjdEVuY29kZXIgPSBudWxsO1xuICAgIH1cbiAgICBpZiAodmFsdWUgPT0gbnVsbCkge1xuICAgICAgcmV0dXJuICdudWxsJztcbiAgICB9XG4gICAgdHlwZSA9IHR5cGVvZiB2YWx1ZTtcbiAgICBpZiAodHlwZSA9PT0gJ29iamVjdCcpIHtcbiAgICAgIGlmICh2YWx1ZSBpbnN0YW5jZW9mIERhdGUpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlLnRvSVNPU3RyaW5nKCk7XG4gICAgICB9IGVsc2UgaWYgKG9iamVjdEVuY29kZXIgIT0gbnVsbCkge1xuICAgICAgICByZXN1bHQgPSBvYmplY3RFbmNvZGVyKHZhbHVlKTtcbiAgICAgICAgaWYgKHR5cGVvZiByZXN1bHQgPT09ICdzdHJpbmcnIHx8IChyZXN1bHQgIT0gbnVsbCkpIHtcbiAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gdGhpcy5kdW1wT2JqZWN0KHZhbHVlKTtcbiAgICB9XG4gICAgaWYgKHR5cGUgPT09ICdib29sZWFuJykge1xuICAgICAgcmV0dXJuICh2YWx1ZSA/ICd0cnVlJyA6ICdmYWxzZScpO1xuICAgIH1cbiAgICBpZiAoVXRpbHMuaXNEaWdpdHModmFsdWUpKSB7XG4gICAgICByZXR1cm4gKHR5cGUgPT09ICdzdHJpbmcnID8gXCInXCIgKyB2YWx1ZSArIFwiJ1wiIDogU3RyaW5nKHBhcnNlSW50KHZhbHVlKSkpO1xuICAgIH1cbiAgICBpZiAoVXRpbHMuaXNOdW1lcmljKHZhbHVlKSkge1xuICAgICAgcmV0dXJuICh0eXBlID09PSAnc3RyaW5nJyA/IFwiJ1wiICsgdmFsdWUgKyBcIidcIiA6IFN0cmluZyhwYXJzZUZsb2F0KHZhbHVlKSkpO1xuICAgIH1cbiAgICBpZiAodHlwZSA9PT0gJ251bWJlcicpIHtcbiAgICAgIHJldHVybiAodmFsdWUgPT09IDJlMzA4ID8gJy5JbmYnIDogKHZhbHVlID09PSAtMmUzMDggPyAnLS5JbmYnIDogKGlzTmFOKHZhbHVlKSA/ICcuTmFOJyA6IHZhbHVlKSkpO1xuICAgIH1cbiAgICBpZiAoRXNjYXBlci5yZXF1aXJlc0RvdWJsZVF1b3RpbmcodmFsdWUpKSB7XG4gICAgICByZXR1cm4gRXNjYXBlci5lc2NhcGVXaXRoRG91YmxlUXVvdGVzKHZhbHVlKTtcbiAgICB9XG4gICAgaWYgKEVzY2FwZXIucmVxdWlyZXNTaW5nbGVRdW90aW5nKHZhbHVlKSkge1xuICAgICAgcmV0dXJuIEVzY2FwZXIuZXNjYXBlV2l0aFNpbmdsZVF1b3Rlcyh2YWx1ZSk7XG4gICAgfVxuICAgIGlmICgnJyA9PT0gdmFsdWUpIHtcbiAgICAgIHJldHVybiAnXCJcIic7XG4gICAgfVxuICAgIGlmIChVdGlscy5QQVRURVJOX0RBVEUudGVzdCh2YWx1ZSkpIHtcbiAgICAgIHJldHVybiBcIidcIiArIHZhbHVlICsgXCInXCI7XG4gICAgfVxuICAgIGlmICgocmVmID0gdmFsdWUudG9Mb3dlckNhc2UoKSkgPT09ICdudWxsJyB8fCByZWYgPT09ICd+JyB8fCByZWYgPT09ICd0cnVlJyB8fCByZWYgPT09ICdmYWxzZScpIHtcbiAgICAgIHJldHVybiBcIidcIiArIHZhbHVlICsgXCInXCI7XG4gICAgfVxuICAgIHJldHVybiB2YWx1ZTtcbiAgfTtcblxuICBJbmxpbmUuZHVtcE9iamVjdCA9IGZ1bmN0aW9uKHZhbHVlLCBleGNlcHRpb25PbkludmFsaWRUeXBlLCBvYmplY3RTdXBwb3J0KSB7XG4gICAgdmFyIGosIGtleSwgbGVuMSwgb3V0cHV0LCB2YWw7XG4gICAgaWYgKG9iamVjdFN1cHBvcnQgPT0gbnVsbCkge1xuICAgICAgb2JqZWN0U3VwcG9ydCA9IG51bGw7XG4gICAgfVxuICAgIGlmICh2YWx1ZSBpbnN0YW5jZW9mIEFycmF5KSB7XG4gICAgICBvdXRwdXQgPSBbXTtcbiAgICAgIGZvciAoaiA9IDAsIGxlbjEgPSB2YWx1ZS5sZW5ndGg7IGogPCBsZW4xOyBqKyspIHtcbiAgICAgICAgdmFsID0gdmFsdWVbal07XG4gICAgICAgIG91dHB1dC5wdXNoKHRoaXMuZHVtcCh2YWwpKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiAnWycgKyBvdXRwdXQuam9pbignLCAnKSArICddJztcbiAgICB9IGVsc2Uge1xuICAgICAgb3V0cHV0ID0gW107XG4gICAgICBmb3IgKGtleSBpbiB2YWx1ZSkge1xuICAgICAgICB2YWwgPSB2YWx1ZVtrZXldO1xuICAgICAgICBvdXRwdXQucHVzaCh0aGlzLmR1bXAoa2V5KSArICc6ICcgKyB0aGlzLmR1bXAodmFsKSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gJ3snICsgb3V0cHV0LmpvaW4oJywgJykgKyAnfSc7XG4gICAgfVxuICB9O1xuXG4gIElubGluZS5wYXJzZVNjYWxhciA9IGZ1bmN0aW9uKHNjYWxhciwgZGVsaW1pdGVycywgc3RyaW5nRGVsaW1pdGVycywgY29udGV4dCwgZXZhbHVhdGUpIHtcbiAgICB2YXIgaSwgam9pbmVkRGVsaW1pdGVycywgbWF0Y2gsIG91dHB1dCwgcGF0dGVybiwgcmVmLCByZWYxLCBzdHJwb3MsIHRtcDtcbiAgICBpZiAoZGVsaW1pdGVycyA9PSBudWxsKSB7XG4gICAgICBkZWxpbWl0ZXJzID0gbnVsbDtcbiAgICB9XG4gICAgaWYgKHN0cmluZ0RlbGltaXRlcnMgPT0gbnVsbCkge1xuICAgICAgc3RyaW5nRGVsaW1pdGVycyA9IFsnXCInLCBcIidcIl07XG4gICAgfVxuICAgIGlmIChjb250ZXh0ID09IG51bGwpIHtcbiAgICAgIGNvbnRleHQgPSBudWxsO1xuICAgIH1cbiAgICBpZiAoZXZhbHVhdGUgPT0gbnVsbCkge1xuICAgICAgZXZhbHVhdGUgPSB0cnVlO1xuICAgIH1cbiAgICBpZiAoY29udGV4dCA9PSBudWxsKSB7XG4gICAgICBjb250ZXh0ID0ge1xuICAgICAgICBleGNlcHRpb25PbkludmFsaWRUeXBlOiB0aGlzLnNldHRpbmdzLmV4Y2VwdGlvbk9uSW52YWxpZFR5cGUsXG4gICAgICAgIG9iamVjdERlY29kZXI6IHRoaXMuc2V0dGluZ3Mub2JqZWN0RGVjb2RlcixcbiAgICAgICAgaTogMFxuICAgICAgfTtcbiAgICB9XG4gICAgaSA9IGNvbnRleHQuaTtcbiAgICBpZiAocmVmID0gc2NhbGFyLmNoYXJBdChpKSwgaW5kZXhPZi5jYWxsKHN0cmluZ0RlbGltaXRlcnMsIHJlZikgPj0gMCkge1xuICAgICAgb3V0cHV0ID0gdGhpcy5wYXJzZVF1b3RlZFNjYWxhcihzY2FsYXIsIGNvbnRleHQpO1xuICAgICAgaSA9IGNvbnRleHQuaTtcbiAgICAgIGlmIChkZWxpbWl0ZXJzICE9IG51bGwpIHtcbiAgICAgICAgdG1wID0gVXRpbHMubHRyaW0oc2NhbGFyLnNsaWNlKGkpLCAnICcpO1xuICAgICAgICBpZiAoIShyZWYxID0gdG1wLmNoYXJBdCgwKSwgaW5kZXhPZi5jYWxsKGRlbGltaXRlcnMsIHJlZjEpID49IDApKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IFBhcnNlRXhjZXB0aW9uKCdVbmV4cGVjdGVkIGNoYXJhY3RlcnMgKCcgKyBzY2FsYXIuc2xpY2UoaSkgKyAnKS4nKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoIWRlbGltaXRlcnMpIHtcbiAgICAgICAgb3V0cHV0ID0gc2NhbGFyLnNsaWNlKGkpO1xuICAgICAgICBpICs9IG91dHB1dC5sZW5ndGg7XG4gICAgICAgIHN0cnBvcyA9IG91dHB1dC5pbmRleE9mKCcgIycpO1xuICAgICAgICBpZiAoc3RycG9zICE9PSAtMSkge1xuICAgICAgICAgIG91dHB1dCA9IFV0aWxzLnJ0cmltKG91dHB1dC5zbGljZSgwLCBzdHJwb3MpKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgam9pbmVkRGVsaW1pdGVycyA9IGRlbGltaXRlcnMuam9pbignfCcpO1xuICAgICAgICBwYXR0ZXJuID0gdGhpcy5QQVRURVJOX1NDQUxBUl9CWV9ERUxJTUlURVJTW2pvaW5lZERlbGltaXRlcnNdO1xuICAgICAgICBpZiAocGF0dGVybiA9PSBudWxsKSB7XG4gICAgICAgICAgcGF0dGVybiA9IG5ldyBQYXR0ZXJuKCdeKC4rPykoJyArIGpvaW5lZERlbGltaXRlcnMgKyAnKScpO1xuICAgICAgICAgIHRoaXMuUEFUVEVSTl9TQ0FMQVJfQllfREVMSU1JVEVSU1tqb2luZWREZWxpbWl0ZXJzXSA9IHBhdHRlcm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG1hdGNoID0gcGF0dGVybi5leGVjKHNjYWxhci5zbGljZShpKSkpIHtcbiAgICAgICAgICBvdXRwdXQgPSBtYXRjaFsxXTtcbiAgICAgICAgICBpICs9IG91dHB1dC5sZW5ndGg7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhyb3cgbmV3IFBhcnNlRXhjZXB0aW9uKCdNYWxmb3JtZWQgaW5saW5lIFlBTUwgc3RyaW5nICgnICsgc2NhbGFyICsgJykuJyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChldmFsdWF0ZSkge1xuICAgICAgICBvdXRwdXQgPSB0aGlzLmV2YWx1YXRlU2NhbGFyKG91dHB1dCwgY29udGV4dCk7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnRleHQuaSA9IGk7XG4gICAgcmV0dXJuIG91dHB1dDtcbiAgfTtcblxuICBJbmxpbmUucGFyc2VRdW90ZWRTY2FsYXIgPSBmdW5jdGlvbihzY2FsYXIsIGNvbnRleHQpIHtcbiAgICB2YXIgaSwgbWF0Y2gsIG91dHB1dDtcbiAgICBpID0gY29udGV4dC5pO1xuICAgIGlmICghKG1hdGNoID0gdGhpcy5QQVRURVJOX1FVT1RFRF9TQ0FMQVIuZXhlYyhzY2FsYXIuc2xpY2UoaSkpKSkge1xuICAgICAgdGhyb3cgbmV3IFBhcnNlTW9yZSgnTWFsZm9ybWVkIGlubGluZSBZQU1MIHN0cmluZyAoJyArIHNjYWxhci5zbGljZShpKSArICcpLicpO1xuICAgIH1cbiAgICBvdXRwdXQgPSBtYXRjaFswXS5zdWJzdHIoMSwgbWF0Y2hbMF0ubGVuZ3RoIC0gMik7XG4gICAgaWYgKCdcIicgPT09IHNjYWxhci5jaGFyQXQoaSkpIHtcbiAgICAgIG91dHB1dCA9IFVuZXNjYXBlci51bmVzY2FwZURvdWJsZVF1b3RlZFN0cmluZyhvdXRwdXQpO1xuICAgIH0gZWxzZSB7XG4gICAgICBvdXRwdXQgPSBVbmVzY2FwZXIudW5lc2NhcGVTaW5nbGVRdW90ZWRTdHJpbmcob3V0cHV0KTtcbiAgICB9XG4gICAgaSArPSBtYXRjaFswXS5sZW5ndGg7XG4gICAgY29udGV4dC5pID0gaTtcbiAgICByZXR1cm4gb3V0cHV0O1xuICB9O1xuXG4gIElubGluZS5wYXJzZVNlcXVlbmNlID0gZnVuY3Rpb24oc2VxdWVuY2UsIGNvbnRleHQpIHtcbiAgICB2YXIgZSwgaSwgaXNRdW90ZWQsIGxlbiwgb3V0cHV0LCByZWYsIHZhbHVlO1xuICAgIG91dHB1dCA9IFtdO1xuICAgIGxlbiA9IHNlcXVlbmNlLmxlbmd0aDtcbiAgICBpID0gY29udGV4dC5pO1xuICAgIGkgKz0gMTtcbiAgICB3aGlsZSAoaSA8IGxlbikge1xuICAgICAgY29udGV4dC5pID0gaTtcbiAgICAgIHN3aXRjaCAoc2VxdWVuY2UuY2hhckF0KGkpKSB7XG4gICAgICAgIGNhc2UgJ1snOlxuICAgICAgICAgIG91dHB1dC5wdXNoKHRoaXMucGFyc2VTZXF1ZW5jZShzZXF1ZW5jZSwgY29udGV4dCkpO1xuICAgICAgICAgIGkgPSBjb250ZXh0Lmk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ3snOlxuICAgICAgICAgIG91dHB1dC5wdXNoKHRoaXMucGFyc2VNYXBwaW5nKHNlcXVlbmNlLCBjb250ZXh0KSk7XG4gICAgICAgICAgaSA9IGNvbnRleHQuaTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnXSc6XG4gICAgICAgICAgcmV0dXJuIG91dHB1dDtcbiAgICAgICAgY2FzZSAnLCc6XG4gICAgICAgIGNhc2UgJyAnOlxuICAgICAgICBjYXNlIFwiXFxuXCI6XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgaXNRdW90ZWQgPSAoKHJlZiA9IHNlcXVlbmNlLmNoYXJBdChpKSkgPT09ICdcIicgfHwgcmVmID09PSBcIidcIik7XG4gICAgICAgICAgdmFsdWUgPSB0aGlzLnBhcnNlU2NhbGFyKHNlcXVlbmNlLCBbJywnLCAnXSddLCBbJ1wiJywgXCInXCJdLCBjb250ZXh0KTtcbiAgICAgICAgICBpID0gY29udGV4dC5pO1xuICAgICAgICAgIGlmICghaXNRdW90ZWQgJiYgdHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyAmJiAodmFsdWUuaW5kZXhPZignOiAnKSAhPT0gLTEgfHwgdmFsdWUuaW5kZXhPZihcIjpcXG5cIikgIT09IC0xKSkge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgdmFsdWUgPSB0aGlzLnBhcnNlTWFwcGluZygneycgKyB2YWx1ZSArICd9Jyk7XG4gICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICBlID0gZXJyb3I7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIG91dHB1dC5wdXNoKHZhbHVlKTtcbiAgICAgICAgICAtLWk7XG4gICAgICB9XG4gICAgICArK2k7XG4gICAgfVxuICAgIHRocm93IG5ldyBQYXJzZU1vcmUoJ01hbGZvcm1lZCBpbmxpbmUgWUFNTCBzdHJpbmcgJyArIHNlcXVlbmNlKTtcbiAgfTtcblxuICBJbmxpbmUucGFyc2VNYXBwaW5nID0gZnVuY3Rpb24obWFwcGluZywgY29udGV4dCkge1xuICAgIHZhciBkb25lLCBpLCBrZXksIGxlbiwgb3V0cHV0LCBzaG91bGRDb250aW51ZVdoaWxlTG9vcCwgdmFsdWU7XG4gICAgb3V0cHV0ID0ge307XG4gICAgbGVuID0gbWFwcGluZy5sZW5ndGg7XG4gICAgaSA9IGNvbnRleHQuaTtcbiAgICBpICs9IDE7XG4gICAgc2hvdWxkQ29udGludWVXaGlsZUxvb3AgPSBmYWxzZTtcbiAgICB3aGlsZSAoaSA8IGxlbikge1xuICAgICAgY29udGV4dC5pID0gaTtcbiAgICAgIHN3aXRjaCAobWFwcGluZy5jaGFyQXQoaSkpIHtcbiAgICAgICAgY2FzZSAnICc6XG4gICAgICAgIGNhc2UgJywnOlxuICAgICAgICBjYXNlIFwiXFxuXCI6XG4gICAgICAgICAgKytpO1xuICAgICAgICAgIGNvbnRleHQuaSA9IGk7XG4gICAgICAgICAgc2hvdWxkQ29udGludWVXaGlsZUxvb3AgPSB0cnVlO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICd9JzpcbiAgICAgICAgICByZXR1cm4gb3V0cHV0O1xuICAgICAgfVxuICAgICAgaWYgKHNob3VsZENvbnRpbnVlV2hpbGVMb29wKSB7XG4gICAgICAgIHNob3VsZENvbnRpbnVlV2hpbGVMb29wID0gZmFsc2U7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAga2V5ID0gdGhpcy5wYXJzZVNjYWxhcihtYXBwaW5nLCBbJzonLCAnICcsIFwiXFxuXCJdLCBbJ1wiJywgXCInXCJdLCBjb250ZXh0LCBmYWxzZSk7XG4gICAgICBpID0gY29udGV4dC5pO1xuICAgICAgZG9uZSA9IGZhbHNlO1xuICAgICAgd2hpbGUgKGkgPCBsZW4pIHtcbiAgICAgICAgY29udGV4dC5pID0gaTtcbiAgICAgICAgc3dpdGNoIChtYXBwaW5nLmNoYXJBdChpKSkge1xuICAgICAgICAgIGNhc2UgJ1snOlxuICAgICAgICAgICAgdmFsdWUgPSB0aGlzLnBhcnNlU2VxdWVuY2UobWFwcGluZywgY29udGV4dCk7XG4gICAgICAgICAgICBpID0gY29udGV4dC5pO1xuICAgICAgICAgICAgaWYgKG91dHB1dFtrZXldID09PSB2b2lkIDApIHtcbiAgICAgICAgICAgICAgb3V0cHV0W2tleV0gPSB2YWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGRvbmUgPSB0cnVlO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgY2FzZSAneyc6XG4gICAgICAgICAgICB2YWx1ZSA9IHRoaXMucGFyc2VNYXBwaW5nKG1hcHBpbmcsIGNvbnRleHQpO1xuICAgICAgICAgICAgaSA9IGNvbnRleHQuaTtcbiAgICAgICAgICAgIGlmIChvdXRwdXRba2V5XSA9PT0gdm9pZCAwKSB7XG4gICAgICAgICAgICAgIG91dHB1dFtrZXldID0gdmFsdWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBkb25lID0gdHJ1ZTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGNhc2UgJzonOlxuICAgICAgICAgIGNhc2UgJyAnOlxuICAgICAgICAgIGNhc2UgXCJcXG5cIjpcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICB2YWx1ZSA9IHRoaXMucGFyc2VTY2FsYXIobWFwcGluZywgWycsJywgJ30nXSwgWydcIicsIFwiJ1wiXSwgY29udGV4dCk7XG4gICAgICAgICAgICBpID0gY29udGV4dC5pO1xuICAgICAgICAgICAgaWYgKG91dHB1dFtrZXldID09PSB2b2lkIDApIHtcbiAgICAgICAgICAgICAgb3V0cHV0W2tleV0gPSB2YWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGRvbmUgPSB0cnVlO1xuICAgICAgICAgICAgLS1pO1xuICAgICAgICB9XG4gICAgICAgICsraTtcbiAgICAgICAgaWYgKGRvbmUpIHtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICB0aHJvdyBuZXcgUGFyc2VNb3JlKCdNYWxmb3JtZWQgaW5saW5lIFlBTUwgc3RyaW5nICcgKyBtYXBwaW5nKTtcbiAgfTtcblxuICBJbmxpbmUuZXZhbHVhdGVTY2FsYXIgPSBmdW5jdGlvbihzY2FsYXIsIGNvbnRleHQpIHtcbiAgICB2YXIgY2FzdCwgZGF0ZSwgZXhjZXB0aW9uT25JbnZhbGlkVHlwZSwgZmlyc3RDaGFyLCBmaXJzdFNwYWNlLCBmaXJzdFdvcmQsIG9iamVjdERlY29kZXIsIHJhdywgc2NhbGFyTG93ZXIsIHN1YlZhbHVlLCB0cmltbWVkU2NhbGFyO1xuICAgIHNjYWxhciA9IFV0aWxzLnRyaW0oc2NhbGFyKTtcbiAgICBzY2FsYXJMb3dlciA9IHNjYWxhci50b0xvd2VyQ2FzZSgpO1xuICAgIHN3aXRjaCAoc2NhbGFyTG93ZXIpIHtcbiAgICAgIGNhc2UgJ251bGwnOlxuICAgICAgY2FzZSAnJzpcbiAgICAgIGNhc2UgJ34nOlxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIGNhc2UgJ3RydWUnOlxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIGNhc2UgJ2ZhbHNlJzpcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgY2FzZSAnLmluZic6XG4gICAgICAgIHJldHVybiAyZTMwODtcbiAgICAgIGNhc2UgJy5uYW4nOlxuICAgICAgICByZXR1cm4gMC8wO1xuICAgICAgY2FzZSAnLS5pbmYnOlxuICAgICAgICByZXR1cm4gMmUzMDg7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICBmaXJzdENoYXIgPSBzY2FsYXJMb3dlci5jaGFyQXQoMCk7XG4gICAgICAgIHN3aXRjaCAoZmlyc3RDaGFyKSB7XG4gICAgICAgICAgY2FzZSAnISc6XG4gICAgICAgICAgICBmaXJzdFNwYWNlID0gc2NhbGFyLmluZGV4T2YoJyAnKTtcbiAgICAgICAgICAgIGlmIChmaXJzdFNwYWNlID09PSAtMSkge1xuICAgICAgICAgICAgICBmaXJzdFdvcmQgPSBzY2FsYXJMb3dlcjtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIGZpcnN0V29yZCA9IHNjYWxhckxvd2VyLnNsaWNlKDAsIGZpcnN0U3BhY2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc3dpdGNoIChmaXJzdFdvcmQpIHtcbiAgICAgICAgICAgICAgY2FzZSAnISc6XG4gICAgICAgICAgICAgICAgaWYgKGZpcnN0U3BhY2UgIT09IC0xKSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gcGFyc2VJbnQodGhpcy5wYXJzZVNjYWxhcihzY2FsYXIuc2xpY2UoMikpKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgICAgIGNhc2UgJyFzdHInOlxuICAgICAgICAgICAgICAgIHJldHVybiBVdGlscy5sdHJpbShzY2FsYXIuc2xpY2UoNCkpO1xuICAgICAgICAgICAgICBjYXNlICchIXN0cic6XG4gICAgICAgICAgICAgICAgcmV0dXJuIFV0aWxzLmx0cmltKHNjYWxhci5zbGljZSg1KSk7XG4gICAgICAgICAgICAgIGNhc2UgJyEhaW50JzpcbiAgICAgICAgICAgICAgICByZXR1cm4gcGFyc2VJbnQodGhpcy5wYXJzZVNjYWxhcihzY2FsYXIuc2xpY2UoNSkpKTtcbiAgICAgICAgICAgICAgY2FzZSAnISFib29sJzpcbiAgICAgICAgICAgICAgICByZXR1cm4gVXRpbHMucGFyc2VCb29sZWFuKHRoaXMucGFyc2VTY2FsYXIoc2NhbGFyLnNsaWNlKDYpKSwgZmFsc2UpO1xuICAgICAgICAgICAgICBjYXNlICchIWZsb2F0JzpcbiAgICAgICAgICAgICAgICByZXR1cm4gcGFyc2VGbG9hdCh0aGlzLnBhcnNlU2NhbGFyKHNjYWxhci5zbGljZSg3KSkpO1xuICAgICAgICAgICAgICBjYXNlICchIXRpbWVzdGFtcCc6XG4gICAgICAgICAgICAgICAgcmV0dXJuIFV0aWxzLnN0cmluZ1RvRGF0ZShVdGlscy5sdHJpbShzY2FsYXIuc2xpY2UoMTEpKSk7XG4gICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgaWYgKGNvbnRleHQgPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgY29udGV4dCA9IHtcbiAgICAgICAgICAgICAgICAgICAgZXhjZXB0aW9uT25JbnZhbGlkVHlwZTogdGhpcy5zZXR0aW5ncy5leGNlcHRpb25PbkludmFsaWRUeXBlLFxuICAgICAgICAgICAgICAgICAgICBvYmplY3REZWNvZGVyOiB0aGlzLnNldHRpbmdzLm9iamVjdERlY29kZXIsXG4gICAgICAgICAgICAgICAgICAgIGk6IDBcbiAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIG9iamVjdERlY29kZXIgPSBjb250ZXh0Lm9iamVjdERlY29kZXIsIGV4Y2VwdGlvbk9uSW52YWxpZFR5cGUgPSBjb250ZXh0LmV4Y2VwdGlvbk9uSW52YWxpZFR5cGU7XG4gICAgICAgICAgICAgICAgaWYgKG9iamVjdERlY29kZXIpIHtcbiAgICAgICAgICAgICAgICAgIHRyaW1tZWRTY2FsYXIgPSBVdGlscy5ydHJpbShzY2FsYXIpO1xuICAgICAgICAgICAgICAgICAgZmlyc3RTcGFjZSA9IHRyaW1tZWRTY2FsYXIuaW5kZXhPZignICcpO1xuICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0U3BhY2UgPT09IC0xKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBvYmplY3REZWNvZGVyKHRyaW1tZWRTY2FsYXIsIG51bGwpO1xuICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgc3ViVmFsdWUgPSBVdGlscy5sdHJpbSh0cmltbWVkU2NhbGFyLnNsaWNlKGZpcnN0U3BhY2UgKyAxKSk7XG4gICAgICAgICAgICAgICAgICAgIGlmICghKHN1YlZhbHVlLmxlbmd0aCA+IDApKSB7XG4gICAgICAgICAgICAgICAgICAgICAgc3ViVmFsdWUgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBvYmplY3REZWNvZGVyKHRyaW1tZWRTY2FsYXIuc2xpY2UoMCwgZmlyc3RTcGFjZSksIHN1YlZhbHVlKTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGV4Y2VwdGlvbk9uSW52YWxpZFR5cGUpIHtcbiAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBQYXJzZUV4Y2VwdGlvbignQ3VzdG9tIG9iamVjdCBzdXBwb3J0IHdoZW4gcGFyc2luZyBhIFlBTUwgZmlsZSBoYXMgYmVlbiBkaXNhYmxlZC4nKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICBjYXNlICcwJzpcbiAgICAgICAgICAgIGlmICgnMHgnID09PSBzY2FsYXIuc2xpY2UoMCwgMikpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIFV0aWxzLmhleERlYyhzY2FsYXIpO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChVdGlscy5pc0RpZ2l0cyhzY2FsYXIpKSB7XG4gICAgICAgICAgICAgIHJldHVybiBVdGlscy5vY3REZWMoc2NhbGFyKTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoVXRpbHMuaXNOdW1lcmljKHNjYWxhcikpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHBhcnNlRmxvYXQoc2NhbGFyKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIHJldHVybiBzY2FsYXI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICBjYXNlICcrJzpcbiAgICAgICAgICAgIGlmIChVdGlscy5pc0RpZ2l0cyhzY2FsYXIpKSB7XG4gICAgICAgICAgICAgIHJhdyA9IHNjYWxhcjtcbiAgICAgICAgICAgICAgY2FzdCA9IHBhcnNlSW50KHJhdyk7XG4gICAgICAgICAgICAgIGlmIChyYXcgPT09IFN0cmluZyhjYXN0KSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBjYXN0O1xuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHJldHVybiByYXc7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSBpZiAoVXRpbHMuaXNOdW1lcmljKHNjYWxhcikpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHBhcnNlRmxvYXQoc2NhbGFyKTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAodGhpcy5QQVRURVJOX1RIT1VTQU5EX05VTUVSSUNfU0NBTEFSLnRlc3Qoc2NhbGFyKSkge1xuICAgICAgICAgICAgICByZXR1cm4gcGFyc2VGbG9hdChzY2FsYXIucmVwbGFjZSgnLCcsICcnKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gc2NhbGFyO1xuICAgICAgICAgIGNhc2UgJy0nOlxuICAgICAgICAgICAgaWYgKFV0aWxzLmlzRGlnaXRzKHNjYWxhci5zbGljZSgxKSkpIHtcbiAgICAgICAgICAgICAgaWYgKCcwJyA9PT0gc2NhbGFyLmNoYXJBdCgxKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiAtVXRpbHMub2N0RGVjKHNjYWxhci5zbGljZSgxKSk7XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcmF3ID0gc2NhbGFyLnNsaWNlKDEpO1xuICAgICAgICAgICAgICAgIGNhc3QgPSBwYXJzZUludChyYXcpO1xuICAgICAgICAgICAgICAgIGlmIChyYXcgPT09IFN0cmluZyhjYXN0KSkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIC1jYXN0O1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gLXJhdztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSBpZiAoVXRpbHMuaXNOdW1lcmljKHNjYWxhcikpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHBhcnNlRmxvYXQoc2NhbGFyKTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAodGhpcy5QQVRURVJOX1RIT1VTQU5EX05VTUVSSUNfU0NBTEFSLnRlc3Qoc2NhbGFyKSkge1xuICAgICAgICAgICAgICByZXR1cm4gcGFyc2VGbG9hdChzY2FsYXIucmVwbGFjZSgnLCcsICcnKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gc2NhbGFyO1xuICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICBpZiAoZGF0ZSA9IFV0aWxzLnN0cmluZ1RvRGF0ZShzY2FsYXIpKSB7XG4gICAgICAgICAgICAgIHJldHVybiBkYXRlO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChVdGlscy5pc051bWVyaWMoc2NhbGFyKSkge1xuICAgICAgICAgICAgICByZXR1cm4gcGFyc2VGbG9hdChzY2FsYXIpO1xuICAgICAgICAgICAgfSBlbHNlIGlmICh0aGlzLlBBVFRFUk5fVEhPVVNBTkRfTlVNRVJJQ19TQ0FMQVIudGVzdChzY2FsYXIpKSB7XG4gICAgICAgICAgICAgIHJldHVybiBwYXJzZUZsb2F0KHNjYWxhci5yZXBsYWNlKCcsJywgJycpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBzY2FsYXI7XG4gICAgICAgIH1cbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIElubGluZTtcblxufSkoKTtcblxubW9kdWxlLmV4cG9ydHMgPSBJbmxpbmU7XG4iLCIvLyBHZW5lcmF0ZWQgYnkgQ29mZmVlU2NyaXB0IDEuMTIuNFxudmFyIElubGluZSwgUGFyc2VFeGNlcHRpb24sIFBhcnNlTW9yZSwgUGFyc2VyLCBQYXR0ZXJuLCBVdGlscztcblxuSW5saW5lID0gcmVxdWlyZSgnLi9JbmxpbmUnKTtcblxuUGF0dGVybiA9IHJlcXVpcmUoJy4vUGF0dGVybicpO1xuXG5VdGlscyA9IHJlcXVpcmUoJy4vVXRpbHMnKTtcblxuUGFyc2VFeGNlcHRpb24gPSByZXF1aXJlKCcuL0V4Y2VwdGlvbi9QYXJzZUV4Y2VwdGlvbicpO1xuXG5QYXJzZU1vcmUgPSByZXF1aXJlKCcuL0V4Y2VwdGlvbi9QYXJzZU1vcmUnKTtcblxuUGFyc2VyID0gKGZ1bmN0aW9uKCkge1xuICBQYXJzZXIucHJvdG90eXBlLlBBVFRFUk5fRk9MREVEX1NDQUxBUl9BTEwgPSBuZXcgUGF0dGVybignXig/Oig/PHR5cGU+IVteXFxcXHw+XSopXFxcXHMrKT8oPzxzZXBhcmF0b3I+XFxcXHx8PikoPzxtb2RpZmllcnM+XFxcXCt8XFxcXC18XFxcXGQrfFxcXFwrXFxcXGQrfFxcXFwtXFxcXGQrfFxcXFxkK1xcXFwrfFxcXFxkK1xcXFwtKT8oPzxjb21tZW50cz4gKyMuKik/JCcpO1xuXG4gIFBhcnNlci5wcm90b3R5cGUuUEFUVEVSTl9GT0xERURfU0NBTEFSX0VORCA9IG5ldyBQYXR0ZXJuKCcoPzxzZXBhcmF0b3I+XFxcXHx8PikoPzxtb2RpZmllcnM+XFxcXCt8XFxcXC18XFxcXGQrfFxcXFwrXFxcXGQrfFxcXFwtXFxcXGQrfFxcXFxkK1xcXFwrfFxcXFxkK1xcXFwtKT8oPzxjb21tZW50cz4gKyMuKik/JCcpO1xuXG4gIFBhcnNlci5wcm90b3R5cGUuUEFUVEVSTl9TRVFVRU5DRV9JVEVNID0gbmV3IFBhdHRlcm4oJ15cXFxcLSgoPzxsZWFkc3BhY2VzPlxcXFxzKykoPzx2YWx1ZT4uKz8pKT9cXFxccyokJyk7XG5cbiAgUGFyc2VyLnByb3RvdHlwZS5QQVRURVJOX0FOQ0hPUl9WQUxVRSA9IG5ldyBQYXR0ZXJuKCdeJig/PHJlZj5bXiBdKykgKig/PHZhbHVlPi4qKScpO1xuXG4gIFBhcnNlci5wcm90b3R5cGUuUEFUVEVSTl9DT01QQUNUX05PVEFUSU9OID0gbmV3IFBhdHRlcm4oJ14oPzxrZXk+JyArIElubGluZS5SRUdFWF9RVU9URURfU1RSSU5HICsgJ3xbXiBcXCdcIlxcXFx7XFxcXFtdLio/KSAqXFxcXDooXFxcXHMrKD88dmFsdWU+Lis/KSk/XFxcXHMqJCcpO1xuXG4gIFBhcnNlci5wcm90b3R5cGUuUEFUVEVSTl9NQVBQSU5HX0lURU0gPSBuZXcgUGF0dGVybignXig/PGtleT4nICsgSW5saW5lLlJFR0VYX1FVT1RFRF9TVFJJTkcgKyAnfFteIFxcJ1wiXFxcXFtcXFxce10uKj8pICpcXFxcOihcXFxccysoPzx2YWx1ZT4uKz8pKT9cXFxccyokJyk7XG5cbiAgUGFyc2VyLnByb3RvdHlwZS5QQVRURVJOX0RFQ0lNQUwgPSBuZXcgUGF0dGVybignXFxcXGQrJyk7XG5cbiAgUGFyc2VyLnByb3RvdHlwZS5QQVRURVJOX0lOREVOVF9TUEFDRVMgPSBuZXcgUGF0dGVybignXiArJyk7XG5cbiAgUGFyc2VyLnByb3RvdHlwZS5QQVRURVJOX1RSQUlMSU5HX0xJTkVTID0gbmV3IFBhdHRlcm4oJyhcXG4qKSQnKTtcblxuICBQYXJzZXIucHJvdG90eXBlLlBBVFRFUk5fWUFNTF9IRUFERVIgPSBuZXcgUGF0dGVybignXlxcXFwlWUFNTFs6IF1bXFxcXGRcXFxcLl0rLipcXG4nLCAnbScpO1xuXG4gIFBhcnNlci5wcm90b3R5cGUuUEFUVEVSTl9MRUFESU5HX0NPTU1FTlRTID0gbmV3IFBhdHRlcm4oJ14oXFxcXCMuKj9cXG4pKycsICdtJyk7XG5cbiAgUGFyc2VyLnByb3RvdHlwZS5QQVRURVJOX0RPQ1VNRU5UX01BUktFUl9TVEFSVCA9IG5ldyBQYXR0ZXJuKCdeXFxcXC1cXFxcLVxcXFwtLio/XFxuJywgJ20nKTtcblxuICBQYXJzZXIucHJvdG90eXBlLlBBVFRFUk5fRE9DVU1FTlRfTUFSS0VSX0VORCA9IG5ldyBQYXR0ZXJuKCdeXFxcXC5cXFxcLlxcXFwuXFxcXHMqJCcsICdtJyk7XG5cbiAgUGFyc2VyLnByb3RvdHlwZS5QQVRURVJOX0ZPTERFRF9TQ0FMQVJfQllfSU5ERU5UQVRJT04gPSB7fTtcblxuICBQYXJzZXIucHJvdG90eXBlLkNPTlRFWFRfTk9ORSA9IDA7XG5cbiAgUGFyc2VyLnByb3RvdHlwZS5DT05URVhUX1NFUVVFTkNFID0gMTtcblxuICBQYXJzZXIucHJvdG90eXBlLkNPTlRFWFRfTUFQUElORyA9IDI7XG5cbiAgZnVuY3Rpb24gUGFyc2VyKG9mZnNldCkge1xuICAgIHRoaXMub2Zmc2V0ID0gb2Zmc2V0ICE9IG51bGwgPyBvZmZzZXQgOiAwO1xuICAgIHRoaXMubGluZXMgPSBbXTtcbiAgICB0aGlzLmN1cnJlbnRMaW5lTmIgPSAtMTtcbiAgICB0aGlzLmN1cnJlbnRMaW5lID0gJyc7XG4gICAgdGhpcy5yZWZzID0ge307XG4gIH1cblxuICBQYXJzZXIucHJvdG90eXBlLnBhcnNlID0gZnVuY3Rpb24odmFsdWUsIGV4Y2VwdGlvbk9uSW52YWxpZFR5cGUsIG9iamVjdERlY29kZXIpIHtcbiAgICB2YXIgYWxpYXMsIGFsbG93T3ZlcndyaXRlLCBibG9jaywgYywgY29udGV4dCwgZGF0YSwgZSwgZmlyc3QsIGksIGluZGVudCwgaXNSZWYsIGosIGssIGtleSwgbCwgbGFzdEtleSwgbGVuLCBsZW4xLCBsZW4yLCBsZW4zLCBsaW5lQ291bnQsIG0sIG1hdGNoZXMsIG1lcmdlTm9kZSwgbiwgbmFtZSwgcGFyc2VkLCBwYXJzZWRJdGVtLCBwYXJzZXIsIHJlZiwgcmVmMSwgcmVmMiwgcmVmTmFtZSwgcmVmVmFsdWUsIHZhbCwgdmFsdWVzO1xuICAgIGlmIChleGNlcHRpb25PbkludmFsaWRUeXBlID09IG51bGwpIHtcbiAgICAgIGV4Y2VwdGlvbk9uSW52YWxpZFR5cGUgPSBmYWxzZTtcbiAgICB9XG4gICAgaWYgKG9iamVjdERlY29kZXIgPT0gbnVsbCkge1xuICAgICAgb2JqZWN0RGVjb2RlciA9IG51bGw7XG4gICAgfVxuICAgIHRoaXMuY3VycmVudExpbmVOYiA9IC0xO1xuICAgIHRoaXMuY3VycmVudExpbmUgPSAnJztcbiAgICB0aGlzLmxpbmVzID0gdGhpcy5jbGVhbnVwKHZhbHVlKS5zcGxpdChcIlxcblwiKTtcbiAgICBkYXRhID0gbnVsbDtcbiAgICBjb250ZXh0ID0gdGhpcy5DT05URVhUX05PTkU7XG4gICAgYWxsb3dPdmVyd3JpdGUgPSBmYWxzZTtcbiAgICB3aGlsZSAodGhpcy5tb3ZlVG9OZXh0TGluZSgpKSB7XG4gICAgICBpZiAodGhpcy5pc0N1cnJlbnRMaW5lRW1wdHkoKSkge1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIGlmIChcIlxcdFwiID09PSB0aGlzLmN1cnJlbnRMaW5lWzBdKSB7XG4gICAgICAgIHRocm93IG5ldyBQYXJzZUV4Y2VwdGlvbignQSBZQU1MIGZpbGUgY2Fubm90IGNvbnRhaW4gdGFicyBhcyBpbmRlbnRhdGlvbi4nLCB0aGlzLmdldFJlYWxDdXJyZW50TGluZU5iKCkgKyAxLCB0aGlzLmN1cnJlbnRMaW5lKTtcbiAgICAgIH1cbiAgICAgIGlzUmVmID0gbWVyZ2VOb2RlID0gZmFsc2U7XG4gICAgICBpZiAodmFsdWVzID0gdGhpcy5QQVRURVJOX1NFUVVFTkNFX0lURU0uZXhlYyh0aGlzLmN1cnJlbnRMaW5lKSkge1xuICAgICAgICBpZiAodGhpcy5DT05URVhUX01BUFBJTkcgPT09IGNvbnRleHQpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgUGFyc2VFeGNlcHRpb24oJ1lvdSBjYW5ub3QgZGVmaW5lIGEgc2VxdWVuY2UgaXRlbSB3aGVuIGluIGEgbWFwcGluZycpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnRleHQgPSB0aGlzLkNPTlRFWFRfU0VRVUVOQ0U7XG4gICAgICAgIGlmIChkYXRhID09IG51bGwpIHtcbiAgICAgICAgICBkYXRhID0gW107XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCh2YWx1ZXMudmFsdWUgIT0gbnVsbCkgJiYgKG1hdGNoZXMgPSB0aGlzLlBBVFRFUk5fQU5DSE9SX1ZBTFVFLmV4ZWModmFsdWVzLnZhbHVlKSkpIHtcbiAgICAgICAgICBpc1JlZiA9IG1hdGNoZXMucmVmO1xuICAgICAgICAgIHZhbHVlcy52YWx1ZSA9IG1hdGNoZXMudmFsdWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCEodmFsdWVzLnZhbHVlICE9IG51bGwpIHx8ICcnID09PSBVdGlscy50cmltKHZhbHVlcy52YWx1ZSwgJyAnKSB8fCBVdGlscy5sdHJpbSh2YWx1ZXMudmFsdWUsICcgJykuaW5kZXhPZignIycpID09PSAwKSB7XG4gICAgICAgICAgaWYgKHRoaXMuY3VycmVudExpbmVOYiA8IHRoaXMubGluZXMubGVuZ3RoIC0gMSAmJiAhdGhpcy5pc05leHRMaW5lVW5JbmRlbnRlZENvbGxlY3Rpb24oKSkge1xuICAgICAgICAgICAgYyA9IHRoaXMuZ2V0UmVhbEN1cnJlbnRMaW5lTmIoKSArIDE7XG4gICAgICAgICAgICBwYXJzZXIgPSBuZXcgUGFyc2VyKGMpO1xuICAgICAgICAgICAgcGFyc2VyLnJlZnMgPSB0aGlzLnJlZnM7XG4gICAgICAgICAgICBkYXRhLnB1c2gocGFyc2VyLnBhcnNlKHRoaXMuZ2V0TmV4dEVtYmVkQmxvY2sobnVsbCwgdHJ1ZSksIGV4Y2VwdGlvbk9uSW52YWxpZFR5cGUsIG9iamVjdERlY29kZXIpKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZGF0YS5wdXNoKG51bGwpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpZiAoKChyZWYgPSB2YWx1ZXMubGVhZHNwYWNlcykgIT0gbnVsbCA/IHJlZi5sZW5ndGggOiB2b2lkIDApICYmIChtYXRjaGVzID0gdGhpcy5QQVRURVJOX0NPTVBBQ1RfTk9UQVRJT04uZXhlYyh2YWx1ZXMudmFsdWUpKSkge1xuICAgICAgICAgICAgYyA9IHRoaXMuZ2V0UmVhbEN1cnJlbnRMaW5lTmIoKTtcbiAgICAgICAgICAgIHBhcnNlciA9IG5ldyBQYXJzZXIoYyk7XG4gICAgICAgICAgICBwYXJzZXIucmVmcyA9IHRoaXMucmVmcztcbiAgICAgICAgICAgIGJsb2NrID0gdmFsdWVzLnZhbHVlO1xuICAgICAgICAgICAgaW5kZW50ID0gdGhpcy5nZXRDdXJyZW50TGluZUluZGVudGF0aW9uKCk7XG4gICAgICAgICAgICBpZiAodGhpcy5pc05leHRMaW5lSW5kZW50ZWQoZmFsc2UpKSB7XG4gICAgICAgICAgICAgIGJsb2NrICs9IFwiXFxuXCIgKyB0aGlzLmdldE5leHRFbWJlZEJsb2NrKGluZGVudCArIHZhbHVlcy5sZWFkc3BhY2VzLmxlbmd0aCArIDEsIHRydWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZGF0YS5wdXNoKHBhcnNlci5wYXJzZShibG9jaywgZXhjZXB0aW9uT25JbnZhbGlkVHlwZSwgb2JqZWN0RGVjb2RlcikpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBkYXRhLnB1c2godGhpcy5wYXJzZVZhbHVlKHZhbHVlcy52YWx1ZSwgZXhjZXB0aW9uT25JbnZhbGlkVHlwZSwgb2JqZWN0RGVjb2RlcikpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmICgodmFsdWVzID0gdGhpcy5QQVRURVJOX01BUFBJTkdfSVRFTS5leGVjKHRoaXMuY3VycmVudExpbmUpKSAmJiB2YWx1ZXMua2V5LmluZGV4T2YoJyAjJykgPT09IC0xKSB7XG4gICAgICAgIGlmICh0aGlzLkNPTlRFWFRfU0VRVUVOQ0UgPT09IGNvbnRleHQpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgUGFyc2VFeGNlcHRpb24oJ1lvdSBjYW5ub3QgZGVmaW5lIGEgbWFwcGluZyBpdGVtIHdoZW4gaW4gYSBzZXF1ZW5jZScpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnRleHQgPSB0aGlzLkNPTlRFWFRfTUFQUElORztcbiAgICAgICAgaWYgKGRhdGEgPT0gbnVsbCkge1xuICAgICAgICAgIGRhdGEgPSB7fTtcbiAgICAgICAgfVxuICAgICAgICBJbmxpbmUuY29uZmlndXJlKGV4Y2VwdGlvbk9uSW52YWxpZFR5cGUsIG9iamVjdERlY29kZXIpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGtleSA9IElubGluZS5wYXJzZVNjYWxhcih2YWx1ZXMua2V5KTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICBlID0gZXJyb3I7XG4gICAgICAgICAgZS5wYXJzZWRMaW5lID0gdGhpcy5nZXRSZWFsQ3VycmVudExpbmVOYigpICsgMTtcbiAgICAgICAgICBlLnNuaXBwZXQgPSB0aGlzLmN1cnJlbnRMaW5lO1xuICAgICAgICAgIHRocm93IGU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCc8PCcgPT09IGtleSkge1xuICAgICAgICAgIG1lcmdlTm9kZSA9IHRydWU7XG4gICAgICAgICAgYWxsb3dPdmVyd3JpdGUgPSB0cnVlO1xuICAgICAgICAgIGlmICgoKHJlZjEgPSB2YWx1ZXMudmFsdWUpICE9IG51bGwgPyByZWYxLmluZGV4T2YoJyonKSA6IHZvaWQgMCkgPT09IDApIHtcbiAgICAgICAgICAgIHJlZk5hbWUgPSB2YWx1ZXMudmFsdWUuc2xpY2UoMSk7XG4gICAgICAgICAgICBpZiAodGhpcy5yZWZzW3JlZk5hbWVdID09IG51bGwpIHtcbiAgICAgICAgICAgICAgdGhyb3cgbmV3IFBhcnNlRXhjZXB0aW9uKCdSZWZlcmVuY2UgXCInICsgcmVmTmFtZSArICdcIiBkb2VzIG5vdCBleGlzdC4nLCB0aGlzLmdldFJlYWxDdXJyZW50TGluZU5iKCkgKyAxLCB0aGlzLmN1cnJlbnRMaW5lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJlZlZhbHVlID0gdGhpcy5yZWZzW3JlZk5hbWVdO1xuICAgICAgICAgICAgaWYgKHR5cGVvZiByZWZWYWx1ZSAhPT0gJ29iamVjdCcpIHtcbiAgICAgICAgICAgICAgdGhyb3cgbmV3IFBhcnNlRXhjZXB0aW9uKCdZQU1MIG1lcmdlIGtleXMgdXNlZCB3aXRoIGEgc2NhbGFyIHZhbHVlIGluc3RlYWQgb2YgYW4gb2JqZWN0LicsIHRoaXMuZ2V0UmVhbEN1cnJlbnRMaW5lTmIoKSArIDEsIHRoaXMuY3VycmVudExpbmUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHJlZlZhbHVlIGluc3RhbmNlb2YgQXJyYXkpIHtcbiAgICAgICAgICAgICAgZm9yIChpID0gaiA9IDAsIGxlbiA9IHJlZlZhbHVlLmxlbmd0aDsgaiA8IGxlbjsgaSA9ICsraikge1xuICAgICAgICAgICAgICAgIHZhbHVlID0gcmVmVmFsdWVbaV07XG4gICAgICAgICAgICAgICAgaWYgKGRhdGFbbmFtZSA9IFN0cmluZyhpKV0gPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgZGF0YVtuYW1lXSA9IHZhbHVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgZm9yIChrZXkgaW4gcmVmVmFsdWUpIHtcbiAgICAgICAgICAgICAgICB2YWx1ZSA9IHJlZlZhbHVlW2tleV07XG4gICAgICAgICAgICAgICAgaWYgKGRhdGFba2V5XSA9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICBkYXRhW2tleV0gPSB2YWx1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaWYgKCh2YWx1ZXMudmFsdWUgIT0gbnVsbCkgJiYgdmFsdWVzLnZhbHVlICE9PSAnJykge1xuICAgICAgICAgICAgICB2YWx1ZSA9IHZhbHVlcy52YWx1ZTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIHZhbHVlID0gdGhpcy5nZXROZXh0RW1iZWRCbG9jaygpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYyA9IHRoaXMuZ2V0UmVhbEN1cnJlbnRMaW5lTmIoKSArIDE7XG4gICAgICAgICAgICBwYXJzZXIgPSBuZXcgUGFyc2VyKGMpO1xuICAgICAgICAgICAgcGFyc2VyLnJlZnMgPSB0aGlzLnJlZnM7XG4gICAgICAgICAgICBwYXJzZWQgPSBwYXJzZXIucGFyc2UodmFsdWUsIGV4Y2VwdGlvbk9uSW52YWxpZFR5cGUpO1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBwYXJzZWQgIT09ICdvYmplY3QnKSB7XG4gICAgICAgICAgICAgIHRocm93IG5ldyBQYXJzZUV4Y2VwdGlvbignWUFNTCBtZXJnZSBrZXlzIHVzZWQgd2l0aCBhIHNjYWxhciB2YWx1ZSBpbnN0ZWFkIG9mIGFuIG9iamVjdC4nLCB0aGlzLmdldFJlYWxDdXJyZW50TGluZU5iKCkgKyAxLCB0aGlzLmN1cnJlbnRMaW5lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChwYXJzZWQgaW5zdGFuY2VvZiBBcnJheSkge1xuICAgICAgICAgICAgICBmb3IgKGwgPSAwLCBsZW4xID0gcGFyc2VkLmxlbmd0aDsgbCA8IGxlbjE7IGwrKykge1xuICAgICAgICAgICAgICAgIHBhcnNlZEl0ZW0gPSBwYXJzZWRbbF07XG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBwYXJzZWRJdGVtICE9PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IFBhcnNlRXhjZXB0aW9uKCdNZXJnZSBpdGVtcyBtdXN0IGJlIG9iamVjdHMuJywgdGhpcy5nZXRSZWFsQ3VycmVudExpbmVOYigpICsgMSwgcGFyc2VkSXRlbSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChwYXJzZWRJdGVtIGluc3RhbmNlb2YgQXJyYXkpIHtcbiAgICAgICAgICAgICAgICAgIGZvciAoaSA9IG0gPSAwLCBsZW4yID0gcGFyc2VkSXRlbS5sZW5ndGg7IG0gPCBsZW4yOyBpID0gKyttKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhbHVlID0gcGFyc2VkSXRlbVtpXTtcbiAgICAgICAgICAgICAgICAgICAgayA9IFN0cmluZyhpKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFkYXRhLmhhc093blByb3BlcnR5KGspKSB7XG4gICAgICAgICAgICAgICAgICAgICAgZGF0YVtrXSA9IHZhbHVlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgIGZvciAoa2V5IGluIHBhcnNlZEl0ZW0pIHtcbiAgICAgICAgICAgICAgICAgICAgdmFsdWUgPSBwYXJzZWRJdGVtW2tleV07XG4gICAgICAgICAgICAgICAgICAgIGlmICghZGF0YS5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgZGF0YVtrZXldID0gdmFsdWU7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIGZvciAoa2V5IGluIHBhcnNlZCkge1xuICAgICAgICAgICAgICAgIHZhbHVlID0gcGFyc2VkW2tleV07XG4gICAgICAgICAgICAgICAgaWYgKCFkYXRhLmhhc093blByb3BlcnR5KGtleSkpIHtcbiAgICAgICAgICAgICAgICAgIGRhdGFba2V5XSA9IHZhbHVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIGlmICgodmFsdWVzLnZhbHVlICE9IG51bGwpICYmIChtYXRjaGVzID0gdGhpcy5QQVRURVJOX0FOQ0hPUl9WQUxVRS5leGVjKHZhbHVlcy52YWx1ZSkpKSB7XG4gICAgICAgICAgaXNSZWYgPSBtYXRjaGVzLnJlZjtcbiAgICAgICAgICB2YWx1ZXMudmFsdWUgPSBtYXRjaGVzLnZhbHVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChtZXJnZU5vZGUpIHtcblxuICAgICAgICB9IGVsc2UgaWYgKCEodmFsdWVzLnZhbHVlICE9IG51bGwpIHx8ICcnID09PSBVdGlscy50cmltKHZhbHVlcy52YWx1ZSwgJyAnKSB8fCBVdGlscy5sdHJpbSh2YWx1ZXMudmFsdWUsICcgJykuaW5kZXhPZignIycpID09PSAwKSB7XG4gICAgICAgICAgaWYgKCEodGhpcy5pc05leHRMaW5lSW5kZW50ZWQoKSkgJiYgISh0aGlzLmlzTmV4dExpbmVVbkluZGVudGVkQ29sbGVjdGlvbigpKSkge1xuICAgICAgICAgICAgaWYgKGFsbG93T3ZlcndyaXRlIHx8IGRhdGFba2V5XSA9PT0gdm9pZCAwKSB7XG4gICAgICAgICAgICAgIGRhdGFba2V5XSA9IG51bGw7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGMgPSB0aGlzLmdldFJlYWxDdXJyZW50TGluZU5iKCkgKyAxO1xuICAgICAgICAgICAgcGFyc2VyID0gbmV3IFBhcnNlcihjKTtcbiAgICAgICAgICAgIHBhcnNlci5yZWZzID0gdGhpcy5yZWZzO1xuICAgICAgICAgICAgdmFsID0gcGFyc2VyLnBhcnNlKHRoaXMuZ2V0TmV4dEVtYmVkQmxvY2soKSwgZXhjZXB0aW9uT25JbnZhbGlkVHlwZSwgb2JqZWN0RGVjb2Rlcik7XG4gICAgICAgICAgICBpZiAoYWxsb3dPdmVyd3JpdGUgfHwgZGF0YVtrZXldID09PSB2b2lkIDApIHtcbiAgICAgICAgICAgICAgZGF0YVtrZXldID0gdmFsO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB2YWwgPSB0aGlzLnBhcnNlVmFsdWUodmFsdWVzLnZhbHVlLCBleGNlcHRpb25PbkludmFsaWRUeXBlLCBvYmplY3REZWNvZGVyKTtcbiAgICAgICAgICBpZiAoYWxsb3dPdmVyd3JpdGUgfHwgZGF0YVtrZXldID09PSB2b2lkIDApIHtcbiAgICAgICAgICAgIGRhdGFba2V5XSA9IHZhbDtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGxpbmVDb3VudCA9IHRoaXMubGluZXMubGVuZ3RoO1xuICAgICAgICBpZiAoMSA9PT0gbGluZUNvdW50IHx8ICgyID09PSBsaW5lQ291bnQgJiYgVXRpbHMuaXNFbXB0eSh0aGlzLmxpbmVzWzFdKSkpIHtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgdmFsdWUgPSBJbmxpbmUucGFyc2UodGhpcy5saW5lc1swXSwgZXhjZXB0aW9uT25JbnZhbGlkVHlwZSwgb2JqZWN0RGVjb2Rlcik7XG4gICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGUgPSBlcnJvcjtcbiAgICAgICAgICAgIGUucGFyc2VkTGluZSA9IHRoaXMuZ2V0UmVhbEN1cnJlbnRMaW5lTmIoKSArIDE7XG4gICAgICAgICAgICBlLnNuaXBwZXQgPSB0aGlzLmN1cnJlbnRMaW5lO1xuICAgICAgICAgICAgdGhyb3cgZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgICAgIGlmICh2YWx1ZSBpbnN0YW5jZW9mIEFycmF5KSB7XG4gICAgICAgICAgICAgIGZpcnN0ID0gdmFsdWVbMF07XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBmb3IgKGtleSBpbiB2YWx1ZSkge1xuICAgICAgICAgICAgICAgIGZpcnN0ID0gdmFsdWVba2V5XTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHR5cGVvZiBmaXJzdCA9PT0gJ3N0cmluZycgJiYgZmlyc3QuaW5kZXhPZignKicpID09PSAwKSB7XG4gICAgICAgICAgICAgIGRhdGEgPSBbXTtcbiAgICAgICAgICAgICAgZm9yIChuID0gMCwgbGVuMyA9IHZhbHVlLmxlbmd0aDsgbiA8IGxlbjM7IG4rKykge1xuICAgICAgICAgICAgICAgIGFsaWFzID0gdmFsdWVbbl07XG4gICAgICAgICAgICAgICAgZGF0YS5wdXNoKHRoaXMucmVmc1thbGlhcy5zbGljZSgxKV0pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHZhbHVlID0gZGF0YTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgICB9IGVsc2UgaWYgKChyZWYyID0gVXRpbHMubHRyaW0odmFsdWUpLmNoYXJBdCgwKSkgPT09ICdbJyB8fCByZWYyID09PSAneycpIHtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgcmV0dXJuIElubGluZS5wYXJzZSh2YWx1ZSwgZXhjZXB0aW9uT25JbnZhbGlkVHlwZSwgb2JqZWN0RGVjb2Rlcik7XG4gICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGUgPSBlcnJvcjtcbiAgICAgICAgICAgIGUucGFyc2VkTGluZSA9IHRoaXMuZ2V0UmVhbEN1cnJlbnRMaW5lTmIoKSArIDE7XG4gICAgICAgICAgICBlLnNuaXBwZXQgPSB0aGlzLmN1cnJlbnRMaW5lO1xuICAgICAgICAgICAgdGhyb3cgZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGhyb3cgbmV3IFBhcnNlRXhjZXB0aW9uKCdVbmFibGUgdG8gcGFyc2UuJywgdGhpcy5nZXRSZWFsQ3VycmVudExpbmVOYigpICsgMSwgdGhpcy5jdXJyZW50TGluZSk7XG4gICAgICB9XG4gICAgICBpZiAoaXNSZWYpIHtcbiAgICAgICAgaWYgKGRhdGEgaW5zdGFuY2VvZiBBcnJheSkge1xuICAgICAgICAgIHRoaXMucmVmc1tpc1JlZl0gPSBkYXRhW2RhdGEubGVuZ3RoIC0gMV07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgbGFzdEtleSA9IG51bGw7XG4gICAgICAgICAgZm9yIChrZXkgaW4gZGF0YSkge1xuICAgICAgICAgICAgbGFzdEtleSA9IGtleTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhpcy5yZWZzW2lzUmVmXSA9IGRhdGFbbGFzdEtleV07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKFV0aWxzLmlzRW1wdHkoZGF0YSkpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gZGF0YTtcbiAgICB9XG4gIH07XG5cbiAgUGFyc2VyLnByb3RvdHlwZS5nZXRSZWFsQ3VycmVudExpbmVOYiA9IGZ1bmN0aW9uKCkge1xuICAgIHJldHVybiB0aGlzLmN1cnJlbnRMaW5lTmIgKyB0aGlzLm9mZnNldDtcbiAgfTtcblxuICBQYXJzZXIucHJvdG90eXBlLmdldEN1cnJlbnRMaW5lSW5kZW50YXRpb24gPSBmdW5jdGlvbigpIHtcbiAgICByZXR1cm4gdGhpcy5jdXJyZW50TGluZS5sZW5ndGggLSBVdGlscy5sdHJpbSh0aGlzLmN1cnJlbnRMaW5lLCAnICcpLmxlbmd0aDtcbiAgfTtcblxuICBQYXJzZXIucHJvdG90eXBlLmdldE5leHRFbWJlZEJsb2NrID0gZnVuY3Rpb24oaW5kZW50YXRpb24sIGluY2x1ZGVVbmluZGVudGVkQ29sbGVjdGlvbikge1xuICAgIHZhciBkYXRhLCBpbmRlbnQsIGlzSXRVbmluZGVudGVkQ29sbGVjdGlvbiwgbmV3SW5kZW50LCByZW1vdmVDb21tZW50cywgcmVtb3ZlQ29tbWVudHNQYXR0ZXJuLCB1bmluZGVudGVkRW1iZWRCbG9jaztcbiAgICBpZiAoaW5kZW50YXRpb24gPT0gbnVsbCkge1xuICAgICAgaW5kZW50YXRpb24gPSBudWxsO1xuICAgIH1cbiAgICBpZiAoaW5jbHVkZVVuaW5kZW50ZWRDb2xsZWN0aW9uID09IG51bGwpIHtcbiAgICAgIGluY2x1ZGVVbmluZGVudGVkQ29sbGVjdGlvbiA9IGZhbHNlO1xuICAgIH1cbiAgICB0aGlzLm1vdmVUb05leHRMaW5lKCk7XG4gICAgaWYgKGluZGVudGF0aW9uID09IG51bGwpIHtcbiAgICAgIG5ld0luZGVudCA9IHRoaXMuZ2V0Q3VycmVudExpbmVJbmRlbnRhdGlvbigpO1xuICAgICAgdW5pbmRlbnRlZEVtYmVkQmxvY2sgPSB0aGlzLmlzU3RyaW5nVW5JbmRlbnRlZENvbGxlY3Rpb25JdGVtKHRoaXMuY3VycmVudExpbmUpO1xuICAgICAgaWYgKCEodGhpcy5pc0N1cnJlbnRMaW5lRW1wdHkoKSkgJiYgMCA9PT0gbmV3SW5kZW50ICYmICF1bmluZGVudGVkRW1iZWRCbG9jaykge1xuICAgICAgICB0aHJvdyBuZXcgUGFyc2VFeGNlcHRpb24oJ0luZGVudGF0aW9uIHByb2JsZW0uJywgdGhpcy5nZXRSZWFsQ3VycmVudExpbmVOYigpICsgMSwgdGhpcy5jdXJyZW50TGluZSk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIG5ld0luZGVudCA9IGluZGVudGF0aW9uO1xuICAgIH1cbiAgICBkYXRhID0gW3RoaXMuY3VycmVudExpbmUuc2xpY2UobmV3SW5kZW50KV07XG4gICAgaWYgKCFpbmNsdWRlVW5pbmRlbnRlZENvbGxlY3Rpb24pIHtcbiAgICAgIGlzSXRVbmluZGVudGVkQ29sbGVjdGlvbiA9IHRoaXMuaXNTdHJpbmdVbkluZGVudGVkQ29sbGVjdGlvbkl0ZW0odGhpcy5jdXJyZW50TGluZSk7XG4gICAgfVxuICAgIHJlbW92ZUNvbW1lbnRzUGF0dGVybiA9IHRoaXMuUEFUVEVSTl9GT0xERURfU0NBTEFSX0VORDtcbiAgICByZW1vdmVDb21tZW50cyA9ICFyZW1vdmVDb21tZW50c1BhdHRlcm4udGVzdCh0aGlzLmN1cnJlbnRMaW5lKTtcbiAgICB3aGlsZSAodGhpcy5tb3ZlVG9OZXh0TGluZSgpKSB7XG4gICAgICBpbmRlbnQgPSB0aGlzLmdldEN1cnJlbnRMaW5lSW5kZW50YXRpb24oKTtcbiAgICAgIGlmIChpbmRlbnQgPT09IG5ld0luZGVudCkge1xuICAgICAgICByZW1vdmVDb21tZW50cyA9ICFyZW1vdmVDb21tZW50c1BhdHRlcm4udGVzdCh0aGlzLmN1cnJlbnRMaW5lKTtcbiAgICAgIH1cbiAgICAgIGlmIChyZW1vdmVDb21tZW50cyAmJiB0aGlzLmlzQ3VycmVudExpbmVDb21tZW50KCkpIHtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBpZiAodGhpcy5pc0N1cnJlbnRMaW5lQmxhbmsoKSkge1xuICAgICAgICBkYXRhLnB1c2godGhpcy5jdXJyZW50TGluZS5zbGljZShuZXdJbmRlbnQpKTtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBpZiAoaXNJdFVuaW5kZW50ZWRDb2xsZWN0aW9uICYmICF0aGlzLmlzU3RyaW5nVW5JbmRlbnRlZENvbGxlY3Rpb25JdGVtKHRoaXMuY3VycmVudExpbmUpICYmIGluZGVudCA9PT0gbmV3SW5kZW50KSB7XG4gICAgICAgIHRoaXMubW92ZVRvUHJldmlvdXNMaW5lKCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgaWYgKGluZGVudCA+PSBuZXdJbmRlbnQpIHtcbiAgICAgICAgZGF0YS5wdXNoKHRoaXMuY3VycmVudExpbmUuc2xpY2UobmV3SW5kZW50KSk7XG4gICAgICB9IGVsc2UgaWYgKFV0aWxzLmx0cmltKHRoaXMuY3VycmVudExpbmUpLmNoYXJBdCgwKSA9PT0gJyMnKSB7XG5cbiAgICAgIH0gZWxzZSBpZiAoMCA9PT0gaW5kZW50KSB7XG4gICAgICAgIHRoaXMubW92ZVRvUHJldmlvdXNMaW5lKCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgbmV3IFBhcnNlRXhjZXB0aW9uKCdJbmRlbnRhdGlvbiBwcm9ibGVtLicsIHRoaXMuZ2V0UmVhbEN1cnJlbnRMaW5lTmIoKSArIDEsIHRoaXMuY3VycmVudExpbmUpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZGF0YS5qb2luKFwiXFxuXCIpO1xuICB9O1xuXG4gIFBhcnNlci5wcm90b3R5cGUubW92ZVRvTmV4dExpbmUgPSBmdW5jdGlvbigpIHtcbiAgICBpZiAodGhpcy5jdXJyZW50TGluZU5iID49IHRoaXMubGluZXMubGVuZ3RoIC0gMSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICB0aGlzLmN1cnJlbnRMaW5lID0gdGhpcy5saW5lc1srK3RoaXMuY3VycmVudExpbmVOYl07XG4gICAgcmV0dXJuIHRydWU7XG4gIH07XG5cbiAgUGFyc2VyLnByb3RvdHlwZS5tb3ZlVG9QcmV2aW91c0xpbmUgPSBmdW5jdGlvbigpIHtcbiAgICB0aGlzLmN1cnJlbnRMaW5lID0gdGhpcy5saW5lc1stLXRoaXMuY3VycmVudExpbmVOYl07XG4gIH07XG5cbiAgUGFyc2VyLnByb3RvdHlwZS5wYXJzZVZhbHVlID0gZnVuY3Rpb24odmFsdWUsIGV4Y2VwdGlvbk9uSW52YWxpZFR5cGUsIG9iamVjdERlY29kZXIpIHtcbiAgICB2YXIgZSwgZm9sZGVkSW5kZW50LCBtYXRjaGVzLCBtb2RpZmllcnMsIHBvcywgcmVmLCByZWYxLCB2YWw7XG4gICAgaWYgKDAgPT09IHZhbHVlLmluZGV4T2YoJyonKSkge1xuICAgICAgcG9zID0gdmFsdWUuaW5kZXhPZignIycpO1xuICAgICAgaWYgKHBvcyAhPT0gLTEpIHtcbiAgICAgICAgdmFsdWUgPSB2YWx1ZS5zdWJzdHIoMSwgcG9zIC0gMik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB2YWx1ZSA9IHZhbHVlLnNsaWNlKDEpO1xuICAgICAgfVxuICAgICAgaWYgKHRoaXMucmVmc1t2YWx1ZV0gPT09IHZvaWQgMCkge1xuICAgICAgICB0aHJvdyBuZXcgUGFyc2VFeGNlcHRpb24oJ1JlZmVyZW5jZSBcIicgKyB2YWx1ZSArICdcIiBkb2VzIG5vdCBleGlzdC4nLCB0aGlzLmN1cnJlbnRMaW5lKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0aGlzLnJlZnNbdmFsdWVdO1xuICAgIH1cbiAgICBpZiAobWF0Y2hlcyA9IHRoaXMuUEFUVEVSTl9GT0xERURfU0NBTEFSX0FMTC5leGVjKHZhbHVlKSkge1xuICAgICAgbW9kaWZpZXJzID0gKHJlZiA9IG1hdGNoZXMubW9kaWZpZXJzKSAhPSBudWxsID8gcmVmIDogJyc7XG4gICAgICBmb2xkZWRJbmRlbnQgPSBNYXRoLmFicyhwYXJzZUludChtb2RpZmllcnMpKTtcbiAgICAgIGlmIChpc05hTihmb2xkZWRJbmRlbnQpKSB7XG4gICAgICAgIGZvbGRlZEluZGVudCA9IDA7XG4gICAgICB9XG4gICAgICB2YWwgPSB0aGlzLnBhcnNlRm9sZGVkU2NhbGFyKG1hdGNoZXMuc2VwYXJhdG9yLCB0aGlzLlBBVFRFUk5fREVDSU1BTC5yZXBsYWNlKG1vZGlmaWVycywgJycpLCBmb2xkZWRJbmRlbnQpO1xuICAgICAgaWYgKG1hdGNoZXMudHlwZSAhPSBudWxsKSB7XG4gICAgICAgIElubGluZS5jb25maWd1cmUoZXhjZXB0aW9uT25JbnZhbGlkVHlwZSwgb2JqZWN0RGVjb2Rlcik7XG4gICAgICAgIHJldHVybiBJbmxpbmUucGFyc2VTY2FsYXIobWF0Y2hlcy50eXBlICsgJyAnICsgdmFsKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiB2YWw7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICgocmVmMSA9IHZhbHVlLmNoYXJBdCgwKSkgPT09ICdbJyB8fCByZWYxID09PSAneycgfHwgcmVmMSA9PT0gJ1wiJyB8fCByZWYxID09PSBcIidcIikge1xuICAgICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICByZXR1cm4gSW5saW5lLnBhcnNlKHZhbHVlLCBleGNlcHRpb25PbkludmFsaWRUeXBlLCBvYmplY3REZWNvZGVyKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICBlID0gZXJyb3I7XG4gICAgICAgICAgaWYgKGUgaW5zdGFuY2VvZiBQYXJzZU1vcmUgJiYgdGhpcy5tb3ZlVG9OZXh0TGluZSgpKSB7XG4gICAgICAgICAgICB2YWx1ZSArPSBcIlxcblwiICsgVXRpbHMudHJpbSh0aGlzLmN1cnJlbnRMaW5lLCAnICcpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBlLnBhcnNlZExpbmUgPSB0aGlzLmdldFJlYWxDdXJyZW50TGluZU5iKCkgKyAxO1xuICAgICAgICAgICAgZS5zbmlwcGV0ID0gdGhpcy5jdXJyZW50TGluZTtcbiAgICAgICAgICAgIHRocm93IGU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmICh0aGlzLmlzTmV4dExpbmVJbmRlbnRlZCgpKSB7XG4gICAgICAgIHZhbHVlICs9IFwiXFxuXCIgKyB0aGlzLmdldE5leHRFbWJlZEJsb2NrKCk7XG4gICAgICB9XG4gICAgICByZXR1cm4gSW5saW5lLnBhcnNlKHZhbHVlLCBleGNlcHRpb25PbkludmFsaWRUeXBlLCBvYmplY3REZWNvZGVyKTtcbiAgICB9XG4gIH07XG5cbiAgUGFyc2VyLnByb3RvdHlwZS5wYXJzZUZvbGRlZFNjYWxhciA9IGZ1bmN0aW9uKHNlcGFyYXRvciwgaW5kaWNhdG9yLCBpbmRlbnRhdGlvbikge1xuICAgIHZhciBpc0N1cnJlbnRMaW5lQmxhbmssIGosIGxlbiwgbGluZSwgbWF0Y2hlcywgbmV3VGV4dCwgbm90RU9GLCBwYXR0ZXJuLCByZWYsIHRleHQ7XG4gICAgaWYgKGluZGljYXRvciA9PSBudWxsKSB7XG4gICAgICBpbmRpY2F0b3IgPSAnJztcbiAgICB9XG4gICAgaWYgKGluZGVudGF0aW9uID09IG51bGwpIHtcbiAgICAgIGluZGVudGF0aW9uID0gMDtcbiAgICB9XG4gICAgbm90RU9GID0gdGhpcy5tb3ZlVG9OZXh0TGluZSgpO1xuICAgIGlmICghbm90RU9GKSB7XG4gICAgICByZXR1cm4gJyc7XG4gICAgfVxuICAgIGlzQ3VycmVudExpbmVCbGFuayA9IHRoaXMuaXNDdXJyZW50TGluZUJsYW5rKCk7XG4gICAgdGV4dCA9ICcnO1xuICAgIHdoaWxlIChub3RFT0YgJiYgaXNDdXJyZW50TGluZUJsYW5rKSB7XG4gICAgICBpZiAobm90RU9GID0gdGhpcy5tb3ZlVG9OZXh0TGluZSgpKSB7XG4gICAgICAgIHRleHQgKz0gXCJcXG5cIjtcbiAgICAgICAgaXNDdXJyZW50TGluZUJsYW5rID0gdGhpcy5pc0N1cnJlbnRMaW5lQmxhbmsoKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKDAgPT09IGluZGVudGF0aW9uKSB7XG4gICAgICBpZiAobWF0Y2hlcyA9IHRoaXMuUEFUVEVSTl9JTkRFTlRfU1BBQ0VTLmV4ZWModGhpcy5jdXJyZW50TGluZSkpIHtcbiAgICAgICAgaW5kZW50YXRpb24gPSBtYXRjaGVzWzBdLmxlbmd0aDtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGluZGVudGF0aW9uID4gMCkge1xuICAgICAgcGF0dGVybiA9IHRoaXMuUEFUVEVSTl9GT0xERURfU0NBTEFSX0JZX0lOREVOVEFUSU9OW2luZGVudGF0aW9uXTtcbiAgICAgIGlmIChwYXR0ZXJuID09IG51bGwpIHtcbiAgICAgICAgcGF0dGVybiA9IG5ldyBQYXR0ZXJuKCdeIHsnICsgaW5kZW50YXRpb24gKyAnfSguKikkJyk7XG4gICAgICAgIFBhcnNlci5wcm90b3R5cGUuUEFUVEVSTl9GT0xERURfU0NBTEFSX0JZX0lOREVOVEFUSU9OW2luZGVudGF0aW9uXSA9IHBhdHRlcm47XG4gICAgICB9XG4gICAgICB3aGlsZSAobm90RU9GICYmIChpc0N1cnJlbnRMaW5lQmxhbmsgfHwgKG1hdGNoZXMgPSBwYXR0ZXJuLmV4ZWModGhpcy5jdXJyZW50TGluZSkpKSkge1xuICAgICAgICBpZiAoaXNDdXJyZW50TGluZUJsYW5rKSB7XG4gICAgICAgICAgdGV4dCArPSB0aGlzLmN1cnJlbnRMaW5lLnNsaWNlKGluZGVudGF0aW9uKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0ZXh0ICs9IG1hdGNoZXNbMV07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG5vdEVPRiA9IHRoaXMubW92ZVRvTmV4dExpbmUoKSkge1xuICAgICAgICAgIHRleHQgKz0gXCJcXG5cIjtcbiAgICAgICAgICBpc0N1cnJlbnRMaW5lQmxhbmsgPSB0aGlzLmlzQ3VycmVudExpbmVCbGFuaygpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChub3RFT0YpIHtcbiAgICAgIHRleHQgKz0gXCJcXG5cIjtcbiAgICB9XG4gICAgaWYgKG5vdEVPRikge1xuICAgICAgdGhpcy5tb3ZlVG9QcmV2aW91c0xpbmUoKTtcbiAgICB9XG4gICAgaWYgKCc+JyA9PT0gc2VwYXJhdG9yKSB7XG4gICAgICBuZXdUZXh0ID0gJyc7XG4gICAgICByZWYgPSB0ZXh0LnNwbGl0KFwiXFxuXCIpO1xuICAgICAgZm9yIChqID0gMCwgbGVuID0gcmVmLmxlbmd0aDsgaiA8IGxlbjsgaisrKSB7XG4gICAgICAgIGxpbmUgPSByZWZbal07XG4gICAgICAgIGlmIChsaW5lLmxlbmd0aCA9PT0gMCB8fCBsaW5lLmNoYXJBdCgwKSA9PT0gJyAnKSB7XG4gICAgICAgICAgbmV3VGV4dCA9IFV0aWxzLnJ0cmltKG5ld1RleHQsICcgJykgKyBsaW5lICsgXCJcXG5cIjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBuZXdUZXh0ICs9IGxpbmUgKyAnICc7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRleHQgPSBuZXdUZXh0O1xuICAgIH1cbiAgICBpZiAoJysnICE9PSBpbmRpY2F0b3IpIHtcbiAgICAgIHRleHQgPSBVdGlscy5ydHJpbSh0ZXh0KTtcbiAgICB9XG4gICAgaWYgKCcnID09PSBpbmRpY2F0b3IpIHtcbiAgICAgIHRleHQgPSB0aGlzLlBBVFRFUk5fVFJBSUxJTkdfTElORVMucmVwbGFjZSh0ZXh0LCBcIlxcblwiKTtcbiAgICB9IGVsc2UgaWYgKCctJyA9PT0gaW5kaWNhdG9yKSB7XG4gICAgICB0ZXh0ID0gdGhpcy5QQVRURVJOX1RSQUlMSU5HX0xJTkVTLnJlcGxhY2UodGV4dCwgJycpO1xuICAgIH1cbiAgICByZXR1cm4gdGV4dDtcbiAgfTtcblxuICBQYXJzZXIucHJvdG90eXBlLmlzTmV4dExpbmVJbmRlbnRlZCA9IGZ1bmN0aW9uKGlnbm9yZUNvbW1lbnRzKSB7XG4gICAgdmFyIEVPRiwgY3VycmVudEluZGVudGF0aW9uLCByZXQ7XG4gICAgaWYgKGlnbm9yZUNvbW1lbnRzID09IG51bGwpIHtcbiAgICAgIGlnbm9yZUNvbW1lbnRzID0gdHJ1ZTtcbiAgICB9XG4gICAgY3VycmVudEluZGVudGF0aW9uID0gdGhpcy5nZXRDdXJyZW50TGluZUluZGVudGF0aW9uKCk7XG4gICAgRU9GID0gIXRoaXMubW92ZVRvTmV4dExpbmUoKTtcbiAgICBpZiAoaWdub3JlQ29tbWVudHMpIHtcbiAgICAgIHdoaWxlICghRU9GICYmIHRoaXMuaXNDdXJyZW50TGluZUVtcHR5KCkpIHtcbiAgICAgICAgRU9GID0gIXRoaXMubW92ZVRvTmV4dExpbmUoKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgd2hpbGUgKCFFT0YgJiYgdGhpcy5pc0N1cnJlbnRMaW5lQmxhbmsoKSkge1xuICAgICAgICBFT0YgPSAhdGhpcy5tb3ZlVG9OZXh0TGluZSgpO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoRU9GKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHJldCA9IGZhbHNlO1xuICAgIGlmICh0aGlzLmdldEN1cnJlbnRMaW5lSW5kZW50YXRpb24oKSA+IGN1cnJlbnRJbmRlbnRhdGlvbikge1xuICAgICAgcmV0ID0gdHJ1ZTtcbiAgICB9XG4gICAgdGhpcy5tb3ZlVG9QcmV2aW91c0xpbmUoKTtcbiAgICByZXR1cm4gcmV0O1xuICB9O1xuXG4gIFBhcnNlci5wcm90b3R5cGUuaXNDdXJyZW50TGluZUVtcHR5ID0gZnVuY3Rpb24oKSB7XG4gICAgdmFyIHRyaW1tZWRMaW5lO1xuICAgIHRyaW1tZWRMaW5lID0gVXRpbHMudHJpbSh0aGlzLmN1cnJlbnRMaW5lLCAnICcpO1xuICAgIHJldHVybiB0cmltbWVkTGluZS5sZW5ndGggPT09IDAgfHwgdHJpbW1lZExpbmUuY2hhckF0KDApID09PSAnIyc7XG4gIH07XG5cbiAgUGFyc2VyLnByb3RvdHlwZS5pc0N1cnJlbnRMaW5lQmxhbmsgPSBmdW5jdGlvbigpIHtcbiAgICByZXR1cm4gJycgPT09IFV0aWxzLnRyaW0odGhpcy5jdXJyZW50TGluZSwgJyAnKTtcbiAgfTtcblxuICBQYXJzZXIucHJvdG90eXBlLmlzQ3VycmVudExpbmVDb21tZW50ID0gZnVuY3Rpb24oKSB7XG4gICAgdmFyIGx0cmltbWVkTGluZTtcbiAgICBsdHJpbW1lZExpbmUgPSBVdGlscy5sdHJpbSh0aGlzLmN1cnJlbnRMaW5lLCAnICcpO1xuICAgIHJldHVybiBsdHJpbW1lZExpbmUuY2hhckF0KDApID09PSAnIyc7XG4gIH07XG5cbiAgUGFyc2VyLnByb3RvdHlwZS5jbGVhbnVwID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgICB2YXIgY291bnQsIGksIGluZGVudCwgaiwgbCwgbGVuLCBsZW4xLCBsaW5lLCBsaW5lcywgcmVmLCByZWYxLCByZWYyLCBzbWFsbGVzdEluZGVudCwgdHJpbW1lZFZhbHVlO1xuICAgIGlmICh2YWx1ZS5pbmRleE9mKFwiXFxyXCIpICE9PSAtMSkge1xuICAgICAgdmFsdWUgPSB2YWx1ZS5zcGxpdChcIlxcclxcblwiKS5qb2luKFwiXFxuXCIpLnNwbGl0KFwiXFxyXCIpLmpvaW4oXCJcXG5cIik7XG4gICAgfVxuICAgIGNvdW50ID0gMDtcbiAgICByZWYgPSB0aGlzLlBBVFRFUk5fWUFNTF9IRUFERVIucmVwbGFjZUFsbCh2YWx1ZSwgJycpLCB2YWx1ZSA9IHJlZlswXSwgY291bnQgPSByZWZbMV07XG4gICAgdGhpcy5vZmZzZXQgKz0gY291bnQ7XG4gICAgcmVmMSA9IHRoaXMuUEFUVEVSTl9MRUFESU5HX0NPTU1FTlRTLnJlcGxhY2VBbGwodmFsdWUsICcnLCAxKSwgdHJpbW1lZFZhbHVlID0gcmVmMVswXSwgY291bnQgPSByZWYxWzFdO1xuICAgIGlmIChjb3VudCA9PT0gMSkge1xuICAgICAgdGhpcy5vZmZzZXQgKz0gVXRpbHMuc3ViU3RyQ291bnQodmFsdWUsIFwiXFxuXCIpIC0gVXRpbHMuc3ViU3RyQ291bnQodHJpbW1lZFZhbHVlLCBcIlxcblwiKTtcbiAgICAgIHZhbHVlID0gdHJpbW1lZFZhbHVlO1xuICAgIH1cbiAgICByZWYyID0gdGhpcy5QQVRURVJOX0RPQ1VNRU5UX01BUktFUl9TVEFSVC5yZXBsYWNlQWxsKHZhbHVlLCAnJywgMSksIHRyaW1tZWRWYWx1ZSA9IHJlZjJbMF0sIGNvdW50ID0gcmVmMlsxXTtcbiAgICBpZiAoY291bnQgPT09IDEpIHtcbiAgICAgIHRoaXMub2Zmc2V0ICs9IFV0aWxzLnN1YlN0ckNvdW50KHZhbHVlLCBcIlxcblwiKSAtIFV0aWxzLnN1YlN0ckNvdW50KHRyaW1tZWRWYWx1ZSwgXCJcXG5cIik7XG4gICAgICB2YWx1ZSA9IHRyaW1tZWRWYWx1ZTtcbiAgICAgIHZhbHVlID0gdGhpcy5QQVRURVJOX0RPQ1VNRU5UX01BUktFUl9FTkQucmVwbGFjZSh2YWx1ZSwgJycpO1xuICAgIH1cbiAgICBsaW5lcyA9IHZhbHVlLnNwbGl0KFwiXFxuXCIpO1xuICAgIHNtYWxsZXN0SW5kZW50ID0gLTE7XG4gICAgZm9yIChqID0gMCwgbGVuID0gbGluZXMubGVuZ3RoOyBqIDwgbGVuOyBqKyspIHtcbiAgICAgIGxpbmUgPSBsaW5lc1tqXTtcbiAgICAgIGlmIChVdGlscy50cmltKGxpbmUsICcgJykubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgaW5kZW50ID0gbGluZS5sZW5ndGggLSBVdGlscy5sdHJpbShsaW5lKS5sZW5ndGg7XG4gICAgICBpZiAoc21hbGxlc3RJbmRlbnQgPT09IC0xIHx8IGluZGVudCA8IHNtYWxsZXN0SW5kZW50KSB7XG4gICAgICAgIHNtYWxsZXN0SW5kZW50ID0gaW5kZW50O1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoc21hbGxlc3RJbmRlbnQgPiAwKSB7XG4gICAgICBmb3IgKGkgPSBsID0gMCwgbGVuMSA9IGxpbmVzLmxlbmd0aDsgbCA8IGxlbjE7IGkgPSArK2wpIHtcbiAgICAgICAgbGluZSA9IGxpbmVzW2ldO1xuICAgICAgICBsaW5lc1tpXSA9IGxpbmUuc2xpY2Uoc21hbGxlc3RJbmRlbnQpO1xuICAgICAgfVxuICAgICAgdmFsdWUgPSBsaW5lcy5qb2luKFwiXFxuXCIpO1xuICAgIH1cbiAgICByZXR1cm4gdmFsdWU7XG4gIH07XG5cbiAgUGFyc2VyLnByb3RvdHlwZS5pc05leHRMaW5lVW5JbmRlbnRlZENvbGxlY3Rpb24gPSBmdW5jdGlvbihjdXJyZW50SW5kZW50YXRpb24pIHtcbiAgICB2YXIgbm90RU9GLCByZXQ7XG4gICAgaWYgKGN1cnJlbnRJbmRlbnRhdGlvbiA9PSBudWxsKSB7XG4gICAgICBjdXJyZW50SW5kZW50YXRpb24gPSBudWxsO1xuICAgIH1cbiAgICBpZiAoY3VycmVudEluZGVudGF0aW9uID09IG51bGwpIHtcbiAgICAgIGN1cnJlbnRJbmRlbnRhdGlvbiA9IHRoaXMuZ2V0Q3VycmVudExpbmVJbmRlbnRhdGlvbigpO1xuICAgIH1cbiAgICBub3RFT0YgPSB0aGlzLm1vdmVUb05leHRMaW5lKCk7XG4gICAgd2hpbGUgKG5vdEVPRiAmJiB0aGlzLmlzQ3VycmVudExpbmVFbXB0eSgpKSB7XG4gICAgICBub3RFT0YgPSB0aGlzLm1vdmVUb05leHRMaW5lKCk7XG4gICAgfVxuICAgIGlmIChmYWxzZSA9PT0gbm90RU9GKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHJldCA9IGZhbHNlO1xuICAgIGlmICh0aGlzLmdldEN1cnJlbnRMaW5lSW5kZW50YXRpb24oKSA9PT0gY3VycmVudEluZGVudGF0aW9uICYmIHRoaXMuaXNTdHJpbmdVbkluZGVudGVkQ29sbGVjdGlvbkl0ZW0odGhpcy5jdXJyZW50TGluZSkpIHtcbiAgICAgIHJldCA9IHRydWU7XG4gICAgfVxuICAgIHRoaXMubW92ZVRvUHJldmlvdXNMaW5lKCk7XG4gICAgcmV0dXJuIHJldDtcbiAgfTtcblxuICBQYXJzZXIucHJvdG90eXBlLmlzU3RyaW5nVW5JbmRlbnRlZENvbGxlY3Rpb25JdGVtID0gZnVuY3Rpb24oKSB7XG4gICAgcmV0dXJuIHRoaXMuY3VycmVudExpbmUgPT09ICctJyB8fCB0aGlzLmN1cnJlbnRMaW5lLnNsaWNlKDAsIDIpID09PSAnLSAnO1xuICB9O1xuXG4gIHJldHVybiBQYXJzZXI7XG5cbn0pKCk7XG5cbm1vZHVsZS5leHBvcnRzID0gUGFyc2VyO1xuIiwiLy8gR2VuZXJhdGVkIGJ5IENvZmZlZVNjcmlwdCAxLjEyLjRcbnZhciBQYXR0ZXJuO1xuXG5QYXR0ZXJuID0gKGZ1bmN0aW9uKCkge1xuICBQYXR0ZXJuLnByb3RvdHlwZS5yZWdleCA9IG51bGw7XG5cbiAgUGF0dGVybi5wcm90b3R5cGUucmF3UmVnZXggPSBudWxsO1xuXG4gIFBhdHRlcm4ucHJvdG90eXBlLmNsZWFuZWRSZWdleCA9IG51bGw7XG5cbiAgUGF0dGVybi5wcm90b3R5cGUubWFwcGluZyA9IG51bGw7XG5cbiAgZnVuY3Rpb24gUGF0dGVybihyYXdSZWdleCwgbW9kaWZpZXJzKSB7XG4gICAgdmFyIF9jaGFyLCBjYXB0dXJpbmdCcmFja2V0TnVtYmVyLCBjbGVhbmVkUmVnZXgsIGksIGxlbiwgbWFwcGluZywgbmFtZSwgcGFydCwgc3ViQ2hhcjtcbiAgICBpZiAobW9kaWZpZXJzID09IG51bGwpIHtcbiAgICAgIG1vZGlmaWVycyA9ICcnO1xuICAgIH1cbiAgICBjbGVhbmVkUmVnZXggPSAnJztcbiAgICBsZW4gPSByYXdSZWdleC5sZW5ndGg7XG4gICAgbWFwcGluZyA9IG51bGw7XG4gICAgY2FwdHVyaW5nQnJhY2tldE51bWJlciA9IDA7XG4gICAgaSA9IDA7XG4gICAgd2hpbGUgKGkgPCBsZW4pIHtcbiAgICAgIF9jaGFyID0gcmF3UmVnZXguY2hhckF0KGkpO1xuICAgICAgaWYgKF9jaGFyID09PSAnXFxcXCcpIHtcbiAgICAgICAgY2xlYW5lZFJlZ2V4ICs9IHJhd1JlZ2V4LnNsaWNlKGksICsoaSArIDEpICsgMSB8fCA5ZTkpO1xuICAgICAgICBpKys7XG4gICAgICB9IGVsc2UgaWYgKF9jaGFyID09PSAnKCcpIHtcbiAgICAgICAgaWYgKGkgPCBsZW4gLSAyKSB7XG4gICAgICAgICAgcGFydCA9IHJhd1JlZ2V4LnNsaWNlKGksICsoaSArIDIpICsgMSB8fCA5ZTkpO1xuICAgICAgICAgIGlmIChwYXJ0ID09PSAnKD86Jykge1xuICAgICAgICAgICAgaSArPSAyO1xuICAgICAgICAgICAgY2xlYW5lZFJlZ2V4ICs9IHBhcnQ7XG4gICAgICAgICAgfSBlbHNlIGlmIChwYXJ0ID09PSAnKD88Jykge1xuICAgICAgICAgICAgY2FwdHVyaW5nQnJhY2tldE51bWJlcisrO1xuICAgICAgICAgICAgaSArPSAyO1xuICAgICAgICAgICAgbmFtZSA9ICcnO1xuICAgICAgICAgICAgd2hpbGUgKGkgKyAxIDwgbGVuKSB7XG4gICAgICAgICAgICAgIHN1YkNoYXIgPSByYXdSZWdleC5jaGFyQXQoaSArIDEpO1xuICAgICAgICAgICAgICBpZiAoc3ViQ2hhciA9PT0gJz4nKSB7XG4gICAgICAgICAgICAgICAgY2xlYW5lZFJlZ2V4ICs9ICcoJztcbiAgICAgICAgICAgICAgICBpKys7XG4gICAgICAgICAgICAgICAgaWYgKG5hbWUubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgaWYgKG1hcHBpbmcgPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICBtYXBwaW5nID0ge307XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBtYXBwaW5nW25hbWVdID0gY2FwdHVyaW5nQnJhY2tldE51bWJlcjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgbmFtZSArPSBzdWJDaGFyO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGkrKztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY2xlYW5lZFJlZ2V4ICs9IF9jaGFyO1xuICAgICAgICAgICAgY2FwdHVyaW5nQnJhY2tldE51bWJlcisrO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjbGVhbmVkUmVnZXggKz0gX2NoYXI7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNsZWFuZWRSZWdleCArPSBfY2hhcjtcbiAgICAgIH1cbiAgICAgIGkrKztcbiAgICB9XG4gICAgdGhpcy5yYXdSZWdleCA9IHJhd1JlZ2V4O1xuICAgIHRoaXMuY2xlYW5lZFJlZ2V4ID0gY2xlYW5lZFJlZ2V4O1xuICAgIHRoaXMucmVnZXggPSBuZXcgUmVnRXhwKHRoaXMuY2xlYW5lZFJlZ2V4LCAnZycgKyBtb2RpZmllcnMucmVwbGFjZSgnZycsICcnKSk7XG4gICAgdGhpcy5tYXBwaW5nID0gbWFwcGluZztcbiAgfVxuXG4gIFBhdHRlcm4ucHJvdG90eXBlLmV4ZWMgPSBmdW5jdGlvbihzdHIpIHtcbiAgICB2YXIgaW5kZXgsIG1hdGNoZXMsIG5hbWUsIHJlZjtcbiAgICB0aGlzLnJlZ2V4Lmxhc3RJbmRleCA9IDA7XG4gICAgbWF0Y2hlcyA9IHRoaXMucmVnZXguZXhlYyhzdHIpO1xuICAgIGlmIChtYXRjaGVzID09IG51bGwpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBpZiAodGhpcy5tYXBwaW5nICE9IG51bGwpIHtcbiAgICAgIHJlZiA9IHRoaXMubWFwcGluZztcbiAgICAgIGZvciAobmFtZSBpbiByZWYpIHtcbiAgICAgICAgaW5kZXggPSByZWZbbmFtZV07XG4gICAgICAgIG1hdGNoZXNbbmFtZV0gPSBtYXRjaGVzW2luZGV4XTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG1hdGNoZXM7XG4gIH07XG5cbiAgUGF0dGVybi5wcm90b3R5cGUudGVzdCA9IGZ1bmN0aW9uKHN0cikge1xuICAgIHRoaXMucmVnZXgubGFzdEluZGV4ID0gMDtcbiAgICByZXR1cm4gdGhpcy5yZWdleC50ZXN0KHN0cik7XG4gIH07XG5cbiAgUGF0dGVybi5wcm90b3R5cGUucmVwbGFjZSA9IGZ1bmN0aW9uKHN0ciwgcmVwbGFjZW1lbnQpIHtcbiAgICB0aGlzLnJlZ2V4Lmxhc3RJbmRleCA9IDA7XG4gICAgcmV0dXJuIHN0ci5yZXBsYWNlKHRoaXMucmVnZXgsIHJlcGxhY2VtZW50KTtcbiAgfTtcblxuICBQYXR0ZXJuLnByb3RvdHlwZS5yZXBsYWNlQWxsID0gZnVuY3Rpb24oc3RyLCByZXBsYWNlbWVudCwgbGltaXQpIHtcbiAgICB2YXIgY291bnQ7XG4gICAgaWYgKGxpbWl0ID09IG51bGwpIHtcbiAgICAgIGxpbWl0ID0gMDtcbiAgICB9XG4gICAgdGhpcy5yZWdleC5sYXN0SW5kZXggPSAwO1xuICAgIGNvdW50ID0gMDtcbiAgICB3aGlsZSAodGhpcy5yZWdleC50ZXN0KHN0cikgJiYgKGxpbWl0ID09PSAwIHx8IGNvdW50IDwgbGltaXQpKSB7XG4gICAgICB0aGlzLnJlZ2V4Lmxhc3RJbmRleCA9IDA7XG4gICAgICBzdHIgPSBzdHIucmVwbGFjZSh0aGlzLnJlZ2V4LCByZXBsYWNlbWVudCk7XG4gICAgICBjb3VudCsrO1xuICAgIH1cbiAgICByZXR1cm4gW3N0ciwgY291bnRdO1xuICB9O1xuXG4gIHJldHVybiBQYXR0ZXJuO1xuXG59KSgpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IFBhdHRlcm47XG4iLCIvLyBHZW5lcmF0ZWQgYnkgQ29mZmVlU2NyaXB0IDEuMTIuNFxudmFyIFBhdHRlcm4sIFVuZXNjYXBlciwgVXRpbHM7XG5cblV0aWxzID0gcmVxdWlyZSgnLi9VdGlscycpO1xuXG5QYXR0ZXJuID0gcmVxdWlyZSgnLi9QYXR0ZXJuJyk7XG5cblVuZXNjYXBlciA9IChmdW5jdGlvbigpIHtcbiAgZnVuY3Rpb24gVW5lc2NhcGVyKCkge31cblxuICBVbmVzY2FwZXIuUEFUVEVSTl9FU0NBUEVEX0NIQVJBQ1RFUiA9IG5ldyBQYXR0ZXJuKCdcXFxcXFxcXChbMGFidFxcdG52ZnJlIFwiXFxcXC9cXFxcXFxcXE5fTFBdfHhbMC05YS1mQS1GXXsyfXx1WzAtOWEtZkEtRl17NH18VVswLTlhLWZBLUZdezh9KScpO1xuXG4gIFVuZXNjYXBlci51bmVzY2FwZVNpbmdsZVF1b3RlZFN0cmluZyA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gICAgcmV0dXJuIHZhbHVlLnJlcGxhY2UoL1xcJ1xcJy9nLCAnXFwnJyk7XG4gIH07XG5cbiAgVW5lc2NhcGVyLnVuZXNjYXBlRG91YmxlUXVvdGVkU3RyaW5nID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgICBpZiAodGhpcy5fdW5lc2NhcGVDYWxsYmFjayA9PSBudWxsKSB7XG4gICAgICB0aGlzLl91bmVzY2FwZUNhbGxiYWNrID0gKGZ1bmN0aW9uKF90aGlzKSB7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbihzdHIpIHtcbiAgICAgICAgICByZXR1cm4gX3RoaXMudW5lc2NhcGVDaGFyYWN0ZXIoc3RyKTtcbiAgICAgICAgfTtcbiAgICAgIH0pKHRoaXMpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5QQVRURVJOX0VTQ0FQRURfQ0hBUkFDVEVSLnJlcGxhY2UodmFsdWUsIHRoaXMuX3VuZXNjYXBlQ2FsbGJhY2spO1xuICB9O1xuXG4gIFVuZXNjYXBlci51bmVzY2FwZUNoYXJhY3RlciA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gICAgdmFyIGNoO1xuICAgIGNoID0gU3RyaW5nLmZyb21DaGFyQ29kZTtcbiAgICBzd2l0Y2ggKHZhbHVlLmNoYXJBdCgxKSkge1xuICAgICAgY2FzZSAnMCc6XG4gICAgICAgIHJldHVybiBjaCgwKTtcbiAgICAgIGNhc2UgJ2EnOlxuICAgICAgICByZXR1cm4gY2goNyk7XG4gICAgICBjYXNlICdiJzpcbiAgICAgICAgcmV0dXJuIGNoKDgpO1xuICAgICAgY2FzZSAndCc6XG4gICAgICAgIHJldHVybiBcIlxcdFwiO1xuICAgICAgY2FzZSBcIlxcdFwiOlxuICAgICAgICByZXR1cm4gXCJcXHRcIjtcbiAgICAgIGNhc2UgJ24nOlxuICAgICAgICByZXR1cm4gXCJcXG5cIjtcbiAgICAgIGNhc2UgJ3YnOlxuICAgICAgICByZXR1cm4gY2goMTEpO1xuICAgICAgY2FzZSAnZic6XG4gICAgICAgIHJldHVybiBjaCgxMik7XG4gICAgICBjYXNlICdyJzpcbiAgICAgICAgcmV0dXJuIGNoKDEzKTtcbiAgICAgIGNhc2UgJ2UnOlxuICAgICAgICByZXR1cm4gY2goMjcpO1xuICAgICAgY2FzZSAnICc6XG4gICAgICAgIHJldHVybiAnICc7XG4gICAgICBjYXNlICdcIic6XG4gICAgICAgIHJldHVybiAnXCInO1xuICAgICAgY2FzZSAnLyc6XG4gICAgICAgIHJldHVybiAnLyc7XG4gICAgICBjYXNlICdcXFxcJzpcbiAgICAgICAgcmV0dXJuICdcXFxcJztcbiAgICAgIGNhc2UgJ04nOlxuICAgICAgICByZXR1cm4gY2goMHgwMDg1KTtcbiAgICAgIGNhc2UgJ18nOlxuICAgICAgICByZXR1cm4gY2goMHgwMEEwKTtcbiAgICAgIGNhc2UgJ0wnOlxuICAgICAgICByZXR1cm4gY2goMHgyMDI4KTtcbiAgICAgIGNhc2UgJ1AnOlxuICAgICAgICByZXR1cm4gY2goMHgyMDI5KTtcbiAgICAgIGNhc2UgJ3gnOlxuICAgICAgICByZXR1cm4gVXRpbHMudXRmOGNocihVdGlscy5oZXhEZWModmFsdWUuc3Vic3RyKDIsIDIpKSk7XG4gICAgICBjYXNlICd1JzpcbiAgICAgICAgcmV0dXJuIFV0aWxzLnV0ZjhjaHIoVXRpbHMuaGV4RGVjKHZhbHVlLnN1YnN0cigyLCA0KSkpO1xuICAgICAgY2FzZSAnVSc6XG4gICAgICAgIHJldHVybiBVdGlscy51dGY4Y2hyKFV0aWxzLmhleERlYyh2YWx1ZS5zdWJzdHIoMiwgOCkpKTtcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHJldHVybiAnJztcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIFVuZXNjYXBlcjtcblxufSkoKTtcblxubW9kdWxlLmV4cG9ydHMgPSBVbmVzY2FwZXI7XG4iLCIvLyBHZW5lcmF0ZWQgYnkgQ29mZmVlU2NyaXB0IDEuMTIuNFxudmFyIFBhdHRlcm4sIFV0aWxzLFxuICBoYXNQcm9wID0ge30uaGFzT3duUHJvcGVydHk7XG5cblBhdHRlcm4gPSByZXF1aXJlKCcuL1BhdHRlcm4nKTtcblxuVXRpbHMgPSAoZnVuY3Rpb24oKSB7XG4gIGZ1bmN0aW9uIFV0aWxzKCkge31cblxuICBVdGlscy5SRUdFWF9MRUZUX1RSSU1fQllfQ0hBUiA9IHt9O1xuXG4gIFV0aWxzLlJFR0VYX1JJR0hUX1RSSU1fQllfQ0hBUiA9IHt9O1xuXG4gIFV0aWxzLlJFR0VYX1NQQUNFUyA9IC9cXHMrL2c7XG5cbiAgVXRpbHMuUkVHRVhfRElHSVRTID0gL15cXGQrJC87XG5cbiAgVXRpbHMuUkVHRVhfT0NUQUwgPSAvW14wLTddL2dpO1xuXG4gIFV0aWxzLlJFR0VYX0hFWEFERUNJTUFMID0gL1teYS1mMC05XS9naTtcblxuICBVdGlscy5QQVRURVJOX0RBVEUgPSBuZXcgUGF0dGVybignXicgKyAnKD88eWVhcj5bMC05XVswLTldWzAtOV1bMC05XSknICsgJy0oPzxtb250aD5bMC05XVswLTldPyknICsgJy0oPzxkYXk+WzAtOV1bMC05XT8pJyArICcoPzooPzpbVHRdfFsgXFx0XSspJyArICcoPzxob3VyPlswLTldWzAtOV0/KScgKyAnOig/PG1pbnV0ZT5bMC05XVswLTldKScgKyAnOig/PHNlY29uZD5bMC05XVswLTldKScgKyAnKD86XFwuKD88ZnJhY3Rpb24+WzAtOV0qKSk/JyArICcoPzpbIFxcdF0qKD88dHo+WnwoPzx0el9zaWduPlstK10pKD88dHpfaG91cj5bMC05XVswLTldPyknICsgJyg/OjooPzx0el9taW51dGU+WzAtOV1bMC05XSkpPykpPyk/JyArICckJywgJ2knKTtcblxuICBVdGlscy5MT0NBTF9USU1FWk9ORV9PRkZTRVQgPSBuZXcgRGF0ZSgpLmdldFRpbWV6b25lT2Zmc2V0KCkgKiA2MCAqIDEwMDA7XG5cbiAgVXRpbHMudHJpbSA9IGZ1bmN0aW9uKHN0ciwgX2NoYXIpIHtcbiAgICB2YXIgcmVnZXhMZWZ0LCByZWdleFJpZ2h0O1xuICAgIGlmIChfY2hhciA9PSBudWxsKSB7XG4gICAgICBfY2hhciA9ICdcXFxccyc7XG4gICAgfVxuICAgIHJlZ2V4TGVmdCA9IHRoaXMuUkVHRVhfTEVGVF9UUklNX0JZX0NIQVJbX2NoYXJdO1xuICAgIGlmIChyZWdleExlZnQgPT0gbnVsbCkge1xuICAgICAgdGhpcy5SRUdFWF9MRUZUX1RSSU1fQllfQ0hBUltfY2hhcl0gPSByZWdleExlZnQgPSBuZXcgUmVnRXhwKCdeJyArIF9jaGFyICsgJycgKyBfY2hhciArICcqJyk7XG4gICAgfVxuICAgIHJlZ2V4TGVmdC5sYXN0SW5kZXggPSAwO1xuICAgIHJlZ2V4UmlnaHQgPSB0aGlzLlJFR0VYX1JJR0hUX1RSSU1fQllfQ0hBUltfY2hhcl07XG4gICAgaWYgKHJlZ2V4UmlnaHQgPT0gbnVsbCkge1xuICAgICAgdGhpcy5SRUdFWF9SSUdIVF9UUklNX0JZX0NIQVJbX2NoYXJdID0gcmVnZXhSaWdodCA9IG5ldyBSZWdFeHAoX2NoYXIgKyAnJyArIF9jaGFyICsgJyokJyk7XG4gICAgfVxuICAgIHJlZ2V4UmlnaHQubGFzdEluZGV4ID0gMDtcbiAgICByZXR1cm4gc3RyLnJlcGxhY2UocmVnZXhMZWZ0LCAnJykucmVwbGFjZShyZWdleFJpZ2h0LCAnJyk7XG4gIH07XG5cbiAgVXRpbHMubHRyaW0gPSBmdW5jdGlvbihzdHIsIF9jaGFyKSB7XG4gICAgdmFyIHJlZ2V4TGVmdDtcbiAgICBpZiAoX2NoYXIgPT0gbnVsbCkge1xuICAgICAgX2NoYXIgPSAnXFxcXHMnO1xuICAgIH1cbiAgICByZWdleExlZnQgPSB0aGlzLlJFR0VYX0xFRlRfVFJJTV9CWV9DSEFSW19jaGFyXTtcbiAgICBpZiAocmVnZXhMZWZ0ID09IG51bGwpIHtcbiAgICAgIHRoaXMuUkVHRVhfTEVGVF9UUklNX0JZX0NIQVJbX2NoYXJdID0gcmVnZXhMZWZ0ID0gbmV3IFJlZ0V4cCgnXicgKyBfY2hhciArICcnICsgX2NoYXIgKyAnKicpO1xuICAgIH1cbiAgICByZWdleExlZnQubGFzdEluZGV4ID0gMDtcbiAgICByZXR1cm4gc3RyLnJlcGxhY2UocmVnZXhMZWZ0LCAnJyk7XG4gIH07XG5cbiAgVXRpbHMucnRyaW0gPSBmdW5jdGlvbihzdHIsIF9jaGFyKSB7XG4gICAgdmFyIHJlZ2V4UmlnaHQ7XG4gICAgaWYgKF9jaGFyID09IG51bGwpIHtcbiAgICAgIF9jaGFyID0gJ1xcXFxzJztcbiAgICB9XG4gICAgcmVnZXhSaWdodCA9IHRoaXMuUkVHRVhfUklHSFRfVFJJTV9CWV9DSEFSW19jaGFyXTtcbiAgICBpZiAocmVnZXhSaWdodCA9PSBudWxsKSB7XG4gICAgICB0aGlzLlJFR0VYX1JJR0hUX1RSSU1fQllfQ0hBUltfY2hhcl0gPSByZWdleFJpZ2h0ID0gbmV3IFJlZ0V4cChfY2hhciArICcnICsgX2NoYXIgKyAnKiQnKTtcbiAgICB9XG4gICAgcmVnZXhSaWdodC5sYXN0SW5kZXggPSAwO1xuICAgIHJldHVybiBzdHIucmVwbGFjZShyZWdleFJpZ2h0LCAnJyk7XG4gIH07XG5cbiAgVXRpbHMuaXNFbXB0eSA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gICAgcmV0dXJuICF2YWx1ZSB8fCB2YWx1ZSA9PT0gJycgfHwgdmFsdWUgPT09ICcwJyB8fCAodmFsdWUgaW5zdGFuY2VvZiBBcnJheSAmJiB2YWx1ZS5sZW5ndGggPT09IDApIHx8IHRoaXMuaXNFbXB0eU9iamVjdCh2YWx1ZSk7XG4gIH07XG5cbiAgVXRpbHMuaXNFbXB0eU9iamVjdCA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gICAgdmFyIGs7XG4gICAgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgT2JqZWN0ICYmICgoZnVuY3Rpb24oKSB7XG4gICAgICB2YXIgcmVzdWx0cztcbiAgICAgIHJlc3VsdHMgPSBbXTtcbiAgICAgIGZvciAoayBpbiB2YWx1ZSkge1xuICAgICAgICBpZiAoIWhhc1Byb3AuY2FsbCh2YWx1ZSwgaykpIGNvbnRpbnVlO1xuICAgICAgICByZXN1bHRzLnB1c2goayk7XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzdWx0cztcbiAgICB9KSgpKS5sZW5ndGggPT09IDA7XG4gIH07XG5cbiAgVXRpbHMuc3ViU3RyQ291bnQgPSBmdW5jdGlvbihzdHJpbmcsIHN1YlN0cmluZywgc3RhcnQsIGxlbmd0aCkge1xuICAgIHZhciBjLCBpLCBqLCBsZW4sIHJlZiwgc3VibGVuO1xuICAgIGMgPSAwO1xuICAgIHN0cmluZyA9ICcnICsgc3RyaW5nO1xuICAgIHN1YlN0cmluZyA9ICcnICsgc3ViU3RyaW5nO1xuICAgIGlmIChzdGFydCAhPSBudWxsKSB7XG4gICAgICBzdHJpbmcgPSBzdHJpbmcuc2xpY2Uoc3RhcnQpO1xuICAgIH1cbiAgICBpZiAobGVuZ3RoICE9IG51bGwpIHtcbiAgICAgIHN0cmluZyA9IHN0cmluZy5zbGljZSgwLCBsZW5ndGgpO1xuICAgIH1cbiAgICBsZW4gPSBzdHJpbmcubGVuZ3RoO1xuICAgIHN1YmxlbiA9IHN1YlN0cmluZy5sZW5ndGg7XG4gICAgZm9yIChpID0gaiA9IDAsIHJlZiA9IGxlbjsgMCA8PSByZWYgPyBqIDwgcmVmIDogaiA+IHJlZjsgaSA9IDAgPD0gcmVmID8gKytqIDogLS1qKSB7XG4gICAgICBpZiAoc3ViU3RyaW5nID09PSBzdHJpbmcuc2xpY2UoaSwgc3VibGVuKSkge1xuICAgICAgICBjKys7XG4gICAgICAgIGkgKz0gc3VibGVuIC0gMTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGM7XG4gIH07XG5cbiAgVXRpbHMuaXNEaWdpdHMgPSBmdW5jdGlvbihpbnB1dCkge1xuICAgIHRoaXMuUkVHRVhfRElHSVRTLmxhc3RJbmRleCA9IDA7XG4gICAgcmV0dXJuIHRoaXMuUkVHRVhfRElHSVRTLnRlc3QoaW5wdXQpO1xuICB9O1xuXG4gIFV0aWxzLm9jdERlYyA9IGZ1bmN0aW9uKGlucHV0KSB7XG4gICAgdGhpcy5SRUdFWF9PQ1RBTC5sYXN0SW5kZXggPSAwO1xuICAgIHJldHVybiBwYXJzZUludCgoaW5wdXQgKyAnJykucmVwbGFjZSh0aGlzLlJFR0VYX09DVEFMLCAnJyksIDgpO1xuICB9O1xuXG4gIFV0aWxzLmhleERlYyA9IGZ1bmN0aW9uKGlucHV0KSB7XG4gICAgdGhpcy5SRUdFWF9IRVhBREVDSU1BTC5sYXN0SW5kZXggPSAwO1xuICAgIGlucHV0ID0gdGhpcy50cmltKGlucHV0KTtcbiAgICBpZiAoKGlucHV0ICsgJycpLnNsaWNlKDAsIDIpID09PSAnMHgnKSB7XG4gICAgICBpbnB1dCA9IChpbnB1dCArICcnKS5zbGljZSgyKTtcbiAgICB9XG4gICAgcmV0dXJuIHBhcnNlSW50KChpbnB1dCArICcnKS5yZXBsYWNlKHRoaXMuUkVHRVhfSEVYQURFQ0lNQUwsICcnKSwgMTYpO1xuICB9O1xuXG4gIFV0aWxzLnV0ZjhjaHIgPSBmdW5jdGlvbihjKSB7XG4gICAgdmFyIGNoO1xuICAgIGNoID0gU3RyaW5nLmZyb21DaGFyQ29kZTtcbiAgICBpZiAoMHg4MCA+IChjICU9IDB4MjAwMDAwKSkge1xuICAgICAgcmV0dXJuIGNoKGMpO1xuICAgIH1cbiAgICBpZiAoMHg4MDAgPiBjKSB7XG4gICAgICByZXR1cm4gY2goMHhDMCB8IGMgPj4gNikgKyBjaCgweDgwIHwgYyAmIDB4M0YpO1xuICAgIH1cbiAgICBpZiAoMHgxMDAwMCA+IGMpIHtcbiAgICAgIHJldHVybiBjaCgweEUwIHwgYyA+PiAxMikgKyBjaCgweDgwIHwgYyA+PiA2ICYgMHgzRikgKyBjaCgweDgwIHwgYyAmIDB4M0YpO1xuICAgIH1cbiAgICByZXR1cm4gY2goMHhGMCB8IGMgPj4gMTgpICsgY2goMHg4MCB8IGMgPj4gMTIgJiAweDNGKSArIGNoKDB4ODAgfCBjID4+IDYgJiAweDNGKSArIGNoKDB4ODAgfCBjICYgMHgzRik7XG4gIH07XG5cbiAgVXRpbHMucGFyc2VCb29sZWFuID0gZnVuY3Rpb24oaW5wdXQsIHN0cmljdCkge1xuICAgIHZhciBsb3dlcklucHV0O1xuICAgIGlmIChzdHJpY3QgPT0gbnVsbCkge1xuICAgICAgc3RyaWN0ID0gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiBpbnB1dCA9PT0gJ3N0cmluZycpIHtcbiAgICAgIGxvd2VySW5wdXQgPSBpbnB1dC50b0xvd2VyQ2FzZSgpO1xuICAgICAgaWYgKCFzdHJpY3QpIHtcbiAgICAgICAgaWYgKGxvd2VySW5wdXQgPT09ICdubycpIHtcbiAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChsb3dlcklucHV0ID09PSAnMCcpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgaWYgKGxvd2VySW5wdXQgPT09ICdmYWxzZScpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgaWYgKGxvd2VySW5wdXQgPT09ICcnKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gISFpbnB1dDtcbiAgfTtcblxuICBVdGlscy5pc051bWVyaWMgPSBmdW5jdGlvbihpbnB1dCkge1xuICAgIHRoaXMuUkVHRVhfU1BBQ0VTLmxhc3RJbmRleCA9IDA7XG4gICAgcmV0dXJuIHR5cGVvZiBpbnB1dCA9PT0gJ251bWJlcicgfHwgdHlwZW9mIGlucHV0ID09PSAnc3RyaW5nJyAmJiAhaXNOYU4oaW5wdXQpICYmIGlucHV0LnJlcGxhY2UodGhpcy5SRUdFWF9TUEFDRVMsICcnKSAhPT0gJyc7XG4gIH07XG5cbiAgVXRpbHMuc3RyaW5nVG9EYXRlID0gZnVuY3Rpb24oc3RyKSB7XG4gICAgdmFyIGRhdGUsIGRheSwgZnJhY3Rpb24sIGhvdXIsIGluZm8sIG1pbnV0ZSwgbW9udGgsIHNlY29uZCwgdHpfaG91ciwgdHpfbWludXRlLCB0el9vZmZzZXQsIHllYXI7XG4gICAgaWYgKCEoc3RyICE9IG51bGwgPyBzdHIubGVuZ3RoIDogdm9pZCAwKSkge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGluZm8gPSB0aGlzLlBBVFRFUk5fREFURS5leGVjKHN0cik7XG4gICAgaWYgKCFpbmZvKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgeWVhciA9IHBhcnNlSW50KGluZm8ueWVhciwgMTApO1xuICAgIG1vbnRoID0gcGFyc2VJbnQoaW5mby5tb250aCwgMTApIC0gMTtcbiAgICBkYXkgPSBwYXJzZUludChpbmZvLmRheSwgMTApO1xuICAgIGlmIChpbmZvLmhvdXIgPT0gbnVsbCkge1xuICAgICAgZGF0ZSA9IG5ldyBEYXRlKERhdGUuVVRDKHllYXIsIG1vbnRoLCBkYXkpKTtcbiAgICAgIHJldHVybiBkYXRlO1xuICAgIH1cbiAgICBob3VyID0gcGFyc2VJbnQoaW5mby5ob3VyLCAxMCk7XG4gICAgbWludXRlID0gcGFyc2VJbnQoaW5mby5taW51dGUsIDEwKTtcbiAgICBzZWNvbmQgPSBwYXJzZUludChpbmZvLnNlY29uZCwgMTApO1xuICAgIGlmIChpbmZvLmZyYWN0aW9uICE9IG51bGwpIHtcbiAgICAgIGZyYWN0aW9uID0gaW5mby5mcmFjdGlvbi5zbGljZSgwLCAzKTtcbiAgICAgIHdoaWxlIChmcmFjdGlvbi5sZW5ndGggPCAzKSB7XG4gICAgICAgIGZyYWN0aW9uICs9ICcwJztcbiAgICAgIH1cbiAgICAgIGZyYWN0aW9uID0gcGFyc2VJbnQoZnJhY3Rpb24sIDEwKTtcbiAgICB9IGVsc2Uge1xuICAgICAgZnJhY3Rpb24gPSAwO1xuICAgIH1cbiAgICBpZiAoaW5mby50eiAhPSBudWxsKSB7XG4gICAgICB0el9ob3VyID0gcGFyc2VJbnQoaW5mby50el9ob3VyLCAxMCk7XG4gICAgICBpZiAoaW5mby50el9taW51dGUgIT0gbnVsbCkge1xuICAgICAgICB0el9taW51dGUgPSBwYXJzZUludChpbmZvLnR6X21pbnV0ZSwgMTApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdHpfbWludXRlID0gMDtcbiAgICAgIH1cbiAgICAgIHR6X29mZnNldCA9ICh0el9ob3VyICogNjAgKyB0el9taW51dGUpICogNjAwMDA7XG4gICAgICBpZiAoJy0nID09PSBpbmZvLnR6X3NpZ24pIHtcbiAgICAgICAgdHpfb2Zmc2V0ICo9IC0xO1xuICAgICAgfVxuICAgIH1cbiAgICBkYXRlID0gbmV3IERhdGUoRGF0ZS5VVEMoeWVhciwgbW9udGgsIGRheSwgaG91ciwgbWludXRlLCBzZWNvbmQsIGZyYWN0aW9uKSk7XG4gICAgaWYgKHR6X29mZnNldCkge1xuICAgICAgZGF0ZS5zZXRUaW1lKGRhdGUuZ2V0VGltZSgpIC0gdHpfb2Zmc2V0KTtcbiAgICB9XG4gICAgcmV0dXJuIGRhdGU7XG4gIH07XG5cbiAgVXRpbHMuc3RyUmVwZWF0ID0gZnVuY3Rpb24oc3RyLCBudW1iZXIpIHtcbiAgICB2YXIgaSwgcmVzO1xuICAgIHJlcyA9ICcnO1xuICAgIGkgPSAwO1xuICAgIHdoaWxlIChpIDwgbnVtYmVyKSB7XG4gICAgICByZXMgKz0gc3RyO1xuICAgICAgaSsrO1xuICAgIH1cbiAgICByZXR1cm4gcmVzO1xuICB9O1xuXG4gIFV0aWxzLmdldFN0cmluZ0Zyb21GaWxlID0gZnVuY3Rpb24ocGF0aCwgY2FsbGJhY2spIHtcbiAgICB2YXIgZGF0YSwgZnMsIGosIGxlbjEsIG5hbWUsIHJlZiwgcmVxLCB4aHI7XG4gICAgaWYgKGNhbGxiYWNrID09IG51bGwpIHtcbiAgICAgIGNhbGxiYWNrID0gbnVsbDtcbiAgICB9XG4gICAgeGhyID0gbnVsbDtcbiAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiAmJiB3aW5kb3cgIT09IG51bGwpIHtcbiAgICAgIGlmICh3aW5kb3cuWE1MSHR0cFJlcXVlc3QpIHtcbiAgICAgICAgeGhyID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG4gICAgICB9IGVsc2UgaWYgKHdpbmRvdy5BY3RpdmVYT2JqZWN0KSB7XG4gICAgICAgIHJlZiA9IFtcIk1zeG1sMi5YTUxIVFRQLjYuMFwiLCBcIk1zeG1sMi5YTUxIVFRQLjMuMFwiLCBcIk1zeG1sMi5YTUxIVFRQXCIsIFwiTWljcm9zb2Z0LlhNTEhUVFBcIl07XG4gICAgICAgIGZvciAoaiA9IDAsIGxlbjEgPSByZWYubGVuZ3RoOyBqIDwgbGVuMTsgaisrKSB7XG4gICAgICAgICAgbmFtZSA9IHJlZltqXTtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgeGhyID0gbmV3IEFjdGl2ZVhPYmplY3QobmFtZSk7XG4gICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHt9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHhociAhPSBudWxsKSB7XG4gICAgICBpZiAoY2FsbGJhY2sgIT0gbnVsbCkge1xuICAgICAgICB4aHIub25yZWFkeXN0YXRlY2hhbmdlID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgaWYgKHhoci5yZWFkeVN0YXRlID09PSA0KSB7XG4gICAgICAgICAgICBpZiAoeGhyLnN0YXR1cyA9PT0gMjAwIHx8IHhoci5zdGF0dXMgPT09IDApIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGNhbGxiYWNrKHhoci5yZXNwb25zZVRleHQpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGNhbGxiYWNrKG51bGwpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgeGhyLm9wZW4oJ0dFVCcsIHBhdGgsIHRydWUpO1xuICAgICAgICByZXR1cm4geGhyLnNlbmQobnVsbCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB4aHIub3BlbignR0VUJywgcGF0aCwgZmFsc2UpO1xuICAgICAgICB4aHIuc2VuZChudWxsKTtcbiAgICAgICAgaWYgKHhoci5zdGF0dXMgPT09IDIwMCB8fCB4aHIuc3RhdHVzID09PSAwKSB7XG4gICAgICAgICAgcmV0dXJuIHhoci5yZXNwb25zZVRleHQ7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHJlcSA9IHJlcXVpcmU7XG4gICAgICBmcyA9IHJlcSgnZnMnKTtcbiAgICAgIGlmIChjYWxsYmFjayAhPSBudWxsKSB7XG4gICAgICAgIHJldHVybiBmcy5yZWFkRmlsZShwYXRoLCBmdW5jdGlvbihlcnIsIGRhdGEpIHtcbiAgICAgICAgICBpZiAoZXJyKSB7XG4gICAgICAgICAgICByZXR1cm4gY2FsbGJhY2sobnVsbCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiBjYWxsYmFjayhTdHJpbmcoZGF0YSkpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBkYXRhID0gZnMucmVhZEZpbGVTeW5jKHBhdGgpO1xuICAgICAgICBpZiAoZGF0YSAhPSBudWxsKSB7XG4gICAgICAgICAgcmV0dXJuIFN0cmluZyhkYXRhKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH1cbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIFV0aWxzO1xuXG59KSgpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IFV0aWxzO1xuIiwiLy8gR2VuZXJhdGVkIGJ5IENvZmZlZVNjcmlwdCAxLjEyLjRcbnZhciBEdW1wZXIsIFBhcnNlciwgVXRpbHMsIFlhbWw7XG5cblBhcnNlciA9IHJlcXVpcmUoJy4vUGFyc2VyJyk7XG5cbkR1bXBlciA9IHJlcXVpcmUoJy4vRHVtcGVyJyk7XG5cblV0aWxzID0gcmVxdWlyZSgnLi9VdGlscycpO1xuXG5ZYW1sID0gKGZ1bmN0aW9uKCkge1xuICBmdW5jdGlvbiBZYW1sKCkge31cblxuICBZYW1sLnBhcnNlID0gZnVuY3Rpb24oaW5wdXQsIGV4Y2VwdGlvbk9uSW52YWxpZFR5cGUsIG9iamVjdERlY29kZXIpIHtcbiAgICBpZiAoZXhjZXB0aW9uT25JbnZhbGlkVHlwZSA9PSBudWxsKSB7XG4gICAgICBleGNlcHRpb25PbkludmFsaWRUeXBlID0gZmFsc2U7XG4gICAgfVxuICAgIGlmIChvYmplY3REZWNvZGVyID09IG51bGwpIHtcbiAgICAgIG9iamVjdERlY29kZXIgPSBudWxsO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IFBhcnNlcigpLnBhcnNlKGlucHV0LCBleGNlcHRpb25PbkludmFsaWRUeXBlLCBvYmplY3REZWNvZGVyKTtcbiAgfTtcblxuICBZYW1sLnBhcnNlRmlsZSA9IGZ1bmN0aW9uKHBhdGgsIGNhbGxiYWNrLCBleGNlcHRpb25PbkludmFsaWRUeXBlLCBvYmplY3REZWNvZGVyKSB7XG4gICAgdmFyIGlucHV0O1xuICAgIGlmIChjYWxsYmFjayA9PSBudWxsKSB7XG4gICAgICBjYWxsYmFjayA9IG51bGw7XG4gICAgfVxuICAgIGlmIChleGNlcHRpb25PbkludmFsaWRUeXBlID09IG51bGwpIHtcbiAgICAgIGV4Y2VwdGlvbk9uSW52YWxpZFR5cGUgPSBmYWxzZTtcbiAgICB9XG4gICAgaWYgKG9iamVjdERlY29kZXIgPT0gbnVsbCkge1xuICAgICAgb2JqZWN0RGVjb2RlciA9IG51bGw7XG4gICAgfVxuICAgIGlmIChjYWxsYmFjayAhPSBudWxsKSB7XG4gICAgICByZXR1cm4gVXRpbHMuZ2V0U3RyaW5nRnJvbUZpbGUocGF0aCwgKGZ1bmN0aW9uKF90aGlzKSB7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbihpbnB1dCkge1xuICAgICAgICAgIHZhciByZXN1bHQ7XG4gICAgICAgICAgcmVzdWx0ID0gbnVsbDtcbiAgICAgICAgICBpZiAoaW5wdXQgIT0gbnVsbCkge1xuICAgICAgICAgICAgcmVzdWx0ID0gX3RoaXMucGFyc2UoaW5wdXQsIGV4Y2VwdGlvbk9uSW52YWxpZFR5cGUsIG9iamVjdERlY29kZXIpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjYWxsYmFjayhyZXN1bHQpO1xuICAgICAgICB9O1xuICAgICAgfSkodGhpcykpO1xuICAgIH0gZWxzZSB7XG4gICAgICBpbnB1dCA9IFV0aWxzLmdldFN0cmluZ0Zyb21GaWxlKHBhdGgpO1xuICAgICAgaWYgKGlucHV0ICE9IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucGFyc2UoaW5wdXQsIGV4Y2VwdGlvbk9uSW52YWxpZFR5cGUsIG9iamVjdERlY29kZXIpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICB9O1xuXG4gIFlhbWwuZHVtcCA9IGZ1bmN0aW9uKGlucHV0LCBpbmxpbmUsIGluZGVudCwgZXhjZXB0aW9uT25JbnZhbGlkVHlwZSwgb2JqZWN0RW5jb2Rlcikge1xuICAgIHZhciB5YW1sO1xuICAgIGlmIChpbmxpbmUgPT0gbnVsbCkge1xuICAgICAgaW5saW5lID0gMjtcbiAgICB9XG4gICAgaWYgKGluZGVudCA9PSBudWxsKSB7XG4gICAgICBpbmRlbnQgPSA0O1xuICAgIH1cbiAgICBpZiAoZXhjZXB0aW9uT25JbnZhbGlkVHlwZSA9PSBudWxsKSB7XG4gICAgICBleGNlcHRpb25PbkludmFsaWRUeXBlID0gZmFsc2U7XG4gICAgfVxuICAgIGlmIChvYmplY3RFbmNvZGVyID09IG51bGwpIHtcbiAgICAgIG9iamVjdEVuY29kZXIgPSBudWxsO1xuICAgIH1cbiAgICB5YW1sID0gbmV3IER1bXBlcigpO1xuICAgIHlhbWwuaW5kZW50YXRpb24gPSBpbmRlbnQ7XG4gICAgcmV0dXJuIHlhbWwuZHVtcChpbnB1dCwgaW5saW5lLCAwLCBleGNlcHRpb25PbkludmFsaWRUeXBlLCBvYmplY3RFbmNvZGVyKTtcbiAgfTtcblxuICBZYW1sLnN0cmluZ2lmeSA9IGZ1bmN0aW9uKGlucHV0LCBpbmxpbmUsIGluZGVudCwgZXhjZXB0aW9uT25JbnZhbGlkVHlwZSwgb2JqZWN0RW5jb2Rlcikge1xuICAgIHJldHVybiB0aGlzLmR1bXAoaW5wdXQsIGlubGluZSwgaW5kZW50LCBleGNlcHRpb25PbkludmFsaWRUeXBlLCBvYmplY3RFbmNvZGVyKTtcbiAgfTtcblxuICBZYW1sLmxvYWQgPSBmdW5jdGlvbihwYXRoLCBjYWxsYmFjaywgZXhjZXB0aW9uT25JbnZhbGlkVHlwZSwgb2JqZWN0RGVjb2Rlcikge1xuICAgIHJldHVybiB0aGlzLnBhcnNlRmlsZShwYXRoLCBjYWxsYmFjaywgZXhjZXB0aW9uT25JbnZhbGlkVHlwZSwgb2JqZWN0RGVjb2Rlcik7XG4gIH07XG5cbiAgcmV0dXJuIFlhbWw7XG5cbn0pKCk7XG5cbmlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiICYmIHdpbmRvdyAhPT0gbnVsbCkge1xuICB3aW5kb3cuWUFNTCA9IFlhbWw7XG59XG5cbmlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiIHx8IHdpbmRvdyA9PT0gbnVsbCkge1xuICB0aGlzLllBTUwgPSBZYW1sO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IFlhbWw7XG4iLCJmdW5jdGlvbiBiYXNlMTBfdG9fYmFzZTY0KG51bSkge1xuICB2YXIgb3JkZXIgPSAnMDEyMzQ1Njc4OWFiY2RlZmdoaWprbG1ub3BxcnN0dXZ3eHl6QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVpfLSc7XG4gIHZhciBiYXNlID0gb3JkZXIubGVuZ3RoO1xuICB2YXIgc3RyID0gJycsIHI7XG4gIHdoaWxlIChudW0pIHtcbiAgICAgIHIgPSBudW0gJSBiYXNlXG4gICAgICBudW0gLT0gcjtcbiAgICAgIG51bSAvPSBiYXNlO1xuICAgICAgc3RyID0gb3JkZXIuY2hhckF0KHIpICsgc3RyO1xuICB9XG4gIHJldHVybiBzdHI7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGJhc2UxMF90b19iYXNlNjQ7IiwiLy8gaHR0cHM6Ly9naXRodWIuY29tL3VzZXJwaXhlbC9taWNyb211c3RhY2hlL2Jsb2IvbWFzdGVyL2xpYi9yZW5kZXIuanNcblxuLyoqXG4gKiBAY2FsbGJhY2sgUmVzb2x2ZXJGblxuICogQHBhcmFtIHtzdHJpbmd9IHZhck5hbWUgLSB2YXJpYWJsZSBuYW1lIGJlZm9yZSBiZWluZyBwYXJzZWQuXG4gKiAgICAgICAgRm9yIGV4YW1wbGU6IHthLmIuY30gLT4gICdhLmIuYycsIHsgIHggIH0gLT4gJ3gnXG4gKiBAcGFyYW0ge09iamVjdH0gdmlldyAtIHRoZSB2aWV3IG9iamVjdCB0aGF0IHdhcyBwYXNzZWQgdG8gLnJlbmRlcigpIGZ1bmN0aW9uXG4gKiBAcmV0dXJucyB7c3RyaW5nfG51bWJlcnxib29sZWFufE9iamVjdHx1bmRlZmluZWR9IHRoZSB2YWx1ZSB0byBiZVxuICogICAgICAgIGludGVycG9sYXRlZC4gSWYgdGhlIGZ1bmN0aW9uIHJldHVybnMgdW5kZWZpbmVkLCB0aGUgdmFsdWUgcmVzb2x1dGlvblxuICogICAgICAgIGFsZ29yaXRobSB3aWxsIGdvIGFoZWFkIHdpdGggdGhlIGRlZmF1bHQgYmVoYXZpb3VyIChyZXNvbHZpbmcgdGhlXG4gKiAgICAgICAgdmFyaWFibGUgbmFtZSBmcm9tIHRoZSBwcm92aWRlZCBvYmplY3QpLlxuICovXG5cbmNvbnN0IFZBUl9NQVRDSF9SRUdFWCA9IC9cXHtcXHtcXHMqKC4qPylcXHMqXFx9XFx9L2c7XG5cbmZ1bmN0aW9uIF92YWx1ZVRvU3RyaW5nICh2YWx1ZSkge1xuICBzd2l0Y2ggKHR5cGVvZiB2YWx1ZSkge1xuICBjYXNlICdzdHJpbmcnOlxuICBjYXNlICdudW1iZXInOlxuICBjYXNlICdib29sZWFuJzpcbiAgICByZXR1cm4gdmFsdWU7XG4gIGNhc2UgJ29iamVjdCc6XG4gICAgdHJ5IHtcbiAgICAgIC8vIG51bGwgaXMgYW4gb2JqZWN0IGJ1dCBpcyBmYWxzeS4gU3dhbGxvdyBpdC5cbiAgICAgIHJldHVybiB2YWx1ZSA9PT0gbnVsbCA/ICcnIDogSlNPTi5zdHJpbmdpZnkodmFsdWUpO1xuICAgIH0gY2F0Y2ggKGpzb25FcnJvcikge1xuICAgICAgcmV0dXJuICd7Li4ufSc7XG4gICAgfVxuICBkZWZhdWx0OlxuICAgICAvLyBBbnl0aGluZyBlbHNlIHdpbGwgYmUgcmVwbGFjZWQgd2l0aCBhbiBlbXB0eSBzdHJpbmdcbiAgICAgLy8gRm9yIGV4YW1wbGU6IHVuZGVmaW5lZCwgU3ltYm9sLCBldGMuXG4gICAgcmV0dXJuICcnO1xuICB9XG59XG5cbi8qKlxuICogUmVjdXJzaXZlbHkgZ29lcyB0aHJvdWdoIGFuIG9iamVjdCB0cnlpbmcgdG8gcmVzb2x2ZSBhIHBhdGguXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IHNjb3BlIC0gVGhlIG9iamVjdCB0byB0cmF2ZXJzZSAoaW4gZWFjaCByZWN1cnNpdmUgY2FsbCB3ZSBkaWcgaW50byB0aGlzIG9iamVjdClcbiAqIEBwYXJhbSB7c3RyaW5nW119IHBhdGggLSBBbiBhcnJheSBvZiBwcm9wZXJ0eSBuYW1lcyB0byB0cmF2ZXJzZSBvbmUtYnktb25lXG4gKiBAcGFyYW0ge251bWJlcn0gW3BhdGhJbmRleD0wXSAtIFRoZSBjdXJyZW50IGluZGV4IGluIHRoZSBwYXRoIGFycmF5XG4gKi9cbmZ1bmN0aW9uIF9yZWN1cnNpdmVQYXRoUmVzb2x2ZXIoc2NvcGUsIHBhdGgsIHBhdGhJbmRleCA9IDApIHtcbiAgaWYgKHR5cGVvZiBzY29wZSAhPT0gJ29iamVjdCcgfHwgc2NvcGUgPT09IG51bGwgfHwgc2NvcGUgPT09IHVuZGVmaW5lZCkge1xuICAgIHJldHVybiAnJztcbiAgfVxuXG4gIGNvbnN0IHZhck5hbWUgPSBwYXRoW3BhdGhJbmRleF07XG4gIGNvbnN0IHZhbHVlID0gc2NvcGVbdmFyTmFtZV07XG5cbiAgaWYgKHBhdGhJbmRleCA9PT0gcGF0aC5sZW5ndGggLSAxKSB7XG4gICAgLy8gSXQncyBhIGxlYWYsIHJldHVybiB3aGF0ZXZlciBpdCBpc1xuICAgIHJldHVybiB2YWx1ZTtcbiAgfVxuXG4gIHJldHVybiBfcmVjdXJzaXZlUGF0aFJlc29sdmVyKHZhbHVlLCBwYXRoLCArK3BhdGhJbmRleCk7XG59XG5cbmZ1bmN0aW9uIGRlZmF1bHRSZXNvbHZlcih2YXJOYW1lLCB2aWV3KSB7XG4gIHJldHVybiBfcmVjdXJzaXZlUGF0aFJlc29sdmVyKHZpZXcsIHZhck5hbWUuc3BsaXQoJy4nKSk7XG59XG5cbi8qKlxuICogUmVwbGFjZXMgZXZlcnkge3t2YXJpYWJsZX19IGluc2lkZSB0aGUgdGVtcGxhdGUgd2l0aCB2YWx1ZXMgcHJvdmlkZWQgYnkgdmlldy5cbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gdGVtcGxhdGUgLSBUaGUgdGVtcGxhdGUgY29udGFpbmluZyBvbmUgb3IgbW9yZSB7e3ZhcmlhYmxlTmFtZXN9fSBldmVyeSB2YXJpYWJsZVxuICogICAgICAgIG5hbWVzIHRoYXQgaXMgdXNlZCBpbiB0aGUgdGVtcGxhdGUuIElmIGl0J3Mgb21pdHRlZCwgaXQnbGwgYmUgYXNzdW1lZCBhbiBlbXB0eSBvYmplY3QuXG4gKiBAcGFyYW0ge09iamVjdH0gW3ZpZXc9e31dIC0gQW4gb2JqZWN0IGNvbnRhaW5pbmcgdmFsdWVzIGZvciBldmVyeSB2YXJpYWJsZSBuYW1lcyB0aGF0IGlzIHVzZWQgaW5cbiAqICAgICAgICB0aGUgdGVtcGxhdGUuIElmIGl0J3Mgb21pdHRlZCwgaXQnbGwgYmUgc2V0IHRvIGFuIGVtcHR5IG9iamVjdCBlc3NlbnRpYWxseSByZW1vdmluZyBhbGxcbiAqICAgICAgICB7e3Zhck5hbWV9fXMgaW4gdGhlIHRlbXBsYXRlLlxuICogQHBhcmFtIHtSZXNvbHZlckZufSBbcmVzb2x2ZXJdIC0gQW4gb3B0aW9uYWwgZnVuY3Rpb24gdGhhdCB3aWxsIGJlXG4gKiAgICAgICAgY2FsbGVkIGZvciBldmVyeSB7e3Zhck5hbWV9fSB0byBnZW5lcmF0ZSBhIHZhbHVlLiBJZiB0aGUgcmVzb2x2ZXIgdGhyb3dzIGFuIGVycm9yXG4gKiAgICAgICAgd2UnbGwgcHJvY2VlZCB3aXRoIHRoZSBkZWZhdWx0IHZhbHVlIHJlc29sdXRpb24gYWxnb3JpdGhtIChmaW5kIHRoZSB2YWx1ZSBmcm9tIHRoZSB2aWV3XG4gKiAgICAgICAgb2JqZWN0KS5cbiAqIEByZXR1cm5zIHtzdHJpbmd9IC0gVGVtcGxhdGUgd2hlcmUgaXRzIHZhcmlhYmxlIG5hbWVzIHJlcGxhY2VkIHdpdGhcbiAqICAgICAgICBjb3JyZXNwb25kaW5nIHZhbHVlcy4gSWYgYSB2YWx1ZSBpcyBub3QgZm91bmQgb3IgaXMgaW52YWxpZCwgaXQgd2lsbFxuICogICAgICAgIGJlIGFzc3VtZWQgZW1wdHkgc3RyaW5nICcnLiBJZiB0aGUgdmFsdWUgaXMgYW4gb2JqZWN0IGl0c2VsZiwgaXQnbGxcbiAqICAgICAgICBiZSBzdHJpbmdpZmllZCBieSBKU09OLlxuICogICAgICAgIEluIGNhc2Ugb2YgYSBKU09OIHN0cmluZ2lmeSBlcnJvciB0aGUgcmVzdWx0IHdpbGwgbG9vayBsaWtlIFwiey4uLn1cIi5cbiAqL1xuZnVuY3Rpb24gcmVuZGVyICh0ZW1wbGF0ZSwgdmlldyA9IHt9LCByZXNvbHZlciA9IGRlZmF1bHRSZXNvbHZlcikge1xuICAvLyBkb24ndCB0b3VjaCB0aGUgdGVtcGxhdGUgaWYgaXQgaXMgbm90IGEgc3RyaW5nXG4gIGlmICh0eXBlb2YgdGVtcGxhdGUgIT09ICdzdHJpbmcnKSB7XG4gICAgcmV0dXJuIHRlbXBsYXRlO1xuICB9XG5cbiAgcmV0dXJuIHRlbXBsYXRlLnJlcGxhY2UoVkFSX01BVENIX1JFR0VYLCBmdW5jdGlvbiAobWF0Y2gsIHZhck5hbWUpIHtcbiAgICB0cnkge1xuICAgICAgLy8gZGVmYXVsdFJlc29sdmVyIG5ldmVyIHRocm93c1xuICAgICAgcmV0dXJuIF92YWx1ZVRvU3RyaW5nKHJlc29sdmVyKHZhck5hbWUsIHZpZXcpKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAvLyBpZiB5b3VyIHJlc29sdmVyIHRocm93cywgd2UgcHJvY2VlZCB3aXRoIHRoZSBkZWZhdWx0IHJlc29sdmVyXG4gICAgICByZXR1cm4gX3ZhbHVlVG9TdHJpbmcoZGVmYXVsdFJlc29sdmVyKHZhck5hbWUsIHZpZXcpKTtcbiAgICB9XG4gIH0pO1xufVxuXG5leHBvcnQgZGVmYXVsdCByZW5kZXI7IiwiLyoqXG4gKiBDcmVhdGVkIGJ5IFRhbWVyIG9uIDE5LzEwLzIwMTcuXG4gKi9cblxuaW1wb3J0IEFjdGlvbnMgZnJvbSAnLi9BY3Rpb25zJ1xuaW1wb3J0IExpc3QgZnJvbSAnLi9MaXN0J1xuXG5TdGFnZS5kZWZpbmVXaWRnZXQoe1xuICBpZDogJ3Zpc3VhbC1pbnB1dCcsXG4gIG5hbWU6ICdWaXN1YWxpemF0aW9uIERlcGxveW1lbnQgQ3JlYXRpb24gSW5wdXQnLFxuICBkZXNjcmlwdGlvbjogJ1Zpc3VhbGl6YXRpb24gRGVwbG95bWVudCBDcmVhdGlvbiBJbnB1dCBXaWRnZXQnLFxuICBpbml0aWFsV2lkdGg6IDEyLFxuICBpbml0aWFsSGVpZ2h0OiAxNixcbiAgY29sb3I6ICdwdXJwbGUnLFxuICBoYXNTdHlsZTogdHJ1ZSxcbiAgaXNSZWFjdDogdHJ1ZSxcblxuICBwZXJtaXNzaW9uOiBTdGFnZS5HZW5lcmljQ29uZmlnLkNVU1RPTV9XSURHRVRfUEVSTUlTU0lPTlMuQ1VTVE9NX0FMTCxcbiAgY2F0ZWdvcmllczogW1N0YWdlLkdlbmVyaWNDb25maWcuQ0FURUdPUlkuU1lTVEVNX1JFU09VUkNFU10sXG5cbiAgaW5pdGlhbENvbmZpZ3VyYXRpb246IFtcbiAgICB7IGlkOiAnYmx1ZXByaW50SWQnLCBuYW1lOiAnQmx1ZXByaW50IElkJywgZGVmYXVsdDogJ3JlcXVlc3QnLCB0eXBlOiBTdGFnZS5CYXNpYy5HZW5lcmljRmllbGQuU1RSSU5HIH0sXG4gICAgeyBpZDogJ2FsbG93TmFtZUVkaXQnLCBuYW1lOiAnQWxsb3cgVXNlciB0byBjaGFuZ2UgRGVwbG95bWVudCBOYW1lJywgZGVmYXVsdDogdHJ1ZSwgdHlwZTogU3RhZ2UuQmFzaWMuR2VuZXJpY0ZpZWxkLkJPT0xFQU5fVFlQRSB9LFxuXG4gICAgeyBpZDogJ29uRmluaXNoUmVkaXJlY3QnLCBuYW1lOiAnUmVkaXJlY3QgdG8gUGFnZSBvbiBmaW5pc2gnLCBkZWZhdWx0OiBmYWxzZSwgdHlwZTogU3RhZ2UuQmFzaWMuR2VuZXJpY0ZpZWxkLkJPT0xFQU5fVFlQRSB9LFxuICAgIHsgaWQ6ICd0ZW1wbGF0ZScsIG5hbWU6ICdUZW1wbGF0ZSB0byBSZWRpcmVjdCB0bywgYWZ0ZXIgZmluaXNoJywgZGVmYXVsdDogJ2RlcGxveW1lbnQnLCB0eXBlOiBTdGFnZS5CYXNpYy5HZW5lcmljRmllbGQuU1RSSU5HX1RZUEUgfVxuICBdLFxuXG4gIGZldGNoRGF0YSh3aWRnZXQsIHRvb2xib3gsIHBhcmFtcykge1xuICAgIGxldCBhY3Rpb25zID0gbmV3IEFjdGlvbnMoT2JqZWN0LmFzc2lnbih7IHRvb2xib3ggfSwgd2lkZ2V0LmNvbmZpZ3VyYXRpb24pKTtcblxuICAgIHJldHVybiBhY3Rpb25zLmRvR2V0SW5wdXREZXNjcmlwdG9yKCk7XG4gIH0sXG5cbiAgcmVuZGVyOiBmdW5jdGlvbiAod2lkZ2V0LCBkYXRhLCBlcnJvciwgdG9vbGJveCkge1xuXG4gICAgaWYgKF8uaXNFbXB0eShkYXRhKSkge1xuICAgICAgcmV0dXJuIDxTdGFnZS5CYXNpYy5Mb2FkaW5nIC8+O1xuICAgIH1cblxuICAgIGxldCBhY3Rpb25zID0gbmV3IEFjdGlvbnMoT2JqZWN0LmFzc2lnbih7IHRvb2xib3ggfSwgd2lkZ2V0LmNvbmZpZ3VyYXRpb24pKTtcblxuXG4gICAgcmV0dXJuIChcbiAgICAgIDxMaXN0XG4gICAgICAgIHdpZGdldD17d2lkZ2V0fVxuICAgICAgICBkYXRhPXtkYXRhfVxuICAgICAgICB0b29sYm94PXt0b29sYm94fVxuICAgICAgICBhY3Rpb25zPXthY3Rpb25zfVxuICAgICAgICAvPlxuICAgICk7XG4gIH1cbn0pOyJdfQ==
